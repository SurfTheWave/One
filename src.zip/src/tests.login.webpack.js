import 'angular';
import 'angular-mocks';
import 'babel-polyfill';
// import 'coffee-namespace';
// import 'localstorage-store';
// import 'ydn';
// import 'salesforce';

// require all modules ending in ".spec.js" from the
// current directory and all subdirectories
let context = require.context('./apps/login', true, /\.spec\.js$/);
context.keys().forEach(context);
