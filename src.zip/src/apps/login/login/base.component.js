import template from './base.tpl.html';
import BaseController from './base.controller.js';

let baseLogin = {
	template: template,
	controller: BaseController,
	
	//this component is the parent of the 2 following components below. Depending on the path, we will go
	//either to one, or the other. NOTE that the path is relative to the path of the parent, meaning that 
	// "/resetpassword"" is added AFTER the base path (which is /login).
	$routeConfig: [{
		path: '/',
		
		//the name of the route for this particular component which can be referenced by e.g. a link, or through
		//another route
		name: 'Login',  
		
		//this is the component name for Angular (this name is referenced in angular.component('myName', ...) )
		component: 'login',
		useAsDefault: true
	}, {
		path: '/resetpassword',
		name: 'ResetPassword',
		component: 'resetPassword'
	}],
	
	//like in login/login.component.js. Have a look there to see what it does.
	/*@ngInject*/
	$canActivate: function($nextInstruction, $prevInstruction, $log) {
		
		$log.log('$canActivate in baseLogin?? will return true to allow the activation', arguments);
		return true;
	}
};

export default baseLogin;