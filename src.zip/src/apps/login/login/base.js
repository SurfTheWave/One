import './base.sass';
import baseLogin from './base.component.js';
import resetPassword from './reset-password/reset-password.component.js';
import login from './login/login.component.js';
import 'youOne/services/modal-dialog/modal-dialog';

//we have just one module for the login, which consists of the BaseApp, the Login page (username/password) and
// the reset password page (only username). We add the 3 components to the app.login module.
angular.module('app.login', ['modal-dialog'])
	.component('baseLogin', baseLogin)
	.component('resetPassword', resetPassword)
	.component('login', login);
