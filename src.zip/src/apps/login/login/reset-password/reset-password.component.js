import template from './reset-password.tpl.html';
import ResetPasswordController from './reset-password.controller.js';

let resetPassword = {
	template,
	controller: ResetPasswordController
};

export default resetPassword;