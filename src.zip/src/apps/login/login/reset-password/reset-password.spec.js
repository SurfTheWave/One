import '../base.js';

describe('Component: reset-password', function() {
	var component, scope, $componentController;
	beforeEach(angular.mock.module('app.login'));

	beforeEach(angular.mock.inject(function($rootScope, _$componentController_) {
		scope = $rootScope.$new();
		$componentController = _$componentController_;
	}));

	it('is supposed to reset the Salesforce password (but will fail because we are not executing in a VF context)', function() {
		component = $componentController(
			'resetPassword', 
			{$scope: scope});

		try {
			component.forgotPassword();
		} catch(e) {
			//dummy testing because we cannot test the js remote sfdc functions...
			expect(e.message).toBe('TQAppController is not defined');
		}
	});
});