export default class ResetPasswordController {
	constructor(modalDialog, $log) {
		'ngInject'
		this.modalDialog = modalDialog;
		this.$log = $log;
		this.isProcessing = false;
		
	}
	
	//called for resetting the password. 
	forgotPassword() {
		this.isProcessing = true;
		try {
			TQAppController.forgotPassword(
				this.username||'',
				(result, event) => {
					let msg;
					if(event.status && result) {
						msg = 'Your password has been reset';
					} else {
						//we have a login error
						msg = 'Unknown user or error';
					}
					this.modalDialog('alert', 'ok', msg).finally(() => {
						this.isProcessing = false;
					});
				}, 
				{escape:false}
			);
		} catch(e) {
			this.isProcessing = false;
			throw e;
		}
	}
}