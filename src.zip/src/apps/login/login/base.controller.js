export default class BaseController {
	constructor() {
	}
}