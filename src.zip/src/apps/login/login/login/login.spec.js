import '../base.js';

describe('Component: login', function() {
	var component, scope, $rootScope, $componentController;
	beforeEach(angular.mock.module('app.login'));

	beforeEach(angular.mock.inject(function(_$rootScope_, _$componentController_) {
		$rootScope = _$rootScope_;
		scope = $rootScope.$new();
		$componentController = _$componentController_;
	}));

	it('is supposed to log in Salesforce (but will fail because we are not executing in a VF context)', function() {
		component = $componentController(
			'login', {
				$scope: scope
			});

		try {
			component.login();
		} catch (e) {
			//dummy testing because we cannot test the js remote sfdc functions...
			expect(e.message).toBe('TQAppController is not defined');
		}
	});
});