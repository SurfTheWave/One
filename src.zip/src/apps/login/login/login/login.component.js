import './login.sass';
import template from './login.tpl.html';
import LoginController from './login.controller.js';

let login = {
	template: template,
	controller: LoginController
};

export default login;