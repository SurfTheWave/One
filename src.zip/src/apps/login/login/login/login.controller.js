export default class LoginController {
	constructor($window, modalDialog, $log) {
		'ngInject'
		this.$window = $window;
		this.modalDialog = modalDialog;
		this.$log = $log;
		this.loginData = {
			username: null,
			password: null
		};
		this.isProcessing = false;
	}

	//our login function to Salesforce, which sends the credentials to a RemoteAction in an ApexController
	//(works only when executing the code in a VF page)
	login() {
		this.isProcessing = true;
		try {
			TQAppController.login(
				this.loginData.username||'',
				this.loginData.password||'',
				'/',
				(result, event) => {
					if (event.status && result.indexOf('https://') > -1) {
						this.$window.location.href = result;
					} else {
						//we have a login error
						this.modalDialog('alert', 'ok', result).finally(() => {
							this.isProcessing = false;
						});
					}
				}, {
					escape: false
				}
			);
		} catch(e) {
			this.isProcessing = false;
			throw e;
		}
	}
}