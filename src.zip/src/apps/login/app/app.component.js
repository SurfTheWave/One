import './app.sass';
import template from './app.tpl.html';
import AppController from './app.controller.js';

let app = {
	//the template of the component
	template: template,

	//the controller of the component 
	controller: AppController,

	//these are the list of sub components
	$routeConfig: [{
		//the path of this router. the 3 dots tells angular that it should try to match the route to subcomponents.
		//In this case, it will go to the baseLogin component and search matching routes there.
		path: '/login/...',
		
		//the name of the route for this particular component which can be referenced by e.g. a link, or through
		//another route
		name: 'BaseLogin',
		
		//the route maps to the baseLogin component.
		component: 'baseLogin',
		
		//the default route
		useAsDefault: true
	}, {
		//if route not found, redirected through a wildcard to the BaseLogin component
		path: '/*otherwise',
		redirectTo: ['BaseLogin']
	}]
};

export default app;