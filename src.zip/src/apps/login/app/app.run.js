/*@ngInject*/
export default function run(store) {
	store.start().then((values) => {
		console.log('store values', values);
	});
}