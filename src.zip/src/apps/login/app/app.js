
/**
 * @ngdoc overview
 * @name login
 * @requires ngComponentRouter 
 * @requires app.login
 *
 * @description
 * Entry point for loading the application
 */

import angular from 'angular';

// Base app config
import './app.sass';
import run from './app.run.js';
import app from './app.component.js';
import 'youOne/services/store/store.js';

// Import components
import footer from '../../../you-one/components/footer/footer.component.js';

// Login
import '../login/base.js';

function config($locationProvider){
	'ngInject';
	$locationProvider.html5Mode(true);
}

export default angular.module('app', [

	'puma.store',
	//ngComponentRouter is the name of the new angular router. it must be added in the root module like here
	'ngComponentRouter',
	'tq.coreapi',
	
	// App modules. We reference the app.login, see the "login" folder.

	'app.login'
])
.config(config)
.run(run)

// We tell the router what is the base/root component (see below)
.value('$routerRootComponent', 'app') 

// Define base component. This is this component that we register in $routerRootComponent
.component('app', app)

// Define footer component
.component('footer', footer);