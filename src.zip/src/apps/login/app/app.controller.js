/*@ngInject*/
export default function AppController($log) {
	//dummy controller for the base component.
	$log.debug('app.controller');
}