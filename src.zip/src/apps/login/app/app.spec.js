import 'router';
import './app.js';

describe('Component: app', function() {
	var $rootScope, $compile, $location, $rootRouter;
	beforeEach(angular.mock.module('app'));

	beforeEach(angular.mock.inject(function(_$rootScope_, _$compile_, _$location_, _$rootRouter_) {
		$rootScope = _$rootScope_;
		$compile = _$compile_;
		$location = _$location_;
		$rootRouter = _$rootRouter_;
	}));

	it('is supposed to go on the login page', function() {
		$compile('<div><app></app</div>')($rootScope);
		$location.path('/');
		$rootScope.$digest();
		expect($location.path()).toBe('/login');
	});
	
	it('is supposed to redirect to the forgot password page', function() {
		$compile('<div><app></app</div>')($rootScope);
		$rootRouter.navigateByUrl('/login/resetpassword');
		$rootScope.$digest();
		expect($location.path()).toBe('/login/resetpassword');
	});
});