/**
 * @ngdoc controller
 * @name hello.controller:HelloCtrl
 * @requires tqCoreConnector
 * @description
 * Produce an amazing Hello World.
 *
 *
 * @example
<example module="hello">
<file name="index.html">
<div ng-controller="HelloCtrl">
	<input type="text" ng-model="helloWorld">
	<pre>{{helloWorld}}</pre>
</div>
</file>
<file name="script.js">
angular.module('hello', []).controller("HelloCtrl", function($scope){
	$scope.helloWorld = 'hello world';
});
</file>
</example>
 */
import template from './hello.tpl.html';
define([
	'angular',
	'coreapi',
	'uiRouter'
], function (angular) {


	// best practice, namespace your modules
	return angular.module('hello', [
			'ui.router',
            'tq.coreapi'
		])
		.config(function ($stateProvider) {

			$stateProvider.state('hello', {
				url: '/hello',
				cache: true,
				template: template,
				controller: 'HelloCtrl'
			});
		})

		.controller('HelloCtrl', HelloCtrl);

		function HelloCtrl(
			$scope, tqCoreConnector) {
            // tqCoreConnector.storage.find({
            //     objectApiName: 'User',
            //     where: {
            //         Id : tqCoreConnector.user.getId()
            //     }
            // }).then(function(result){
            //     $scope.user = result[0];
            // });
            $scope.helloWorld = 'hello world';
		}
});
