import './hello';

describe('HelloCtrl', function() {
  	beforeEach(angular.mock.module('hello'));

  	var $controller;

  	beforeEach(inject(function(_$controller_){
    	// The injector unwraps the underscores (_) from around the parameter names when matching
    	$controller = _$controller_;
  	}));

  	describe('$scope.user', function() {
    	it('is just supposed to be a very simple hello world!', function() {
      		var $scope = {};
      		var controller = $controller('HelloCtrl', { $scope: $scope });
      		expect($scope.helloWorld).toEqual('hello world');
    	});
  	});
});
