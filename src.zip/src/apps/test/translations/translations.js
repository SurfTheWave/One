/**
 * @ngdoc object
 * @name test.translations.object:test_TRANSLATION_FILES
 * @requires $translateProvide
 * @requires ACN_NG_TRANSLATION_FILES
 * @requires YOU_ONE_TRANSLATION_FILES
 *
 * @description
 * Module used for doing translations and setting some defaults values ...
 *
 *
 */

 define([
	'angular',
	'angularTranslate',
	'angularTranslateLoaderStaticFiles',
	'youOne/translations/translations',
	'components/translations/translations'

], function (angular) {
	'use strict';

	return angular.module('test.translations', [
		'yo.translations',
		'tq.translations',
		'pascalprecht.translate'

	])
		.constant('test_TRANSLATION_FILES', [
			window.getSfdcStaticResourcePathSafe().concat('src/apps/test/translations/dictionary.en')
		])

		.config(function ($translateProvider, ACN_NG_TRANSLATION_FILES, YOU_ONE_TRANSLATION_FILES, test_TRANSLATION_FILES) {

			var currentBrandName = window.themeId;
			var translationFileName = 'test.'.concat(currentBrandName).concat('.en');
			var translationFilePrefix = 'src/apps/test/themes/'.concat(currentBrandName).concat('/translations/');

			var currentBrandsTranslationFiles = [
				window.getSfdcStaticResourcePathSafe().concat(translationFilePrefix).concat(translationFileName)
			];

			var languageStack = [];
			languageStack = languageStack.concat(ACN_NG_TRANSLATION_FILES);
			languageStack = languageStack.concat(YOU_ONE_TRANSLATION_FILES);
			languageStack = languageStack.concat(MTS_TRANSLATION_FILES);
			languageStack = languageStack.concat(currentBrandsTranslationFiles);

			var topLevelLanguageInStack = languageStack.pop();
			$translateProvider.fallbackLanguage(languageStack); // all the lower level translations in the stack
			$translateProvider.preferredLanguage(topLevelLanguageInStack); // current app/brand
		});
});
