define([
	'angular',
	'uiRouter',
	'components/redirector/redirector'], function (angular) {

	return angular.module('client.routes', [
		'ui.router',
		'tq.redirector'])

		.config(function ClientConfig($stateProvider, $urlRouterProvider) {
			// Here you can define the new one states
		})

		.run(function (tqRedirector, $location) {



			// Example1
			// In this function you will overwrite existing defined states according to the new rules
			// tqRedirector.state takes the same parameters like the $stateProvider
			// Each parameter could be:
			// 1) Object/string, then original data will be replaced with the new one
			// 2) Function, in this case method will get url parameters and replace original parameter with result of
			// function, if function returns null or undefined, then the original value will remain unchanged

//            tqRedirector.state('tqdetails', {
//                controller: function(params) {
//                    return (params.objectapiname == 'Contact') ? 'ClientGuestDetailsCtrl' : 'TqDetailsCtrl';
//                },
//                templateUrl: function(params) {
//                    return (params.objectapiname == 'Contact') ? 'client/guestdetails/guestdetails.tpl.html' : 'acn-one/acn-ng/details/details.tpl.html';
//                },
//                data: { pageTitle: 'Guest Details' }
//            });


//            // Example2
//            tqRedirector.addRuleMethod(function(state, stateParams){
//                if(state.name === 'tqobjects'){
//                    $location.path('/tqrecords/Account');
//                }
//            });

			// // Example 3: TestPage redirect
			// tqRedirector.state('tqrecords', {
			//     controller: function(params) {
			//         return 'TestPageCtrl';
			//     },
			//     templateUrl: function(params) {
			//         return 'client/testpage/testpage.tpl.html';
			//     },
			//     data: { pageTitle: 'Records' }
			// });
		});
});