/**
 * @ngdoc overview
 * @name app
 *
 * @description
 * Module used for bootstrapping the puma angular application. AppCtrl sets some variable on the window.
 *
 *
 */
 import template from 'app/index.tpl.html';

 define([
	'angular',
	'ionic',
	'coreapi',
    'app/config',
	'acnNg/app',
    'acnNg/appdemo',
	'youOne/app',

	//app modules files
	'app/hello/hello'

], function (angular, ionic) {

	// because we're not using AMD properly!
	return angular.module('app', [
		'ionic',
		'acnone',
        'acnone.demo',
		'youone',
		'ngTouch',
		'tq.coreapi',
		'tq.bootstrap',

		//app modules
		'hello'
	])
		.config(function (tqBootstrapProvider) {

		})

		.run(function run($rootScope, $ionicScrollDelegate, $timeout, tqLoading, $ionicSideMenuDelegate) {

            // defines the index.tpl.html specific to the app, to be embedded in the you-one tpl
        //    $rootScope.rootTemplate = template;

            var ionicLoadingShown = false;

            $rootScope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams){
                //Display automatically ionicLoading if loading state has resolve blocks
                if ((!!toState.resolve || (toState.data && toState.data.showLoading)) && !event.defaultPrevented) {
                    tqLoading.show();
                    ionicLoadingShown = true;
                }
            });

            $rootScope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState, fromParams) {
                //Hide automatically displayed ionicLoading popup
                if (ionicLoadingShown){
                    tqLoading.hide();
                    ionicLoadingShown = false;
                }

                $rootScope.state = {
                    name: toState.name,
                    data: toState.data,
                    params: toParams
                };

                if ($ionicSideMenuDelegate.isOpenRight()){
                    $ionicSideMenuDelegate.toggleRight();
                }
            });

            $rootScope.$on('$stateChangeError', function (event, toState, toParams, fromState, fromParams) {
                //Hide automatically displayed ionicLoading popup
                if (ionicLoadingShown){
                    tqLoading.hide();
                    ionicLoadingShown = false;
                }

                console.log('State change error!');
                console.log(arguments);
            });
		})

		.controller('AppCtrl', function ($scope, tqCoreConnector) {
            window.tqCoreConnector = tqCoreConnector;
        })
        .component('app', {
            template,
            restrict: 'E',
            controller: CmpController
        });

    function CmpController($scope, $rootScope) {
        $scope.showFooter = false;
        $scope.backButtonHidden = true;

        $rootScope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
            // call the standard redirection service
            // where to show footer
			$scope.showFooter = !(toState.name === 'tqlogin' || toState.name === 'tqhome' || toState.name === 'tqactivation' || toState.name === 'register');
            $scope.backButtonHidden = false;
        });

    }
});
