import Account from 'youOne/services/account/account.class.js';

class MySitesController {

	constructor($scope, $rootScope, $log, accountService, tankDipLevelDialogService, missingTankDipDatesDialogService, platformSelectorService, platformType) {
		'ngInject';
		
		// Public members
		this.$scope = $scope;
		this.$rootScope = $rootScope;
		this.$log = $log;
		this.accountService = accountService;
		this.tankDipLevelDialogService = tankDipLevelDialogService;
		this.missingTankDipDatesDialogService = missingTankDipDatesDialogService;
		this.platformSelectorService = platformSelectorService;
		this.platformType = platformType;
		this.$scope.Account = Account;
		
		this.$scope.mySites = [];
		
		this.$scope.siteToShowDetail = null;
		
		this.$scope.onSiteClick = (site) => {
			this.$log.debug('User clicked site: ' + site.name);
			this.$scope.siteToShowDetail = site;
			this.$rootScope.$broadcast('hideHeader');
		};
		
		this.$scope.onSiteBackButtonClick = () => {
			this.$log.debug('User clicked back button in mobile');
			this.$scope.siteToShowDetail = null;
			this.$rootScope.$broadcast('showHeader');
		};
		
		this.$log.debug('My Sites controller created. Retrieving sites...');
		
		this.accountService.getSellToAccount().then((sellToAccount) =>{
			this.$log.debug('Done. ' + sellToAccount.shipToList.length + ' sites retrieved.');
			
			this.$scope.mySites = sellToAccount.shipToList;
			this.$log.debug(sellToAccount.shipToList);
			
			_.forEach($scope.mySites, (site) => {
				site.onEnterTankLevelClick = () => {
					this.$log.debug('User clicked Enter Level button');
					
					this.tankDipLevelDialogService.open(site, null);
				};
				
				site.onEnterMissingTankLevelsClick = () => {
					this.$log.debug('User clicked Enter Missing Tank Levels button');
					
					this.missingTankDipDatesDialogService.open(site, false);
				};
			});
			
			this.$scope.isSingleSite = $scope.mySites.length === 1;
			
			this.$log.debug('# of sites retrieved: ' + $scope.mySites.length);
		});
		
		this.platformSelectorService.registerPlatformTypeChangeEvent((newPlatform) => {
			// this.$log.debug('Platform type changed to ' + this.platformType.toString(newPlatformType));
			
			// If changed to mobile
			if(newPlatform === this.platformType.MOBILE) {
				// If we are showing a site detail page, hide the header
				if(this.$scope.siteToShowDetail) {
					this.$rootScope.$broadcast('hideHeader');
				}
				
				// Otherwise, show header
				else {
					this.$rootScope.$broadcast('showHeader');
				}
			}
			
			// If changed to tablet or desktop
			else {
				// If we are showing a site detail page, show the header
				if(this.$scope.siteToShowDetail) {
					this.$rootScope.$broadcast('showHeader');
				}
			}
		});
		
		this.$scope.$on('$destroy', () => {
			console.debug('My sites controller destroyed.');
			
			// If scope is destroyed (view is changed) and we are showing a site detail page, show the header
			if(this.$scope.siteToShowDetail) {
				this.$rootScope.$broadcast('showHeader');
			}
		});
	}
}

export default MySitesController;
