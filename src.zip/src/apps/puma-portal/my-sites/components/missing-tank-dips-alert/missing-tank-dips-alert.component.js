import './missing-tank-dips-alert.sass';
import template from './missing-tank-dips-alert.tpl.html';

let missingTankDipsAlert = {
	template: template,
	bindings: {
		siteData: '<'
	}
};

export default missingTankDipsAlert;