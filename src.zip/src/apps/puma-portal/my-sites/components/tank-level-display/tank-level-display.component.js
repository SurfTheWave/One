import './tank-level-display.sass';
import template from './tank-level-display.tpl.html';
import TankLevelDisplayController from './tank-level-display.controller.js';

let tankLevelDisplay = {
	bindings: {
		tank: '<',
		state: '='
	},
	template: template,
	controller: TankLevelDisplayController,
	transclude: true
};

export default tankLevelDisplay;



