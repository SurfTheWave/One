class TankLevelDisplayController {
	
	constructor() {
		//TODO @mehmettop => This constant value will be moved in static conf file
		this.fineStockPercent  = 50;
	}
	
	getRulerRangeCount(){
		let ruler = [0,1,2,3,4,5,6,7,8,9,10];
		return ruler;
	}
	
	getTankFilledLevelAreaHight(){
		let tankFillPercent = ( this.tank.getDipLevel() / this.tank.getCapacity() ) * 100;
		// 93 value is max adjustable height percent of the div.
		// So, we have to normalize tank fill percent between 0-93 instead of 0-100
		tankFillPercent = (tankFillPercent * 93)/ 100;
		return tankFillPercent + '%';
	}
	
	getLastMeasurementTime(){
		if(this.tank.getLastDipReadingDate() != null){
			let lastMeasurementTimeObj = new Date(this.tank.getLastDipReadingDate());
			let dateString =  lastMeasurementTimeObj.toString();
			let dateArray = dateString.split(' ');
			let timeArray = dateArray[4].split(':');
			return dateArray[2] + ' ' + dateArray[1] + ' ' + dateArray[3] + ' ' + timeArray[0] + ':' + timeArray[1]
		}
		return false;
	}
	
	getLastMeasurementHour(){
		if(this.tank.getLastDipReadingDate() != null){
			let lastMeasurementTimeObj = new Date(this.tank.getLastDipReadingDate());
			let dateString =  lastMeasurementTimeObj.toString();
			let dateArray = dateString.split(' ');
			let timeArray = dateArray[4].split(':');
			return timeArray[0] + ':' + timeArray[1]
		}
		return false;
	}
}

export default TankLevelDisplayController;