import './site-detail-mobile.sass';
import template from './site-detail-mobile.tpl.html';

let siteDetailMobile = {
	template: template,
	bindings: {
		showHeader: '<',
		siteData: '<',
		isActive: '<',
		onBackButtonClick: '&'
	}
};

export default siteDetailMobile;