import './time-input.sass';
import template from './time-input.tpl.html';
import TimeInputController from './time-input.controller.js';
/*
* caption 			: Time field's caption, must be entered !!!
* captionPosition	: Position of the caption. Options => <top | left>
* fieldId			: Time field's id, it is important for getting data.
* bindingData		: To give time field initial value, time field's data must be binded tank's time
* isRequired		: Is field must be filled. Options => <true | false>
*/
let timeInput = {
	bindings: {
		caption			:	'<',
		captionPosition	: 	'<',
		fieldId			:	'<',
		isRequired		:	'<',
		bindValue		:	'=',
		focusStatus		:	'=',
		hoverFunction	:	'&'

	},
	template: template,
	controller: TimeInputController
};

export default timeInput;