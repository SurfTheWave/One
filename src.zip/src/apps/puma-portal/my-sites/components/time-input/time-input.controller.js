class TimeInputController {
	
	constructor($scope) {
		'ngInject';
		this.focusStatus = false;
		this.buttonShowStatus = false;
		this.btnFocusStatus = false;

	}
	
	focus(){
		this.focusStatus = true;
		this.btnFocusStatus = false;
	}
	
	notFocus(){
		this.focusStatus = false;
	}
	
	btnFocus(){
		this.btnFocusStatus = true;
	}
	
	btnBlur(){
		this.btnFocusStatus = false;
	}
	
	hideHoverButton(){
		this.buttonShowStatus = false;
	}
	
	checkInputKey(e){
		if ((e.which >= 48 && e.which <= 57) || e.which == 8 || e.which == 0){
			
		}else{
			return e.preventDefault();
		}		
	}

	checkInputValue(e){
		let fieldValue = document.getElementById(this.fieldId).value
		if(e.which == 8 & fieldValue.length ==2){
			return;
		}else if (fieldValue.length == 2){
			document.getElementById(this.fieldId).value = fieldValue + ":"
		}else if( !(fieldValue.indexOf(':') > -1) && fieldValue.length > 2){
			let hour = fieldValue.substring(0,2);
			let minute = fieldValue.substring(2,4);
			document.getElementById(this.fieldId).value = hour + ":" + minute;
		}
		//--
		if(fieldValue.length == 5){
			this.buttonShowStatus = true;
		}else{
			this.buttonShowStatus = false;
		}
		
	}
}

export default TimeInputController;