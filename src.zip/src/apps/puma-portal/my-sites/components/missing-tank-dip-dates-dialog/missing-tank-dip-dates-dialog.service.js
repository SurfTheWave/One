import MissingTankDipDatesDialogTemplate from './missing-tank-dip-dates-dialog.tpl.html';
import MissingTankDipDatesDialogController from './missing-tank-dip-dates-dialog.controller.js';
import './missing-tank-dip-dates-dialog.sass';

class MissingTankDipDatesDialogService {
	constructor($log,  ngDialog) {
		'ngInject';
		
		this.$log = $log;
		this.ngDialog = ngDialog;
	}

	open(site, fromDashboard) {
		this.dialogInstance = this.ngDialog.open({
			template: MissingTankDipDatesDialogTemplate,
			plain: true,
			className: 'ngdialog-theme-default missing-tank-dip-dates-dialog',
			controller: MissingTankDipDatesDialogController,
			closeByDocument: false,
			data: {
				site: site,
				fromDashboard: fromDashboard
			}
		});
	}

	close() {
		if(this.dialogInstance) {
			this.dialogInstance.close();
		}
	}
}

export default MissingTankDipDatesDialogService;