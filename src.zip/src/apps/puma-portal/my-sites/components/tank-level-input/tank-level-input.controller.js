class TankLevelInputController {
	
	constructor($scope) {
		'ngInject';
		this.tankTime = '';
		this.cpTank = angular.copy(this.tank);
		this.maxLength = (this.tank.getSafeFillLevel().toString()).length + 1;
		this.cpTankLevelInput;
		this.focusStatus = false;
		this.tankLevelTolarance = 0.1;
		this.timeInputPrefix = 'input-tank-level-time-';
		this.dipLevelInputPrefix = 'input-tank-level-dip-';
		this.errorMessagePrefix = 'tank-level-enter-status-';
		this.upperDipLevel = parseInt(this.tank.getCapacity()) + (parseInt(this.tank.getCapacity()) * this.tankLevelTolarance);
		//--
		this.isDipLevelValid = true;
		this.isTimeValid = true;
		//--
		this.isDipLevelEmpty 	= false;
		this.isTimeEmpty		= false;
		//--
		console.log(this.cpTank);
	}
	
	applyValue(){
		//--
		if(isNaN(this.cpTankLevelInput) || this.cpTankLevelInput == ''){
			this.cpTank.setDipLevel(this.tank.getDipLevel());
		}else{
			this.cpTank.setDipLevel(parseInt(this.cpTankLevelInput));
		}
	}
	
	checkDipLevel(){
		//TODO @mehmettop => Currently we are using tolerance percent as a constant. In the future this constant will get from service for per tank.
		let formControl = true;
		this.isDipLevelEmpty 	= false;
		let inputDipLevelElement = document.getElementById(this.dipLevelInputPrefix + this.tank.Id);
		if(inputDipLevelElement == null){
			return false;
		}
		let errorElement = document.getElementById(this.errorMessagePrefix + this.tank.Id);
		//-- Clear Error Message...
		errorElement.innerHTML = '';
		//--
		if(this.cpTankLevelInput != null && this.cpTankLevelInput != ''){
			
			if(this.cpTankLevelInput >= this.upperDipLevel){
				errorElement.innerHTML = 'Your dip has exceeded the available capacity of the tank';
				formControl = false;
			}else if(this.cpTankLevelInput < parseInt(this.tank.getDeadStockLevel())){
				formControl = false;
				errorElement.innerHTML = 'Your dip has been below the minimum capacity of the tank';
			}
		//-- Tank Dip Level Was Not Entered !	
		}else{
			//-- Clear Error Message
			formControl = false;
			this.isDipLevelEmpty = true;
		}
		this.isDipLevelValid = formControl;
		if((this.isDipLevelEmpty && !this.isTimeEmpty && this.isTimeValid)){
			inputDipLevelElement.className += ' ng-invalid';
		}else if(!this.isDipLevelEmpty && !this.isDipLevelValid){
			inputDipLevelElement.className += ' ng-invalid';
		}else{
			inputDipLevelElement.classList.remove('ng-invalid');
		}
		return formControl;
	}
	
	validateField(){
		let validation = true;
		if(!this.checkDipLevel()){
			validation =  false;
		}
		
		if(!this.checkTime()){
			validation =  false;
		}
		
		return validation;
	}
	
	checkTime(){	
		let formControl = true;
		this.isTimeEmpty		= false;
		//-- GET CURRENT TIME
		let currentTime = new Date(this.shipToDateTime);
		currentTime.setSeconds(0);
		currentTime.setMilliseconds(0);
		currentTime = currentTime.getTime();
		//--
		let inputTimeElement = document.getElementById(this.timeInputPrefix + this.tank.Id);
		if(inputTimeElement == null){
			return false;
		}
		let lastMeasurementDateTime = new Date(this.tank.getLastDipReadingDate());
		let errorElement = document.getElementById(this.errorMessagePrefix + this.tank.Id);
		lastMeasurementDateTime = lastMeasurementDateTime.getTime();
		let enteredTime = this.tankTime
		//-- Time Input is valid and ready to validate
		if(enteredTime != null && enteredTime != ''){
			let enteredTimeArray = enteredTime.split(':');
			this.enteredHour = enteredTimeArray[0];
			this.enteredMinute = enteredTimeArray[1];
			//-- 
			let enteredDateTime = new Date();
			enteredDateTime.setSeconds(0);
			enteredDateTime.setMilliseconds(0);
			enteredDateTime.setHours(this.enteredHour);
			enteredDateTime.setMinutes(this.enteredMinute);
			enteredDateTime = enteredDateTime.getTime();
			//--
			//-- Todays Dip, Entered time must not be bigger than current time ! And also not to be smaller than last measurement time
			if(!this.isMissingDate){
				//Even if tank does not have lastMeasurementDateTime this blocks works.
				if(enteredDateTime <= lastMeasurementDateTime){
					errorElement.innerHTML = 'You can not enter dip level before last measurement time';
					formControl = false;
				}else if(enteredDateTime >= currentTime){
					errorElement.innerHTML = 'You cannot enter for future time';
					formControl = false;
				}
			}else{
				//-- Missing Date Validation Block...
				formControl = true;
			}
		//--Tank Time was not entered !!!
		}else{
			formControl = false;
			this.isTimeEmpty = true;
		}
		//-- Do Not Submit Form To Server
		this.isTimeValid = formControl;
		if(this.isTimeEmpty && !this.isDipLevelEmpty && this.isDipLevelValid){
			inputTimeElement.className += ' ng-invalid';
		}else if(!this.isTimeEmpty && !this.isTimeValid){
			inputTimeElement.className += ' ng-invalid';
		}else{
			inputTimeElement.classList.remove('ng-invalid');
		}
		return formControl;
	}
	
	getUnit(tankUnit){
		if(tankUnit == 'LITERS'){
			return 'lt';
		}else if(tankUnit == 'CENTIMETERS'){
			return 'cm';
		}
	}
}

export default TankLevelInputController;