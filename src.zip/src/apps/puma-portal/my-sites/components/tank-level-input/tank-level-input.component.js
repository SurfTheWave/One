import './tank-level-input.sass';
import template from './tank-level-input.tpl.html';
import TankLevelInputController from './tank-level-input.controller.js';

let tankLevelInput = {
	bindings: {
		tank			: '<',
		shipToDateTime	: '<',
		layout			: '=',
		state			: '=',
		timeApply		: '&',
		isMissingDate	: '<'
	},
	template: template,
	controller: TankLevelInputController,
	transclude: true
};

export default tankLevelInput;