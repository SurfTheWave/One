import './text-input.sass';
import template from './text-input.tpl.html';
import TextInputController from './text-input.controller.js';

let textInput = {
	
	bindings: {
		
		fieldId				: '<',
		caption				: '<',
		captionPosition		: '<',
		type				: '<',
		pattern				: '<',
		isRequired			: '<',
		placeHolder			: '<',
		unit				: '<',
		maxLength			: '<',
		keyUp				: '&',
		bindValue			: '=',
		focusStatus			: '='
	},
	
	template: template,
	controller: TextInputController
};

export default textInput;