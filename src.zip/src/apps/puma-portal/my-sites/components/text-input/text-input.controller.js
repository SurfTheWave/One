class TextInputController {
	
	constructor() {
		
		this.focusStatus = false;
		console.log("PLACE HOLDER: " + this.placeHolder);

	}
	
	focus(){
		this.focusStatus = true;
	}
	
	notFocus(){
		this.focusStatus = false;
	}
}

export default TextInputController;