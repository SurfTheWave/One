class TankLevelInputPageController{
	constructor(accountService, tankService, $filter){
		'ngInject';
		//Default Layout is Vertical
		this.$filter = $filter;
		this.layout = 'vertical';
		this.timeInputPrefix = 'input-tank-level-time-';
		this.dipLevelInputPrefix = 'input-tank-level-dip-';
		this.errorMessagePrefix = 'tank-error-';
		this.tankLevelTolarance = 0.1;
		this.accountService = accountService;
		this.tankService = tankService;
		this.missingDates = [];
		this.updatedTankIds = [];
		this.updatedTankList = [];
		this.state = 'submission'; // other uses: 'success', 'failure' (not necessary for now)
		//--
		if(this.missingDate != null){
			//--Convert date object to string
			this.missingDate = new Date(this.missingDate);
			this.date = $filter('date')(this.missingDate, "dd.MM.yyyy");
		}
		else{
			this.missingDate = this.getShipToDateTime();
			this.date =  $filter('date')(this.missingDate, "dd.MM.yyyy");
		}
		this.dateOrig = angular.copy( this.date);
		this.dateArray = this.date.split('.');
		this.day = this.dateArray[0];
		this.month = this.dateArray[1];
		this.year = this.dateArray[2];
		//--
		this.updateTankList(this.site.id, this.missingDate.getDate());
		this.getMissingDates();
		
	}
	
	getActiveTanks(){
		let activeTanks = [];
		for(let i = 0; i < this.tankList.length; i++) {
			if(this.tankList[i].isActive()){
				activeTanks.push(this.tankList[i]);
			}
		}
		return activeTanks;
	}
	
	getShipToDateTime(){
		let dateObject = new Date(this.site.shipToDateTime);
		dateObject.setSeconds(0);
		dateObject.setMilliseconds(0);
		return dateObject;
	}
	
	getShipToDateTimeText(){
		let  dateObject = this.getShipToDateTime();
		//--
		let hour = dateObject.getHours();
		let minute = dateObject.getMinutes();
		if(hour < 10){
			hour = "0" + hour;
		}
		if(minute < 10){
			minute = "0" + minute;	
		}
		//--
		let dateString = this.$filter('date')(dateObject, "dd.MM.yyyy");
		dateString = dateString + " - " + hour + ":" + minute;
		return dateString;
	}
	
	updateTankList(siteId, tankDate){		
		this.tankService.getTankData(siteId, tankDate).then((tanks) => {
			this.tankList = tanks;
			
			this.updatedTankList = [];
			var i;
			for(i = 0; i < this.tankList.length; i++) {
				if(this.updatedTankIds.indexOf(this.tankList[i].Id) != -1) {
					this.updatedTankList.push(this.tankList[i]);
				}
			}
		});
	}
	
	getMissingDates(){
		this.missingDates = this.site.missingTankDipDates;
	}
	
	updateTanks(){
		//this method is called many times??
		let selectedDate = this.getDatePickerValue();
		if(this.dateOrig === this.date){
			return;
		}
		this.dateOrig = this.date;
		this.updateTankList(this.site.id, selectedDate.getDate());	
	}
	
	getDatePickerValue(){
		let dateArray = this.date.split('.');
		let selectedDate = new Date(dateArray[2], dateArray[1] - 1, dateArray[0]);
		return selectedDate;
	}
	
	getDatePickerDay(){
		let selectedDate = this.getDatePickerValue();
		let dateString =  selectedDate.toString();
		let dateArray = dateString.split(' ');
		return dateArray[2] + ' ' + dateArray[1] + ' ' + dateArray[3];
	}
	
	isMissingDate(){
		let selectedDate = this.getDatePickerValue();
		let currentDate = new Date();
		currentDate.setMilliseconds(0);
		currentDate.setMinutes(0);
		currentDate.setHours(0);
		if(selectedDate.getDate() == currentDate.getDate()){
			return false;
		}
		return true;
	}

	changeView(layout){
		this.layout = layout;
	}
	
	submitTanksLevel(form){
		if(form.$valid && this.isFormValid()){
			let requestData = this.prepareRequestData();
			if(requestData.tanks.length === 0) {
				return;
			}
			let result = this.tankService.submitTankDips(requestData);
			if(result.$$state.value.status == 200){
				this.onSubmitTankDipSuccess();
				this.state = 'success';
				this.updateTankList(this.site.id, this.getDatePickerValue().getDate());
			}
		}else{
			alert("NOT VALID");
		}
	}
	
	isFormValid(){
		for (let i=0; i < this.site.tanks.length; i++){
			if(this.site.tanks[i].isActive()){
				let inputTimeElement = document.getElementById(this.timeInputPrefix + this.site.tanks[i].Id); 
				let inputDipLevelElement = document.getElementById(this.dipLevelInputPrefix + this.site.tanks[i].Id);
				//--
				if(inputDipLevelElement == null || inputTimeElement == null){
					return false;
				}
				//--
				if(this.hasClass(inputDipLevelElement, 'ng-invalid') || this.hasClass(inputTimeElement, 'ng-invalid')){
					return false;
				}
			}
		}
		return true;
	}
	
	isFormFilled(){
		for (let i=0; i < this.site.tanks.length; i++){
			if(this.site.tanks[i].isActive()){	
				let inputTimeElement = document.getElementById(this.timeInputPrefix + this.site.tanks[i].Id); 
				let inputDipLevelElement = document.getElementById(this.dipLevelInputPrefix + this.site.tanks[i].Id);
				//--
				if(inputDipLevelElement == null || inputTimeElement == null){
					return false;
				}
				//--
				if(inputDipLevelElement.value || inputTimeElement.value ){
					return true;
				}
			}
		}
		return false;
	}
	
	hasClass(inputElement, className) {
		return (' ' + inputElement.className + ' ').indexOf(' ' + className + ' ') > -1;
	}
	
	prepareRequestData(){
		var request = {shipToId: this.site.id, tanks:[]};
		let i = 0;
		for (i=0; i < this.site.tanks.length; i++){
			if(this.site.tanks[i].isActive()){
				let inputTimeElement = document.getElementById(this.timeInputPrefix + this.site.tanks[i].Id); 
				let inputDipLevelElement = document.getElementById(this.dipLevelInputPrefix + this.site.tanks[i].Id);
				//--
				let enteredDipLevel = inputDipLevelElement.value;
				let enteredTime = inputTimeElement.value;
				if(enteredTime != '' && enteredDipLevel != ''){
					let enteredDateTime = this.getDatePickerValue();
					let enteredTimeArray = enteredTime.split(':');
					enteredDateTime.setSeconds(0);
					enteredDateTime.setMilliseconds(0);
					enteredDateTime.setHours(enteredTimeArray[0]);
					enteredDateTime.setMinutes(enteredTimeArray[1]);
					//-- Send  UTC Time to server via .getTime()
					request.tanks.push({Id: this.site.tanks[i].Id, dipLevel: enteredDipLevel, lastMeasurementTime: enteredDateTime.getTime()});
					this.updatedTankIds.push(this.site.tanks[i].Id);
				}
			}
		}
		//console.log("Prepared Request: " + JSON.stringify(request))
		return request;
	}
	
	applyTimeToAll(tankId){
		let givenTime = document.getElementById(this.timeInputPrefix + tankId);
		let i = 0;
		for (i=0; i < this.site.tanks.length; i++){
			//-- Check tank is operational
			if(this.site.tanks[i].isActive()){
				let tmpTimeElement = document.getElementById(this.timeInputPrefix + this.site.tanks[i].Id);
				tmpTimeElement.value = givenTime.value;
				//--
				if ('createEvent' in document) {
					var evt = document.createEvent('HTMLEvents');
					evt.initEvent('change', false, true);
					tmpTimeElement.dispatchEvent(evt);
				}else{
					tmpTimeElement.fireEvent('onchange');
				}
			}
		}
	}
}

export default TankLevelInputPageController;