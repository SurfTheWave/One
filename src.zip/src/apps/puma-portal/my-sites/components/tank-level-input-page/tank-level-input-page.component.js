import './tank-level-input-page.sass';
import template from './tank-level-input-page.tpl.html';
import TankLevelInputPageController from './tank-level-input-page.controller.js';

let tankLevelInputPage = {
	bindings: {
		site: '<',
		missingDate: '=',
		onSubmitTankDipSuccess: '&',
		done: '&'
	},
	template: template,
	controller: TankLevelInputPageController,
	transclude: true
};

export default tankLevelInputPage;