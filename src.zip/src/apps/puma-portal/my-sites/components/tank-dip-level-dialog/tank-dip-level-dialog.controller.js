import BaseDialogController from 'youOne/components/base-dialog/base-dialog.class.js';

export default class TankDipLevelDialogController extends BaseDialogController {
	
	constructor($scope, $log, accountService) {
		'ngInject';
		
		super('past', ...arguments);
		
		$log.debug('Tank dip level dialog controller created. shipTo name: ' + $scope.ngDialogData.shipTo.name);
		
		this.$scope = $scope;
		this.accountService = accountService;
		this.$log = $log;
		
		this.shipToAccount =this.$scope.ngDialogData.shipTo;
		this.missingDate = this.$scope.ngDialogData.missingDate;
		
		/******* Dialog configurations for base dialog controller ********/
		// Initialize state to submission state
		this.state = this.states.Submission;
		
		// It is used to set minimize height of dialog for success/confirmation state
		this.successDialogMinimizePercent=1;
		this.confirmationDialogMinimizePercent=0.55;
		/*****************************************************************/
	}
	
	/**
	* @ngdoc function
	* @name getThankYouMessage
	* Produce success message
	*/	
	getThankYouMessage() {
		let thankYouMessageText = 'YOUR SHIP TO UPDATE REQUEST CREATED, CHANGE REQUEST ID: '+ this.changeRequestId;
		
		return thankYouMessageText;
	}
	
	/**
	* @ngdoc function
	* @name getConfirmationQuestion
	* Produce confirmation question
	*/	
	getConfirmationMessage() {
		let confirmText = 'Are you sure you want to close new ship to account dialog?';
		
		return confirmText;
	}
	
	onSubmitTankDipSuccess() {
		this.changeState(this.states.Success);
		this.$log.debug('Successfully submitted tank dip levels. Retrieving up-to-date site...');
		this.accountService.getSellToAccount().then((sellToAccount) => {
			let shipTo = sellToAccount.shipToList.find((x) => x.id === this.shipToAccount.id);
			this.shipToAccount.tanks = shipTo.tanks;
		});
	}
}