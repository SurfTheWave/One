import './overall-status-mobile.sass';
import template from './overall-status-mobile.tpl.html';

let overallStatusMobile = {
	template: template,
	bindings: {
		siteCount: '<',
		showSiteCount: '<'
	}
};

export default overallStatusMobile;