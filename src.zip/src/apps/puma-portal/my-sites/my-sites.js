// Import angular
import angular from 'angular';

// Import services
import 'youOne/services/modal-dialog/modal-dialog.js';
import 'youOne/services/site/site.js';

// Import components
import mySites from './my-sites.component.js';
import overallStatusMobile from './components/overall-status-mobile/overall-status-mobile.component.js';
import siteDetailMobile from './components/site-detail-mobile/site-detail-mobile.component.js';
import missingTankDipsAlert from './components/missing-tank-dips-alert/missing-tank-dips-alert.component.js';
import tankLevelDisplay from './components/tank-level-display/tank-level-display.component.js';
import textInput from './components/text-input/text-input.component.js';
import timeInput from './components/time-input/time-input.component.js';
import tankLevelInput from './components/tank-level-input/tank-level-input.component.js';
import tankLevelInputPage from './components/tank-level-input-page/tank-level-input-page.component.js';
import tankDipLevelDialogService from './components/tank-dip-level-dialog/tank-dip-level-dialog.service.js';
import missingTankDipDatesDialogService from './components/missing-tank-dip-dates-dialog/missing-tank-dip-dates-dialog.service.js';

export default angular.module('app.my-sites', ['puma.site', 'modal-dialog'])
	.component('mySites', mySites)
	.component('overallStatusMobile', overallStatusMobile)
	.component('siteDetailMobile', siteDetailMobile)
	.component('missingTankDipsAlert', missingTankDipsAlert)
	.component('tankLevelDisplay', tankLevelDisplay)
	.component('textInput', textInput)
	.component('timeInput', timeInput)
	.component('tankLevelInput', tankLevelInput)
	.component('tankLevelInputPage', tankLevelInputPage)
	.service('tankDipLevelDialogService', tankDipLevelDialogService)
	.service('missingTankDipDatesDialogService', missingTankDipDatesDialogService);