import './my-sites.sass';
import template from './my-sites.tpl.html';
import MySitesController from './my-sites.controller.js';

let mySites = {
	template: template,
	controller: MySitesController
};

export default mySites;