import './my-sites.js';

describe('Component: my-sites', () => {
	var $scope, tankDipLevelDialogService, missingTankDipDatesDialogService;
	var sellToAccount = {
		shipToList: [
			{
				
			},
			
			{
				
			}
		]
	};
	
	// Implement mock services used by my sites controller
	beforeEach(() => {
		angular.mock.module('app.my-sites');
		
		// Provide will help us create fake implementations for our dependencies
		angular.mock.module(($provide) => {
		
			// Mock accountService
			$provide.service('accountService', () => {
				return {
					getSellToAccount: () => {
						return { 
							then: (callback) => {
								return callback(sellToAccount);
							}
						};
					}
				};
			});
			
			// Mock tankDipLevelDialogService service
			$provide.service('tankDipLevelDialogService', () => {
				return {
					open: () => {
						
					},
					
					close: () => {
						
					}
				};
			});
			
			// Mock missingTankDipDatesDialogService service
			$provide.service('missingTankDipDatesDialogService', () => {
				return {
					open: () => {
						
					},
					
					close: () => {
						
					}
				};
			});
		});
	});
	
	// Assign injected services to local instances
	beforeEach(angular.mock.inject((_tankDipLevelDialogService_, _missingTankDipDatesDialogService_) => {
		tankDipLevelDialogService = _tankDipLevelDialogService_;
		missingTankDipDatesDialogService = _missingTankDipDatesDialogService_;
	}));
	
	// Create a new scope and create mySites component with newly created scope
	beforeEach(angular.mock.inject((_$rootScope_, _$componentController_) => {
		$scope = _$rootScope_.$new();
		
		_$componentController_('mySites', {
			$scope: $scope
		});
	}));
	
	it('is supposed to fill $scope.mySites with shipToList of sellToAccount', () => {
		expect($scope.mySites).toEqual(sellToAccount.shipToList);
	});

	it('is supposed to open tank dip level submission dialog at calling onEnterTankLevelClick', () => {
		spyOn(tankDipLevelDialogService, 'open');
		
		$scope.mySites[0].onEnterTankLevelClick();
		expect(tankDipLevelDialogService.open).toHaveBeenCalled();
	});
	
	it('is supposed to open missing tank dip dates dialog at calling onEnterMissingTankLevelsClick', () => {
		spyOn(missingTankDipDatesDialogService, 'open');
		
		$scope.mySites[0].onEnterMissingTankLevelsClick();
		expect(missingTankDipDatesDialogService.open).toHaveBeenCalled();
	});

	it('is supposed to assign a site to siteToShowDetail when onSiteClick is clicked', () => {
		$scope.onSiteClick($scope.mySites[0]);
		expect($scope.siteToShowDetail).toEqual($scope.mySites[0]);
	});

	it('is supposed to assign null to siteToShowDetail when onSiteBackButtonClick is clicked', () => {
		$scope.onSiteBackButtonClick();
		expect($scope.siteToShowDetail).toEqual(null);
	});
	
	it('is supposed to be a multi-site view', () => {
		expect($scope.isSingleSite).toEqual(false);
	});
});