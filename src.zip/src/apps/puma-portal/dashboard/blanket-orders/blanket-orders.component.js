import './blanket-orders.sass';
import template from './blanket-orders.tpl.html';
import BlanketOrdersController from './blanket-orders.controller.js';

let blanketOrders = {
	template: template,
	controller: BlanketOrdersController
};

export default blanketOrders;