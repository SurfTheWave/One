
export default class BlanketOrdersController {
	constructor($window, $timeout) {
		'ngInject';
		this.$window = $window;
		this.$timeout = $timeout;
	}
	
	$onInit() {
		this.$timeout(() => {
			this.$window.scroll(0, 208);
		})
	}
}