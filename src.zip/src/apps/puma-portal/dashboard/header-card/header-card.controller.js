export default class HeaderCardController {
	constructor($interval) {
		'ngInject';
		this.$interval = $interval;
		if (this.route) {
			this.text = this.route.replace(/([A-Z])/g, ' $1').trim();
			this.value = 0;
		}
	}
/**
 * @ngdoc function
 * @name header-card.function:isRouteActive
 * @usage
 * @description
 * Returning a boolean to tell whether a route is active
 */
	isRouteActive(myRoute) {
		return this.$router.isRouteActive(this.$router.generate(['./' + myRoute]));
	}
	
/**
 * @ngdoc function
 * @name header-card.function:scrolling
 * @description
 * The scrolling method is used for making a smooth transition to the right or to the left.
 * If the first or second element is clicked, it will go on the left. If one of the 2 last elements
 * are clicked, it will go on the right.
 */
	scrolling() {
		let scrollTo = (to) => {
			let currentScroll;
			let elm;

			let interval = this.$interval(() => {
				currentScroll = document.getElementById('dashboard').scrollLeft;
				
				if (to === 0) {
					document.getElementById('dashboard').scrollLeft -= 5;
				} else {
					document.getElementById('dashboard').scrollLeft += 5;
				}
				elm = document.getElementById('dashboard').scrollLeft;
				if (elm <= 0 || elm === currentScroll) {
					this.$interval.cancel(interval);
				}
			}, 10);
		}

		if (this.pos <= 1) {
			scrollTo(0);
		} else {
			scrollTo(1);
		}
	}
}