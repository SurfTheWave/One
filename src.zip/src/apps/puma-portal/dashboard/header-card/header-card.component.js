/**
 * @ngdoc directive
 * @name header-card
 * @restrict 'E'
 * @param {text} route Name of the route
 * @param {number} pos Position of the route (used for scrolling)
 * @description
 * The header card of the dashboard.
 */

import './header-card.sass';
import template from './header-card.tpl.html';
import HeaderCardController from './header-card.controller.js';

let headerCard = {
	template: template,
	controller: HeaderCardController,
	bindings: {
		route: '@',
		$router: '<',
		pos: '@',
		value: '<'
	}
};

export default headerCard;