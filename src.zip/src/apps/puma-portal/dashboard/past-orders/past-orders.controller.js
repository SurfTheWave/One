import OrdersController from '../commons/orders.class.js';

export default class PastOrdersController extends OrdersController {
	constructor($window, $timeout, $scope, pumaConnector, accountService, OrderStatusListService, orderService) {
		'ngInject';
		super('past', ...arguments);
	}
}