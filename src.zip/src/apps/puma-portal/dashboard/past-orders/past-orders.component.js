import './past-orders.sass';
import template from './past-orders.tpl.html';
import PastOrdersController from './past-orders.controller.js';

let pastOrders = {
	template: template,
	controller: PastOrdersController,
	require: {
		ordersCtrl: '^orders'
	}
};

export default pastOrders;