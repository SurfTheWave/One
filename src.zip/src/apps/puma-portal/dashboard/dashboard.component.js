import './dashboard.sass';
import template from './dashboard.tpl.html';
import DashboardController from './dashboard.controller.js';

let dashboard = {
	template: template,
	controller: DashboardController,
	$routeConfig: [{
		path: '/orders/...',
		name: 'Orders',
		component: 'orders',
		useAsDefault: true
	}, {
		path: '/new-order',
		name: 'NewOrder',
		component: 'newOrder'
	}, {
		path: '/*otherwise',
		redirectTo: ['Orders', 'ActiveOrders']
	}]
};

export default dashboard;

