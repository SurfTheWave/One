export default class PastDueInvoicesController {
	constructor($scope, $log, store) {
		'ngInject';
		this.$scope = $scope;
		this.$log = $log;
		this.store = store;
	}
	
	$onInit() {
		this.$log.debug('Past due invoices controller created. Retrieving past due invoices...');
		
		this.store.getBootstrapData()
			.then((response) => {
				this.$log.debug('Done. ' + response.dashboard.pastDueInvoices.length + ' past due invoices retrieved.');
				this.pastDueInvoices = response.dashboard.pastDueInvoices;
			})
			.catch((error) => {
				this.$log.error('An error occured while retrieving past due invoices: ' + error);
			});
	}
}