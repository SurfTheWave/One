import './past-due-invoices.sass';
import PastDueInvoicesTemplate from './past-due-invoices.tpl.html';
import PastDueInvoicesController from './past-due-invoices.controller.js';

let pastDueInvoices = {
	template: PastDueInvoicesTemplate,
	controller: PastDueInvoicesController
};

export default pastDueInvoices;