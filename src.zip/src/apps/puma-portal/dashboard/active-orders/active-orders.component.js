import './active-orders.sass';
import template from './active-orders.tpl.html';
import ActiveOrdersController from './active-orders.controller.js';

let activeOrders = {
	template: template,
	controller: ActiveOrdersController,
	require: {
		ordersCtrl: '^orders'
	}
};

export default activeOrders;