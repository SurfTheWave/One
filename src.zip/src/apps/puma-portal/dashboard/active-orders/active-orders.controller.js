import OrdersController from '../commons/orders.class.js';

export default class ActiveOrdersController extends OrdersController {
	constructor($window, $timeout, $scope, pumaConnector, accountService, OrderStatusListService, orderService) {
		'ngInject';
		super('active', ...arguments);
	}

	$onInit(){
		//Get list of possible statuses before starting generation of list UI
		this.OrderStatusListService.getOrderStatusList().then((statusList) => {
			this.statusList = statusList;
			this.OrderStatusListService.getTotalStepNumber(statusList);
			this.stepIndexesArray = [1,2,3,4];
			super.$onInit();
		});
	}

	getStatusIndex(orderStatusData){
		return this.OrderStatusListService.getStepNumber(
			orderStatusData.status.statusCaption, this.statusList, orderStatusData.deliveryType, orderStatusData.paymentTerm
		);
	}

	getStatusElementClass(statusIndex, currentIndex, order){
		if (currentIndex < statusIndex){
			return 'icon-done';
		} else if (currentIndex === statusIndex){
			return order.status.statusType === 'step' ? 'icon-green-dot' : 'icon-delay';
		} else {
			return 'icon-grey-dot';
		}
	}
}