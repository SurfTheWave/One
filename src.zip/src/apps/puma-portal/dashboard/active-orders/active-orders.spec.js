import '../../app/app.js';
import '../dashboard.js';

describe('Component: active-orders', function() {
	let activeOrders

	beforeEach(() => {
		angular.mock.module('app');
		angular.mock.module('app.dashboard');	
	});

	beforeEach(angular.mock.inject(function($rootScope, _$componentController_) {

		let $componentController = _$componentController_;
		let ordersCtrl = $componentController('orders', {
			$scope: $rootScope.$new()
		});

		//activeOrders depends on orders. Must bind both together...
		activeOrders = $componentController('activeOrders', {
			$scope: $rootScope.$new()
		}, {
				ordersCtrl: ordersCtrl
			});
		$rootScope.$digest();
	}));

	it('displays all orders', function() {
		expect(activeOrders.orders.length).toEqual(activeOrders.allOrders.length);
		expect(activeOrders.orders.length).toEqual(10000);
	});

	it('filters accordingly', function() {
		activeOrders.selectedDate = '1d';
		activeOrders.selectedShipTo = 'SITE:1';
		activeOrders.applyFilter();

		let counter = 0;
		let filterDate = new Date();
		filterDate.setDate(filterDate.getDate() - 1);
		filterDate = filterDate.getTime();
		activeOrders.allOrders.forEach((order) => {
			if (order.shipTo === 'SITE:1' && order.orderDate >= filterDate) {
				counter++;
			}
		})
		expect(activeOrders.allOrders.length).toEqual(10000);
		expect(activeOrders.orders.length).toEqual(counter);
	});

	it('should have no expanded orders by default', () => {

		let expandedOrder;

		expandedOrder = activeOrders.allOrders.find(x => {

			return x.expanded;
		});

		expect(expandedOrder).not.toBeDefined();
	});

	it('should expand an order on request', () => {

		let selectedOrder = activeOrders.allOrders[0];

		activeOrders.showStatusDetail(selectedOrder);

		expect(activeOrders.expandedOrderId).toEqual(selectedOrder.id);
		expect(selectedOrder.expanded).toEqual(true);
	});

	it('should toogle the Expansion of an order', () => {

		let selectedOrder = activeOrders.allOrders[0];

		activeOrders.showStatusDetail(selectedOrder);

		expect(activeOrders.expandedOrderId).toEqual(selectedOrder.id);
		expect(selectedOrder.expanded).toEqual(true);

		activeOrders.showStatusDetail(selectedOrder);

		expect(selectedOrder.expanded).toEqual(false);
	});

	it('should change the expanded order', () => {

		let selectedOrder = activeOrders.allOrders[0];
		let otherOrder = activeOrders.allOrders[1];

		activeOrders.showStatusDetail(selectedOrder);

		expect(activeOrders.expandedOrderId).toEqual(selectedOrder.id);
		expect(selectedOrder.expanded).toEqual(true);

		activeOrders.showStatusDetail(otherOrder);

		expect(activeOrders.expandedOrderId).toEqual(otherOrder.id);
		expect(selectedOrder.expanded).toEqual(false);
		expect(otherOrder.expanded).toEqual(true);
	});

	it('should reset the expansion on filtering', () => {

		let order = activeOrders.allOrders.find(x => {

			return x.shipTo === 'SITE:1';
		});

		activeOrders.showStatusDetail(order);

		expect(order.expanded).toEqual(true);

		activeOrders.selectedShipTo = 'SITE:2';
		activeOrders.applyFilter();

		expect(order.expanded).toEqual(false);
	});

	it('should keep the expansion on all filter', () => {

		let order = activeOrders.allOrders.find(x => {

			return x.shipTo === 'SITE:1';
		});

		let orderTwo = activeOrders.allOrders.find(x => {

			return x.shipTo === 'SITE:2';
		});

		activeOrders.showStatusDetail(order);

		expect(order.expanded).toEqual(true);

		activeOrders.selectedShipTo = 'SITE:2';
		activeOrders.applyFilter();

		activeOrders.showStatusDetail(orderTwo);

		expect(orderTwo.expanded).toEqual(true);
		expect(order.expanded).toEqual(false);

		activeOrders.selectedShipTo = 'all';
		activeOrders.applyFilter();
		expect(orderTwo.expanded).toEqual(true);
	});


});