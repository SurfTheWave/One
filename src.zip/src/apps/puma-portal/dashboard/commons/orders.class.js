import angular from 'angular';

export default class OrdersController {
	constructor(type, $window, $timeout, $scope, pumaConnector, accountService, OrderStatusListService, orderService) {

		//construct assignment
		this.$window = $window;
		this.$timeout = $timeout;
		this.$scope = $scope;
		this.pumaConnector = pumaConnector;
		this.type = type;
		this.accountService = accountService;
		this.OrderStatusListService = OrderStatusListService;
		this.orderService = orderService;

		//variable declaration
		this.storageKey = 'Puma-Portal_expandedOrderId';
		this.sellToAccount = null;
		this.deliveryType = null;
		this.unbindMethod = null;
		this.orders = [];
		this.allOrders = [];
		this.shipTos = [];
		this.dateOptions = [{
			id: 'all',
			label: 'All Dates'
		}, {
				id: '1d',
				label: 'Yesterday'
			}, {
				id: '3d',
				label: '3 Last Days'
			}, {
				id: '7d',
				label: 'Last Week'
			}, {
				id: '14d',
				label: 'Last 2 Weeks'
			}, {
				id: '1m',
				label: 'Last Month'
			}];
		this.isHeaderFixed = false;
		this.shipToOptions = [{
			id: 'all',
			label: 'All Ship To'
		}];
		this.selectedDate = 'all';
		this.selectedShipTo = 'all';
		this.expandedOrderId = this.$window.localStorage.getItem(this.storageKey) || undefined;

		this.accountService.getSellToAccount().then((sellToAccount) => {

			this.deliveryType = sellToAccount.getDeliveryType();
			this.sellToAccount = sellToAccount;

			this.accountService.getShipToAccounts(this.sellToAccount.Id).then((shipTos) => {

				this.shipTos = shipTos;

				//fetching orders
				this.getOrders().then(() => {
					this.orders = this.orders.sort((a, b) => {
						if (this.type === 'active' && a.etaDate < b.etaDate ||
							this.type === 'past' && a.etaDate > b.etaDate) {
							return -1;
						}
						return 1;
					});
					this.allOrders = this.orders;
				})
			})
		});
	}

	$onInit() {

		//scroll always to the position 208 (basically to the 4 cards)
		this.$timeout(() => {
			this.$window.scroll(0, 208);
		})

		//once when the component is init.
		if (this.$window.pageYOffset >= 208) {
			this.isHeaderFixed = true;
		}
		//event monitoring scrolling and adding/removing a class depending on the height from the top
		this.unbindMethod = angular.element(this.$window).bind('scroll', () => {
			//toggling at 208. 
			//208 = puma logo (64) + thin green layer (8) + User Account Info/Balance (136)
			if (this.$window.pageYOffset >= 208 && !this.isHeaderFixed ||
				this.$window.pageYOffset < 208 && this.isHeaderFixed) {
				this.isHeaderFixed = !this.isHeaderFixed;
				this.$scope.$apply();
			}
		});
	}

	$onDestroy() {
		this.hideLastStatusDetail();

		if (angular.isFunction(this.unbindMethod)) {
			this.unbindMethod();
		}
	}
	
	//workaround for getting the element for IE11 (hiding the selected element while focussed...)
	focusSelect(event) {
		this.selectedSelect = event.target;
	}
	applyFilter() {
		if (this.selectedDate !== 'all' || this.selectedShipTo !== 'all') {

			this.hideLastStatusDetail();
		}

		let filterDate = new Date();
		if (this.selectedDate === 'all') {
			filterDate = -1;
		} else if (this.selectedDate.endsWith('d')) {
			const days = this.selectedDate.substr(0, this.selectedDate.length - 1);
			filterDate.setDate(filterDate.getDate() - days);
			filterDate = filterDate.getTime();
		} else if (this.selectedDate.endsWith('m')) {
			const months = this.selectedDate.substr(0, this.selectedDate.length - 1);
			filterDate.setMonth(filterDate.getMonth() - months);
			filterDate = filterDate.getTime();
		}

		//applying filter on date and on the ship to.
		this.orders = this.allOrders.filter((order) => {
			return order.orderDate >= filterDate &&
				(this.selectedShipTo === 'all' || this.selectedShipTo === order.shipTo);
		});

		//we update the overall amount of displayed records
		this.ordersCtrl.setHeaderValue({
			type: this.type,
			value: this.orders.length
		});
		this.selectedSelect && this.selectedSelect.blur(); //blur for IE11
	}

	getShipToOptions() {
		//getting the current ship to for the ship to filter.
		const uniquesShipTo = [...new Set(this.allOrders.map(item => item.shipTo))];

		//we format the uniquesTo to what is expected by the filter
		this.shipToOptions = uniquesShipTo.map((item) => {
			return {
				id: item,
				label: item
			};
		}).sort((a, b) => { //label alphabetically sorted
			if (a.label < b.label) {
				return -1;
			} else {
				return 1;
			}
		});

		//adding the All Ship To option as first.
		this.shipToOptions.unshift({
			id: 'all',
			label: 'All Ship To'
		});
	}

	getOrders() {
		return this.orderService.getOrderList({
			offset: 0,
			limit: 50000,
			type: this.type
		}).then((orders) => {
			this.allOrders.push(...orders);
			this.applyFilter();
			this.getShipToOptions();
		});
	}

	/**
	 * @ngdoc function
	 * @name showStatusDetail
	 * @param {Object} the order object which was clicked by the user
	 * @description
	 * sets the required properties for an order expansion in the frontend and save it`s id
	 */
	showStatusDetail(order) {

		let oldOrder = undefined;

		/** identify if there is already an expanded order */
		if (angular.isDefined(this.expandedOrderId)) {

			oldOrder = this.orders.find(x => {
				return String(x.id) === this.expandedOrderId;
			});
		}

		if (angular.isDefined(oldOrder)) {

			/** if the clicked order is already expanded, fold it back, otherwise set the required properties for the frontend */
			if (oldOrder.id === order.id) {

				order.expanded = !order.expanded;
			} else {

				order.expanded = true;
				oldOrder.expanded = false;
			}
		} else {

			order.expanded = true;
		}

		/** save the id of the expanded order */
		/** the id is saved also in the local storage, can later be used e. g. to keep the expansion state 
		 * when user leave the order context and comes back later. For now its not further used */
		this.expandedOrderId = order.id;
		this.$window.localStorage.setItem(this.storageKey, this.expandedOrderId);

		/** waits for the dom update of the frontend and then center the expanded element */
		this.$timeout(() => {

			let statusComponent = angular.element('#orderStatusDetail' + order.id);
			let modifier = 0;

			/** modifier value which is used for smaller display sizes */
			if (this.$window.innerHeight < 800) {

				modifier = 30;
			}

			if (statusComponent) {

				angular.element('body, html').animate({ scrollTop: (statusComponent.offset()['top'] - this.$window.innerHeight / 2) - modifier });
			}
		}, 100);
	}

	/**
	 * @ngdoc function
	 * @name hideLastStatusDetail
	 * @description
	 * resets the expanded state for the orders. Gets called on destroy of a component and if a filter is set
	 */
	hideLastStatusDetail() {

		let order = this.orders.find(x => {

			return x.id === this.expandedOrderId;
		});

		if (angular.isDefined(order)) {

			order.expanded = false;
		}
	}
}