import dashboard from './dashboard.component.js';
import headerCard from './header-card/header-card.component.js';
import alerts from './alerts/alerts.component.js';
import activeOrders from './active-orders/active-orders.component.js';
import pastOrders from './past-orders/past-orders.component.js';
import blanketOrders from './blanket-orders/blanket-orders.component.js';
import orders from './orders/orders.component.js';
import newOrder from './new-order/new-order.component.js';
import pastDueInvoices from './past-due-invoices/past-due-invoices.component.js';

import angular from 'angular';
import pumaList from 'youOne/components/list/list.component.js';
import vsRepeat from 'angular-vs-repeat';
import orderStatus from './orderStatus/orderStatus.component.js';
import currencyMap from 'youOne/static-files/currencyMap.js';
import 'animate';

import 'puma-connector';

angular.module('app.dashboard', [vsRepeat, 'ngAnimate', 'puma.connector', 'puma.account', 'puma.order'])
	.component('dashboard', dashboard)
	.component('headerCard', headerCard)
	.component('alerts', alerts)
	.component('activeOrders', activeOrders)
	.component('pastOrders', pastOrders)
	.component('pumaList', pumaList)
	.component('blanketOrders', blanketOrders)
	.component('newOrder', newOrder)
	.component('orders', orders)
	.component('orderStatus', orderStatus)
	.component('pastDueInvoices', pastDueInvoices)
	.constant('currencyMap', currencyMap);