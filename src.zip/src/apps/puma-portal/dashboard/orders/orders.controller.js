/*@ngInject*/
export default class OrdersController {
	constructor($window, $scope, $q, orderService) {
		this.$window = $window;
		this.$scope = $scope;
		this.$q = $q;
		this.orderService = orderService;
		this.size = {};
		this.isHeaderFixed = false;
		//once when the component is init.
		if (this.$window.pageYOffset >= 208) {
			this.isHeaderFixed = true;
		}
		angular.element(this.$window).on('scroll', this.scrollBinding.bind(this));

		//Stop watching window resize on component change
		$scope.$on('$destroy', () => {
			angular.element(this.$window).off('scroll');
		});
	}
	
	$onInit() {
		this.$q.all([
			this.orderService.getOrderList({
				offset: 0,
				limit: 1,
				type: 'alert'
			}),
			this.orderService.getOrderList({
				offset: 0,
				limit: 1,
				type: 'active'
			}),
			this.orderService.getOrderList({
				offset: 0,
				limit: 1,
				type: 'past'
			})
		]).then((values) => {
			const alerts = values[0];
			const actives = values[1];
			const pasts = values[2];
			if(alerts && alerts.length) {
				// there are alerts to display
				this.$router.navigate(['Alerts']);
			} else if(actives && actives.length) {
				// there are active orders to display
				this.$router.navigate(['ActiveOrders']);
			} else if (pasts && pasts.length) {
				// there are maybe past orders to display
				this.$router.navigate(['PastOrders']);
			} else {
				this.$router.navigate(['ActiveOrders']);
			}
		});
	}

	scrollBinding() {
		//toggling at 208.
		//208 = puma logo (64) + thin green layer (8) + User Account Info/Balance (136)
		if (this.$window.pageYOffset >= 208 && !this.isHeaderFixed ||
			this.$window.pageYOffset < 208 && this.isHeaderFixed) {
			this.isHeaderFixed = !this.isHeaderFixed;
			this.$scope.$apply();
		}
	}

	setHeaderValue({type, value}) {
		this.size[type] = value;
	}

	setVSExcessAttribute() {

		let value = Math.round((1100 / this.$window.innerHeight) * ((1100 - this.$window.innerHeight) / 100 * 5));

		value = value < 2 ? 2 : value;

		return value;
	}
}