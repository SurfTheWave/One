import './orders.sass';
import template from './orders.tpl.html';
import OrdersController from './orders.controller.js';

let orders = {
	template: template,
	controller: OrdersController,
	$routeConfig: [{
		path: '/alerts',
		name: 'Alerts',
		component: 'alerts'
	}, {
		path: '/active',
		name: 'ActiveOrders',
		component: 'activeOrders'
	}, {
		path: '/blanket',
		name: 'BlanketOrders',
		component: 'blanketOrders'
	}, {
		path: '/past',
		name: 'PastOrders',
		component: 'pastOrders'
	}, {
		path: '/*otherwise',
		redirectTo: ['ActiveOrders']
	}],
	bindings: {
		$router: '<'
	}
};

export default orders;