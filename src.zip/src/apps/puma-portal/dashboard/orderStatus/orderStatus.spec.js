import '../../app/app.js';
import '../dashboard.js';

describe('Component: order-status', () => {

	let $componentController, component, $rootScope, statusService
	let today = new Date();
	let order = {
		etaDate: today,
		etaTime: '08:00-09:00',
		shipTo: 'SITE:' + parseInt(Math.random() * 10),
		orderNumber: 'A1234567890',
		orderDate: today.getTime() - parseInt(Math.random() * 1000000000 + 300000000),
		productUnit: 'Lt',
		products: {
			'Regular': 321501,
			'Premium': 321501,
			'Diesel': 321501
		},
		productRegular: 321501,
		productPremium: 321501,
		productDiesel: 321501,
		total: 1064561,
		id: 1,
		shippingAddress: 'ShipToShippingAdress',
		billingAdress: 'BillingStreet',
		status: {
			statusCaption: 'Ordered',
			subStatus: 'Your order has been submitted but is pending price confirmation',
			statusType: 'step'
		},
		deliveryType: 'Delivery',
		paymentTerm: 'Prepayment'
	}

	beforeEach(() => {
		angular.mock.module('app');
		angular.mock.module('app.dashboard');
	});

	beforeEach(angular.mock.inject((_$rootScope_, _$componentController_, _OrderStatusListService_) => {

		$componentController = _$componentController_;
		statusService = _OrderStatusListService_
		$rootScope = _$rootScope_;
	}));

	it('should call OrderStatusListService to get Data', () => {

		spyOn(statusService, 'setTypeData');
		spyOn(statusService, 'getTotalStepNumber');
		spyOn(statusService, 'getStepNumber');
		spyOn(statusService, 'getStepLabels');

		component = $componentController(
			'orderStatus', {
				$scope: $rootScope.$new()
			}, {
				order: order,
				type: 'active'
			}
		);

		expect(statusService.setTypeData).toHaveBeenCalledWith(order.deliveryType, order.paymentTerm);
		expect(statusService.getTotalStepNumber).toHaveBeenCalled();
		expect(statusService.getStepNumber).toHaveBeenCalledWith(order.status.statusCaption);
		expect(statusService.getStepLabels).toHaveBeenCalled();
	});

	it('should create correct values of the OrderStatusListService Data', () => {

		spyOn(statusService, 'setTypeData');
		spyOn(statusService, 'getTotalStepNumber').and.returnValue(3);
		spyOn(statusService, 'getStepNumber').and.returnValue(2);
		spyOn(statusService, 'getStepLabels').and.returnValue(['Test1', 'Test2', 'Test3']);

		component = $componentController(
			'orderStatus', {
				$scope: $rootScope.$new()
			}, {
				order: order,
				type: 'active'
			}
		);

		expect(component.hasError).toBe(false);
		expect(component.showError).toBe(false);
		expect(component.progressIndicatorRange.length).toBe(3);
		expect(component.progressIndicatorRange[0]).toBe('success');
		expect(component.progressIndicatorRange[1]).toBe('inProgress');
		expect(component.progressIndicatorRange[2]).toBe('');
		expect(component.stepNumbers).toBe(3);
		expect(component.stepNumber).toBe(2);
		expect(component.stepLabels).toEqual(['Test1', 'Test2', 'Test3']);
		expect(component.progressWidth.width).toEqual('30%');
	});

	it('should set the showError Flag', () => {

		order.status = {
			statusCaption: 'Declined',
			subStatus: 'Your order has been declined',
			statusType: 'error'
		}

		spyOn(statusService, 'setTypeData');
		spyOn(statusService, 'getTotalStepNumber').and.returnValue(3);
		spyOn(statusService, 'getStepNumber').and.returnValue(2);
		spyOn(statusService, 'getStepLabels').and.returnValue(['Test1', 'Test2', 'Test3']);

		component = $componentController(
			'orderStatus', {
				$scope: $rootScope.$new()
			}, {
				order: order,
				type: 'past'
			}
		);

		expect(component.hasError).toBe(false);
		expect(component.showError).toBe(true);
		expect(component.progressIndicatorRange.length).toBe(3);
		expect(component.progressIndicatorRange[0]).toBe(undefined);
		expect(component.progressIndicatorRange[1]).toBe(undefined);
		expect(component.progressIndicatorRange[2]).toBe(undefined);
	});

	it('should set the alert Flag', () => {

		order.status = {
			statusCaption: 'Ordered',
			subStatus: 'Your order has been submitted but is blocked as you have exceeded the credit limit',
			statusType: 'alert'
		}

		spyOn(statusService, 'setTypeData');
		spyOn(statusService, 'getTotalStepNumber').and.returnValue(3);
		spyOn(statusService, 'getStepNumber').and.returnValue(2);
		spyOn(statusService, 'getStepLabels').and.returnValue(['Test1', 'Test2', 'Test3']);

		component = $componentController(
			'orderStatus', {
				$scope: $rootScope.$new()
			}, {
				order: order,
				type: 'active'
			}
		);

		expect(component.hasError).toBe(false);
		expect(component.showError).toBe(false);
		expect(component.progressIndicatorRange.length).toBe(3);
		expect(component.progressIndicatorRange[0]).toBe('success');
		expect(component.progressIndicatorRange[1]).toBe('alert');
		expect(component.progressIndicatorRange[2]).toBe('');
	});

	it('should set the hasError Flag', () => {

		spyOn(statusService, 'hasError').and.returnValue(true);

		component = $componentController(
			'orderStatus', {
				$scope: $rootScope.$new()
			}, {
				order: order,
				type: 'active'
			}
		);

		expect(component.hasError).toBe(true);
		expect(component.showError).toBe(false);
		expect(component.progressIndicatorRange.length).toBe(0);
	});

});
