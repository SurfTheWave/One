import './orderStatus.sass'
import template from './orderStatus.tpl.html';
import OrderStatusController from './orderStatus.controller.js';

let orderStatus = {

	template: template,
	controller: OrderStatusController,
	bindings: {
		order: '<',
		type: '<'
	}
}

export default orderStatus;