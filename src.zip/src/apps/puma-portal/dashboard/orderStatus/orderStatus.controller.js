/**
 * @ngdoc overview
 * @name OrderStatusController
 * @description
 * Controller for the orderStatus Component which builds the data required for progressbars and display of status values
 */
class OrderStatusController {

	constructor(OrderStatusListService) {

		'ngInject'
		this.hasError = false;
		this.showError = false;
		this.OrderStatusListService = OrderStatusListService;

		/** collects required Data from the OrderStatusListService */
		this.OrderStatusListService.setTypeData(this.order.deliveryType, this.order.paymentTerm);
		this.stepNumbers = this.OrderStatusListService.getTotalStepNumber();
		this.stepNumber = this.OrderStatusListService.getStepNumber(this.order.status.statusCaption);
		this.stepLabels = this.OrderStatusListService.getStepLabels();
		this.progressIndicatorRange = [];

		/** flag will be used in the template to hide or show the error message */
		if (this.OrderStatusListService.hasError) {

			this.hasError = true
		} else {

			/** creates an array equal to the amount of order steps which holds information about the status of a step */
			this.progressIndicatorRange = new Array(this.stepNumbers);


			for (let iterator = 0; iterator < this.stepNumbers; iterator++) {

				/** If the current Step is an error just set the flag to display its message and skip further processing */
				if (this.order.status.statusType === 'error') {

					this.showError = true;
					break;
				} else {

					/** locates the current step, marks past steps with success, the actual step with inProgress or alert Status */
					if (this.stepNumber > iterator + 1
						|| (this.stepNumber === this.stepNumbers
							&& (iterator + 1) == this.stepNumber)) {

						this.progressIndicatorRange[iterator] = 'success';
					} else if (this.stepNumber === iterator + 1 && iterator + 1 !== this.stepNumbers) {

						if (this.order.status.statusType === 'alert') {

							this.progressIndicatorRange[iterator] = 'alert';
						} else {

							this.progressIndicatorRange[iterator] = 'inProgress';
						}
					} else {

						this.progressIndicatorRange[iterator] = '';
					}
				}
			}

			/** calculates the width for every progressbar which is used as css map in the template */
			this.progressWidth = {

				'width': parseInt(90 / this.progressIndicatorRange.length) + '%'
			};
		}
	}

	/**
	 * @ngdoc function
	 * @name showComponent
	 * @param {String} the name of the component for which the display condition should be checked 
	 * @description
	 * returns true if all display conditions are met and the component should be displayed in the view 
	 */
	showComponent(type) {

		if (type === 'orderDetails') {

			return (this.order.status.statusType === 'alert' || (this.type === 'past' && this.stepNumber === this.stepNumbers));
		}

		if (type === 'scheduling') {

			return (this.order.status.statusType === 'step' && this.type === 'active' && this.order.deliveryType === 'Ex-Rack');
		}

		if (type === 'shipping') {

			return (this.order.status.statusType === 'step' && this.type === 'active' && this.order.deliveryType === 'Delivery');
		}

		if (type === 'billing') {

			return (this.order.status.statusType === 'step' && this.type === 'active');
		}

	}
}
export default OrderStatusController;