/*@ngInject*/
export default class DashboardController {
	constructor(store, accountService) {
		this.accountService = accountService;
	}

	$onInit(){
		this.accountService.getSellToAccount().then((account)=>{
			this.sellTo = account;
		});
	}
}