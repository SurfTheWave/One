import './new-order.sass';
import template from './new-order.tpl.html';
import NewOrderController from './new-order.controller.js';

let newOrder = {
    template: template,
    controller: NewOrderController
};

export default newOrder;