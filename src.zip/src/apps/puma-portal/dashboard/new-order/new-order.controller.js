import Account from 'youOne/services/account/account.class.js';
/*@ngIject@*/
export default class NewOrderController {
	constructor($scope, accountService, orderService, $q, $filter, modalDialog, $location, $element, $timeout) {
		'ngInject'
		this.$scope = $scope;
		this.accountService = accountService;
		this.orderService = orderService;
		this.$q = $q;
		this.$filter = $filter;
		this.$location = $location;
		this.modalDialog = modalDialog;
		this.$element = $element;
		this.$timeout = $timeout;

		$scope.Account = Account; //Link to Account class

		this.sellToAccount = null; //SellTo account, which we are making order for
		this.selectedSite = null; //For Delivery site which were selected to make an order, default when site is single
		this.deliveryType = null; //Delivery type of new order Ex-Rack or Delivery

		this.newOrderInfo = null; //API response for newOrderInfo call
		this.orderComponents = [];
		this.selectedOrderComponent = null;

		this.terminalAlertShown = false;
		this.componentPrice = null; //API Response with calculated prices for selected order component

		this.selectShown = false;
		this.isMultiSite = false;
	}

	//Get Selected SellToAccount from the list
	getSellTo(){
		var self = this;
		return this.accountService.getSellToAccount().then(
			function onSuccess(sellToAccount){
				self.deliveryType = sellToAccount.getDeliveryType;
				return self.sellToAccount = sellToAccount;
			}
		);
	}

	//Select order info, containing delivery type, status, order from the list.
	getNewOrderInfo(){
		var self = this;
		this.orderService.getNewOrderInfo(this.sellToAccount.id).then((newOrderInfo) => {
			self.newOrderInfo = newOrderInfo;
			self.deliveryType = newOrderInfo.deliveryType;

			if (newOrderInfo.deliveryType == Account.DeliveryType.ExRack){
				self.selectedOrderComponent = newOrderInfo.getNewOrderComponent();
				self.selectedOrderComponent.sellToId = this.sellToAccount.id;
				self.orderComponents.push(self.selectedOrderComponent);
			} else {
				if (newOrderInfo.shipToList.length === 1) {
					self.selectSite(newOrderInfo.shipToList[0]);
				} else {
					self.isMultiSite = true;
				}
			}
		});
	}

	//Returns list of available terminals which contain selected product
	getAvailableProductTerminals(productInfo){
		if (this.deliveryType === Account.DeliveryType.Delivery || !this.newOrderInfo){
			return null;
		} else {
			var resultString = 'Not available in terminals';
			if (Array.isArray(this.newOrderInfo.terminalInfoList)) {
				var teminalNamesArray = [];
				for (var terminalInfo of this.newOrderInfo.terminalInfoList) {
					if (terminalInfo.availableProductIds &&
						terminalInfo.availableProductIds.indexOf(productInfo.productId) > -1){
						teminalNamesArray.push(terminalInfo.terminalName);
					}
				}
				if (teminalNamesArray.length > 4){
					resultString = 'Available in ' + teminalNamesArray.slice(0, 3).join(', ') +
						' and ' + (teminalNamesArray.length - 3) + ' more';
				} else {
					resultString = 'Available in ' + teminalNamesArray.join(', ');
				}

			}
			return resultString;
		}
	}

	//Renders list of available terminals based on selected products
	getListOfAvailableTerminals(){
		//Step should be skiped for delivery type
		if (this.deliveryType === Account.DeliveryType.Delivery || !this.selectedOrderComponent){
			return null;
		}
		//Get list of selected products from the form
		var selectedProductsIds = this.selectedOrderComponent.getSelectedProductIds();

		if (!selectedProductsIds.length){
			return this.newOrderInfo.terminalInfoList;
		} else {
			return this.newOrderInfo.getTerminalsForProductIds(selectedProductsIds);
		}
	}

	displayTerminalAlertIfNeeded(){
		var self = this;
		if (this.deliveryType === Account.DeliveryType.ExRack) {
			var terminalList = this.getListOfAvailableTerminals();
			if (!this.terminalAlertShown && (!terminalList || terminalList.length === 0)) {
				if (this.$element){
					this.$timeout(function() {
						self.$element.find('button').focus();
					}, 500);
				}
				this.modalDialog('alert', ['OK'],
						'There is no terminals containing all selected products, please create ' +
						'multiple orders with different terminals',
					'No terminals available');
				this.terminalAlertShown = true;
			} else if (terminalList.length > 0) {
				this.terminalAlertShown = false;
			}
		}
	}

	isDateAvailableForOrder($date) {
		//var activeDate = moment($scope.dateRangeStart).subtract(1, $view).add(1, 'minute');
		if (!this.newOrderInfo || !this.selectedOrderComponent){
			return false;
		}
		if (this.deliveryType === Account.DeliveryType.Delivery){
			var reachedTime = new Date().getTime();
			//If cutoff reached then we cannot make delivery tomorrow as well, only day after tomorrow
			if (this.newOrderInfo.cutOffTimeReached){
				reachedTime += 24 * 60 * 60 * 1000;
			}
			return $date.getTime() > reachedTime;
		} else {
			//Return true if this day could be found in list of available days
			return !!this.newOrderInfo.getTerminalDayData(this.selectedOrderComponent.terminalId, $date);
		}
	}

	cancelSelectedTerminal(){
		if (this.deliveryType === Account.DeliveryType.ExRack) {
			this.selectedOrderComponent.terminalId = null;
			this.cancelSelectedDayTime();
		}
	}

	cancelSelectedDayTime(){
		if (this.deliveryType === Account.DeliveryType.ExRack) {
			this.selectedOrderComponent.orderDate = null;
			this.selectedOrderComponent.orderTime = null;
			this.componentPrice = null;
		}
	}

	cleanNonNumberAmount(productId){
		if (this.selectedOrderComponent) {
			var amount = this.selectedOrderComponent.productAmounts[productId];
			if (isNaN(amount)  || amount <= 0){
				this.selectedOrderComponent.productAmounts[productId] = null;
			}
		}
	}


	recalculateDeliveryTimeArray(){
		if (this.deliveryType === Account.DeliveryType.Delivery){
			this.deliveryTimeArray = ['AM', 'PM'];
		} else {
			this.deliveryTimeArray = [];
			let selectedDate = this.selectedOrderComponent.orderDate,
				selectedTerminalId = this.selectedOrderComponent.terminalId;
			if (this.selectedOrderComponent) {
				var terminalDayData = this.newOrderInfo.getTerminalDayData(selectedTerminalId, selectedDate);
				//Do change if terminal is working on those day
				if (terminalDayData && Array.isArray(terminalDayData.timePeriods)) {
					for (let timePeriod of terminalDayData.timePeriods){
						var timePeriodStartString = String(timePeriod.startTime).substring(0,5),
							timePeriodEndString = String(timePeriod.endTime).substring(0,5);

						this.deliveryTimeArray.push(timePeriodStartString + ' - ' + timePeriodEndString);
					}
				}
			}
		}

		if (this.selectedOrderComponent && this.deliveryTimeArray.indexOf(this.selectedOrderComponent.orderTime) === -1){
			this.selectedOrderComponent.orderTime = null;
		}
	}

	recalculatePriceWhenNeeded(){
		this.componentPrice = null;
		if (this.formIsReadyForSubmission(true)){
			this.recalculateOrderComponentPrice(true);
		}
	}

	formIsReadyForSubmission(forPrice){
		if (!this.selectedOrderComponent){
			return false;
		}

		if (this.deliveryType == Account.DeliveryType.ExRack){
			return this.selectedOrderComponent.orderTime && this.selectedOrderComponent.orderDate &&
				   this.selectedOrderComponent.terminalId && (this.selectedOrderComponent.truckPlate || forPrice) &&
				   this.selectedOrderComponent.getSelectedProductIds().length > 0;
		} else {
			return this.selectedOrderComponent && this.selectedOrderComponent.orderDate &&
				this.selectedOrderComponent.orderTime && this.selectedOrderComponent.getSelectedProductIds().length > 0;
		}
	}

	productsAreNotSelectedFoxExRack(){
		return this.deliveryType === Account.DeliveryType.ExRack &&
			!this.selectedOrderComponent.getSelectedProductIds().length;
	}

	recalculateOrderComponentPrice(){
		var self = this, defer;
		defer = self.priceDefer = self.orderService.calculateOrderPrice(this.selectedOrderComponent).then(
			function onSuccess(priceResponse){
				if (defer == self.priceDefer) {
					self.componentPrice = priceResponse;
					self.priceDefer = null;
				}
			}
		);
	}

	//ShipTo site selection
	selectSite(siteData){
		if (this.selectedSite != null){
			this.orderComponents = [];
		}

		this.selectedSite = siteData;
		this.selectedOrderComponent = this.newOrderInfo.getNewOrderComponent();
		this.selectedOrderComponent.sellToId = this.sellToAccount.id;
		this.selectedOrderComponent.shipToId = siteData.shipToId;
		this.orderComponents.push(this.selectedOrderComponent);
		this.selectShown = false;
	}

	cancelSiteSelection(){
		this.selectedSite = null;
		this.componentPrice = null;
		this.selectedOrderComponent = null;
		this.selectShown = false;
		this.orderComponents = [];
	}

	productIsAvailableForSelection(productId){
		if (this.deliveryType === Account.DeliveryType.Delivery) {
			return this.selectedSite && this.selectedSite.availableProductIds.indexOf(productId) > -1
		}
		return true;
	}


	//PRICE CALCULATION METHODS
	formattedCurrency(amount){
		let currencyCode = this.newOrderInfo ? this.newOrderInfo.currencyCode : '$';
		return this.$filter('currency')(amount, currencyCode + ' ')
	}

	submitOrder(){
		var self = this;
		if (!self.formIsReadyForSubmission()) { return; }
		return self.orderService.createNewOrder(this.orderComponents).then(function onSucces(orderInfo){
			return self.modalDialog('info', ['OK'],
					'New order ' + orderInfo.newOrderNumber +
					' has been successfully created.',
				'Operation finished' ).then(function(){
					self.$location.path('/dashboard');
				});
		});
	}

	cancelOrderCreation(showDialogIfFormEmpty){
		var self = this;
		if (showDialogIfFormEmpty && (!this.selectedOrderComponent ||
			!(this.selectedOrderComponent.orderTime || this.selectedOrderComponent.orderDate ||
			this.selectedOrderComponent.terminalId || this.selectedOrderComponent.getSelectedProductIds().length)
			)){
			return self.$location.path('/dashboard');
		}
		return this.modalDialog(
			'alert', 'yesno', 'Do you really want to cancel order creation?', 'Cancel order creation'
		).then((resolve) => {
			if (resolve === 'yes') {
				self.$location.path('/dashboard');
			}
		})
	}

	$onInit(){
		var self = this;

		this.$scope.$watch('$ctrl.selectedOrderComponent.orderDate', (newValue, oldValue) => {
			if (newValue != oldValue){
				this.recalculateDeliveryTimeArray();
			}
		});

		return this.getSellTo().then(function onSuccess(sellToAccount){
			return self.getNewOrderInfo();
		});
	}

}