import '../../app/app.js';
import '../dashboard.js';
import Account from 'youOne/services/account/account.class.js';

describe('Component: new-order', function() {
	var newOrderCtrl, $rootScope, accountService, orderService;
	var elementMock = {
		find: function () { return this; },
		focus: function () {}
	};

	beforeEach(() => {
		angular.mock.module('app');
		angular.mock.module('app.dashboard');
	});

	beforeEach(angular.mock.inject(function(_$rootScope_, _$componentController_, _$location_) {
		$rootScope = _$rootScope_;

		let $componentController = _$componentController_;
		newOrderCtrl = $componentController('newOrder', {
			$scope: $rootScope.$new(),
			$location: _$location_,
			$element: elementMock
		});

		accountService = newOrderCtrl.accountService;
		orderService = newOrderCtrl.orderService;
		$rootScope.$digest();
	}));

	describe('Form initialization', function() {
		it('should initalize multisite properly', function () {
			newOrderCtrl.$onInit();

			$rootScope.$digest();
			expect(newOrderCtrl.newOrderInfo.currencyCode).toEqual('$');
			expect(newOrderCtrl.isMultiSite).toEqual(true);
			expect(newOrderCtrl.deliveryType).toEqual(Account.DeliveryType.Delivery);
		});

		it('should autoselect single site', function () {
			accountService.defaultSellToIndex = 2;
			newOrderCtrl.$onInit();

			$rootScope.$digest();
			expect(newOrderCtrl.deliveryType).toEqual(Account.DeliveryType.Delivery);
			expect(newOrderCtrl.isMultiSite).toEqual(false);
			expect(newOrderCtrl.selectedSite).not.toBe(null);
			expect(newOrderCtrl.selectedOrderComponent.shipToId).toEqual(newOrderCtrl.selectedSite.shipToId);
		});

		it('should initialize ex-rack properly', function(){
			accountService.defaultSellToIndex = 1;
			newOrderCtrl.$onInit();

			$rootScope.$digest();
			expect(newOrderCtrl.deliveryType).toEqual(Account.DeliveryType.ExRack);
			expect(newOrderCtrl.isMultiSite).toEqual(false);
			expect(newOrderCtrl.selectedOrderComponent.sellToId).toEqual(accountService.sellToAccounts[1].id);
			expect(newOrderCtrl.selectedOrderComponent.deliveryType).toEqual(Account.DeliveryType.ExRack);
		});


		it('should return empty data when not initialized', function(){
			$rootScope.$digest();
			expect(newOrderCtrl.getAvailableProductTerminals()).toBe(null);
			expect(newOrderCtrl.getListOfAvailableTerminals()).toBe(null);
			expect(newOrderCtrl.isDateAvailableForOrder(new Date())).toEqual(false);
			expect(newOrderCtrl.formIsReadyForSubmission()).toEqual(false);
			expect(newOrderCtrl.productIsAvailableForSelection()).toEqual(true);
		});
	});

	describe('Ex-Rack order creation', function(){
		beforeEach(() => {
			newOrderCtrl.accountService.defaultSellToIndex = 1;
			newOrderCtrl.$onInit();
			$rootScope.$digest();
		});

		it ('should display available products per terminal', function(){
			newOrderCtrl.newOrderInfo.terminalInfoList = [
				{
					terminalName: 'Terminal 1',
					availableProductIds: ['product1']
				},
				{
					terminalName: 'Terminal 2',
					availableProductIds: ['product2']
				},
				{
					terminalName: 'Terminal 3',
					availableProductIds: ['product1', 'product2']
				}
			];

			//Create a lot of available terminals to see not all of them will be displayed directly
			//But total number of available terminals will
			var totalTerminalCount = Math.round(Math.random() * 10) + 6;
			for (let index = 4; index <= totalTerminalCount; index++){
				newOrderCtrl.newOrderInfo.terminalInfoList.push({
					terminalName: 'Terminal ' + index,
					availableProductIds: (index & 1) ? ['productx', 'product2', 'producty'] : ['product2']
				});
			}

			let product1Info = {productId : 'product1'}, product2Info = {productId : 'product2'};
			expect(newOrderCtrl.getAvailableProductTerminals(product1Info)).toEqual('Available in Terminal 1, Terminal 3');
			expect(newOrderCtrl.getAvailableProductTerminals(product2Info)).toContain((totalTerminalCount - 4) + ' more');
		});

		it ('should display only available terminals', function(){
			newOrderCtrl.newOrderInfo.terminalInfoList = [
				{
					terminalName: 'Terminal 1',
					availableProductIds: ['product1']
				},
				{
					terminalName: 'Terminal 2',
					availableProductIds: ['product2']
				},
				{
					terminalName: 'Terminal 3',
					availableProductIds: ['product1', 'product2']
				}
			];

			//Check if nothing selected then we display all terminals
			expect(newOrderCtrl.getListOfAvailableTerminals().length).toEqual(3);

			//Check if product is selected then terminal will contain specific result
			newOrderCtrl.selectedOrderComponent.productIds = ['product1', 'product2'];
			newOrderCtrl.selectedOrderComponent.productAmounts = {
				'product1' : 100,
				'product2' : 500
			};
			expect(newOrderCtrl.getListOfAvailableTerminals().length).toEqual(1);
		});


		it ('should display alert when no terminals available', function(){
			newOrderCtrl.newOrderInfo.terminalInfoList = [
				{
					terminalName: 'Terminal 1',
					availableProductIds: ['product1', 'product2']
				},
				{
					terminalName: 'Terminal 2',
					availableProductIds: ['product2', 'product3']
				},
				{
					terminalName: 'Terminal 3',
					availableProductIds: ['product3']
				}
			];

			//Check if nothing selected then we display all terminals
			expect(newOrderCtrl.getListOfAvailableTerminals().length).toEqual(3);

			//Check if product is selected then terminal will contain specific result
			newOrderCtrl.selectedOrderComponent.productIds = ['product1', 'product2', 'product3'];
			newOrderCtrl.selectedOrderComponent.productAmounts = {
				'product1' : 100,
				'product2' : 500,
				'product3' : 1000
			};
			newOrderCtrl.displayTerminalAlertIfNeeded();
			expect(newOrderCtrl.terminalAlertShown).toEqual(true);

			delete newOrderCtrl.selectedOrderComponent.productAmounts['product3'];
			newOrderCtrl.displayTerminalAlertIfNeeded();
			expect(newOrderCtrl.terminalAlertShown).toEqual(false);
		});

		it ('should cancel terminal on form change', function(){
			newOrderCtrl.selectedOrderComponent = {
				terminalId : 'terminal1',
				orderDate : new Date(),
				orderTime : '12:00'
			};

			newOrderCtrl.cancelSelectedTerminal();
			expect(newOrderCtrl.selectedOrderComponent.terminalId).toEqual(null);
			expect(newOrderCtrl.selectedOrderComponent.orderDate).toEqual(null);
			expect(newOrderCtrl.selectedOrderComponent.orderTime).toEqual(null);
		});

		it ('should prevent non number values', function(){
			newOrderCtrl.selectedOrderComponent.productAmounts = {
				'product1' : '23454.00+w324d',
				'product2' : '-5.234234'
			};

			newOrderCtrl.cleanNonNumberAmount('product1');
			newOrderCtrl.cleanNonNumberAmount('product2');

			expect(newOrderCtrl.selectedOrderComponent.productAmounts.product1).toBe(null);
			expect(newOrderCtrl.selectedOrderComponent.productAmounts.product2).toBe(null);
		});


		it ('should calculate date periods properly', function(){
			//TODO change it accordingly to Spiros scripts
		});

		it ('should do proper price calculation', function(){
			var orderComponent = newOrderCtrl.selectedOrderComponent;
			var productsCount = orderComponent.productIds.length;
			for (let productId in orderComponent.productIds) {
				orderComponent.productAmounts[productId] = 1000;
			}
			orderComponent.terminalId = 'terminal1';
			orderComponent.orderDate = new Date();
			orderComponent.orderTime = 'AM';
			expect(newOrderCtrl.formIsReadyForSubmission(true)).toEqual(true);
			expect(newOrderCtrl.formIsReadyForSubmission(false)).toEqual(false);

			newOrderCtrl.recalculatePriceWhenNeeded();
			$rootScope.$digest();

			expect(newOrderCtrl.productsAreNotSelectedFoxExRack()).toEqual(false);
		});
	});


	describe('Delivery order creation', function(){
		beforeEach(() => {
			newOrderCtrl.accountService.defaultSellToIndex = 0;
			newOrderCtrl.$onInit();
			$rootScope.$digest();
			newOrderCtrl.selectSite(newOrderCtrl.newOrderInfo.shipToList[0]);
		});

		it ('should successfully select website', function(){
			newOrderCtrl.selectSite(newOrderCtrl.newOrderInfo.shipToList[1]);
			var selectedSiteId = newOrderCtrl.newOrderInfo.shipToList[1].shipToId;
			expect(newOrderCtrl.selectedOrderComponent.shipToId).toEqual(selectedSiteId);
			expect(newOrderCtrl.selectedSite).not.toBe(null);
		});

		it ('should successfully cancel website selection', function(){
			newOrderCtrl.cancelSiteSelection();
			expect(newOrderCtrl.selectedSite).toBe(null);
			expect(newOrderCtrl.componentPrice).toBe(null);
		});

		it ('should submit product successfully', function(){
			var orderComponent = newOrderCtrl.selectedOrderComponent;
			orderComponent.orderDate = new Date();
			orderComponent.orderTime = 'AM';
			for (let productId in orderComponent.productIds) {
				orderComponent.productAmounts[productId] = 1000;
			}

			var deferred = newOrderCtrl.$q.defer();
			spyOn(newOrderCtrl, 'modalDialog').and.returnValue(deferred.promise);
			let submitPromise = newOrderCtrl.submitOrder();
			$rootScope.$digest();
			deferred.resolve();
			$rootScope.$digest();

			expect(newOrderCtrl.$location.path()).toEqual('/dashboard');
		});


		it ('should relocate on cancel creation when form is empty', function(){
			newOrderCtrl.cancelOrderCreation(true);
			expect(newOrderCtrl.$location.path()).toEqual('/dashboard');
		});

		it ('displays dialog on close when form is not empty', function(){
			var orderComponent = newOrderCtrl.selectedOrderComponent;
			orderComponent.orderDate = new Date();
			orderComponent.orderTime = 'AM';

			var resultPromise = newOrderCtrl.cancelOrderCreation(false);
			expect(resultPromise).not.toBe(null);
		});
	});
});