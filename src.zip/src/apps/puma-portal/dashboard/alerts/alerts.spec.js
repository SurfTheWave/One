import '../dashboard.js';

describe('Component: alerts', () => {
	var $scope, missingTankDipDatesDialogService;
	var sellToAccount = {
		shipToList: [
			{
				missingTankDipDates: [
					new Date()
				]
			},
			
			{
				missingTankDipDates: [
					new Date(),
					new Date()
				]
			}
		]
	};
	
	// Implement mock services used by alerts controller
	beforeEach(() => {
		angular.mock.module('app.dashboard');
		
		// Provide will help us create fake implementations for our dependencies
		angular.mock.module(($provide) => {
		
			// Mock accountService
			$provide.service('accountService', () => {
				return {
					getSellToAccount: () => {
						return {
							then: (callback) => {
								return callback(sellToAccount);
							}
						};
					}
				};
			});
			
			// Mock missingTankDipDatesDialogService service
			$provide.service('missingTankDipDatesDialogService', () => {
				return {
					open: () => {
						
					},
					
					close: () => {
						
					}
				};
			});
		});
	});
	
	// Assign injected services to local instances
	beforeEach(angular.mock.inject((_missingTankDipDatesDialogService_) => {
		missingTankDipDatesDialogService = _missingTankDipDatesDialogService_;
	}));
	
	// Create a new scope and create alerts component with newly created scope
	beforeEach(angular.mock.inject((_$rootScope_, _$componentController_) => {
		$scope = _$rootScope_.$new();
		
		_$componentController_('alerts', {
			$scope: $scope
		});
	}));
	
	it('is supposed to fill $scope.sites with shipToList of sellToAccount', () => {
		expect($scope.sites).toEqual(sellToAccount.shipToList);
	});
	
	it('is supposed to open missing tank dip dates dialog at calling onEnterLevelButtonClick', () => {
		spyOn(missingTankDipDatesDialogService, 'open');
		
		$scope.$ctrl.onEnterLevelButtonClick(sellToAccount.shipToList[0]);
		expect(missingTankDipDatesDialogService.open).toHaveBeenCalled();
	});
	
	it('is supposed to have missing tank dips available', () => {
		expect($scope.noMissingTankDipAvailable).toEqual(false);
	});
});