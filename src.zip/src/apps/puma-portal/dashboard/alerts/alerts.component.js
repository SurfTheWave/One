import './alerts.sass';
import template from './alerts.tpl.html';
import AlertsController from './alerts.controller.js';

let alerts = {
	template: template,
	controller: AlertsController
};

export default alerts;