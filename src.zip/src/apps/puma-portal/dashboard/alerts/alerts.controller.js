export default class AlertsController {
	constructor($window, $timeout, $log, $scope, missingTankDipDatesDialogService, accountService) {
		'ngInject';
		this.$window = $window;
		this.$timeout = $timeout;
		this.accountService = accountService;
		this.$log = $log;
		this.$scope = $scope;
		this.missingTankDipDatesDialogService = missingTankDipDatesDialogService;
		
		this.$log.debug('Alerts controller is created. Fetching sites to find missing tank dips...');
		
		this.$scope.noMissingTankDipAvailable = true;
		this.accountService.getSellToAccount().then((sellToAccount) => {
			_.forEach(sellToAccount.shipToList, (site) => {
				if(site.missingTankDipDates && site.missingTankDipDates.length > 0) {
					this.$scope.noMissingTankDipAvailable = false;
					
					this.$log.debug('For site ' + site.name + ', ' + site.missingTankDipDates.length + ' missing tank dip days found');
				}
			});
				
			this.$scope.sites = sellToAccount.shipToList;
		});
		
		// this.$scope.pastDueInvoicesList = [{
		// 	invoiceNumber: 0,
		// 	issueDate: new Date(),
		// 	dueDate: new Date(),
		// 	amount: 106456.5,
		// 	remainingBalance: 20145.2,
		// 	linkToPDF: 'http://www.google.com'
		// }, {
		// 	invoiceNumber: 1,
		// 	issueDate: new Date(),
		// 	dueDate: new Date(),
		// 	amount: 192823.3,
		// 	remainingBalance: 36271.0,
		// 	linkToPDF: 'http://www.google.com'
		// }, {
		// 	invoiceNumber: 2,
		// 	issueDate: new Date(),
		// 	dueDate: new Date(),
		// 	amount: 20839.9,
		// 	remainingBalance: 30800.7,
		// 	linkToPDF: 'http://www.google.com'
		// }];
	}
	
	onEnterLevelButtonClick(site) {
		this.$log.debug('User clicked Enter Level button');
		
		this.missingTankDipDatesDialogService.open(site, true);
	}
}