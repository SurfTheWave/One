export default class HelpmobileController {
	constructor($scope, $log, $window, accountService, platformSelectorService) {
		'ngInject';
		
		
		this.$scope = $scope;
		this.accountService = accountService;
		this.sellToAccount = null;
		this.platformSelectorService = platformSelectorService; // Sell to account which is showing
		
		// Setting menu and component configurations
		// TODO: We can move configurations different place. @AlperG.
		$scope.subTabs = [{subNavItemName:'MAINTENANCE', id:1},{subNavItemName:'ORDER TRACKING', id:2}
							,{subNavItemName:'ORDER PLACEMENT', id:3},{subNavItemName:'DIP MEASUREMENT', id:4}
							,{subNavItemName:'INVOICE MANAGEMENT', id:5},{subNavItemName:'CASE MANAGEMENT', id:6}],
		$scope.helps = [{
			name:'MostPopularTopics',
			componentName:'mostpopulartopic',
			mobilePath:'MostPopularTopics',
			description:'mostpopulartopic description'
		}, {
			name: 'SiteManagement',
			componentName:'sitemanagement',
			mobilePath:'SiteManagement',
			description:'sitemanagement description',
			subNavItems: [],
		}, {
			name: 'CaseManagement',
			mobilePath:'CaseManagement',
			componentName:'casemanagement',
			description:'casemanagement description',
		},{
		name: 'ContactUs',
		componentName: 'contactus',
		mobilePath:'ContactUs',
		description:'contactus description',
	
	}];
	//this.fillNavItemsAndGetSellTo();
	}
	
	/*fillNavItemsAndGetSellTo() {
		var self = this;
		return this.accountService.getSellToAccount().then(
			function onSuccess(sellToAccount) {
				self.sellToAccount = sellToAccount;
				self.fillSiteNavigationItems();
				return;
			}
		);
	}*/
	
	fillSiteNavigationItems() {
		var accountAndSitesSettings = this.$scope.helps[1];
		var subTabs= this.$scope.subTabs[1];
		for(let shipTo of this.sellToAccount.shipToList) {
			accountAndSitesSettings.subNavItems.push({subNavItemName:subTabs.subNavItemName, id:subTabs.id});
		}
	}
	
	/*$onInit() {
		this.$rootScope.$broadcast('showHeader');
		
		this.platformSelectorService.registerPlatformTypeChangeEvent((newPlatform) => {
			// If changed to tablet or desktop and we are showing a site detail page, show the header
			this.$rootScope.$broadcast('showHeader');
		});
	}*/
}