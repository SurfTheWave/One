/**
 * @ngdoc directive
 * @name settings-mobile
 * @restrict 'E'
 * @param {text} router - Router text for settings-mobile page navigation
 * @description
 * Includes settings page with a sub menu and menu item contents (e.g. profile settings, account and sites pages etc.)
 * Each settigs view consist of information of sell to and ship to accounts
 */

import '../help.sass';
import template from './help.mobile.tpl.html';
import HelpmobileController from './help.mobile.controller.js';

let helpMobile = {
	template: template,
	controller: HelpmobileController,
	bindings: {
		$router: '<'
	}
};

export default helpMobile;