/**
 * @ngdoc directive
 * @name site-detail
 * @restrict 'E'
 * @param {string} shipToId - Id for ship to account (ship to account == site)
 * @description
 * The site detail component includes site related information (e.g. site address, site's tank information etc.)
 */

import './sm-detail.sass';
import template from './sm-detail.tpl.html';
import SmDetailController from './sm-detail.controller.js';

let smDetail = {
	template: template,
	controller: SmDetailController,
	bindings: {
		shipToId: '<'
	}
};

export default smDetail; 