
export default class SmDetailController {
	constructor($scope, accountService,siteManagementDialogService, pumaConnector) {

		'ngInject'
		this.$scope = $scope;
		this.accountService = accountService;
		this.shipToAccount = null;
		this.siteManagementDialogService= siteManagementDialogService;
		this.pumaConnector = pumaConnector;
		$scope.subNavId = null;
		
		this.$routerOnActivate = function(next) {	
			this.subNavId = next.params.id;
			console.log("this.subNavId",this.subNavId);
			if(this.subNavId > 0){
				
				this.$scope.subNavRec = this.$scope.subNavList[this.subNavId - 1];
			}
			console.log('subNavRec',this.$scope.subNavRec);
	
		};
		
		$scope.helpList = $scope.$parent.helps;
		$scope.subNavIdList = [];
		$scope.subNavNameList = [];
		$scope.subNavList = [];
		
		_.forEach(this.$scope.helpList, (help) => {
				if(help.subNavItems){
					
					_.forEach(help.subNavItems, (subHelp) => {
						
						this.$scope.subNavIdList.push(subHelp.id);
						this.$scope.subNavNameList.push(subHelp.subNavItemName);
						
						this.$scope.subNavList.push({subNavName : subHelp.subNavItemName,id : subHelp.id});
						
					});
				}
			});
		$scope.subNavRec = null;
		console.log("subNavList",this.$scope.subNavList);	
		   var limitStep = 3;
		//$scope.myValue = true;
		$scope.limit = limitStep;
		$scope.incrementLimit = function() {
			
			$scope.limit += limitStep;
			$scope.myValue = true;
			
		};
		 pumaConnector.query({objectApiName: 'FAQ__kav',where: {'PublishStatus' : {$eq : 'Online'},
    'Language':{$eq:'en_US'}},
     fields:['Id','Language','ArticleNumber','PublishStatus','Answer__c',
	 'Question__c','EP_FE_Featured__c','CreatedDate','CreatedById','EP_FE_Article_Body__c','LastPublishedDate'] }).then(function(result){
    
				   $scope.FAQrec =  result;
				   $scope.length = result.length;
				      
                  },function error(eerrrr){
					   console.log(eerrrr);
					       alert(eerrrr.message);
					});
		
	}

	onDetailsButtonClick(site) {
		this.siteManagementDialogService.open(site, true);
	}
	
	
}