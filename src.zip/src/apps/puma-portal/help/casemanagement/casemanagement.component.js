import './casemanagement.sass';
import template from './casemanagement.tpl.html';
import casemanagementController from './casemanagement.controller.js';

let casemanagementtab = {
	template: template,
	controller: casemanagementController,
	controllerAs: '$ctrl'
	
};

export default casemanagementtab;