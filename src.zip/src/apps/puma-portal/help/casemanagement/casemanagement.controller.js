import HelpBase from '../helpBase.class.js';

export default class casemanagementController extends HelpBase{
constructor($window,$scope,$filter,$timeout,pumaConnector,
				$log,accountService,caseRecordInfoDialogService,
				caseManagementDialogService,$rootScope,platformSelectorService, platformType
								,caseService){
	'ngInject';

	super($rootScope, platformSelectorService, platformType);

	this.$scope = $scope;
	this.$filter = $filter;
	this.caseManagementDialogService = caseManagementDialogService;
	this.$timeout = $timeout;
	this.accountService = accountService;
	this.$log = $log;
	this.caseRecordInfoDialogService = caseRecordInfoDialogService;
	this.pumaConnector = pumaConnector;
	this.$rootScope = $rootScope;

	var keepGoing = true;
	this.caseService = caseService;
	//this.caseCommentsService = caseCommentsService;
	$scope.selectedFromDate;
	$scope.selectedToDate;
	$scope.userList = [];

	var date2 = new Date();

	$scope.value = $filter('date')(new Date(), 'dd-MM-yyyy');
	$scope.value2 = $filter('date')(new Date(), 'dd-MM-yyyy');
	var limitStep = 3;
	//$scope.myValue = true;
	$scope.limit = limitStep;
	$scope.incrementLimit = function() {
	
	$scope.limit += limitStep;
	$scope.myValue = true;
	
	};
	$scope.decrementLimit = function() {
	$scope.limit -= limitStep;
	};
	//in this method first if is working but 2nd if is not working.                            
	$scope.filterFn = function(car)
	{      
		let dateCreatedDateArray = car.CreatedDate.split('-');
		let selectedCreatedDate = new Date(dateCreatedDateArray[0],dateCreatedDateArray[1]-1,dateCreatedDateArray[2].substring(0, 2));

		if(keepGoing){						
			if($scope.selectedToDate < $scope.selectedFromDate) {			
				$scope.errorMessage = "From Date cannot be greater than To Date";
				keepGoing = false;
			}
		}      		
		if(selectedCreatedDate >= $scope.selectedFromDate
			&& selectedCreatedDate <= $scope.selectedToDate){
				keepGoing = true;
				$scope.errorMessage = "";
				console.log('111111111111');
				return true; 
			}
				console.log('2222222222222');
				return false;
	};

   // to avoid refresh on Case Management tab click refresh data
         $scope.casesRec = $rootScope.noOfCases;
  
         //retrieve cases from case service
         
         this.caseService.getCaseManagementData().then((caseDataList) => {
             console.log("caseDataList---",caseDataList);
             $scope.casesRec = caseDataList;
  			 $scope.length = caseDataList.length;
	     });
		 
																												
}

onFromFilterClick(){	
	this.$scope.selectedFromDate = this.getFromDatePickerValue();
}

onToFilterClick(){	
	this.$scope.selectedToDate = this.getToDatePickerValue();
}

getToDatePickerValue(){
	let dateArray = this.$scope.value2.split('-');
	let selectedToDate = new Date(dateArray[2], dateArray[1]-1, dateArray[0]);
	return selectedToDate;
}
getFromDatePickerValue(){
	let dateArray = this.$scope.value.split('-');
	let selectedFromDate = new Date(dateArray[2], dateArray[1]-1, dateArray[0]);
	return selectedFromDate;
}

onEnterLevelButtonClick() {
	this.caseManagementDialogService.open();
}
 getCaseDetail(cRec) {
	this.caseRecordInfoDialogService.open(cRec);
}

}
