import './help.sass';
import template from './help.tpl.html';
import HelpController from './help.controller.js';

let help = {
	template: template,
	controller: HelpController,
	$routeConfig: [{
		path: '/most-popular-topics',
		name: 'MostPopularTopics',
		component: 'mostpopulartopic',
		useAsDefault: true	
	}/*,{
		//path: '/',
		//name: 'HelpMobile',
		//component: 'helpMobile',		
	}*/,{
		path: '/site-management',
		name: 'FaqLibrary',
		component: 'sitemanagement'
	},{
		path: '/site-management-subtab',
		name: 'SitemanagementSubtabs',
		component: 'sitemanagementsubtabList'		
	},{
		path: '/sm-detail/:id',
		name: 'SmDetail',
		component: 'smDetail'
	},{
		path: '/casemanagement',
		name: 'CaseManagement',
		component: 'casemanagement'
	},{
		path: '/Contactus',
		name: 'ContactUs',
		component: 'contactus'
	
	}],
	bindings: {
		$router: '<'
	}
};

export default help;