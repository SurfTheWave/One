export default class SiteManagementController {
	constructor($window, $timeout, $log, $scope,caseResolutionDialogService,
				caseConfirmDialogService, siteManagementDialogService, accountService, 
				caseResolutionThankyouDialogService, pumaConnector) {
		'ngInject';
		this.$window = $window;
		this.$timeout = $timeout;
		this.accountService = accountService;
		this.$log = $log;
		this.$scope = $scope;
		this.siteManagementDialogService = siteManagementDialogService;
		this.caseResolutionThankyouDialogService = caseResolutionThankyouDialogService;
		this.caseResolutionDialogService = caseResolutionDialogService;
        this.caseConfirmDialogService = caseConfirmDialogService;
        this.pumaConnector = pumaConnector;
		this.$scope.noMissingTankDipAvailable = true;
		this.$scope.name1 = 'Maintenance';
		this.$scope.name2 = 'Order Tracking';
		this.$scope.name3 = 'Order Placement';
		this.$scope.name4 = 'Dip Measurement';
		this.$scope.name5 = 'Invoice Management';
		this.$scope.name6 = 'Case Management';
		this.accountService.getSellToAccount().then((sellToAccount) => {
			_.forEach(sellToAccount.shipToList, (site) => {

					if(site.missingTankDipDates && site.missingTankDipDates.length > 0) {						
						this.$scope.noMissingTankDipAvailable = false;
						
					}
				});
				
				$scope.sites = sellToAccount.shipToList;
		});
		
		if(this.route) {
			this.text = this.route.replace(/([A-Z])/g, ' $1').trim();
		}
		
		$scope.shipToId = null; // Hold shipToId
		
		// Get site id as a site URL parameter.
		this.$routerOnActivate = function(next, previous) {	
			$scope.shipToId = next.params.id;
		};
        
		 var limitStep = 3;
		$scope.limit = limitStep;
		$scope.incrementLimit = function() {
			
			$scope.limit += limitStep;
			$scope.myValue = true;
			

		};
		$scope.decrementLimit = function() {
			$scope.limit -= limitStep;
		};
		
		
	pumaConnector.query({objectApiName: 'FAQ__kav',where: {'PublishStatus' : {$eq : 'Online'},
    'Language':{$eq:'en_US'}},
     fields:['Id','Language','ArticleNumber','PublishStatus','Answer__c',
	 'Question__c','EP_FE_Featured__c','CreatedDate','CreatedById','EP_FE_Article_Body__c','LastPublishedDate'] }).then(function(result){
			$scope.FAQrec =  result;
			$scope.length = result.length;

		},function error(eerrrr){
			console.log(eerrrr);
				
		});
	}	
	
	onEnterLevelButtonClick(site) {
		this.$log.debug('User clicked Enter Level button');		
		//this.missingTankDipDatesDialogService.open(site, true);
		this.siteManagementDialogService.open(site, true);
	}
	onEnterConfirmThankyouClick(site) {
		this.$log.debug('User clicked Enter Level button');		
		//this.missingTankDipDatesDialogService.open(site, true);
		this.caseResolutionThankyouDialogService.open(site, true);
	}
	onEnterReportCaseClick(site) {
        this.$log.debug('User clicked Enter Level button');     
        //this.missingTankDipDatesDialogService.open(site, true);
        this.caseConfirmDialogService.open(site, true);
    }
    
    onEnterConfirmClick(site) {
        this.$log.debug('User clicked Enter Level button');     
        //this.missingTankDipDatesDialogService.open(site, true);
        this.caseResolutionDialogService.open(site, true);
    }
	
	isRouteActive(primaryRoute, secondaryRoute) {
		
		var isRouteActive = false;
		if(this.subNavItems){
			for(let subItem of this.subNavItems){
				isRouteActive |= this.$router.isRouteActive(this.$router.generate(['./' + secondaryRoute, {id:subItem.id}]));
			}
		}
		return isRouteActive || this.$router.isRouteActive(this.$router.generate(['./' + primaryRoute]));
	}
}
