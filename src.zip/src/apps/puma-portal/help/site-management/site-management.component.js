import './site-management.sass';
import template from './site-management.tpl.html';
import SiteManagementController from './site-management.controller.js';

let sitemanagement = {
	template: template,
	controller: SiteManagementController
};

export default sitemanagement;