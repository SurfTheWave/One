import './help-nav-item.sass';
import template from './help-nav-item.tpl.html';
import HelpNavItemController from './help-nav-item.controller.js';

let helpNavItem = {
	template: template,
	controller: HelpNavItemController,
	bindings: {
		route: '<',
		$router: '<',
		subNavItems: '<',
		subRoute: '<'
	}
};

export default helpNavItem;
