export default class HelpNavItemController {
	constructor($scope) {
		'ngInject';
		if(this.route) {
			this.text = this.route.replace(/([A-Z])/g, ' $1').trim();
		}
		
		$scope.IsVisible = false;
            $scope.ShowHide = function () {
                //If DIV is visible it will be hidden and vice versa.
                $scope.IsVisible = $scope.IsVisible ? false : true;
            }
	}
	
	/*isRouteActive(myRoute) {
		var isRouteActive = false;
		if(this.subNavItems){
			for(let subItem of this.subNavItems){
				isRouteActive |= this.$router.isRouteActive(this.$router.generate(['./' + myRoute, {id:subItem.id}]));
			}
		}
		return isRouteActive || this.$router.isRouteActive(this.$router.generate(['./' + myRoute]));
	}*/
	isRouteActive(primaryRoute, secondaryRoute) {
		
		var isRouteActive = false;
		if(this.subNavItems){
			for(let subItem of this.subNavItems){
				isRouteActive |= this.$router.isRouteActive(this.$router.generate(['./' + secondaryRoute, {id:subItem.id}]));
			}
		}
		return isRouteActive || this.$router.isRouteActive(this.$router.generate(['./' + primaryRoute]));
	}
}