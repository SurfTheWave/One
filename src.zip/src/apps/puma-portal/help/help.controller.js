export default class HelpController {
	constructor($scope, $log, $window, accountService,$rootScope,caseService) {
		'ngInject';
		this.visibilityState = 'closed';
		this.$rootScope = $rootScope;
		
		this.$scope = $scope;
		this.accountService = accountService;
		this.caseService = caseService;
		this.sellToAccount = null; // Sell to account which is showing
		$rootScope.noOfOpenCases = 0;
		
		
		this.caseService.getCaseManagementData().then((caseDataList) => {
 
            $rootScope.noOfCases = caseDataList;

        });
 
        //retrieve open cases count
        this.caseService.getOpenCases().then((count) =>{
            $rootScope.noOfOpenCases = count;
        });
		
		// Setting menu and component configurations
		// TODO: We can move configurations different place. @AlperG.
		$scope.subTabs = [{"firstName":"John", "lastName":"Doe"},
   							 {"firstName":"Anna", "lastName":"Smith"},
    						{"firstName":"Peter", "lastName":"Jones"}];
		$scope.helps = [{
			name:'MostPopularTopics',
			componentName:'mostpopulartopic',
			description:'mostpopulartopic description'
		}, {
			name: 'FaqLibrary',
			componentName:'sitemanagement',
			description:'sitemanagement description',
			subNavItems: [{subNavItemName:'Maintenance', id:1},{subNavItemName:'Order Tracking', id:2}
							,{subNavItemName:'Order Placement', id:3},{subNavItemName:'Dip Measurement', id:4}
							,{subNavItemName:'Invoice Management', id:5},{subNavItemName:'Case Management', id:6}],
			subRoute:'SmDetail'
		}, {
			name: 'CaseManagement',
			componentName:'casemanagement',
			description:'casemanagement description',
		},{
		name: 'ContactUs',
		componentName: 'contactus',
		description:'contactus description',
	
	}];
		
		this.fillNavItemsAndGetSellTo(); // Service call to get sell to account & fill nav site items
		$scope.settingToShowDetail = false;
		$scope.settingNameToShow = null;
		
		//header top container element
		let headerTopContainer = angular.element(document.getElementsByClassName('header-top-container'));
		//increase page container top position on back
		let pageContainer = angular.element(document.getElementsByClassName('page-container'));
		
		// Mobile setting item clicked
		$scope.onHelpClick = function(help) {

			$scope.settingToShowDetail = true;
			$scope.settingNameToShow = help.name.replace(/([A-Z])/g, ' $1').trim();
			
			//hide header top container when sub view is opened
			headerTopContainer.hide();
			//decrease page container top position
			pageContainer.css({top: '10px'});
		};
		
		// Mobile setting back button clicked
		$scope.onHelpBackButtonClick = function() {
			$log.debug('User clicked back button in mobile');
			$scope.settingNameToShow = null;
			$scope.settingToShowDetail = false;
			
			//show header top container when back from sub view
			headerTopContainer.show();
			//increase page container top position on back
			pageContainer.css({top: '72px'});
		};
		
		// Show or hide ng-outlet component
		$scope.ShowHelpComponent =function() {
			var display = angular.element(document.getElementById('desktop-view')).css('display');
			//var isMobile = (display === 'none');

			var isMobile = (display === 'none');

			return (isMobile) ? $scope.settingToShowDetail : true;
		};
	}
	
	fillNavItemsAndGetSellTo() {
		var self = this;
		return this.accountService.getSellToAccount().then(
			function onSuccess(sellToAccount) {
				self.sellToAccount = sellToAccount;
				self.fillSiteNavigationItems();
				return;
			}
		);
	}
	
	fillSiteNavigationItems() {
		var accountAndSitesSettings = this.$scope.helps[1];
		for(let shipTo of this.sellToAccount.shipToList) {
		//	accountAndSitesSettings.subNavItems.push({subNavItemName:shipTo.getName(), id:shipTo.getAccountNumber()});
		}
	}
	
	toggleVisibilityState() {
		this.visibilityState = this.visibilityState === 'open' ? 'closed' : 'open';
	}
	
	collapseMenu() {
		if( this.visibilityState === 'open' )
		{
			this.visibilityState = 'closed';
		}
	}
}