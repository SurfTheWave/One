import help from './help.component.js';
import helpNavItem from './help-nav-item/help-nav-item.component.js';
import helpSubNavItem from './help-sub-nav-item/help-sub-nav-item.component.js';
import mostpopulartopic from './most-popular-topics/most-popular-topics.component.js';
import sitemanagement from './site-management/site-management.component.js';
//import missingTankDipDatesDialogService from './missing-tank-dip-dates-dialog/missing-tank-dip-dates-dialog.service.js';
import casemanagement from './casemanagement/casemanagement.component.js';
import contactus from './contactus/contactus.component.js';
import angular from 'angular';
import 'puma-connector';
import helpNavItemMobile from './help-nav-item-mobile/help-nav-item-mobile.component.js';
import smDetail from './sm-detail/sm-detail.component.js';
import helpMobile from './help-mobile/help.mobile.component.js';
import sitemanagementsubtabList from './site-management-subtab/site-management-subtab.component.js';
import 'youOne/services/modal-dialog/modal-dialog.js';

angular.module('app.help', ['puma.helpService','puma.connector','modal-dialog'])
	.component('help', help)
	.component('helpNavItem', helpNavItem)
	.component('helpSubNavItem', helpSubNavItem)
	.component('helpNavItemMobile', helpNavItemMobile)
	.component('mostpopulartopic', mostpopulartopic)
	.component('sitemanagement', sitemanagement)
	.component('smDetail', smDetail)
	.component('helpMobile', helpMobile)
	.component('sitemanagementsubtabList', sitemanagementsubtabList)
	.component('casemanagement', casemanagement)
	.component('contactus', contactus);

