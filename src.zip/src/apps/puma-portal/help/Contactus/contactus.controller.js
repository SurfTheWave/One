import BaseDialogController from 'youOne/components/base-dialog/base-dialog.class.js';
//import LogOutController from 'app/logout/logout.controller.js';

export default class contactusController extends BaseDialogController{
	constructor($scope,modalDialog, $window,contactThankYouDialogService) {
		'ngInject';
		super('past', ...arguments);
		
		this.$scope = $scope;
		
		this.contactThankYouDialogService = contactThankYouDialogService;
		
		this.state = this.states.Submission;
		
		
		
		$scope.uploadFile = function(files) {
			var fd = new FormData();
			//Take the first selected file
			fd.append("file", files[0]);

			$http.post(uploadUrl, fd, {
				withCredentials: true,
				headers: {'Content-Type': undefined },
				transformRequest: angular.identity
			}).success( all ).error(damn );

		}
	}	
	
	sendMessage() {
		this.$log.debug('add case on Submit button clicked.');
		this.contactThankYouDialogService.open(true);
		//this.changeState(this.states.Success);
		
		/*let changeRequest = this.sellToAccountNotModified.getChangeRequestForUpdate(this.sellToAccount);
		this.accountService.updateSellToAccount(changeRequest).then((response) => {
			if(response.body[0].success === true) {
				this.changeRequestId = response.body[0].record.Name;
				this.$log.debug('Sell To account update request succesfully created with change request id:'+ this.changeRequestId);
				//change state to success
				this.changeState(this.states.Success);
			} else {
				this.changeState(this.states.Failure);
				this.$log.debug('Sell To account update request could not be created:'+ JSON.stringify(response));			
			}
		});*/
	}
	showConfirmDialogFrom(){
		this.contactThankYouDialogService.open();
	}
	
			
}