import './contactus.sass';
import template from './contactus.tpl.html';
import contactusController from './contactus.controller.js';

let contactus = {
	bindings: {
		title: '@',
		message: '@'
	},
	template: template,
	controller: contactusController,
	};

export default contactus;