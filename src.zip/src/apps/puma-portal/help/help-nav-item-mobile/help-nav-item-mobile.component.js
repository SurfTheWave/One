import './help-nav-item-mobile.sass';
import template from './help-nav-item-mobile.tpl.html';
import HelpNavItemMobileController from './help-nav-item-mobile.controller.js';

let helpNavItemMobile = {
	template: template,
	controller: HelpNavItemMobileController,
	bindings: {
		name: '<',
		description: '<'
	}
};

export default helpNavItemMobile;