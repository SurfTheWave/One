export default class HelpNavItemMobileController {
	constructor() {
		if(this.name) {
			this.text = this.name.replace(/([A-Z])/g, ' $1').trim();
		}
	}

}