export default class HelpBase {
	constructor($rootScope, platformSelectorService, platformType) {
		this.$rootScope = $rootScope;
		this.platformSelectorService = platformSelectorService;
		this.platformType = platformType;
	}
	
	$onInit() {
		if(this.platformSelectorService.isMobile()) {
			this.$rootScope.$broadcast('hideHeader');
		}
		
		this.platformSelectorService.registerPlatformTypeChangeEvent((newPlatform) => {
			
			if(newPlatform === this.platformType.MOBILE) {
				this.$rootScope.$broadcast('hideHeader');
			}
			
			else {
				this.$rootScope.$broadcast('showHeader');
			}
		});
	}
}