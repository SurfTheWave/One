import './most-popular-topics.sass';
import template from './most-popular-topics.tpl.html';
import MostPopularTopicsController from './most-popular-topics.controller.js';

let mostpopulartopic = {
	template: template,
	controller: MostPopularTopicsController
};

export default mostpopulartopic;