export default class MostPopularTopicsController {
	constructor($window, $timeout, $log, $scope, mostpopularDialogService, siteManagementDialogService, accountService,pumaConnector) {
		'ngInject';
		this.$window = $window;
		this.$timeout = $timeout;
		this.accountService = accountService;
		this.$log = $log;
		this.$scope = $scope;
		this.pumaConnector = pumaConnector;
		//this.missingTankDipDatesDialogService = missingTankDipDatesDialogService;
		this.mostpopularDialogService= mostpopularDialogService;
        this.siteManagementDialogService = siteManagementDialogService;
		this.$scope.noMissingTankDipAvailable = true;
		$scope.FAQrec = [];
		this.accountService.getSellToAccount().then((sellToAccount) => {
			_.forEach(sellToAccount.shipToList, (site) => {
				//alert('hi------'+site);
					if(site.missingTankDipDates && site.missingTankDipDates.length > 0) {
						
						//alert('hi------'+site.missingTankDipDates);
						this.$scope.noMissingTankDipAvailable = false;
						
					}
				});
				
				$scope.sites = sellToAccount.shipToList;
		});
        var limitStep = 3;
		//$scope.myValue = true;
		$scope.limit = limitStep;
		$scope.incrementLimit = function() {
			
			$scope.limit += limitStep;
			$scope.myValue = true;
			
		};
		$scope.decrementLimit = function() {
			$scope.limit -= limitStep;
		};
		
    pumaConnector.query({objectApiName: 'FAQ__kav',where: {'PublishStatus' : {$eq : 'Online'},'EP_FE_Featured__c': {$eq : true},
    'Language':{$eq:'en_US'}},
     fields:['Id','Language','ArticleNumber','PublishStatus','Answer__c',
	 'Question__c','EP_FE_Featured__c','CreatedDate','CreatedById','EP_FE_Article_Body__c','LastPublishedDate'] }).then(function(result){

		$scope.FAQrec =  result;
		$scope.length = result.length;
		    
		},function error(eerrrr){
			console.log(eerrrr);
				alert(eerrrr.message);
		});
	}	
	
	onDetailsButtonClick(FAQ) {
		this.$log.debug('User clicked Enter Level button' + FAQ.Id);	
		this.$log.debug('User clicked Enter Level button' + FAQ.LastPublishedDate);	
		this.$log.debug('User clicked Enter Level button' + FAQ.Question__c);	
		this.$log.debug('User clicked Enter Level button' + FAQ.EP_FE_Article_Body__c);		
		this.siteManagementDialogService.open(FAQ);
	}
}