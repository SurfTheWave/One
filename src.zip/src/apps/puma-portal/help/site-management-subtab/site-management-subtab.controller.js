import HelpBase from '../HelpBase.class.js';

export default class SitemanagementListController extends HelpBase {
	constructor($rootScope, $scope,pumaConnector, accountService, siteDetailInformationDialogService, platformSelectorService, platformType) {
		'ngInject';
		
		super($rootScope, platformSelectorService, platformType);
		
		this.$scope = $scope;
		this.$scope.name = 'MAINTANANCE';
		
		this.accountService = accountService;
		this.pumaConnector = pumaConnector;
		this.$scope.name1 = 'Maintenance';
		this.$scope.name2 = 'Order Tracking';
		this.$scope.name3 = 'Order Placement';
		this.$scope.name4 = 'Dip Measurement';
		this.$scope.name5 = 'Invoice Management';
		this.$scope.name6 = 'Case Management';
		this.siteDetailInformationDialogService = siteDetailInformationDialogService;
				/*$scope.subTabname = [{"TabName":"MAINTANANCE",description:'mostpopulartopic description'},
   							 {"TabName":"ORDER TRACKING",description:'mostpopulartopic description'},
    						{"TabName":"ORDER PLACEMENT",description:'mostpopulartopic description'},
							{"TabName":"DIP MEASUREMENT",description:'mostpopulartopic description'},
							{"TabName":"INVOICE MANAGEMENT",description:'mostpopulartopic description'},
							{"TabName":"CASE MANAGEMENT",description:'mostpopulartopic description'}];*/
				 
	}
	
	$onInit() {
		super.$onInit();
		
		this.accountService.getSellToAccount().then((account) => {
			
			this.$scope.sellToAccount = account;
			this.$scope.description = this.$scope.sellToAccount.name;
		});
	}
	
	openNewSiteDialog() {
		this.siteDetailInformationDialogService.openNewDialog(this.$scope.sellToAccount);
	}
}