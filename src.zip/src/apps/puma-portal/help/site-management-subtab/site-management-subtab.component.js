import template from './site-management-subtab.tpl.html';
import SitemanagementListController from './site-management-subtab.controller.js';

let sitemanagementsubtabList = {
	template: template,
	controller: SitemanagementListController,
	bindings: {
		$router: '<'
	}
};

export default sitemanagementsubtabList;