import './help-sub-nav-item.sass';
import template from './help-sub-nav-item.tpl.html';
import HelpSubNavItemController from './help-sub-nav-item.controller.js';

let helpSubNavItem = {
	template: template,
	controller: HelpSubNavItemController,
	bindings: {
		name: '<',
		id: '<',
		route: '<',
		$router: '<'
	}
};

export default helpSubNavItem;