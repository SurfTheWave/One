export default class HelpSubNavItemController {
	constructor() {
	}
	
	isRouteActive(myRoute, id) {
		return this.$router.isRouteActive(this.$router.generate(['./' + myRoute, {id:id}]));
	}
}