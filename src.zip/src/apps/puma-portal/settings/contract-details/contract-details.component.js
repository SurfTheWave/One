import './contract-details.sass';
import template from './contract-details.tpl.html';
import ContractDetailsController from './contract-details.controller.js';

let contractDetails = {
	template: template,
	controller: ContractDetailsController
};

export default contractDetails;