import SettingsBase from '../settingsBase.class.js';

export default class ContractDetailsController extends SettingsBase {
	constructor($rootScope, platformSelectorService, platformType) {
		'ngInject';
		
		super($rootScope, platformSelectorService, platformType);
	}
}