/**
 * @ngdoc directive
 * @name settings
 * @restrict 'E'
 * @param {text} router - Router text for settings page navigation
 * @description
 * Includes settings page with a sub menu and menu item contents (e.g. profile settings, account and sites pages etc.)
 * Each settigs view consist of information of sell to and ship to accounts
 */

import './settings.sass';
import template from './settings.tpl.html';
import SettingsController from './settings.controller.js';

let settings = {
	template: template,
	controller: SettingsController,
	$routeConfig: [{
		path: '/',
		name: 'SettingsMobile',
		component: 'settingsMobile',
		useAsDefault: true		
	},{
		path: '/profile-settings',
		name: 'ProfileSettings',
		component: 'profileSettings'		
	}, {
		path: '/payment-details',
		name: 'PaymentDetails',
		component: 'paymentDetails'
	},{
		path: '/account-and-sites',
		name: 'AccountAndSites',
		component: 'accountAndSites'		
	},{
		path: '/account-and-sites-list',
		name: 'AccountAndSitesList',
		component: 'accountAndSitesList'		
	},{
		path: '/site-details/:id',
		name: 'SiteDetails',
		component: 'siteDetail'
	}, {
		path: '/tank-details/:shipToId/:tankId',
		name: 'TankDetails',
		component: 'tankDetail'
	},{
		path: '/contract-details',
		name: 'ContractDetails',
		component: 'contractDetails'
	}, {
		path: '/portal-settings',
		name: 'PortalSettings',
		component: 'portalSettings'
	}],
	bindings: {
		$router: '<'
	}
};

export default settings;