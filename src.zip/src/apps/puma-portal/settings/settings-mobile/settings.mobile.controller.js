export default class SettingsMobileController {
	constructor($rootScope, $scope, accountService, platformSelectorService) {
		'ngInject';
		
		this.$rootScope = $rootScope;
		this.$scope = $scope;
		this.accountService = accountService;
		this.platformSelectorService = platformSelectorService;
		
		// Setting menu and component configurations
		// TODO: We can move configurations different place. @AlperG.
		this.$scope.settings = [{
			name:'ProfileSettings',
			mobilePath:'ProfileSettings',
			componentName:'profile-settings',
			description:'Profile Picture, Personal Information, Contact Adress'
		}, {
			name: 'PaymentDetails',
			mobilePath:'PaymentDetails',
			componentName:'payment-details',
			description:'Payment Details'
		}, {
			name:'AccountAndSites',
			mobilePath:'AccountAndSitesList',
			componentName:'account-and-sites', 
			description:'Site Manager, Site Address, Tank Information, Site Pictures',
			subNavItems: []
		}, {
			name:'ContractDetails',
			mobilePath:'ContractDetails',
			componentName:'contract-details',
			description:'Sales terms, Site Maintanance'
		}, {
			name:'PortalSettings',
			mobilePath:'PortalSettings',
			componentName:'portal-settings',
			description:'Notification, Authorizatiohn, Conversation and Portal Language settings'
		}];
		
		this.fillNavItemsAndGetSellTo();
	}
	
	fillNavItemsAndGetSellTo() {
		var self = this;
		return this.accountService.getSellToAccount().then(
			function onSuccess(sellToAccount) {
				self.sellToAccount = sellToAccount;
				self.fillSiteNavigationItems();
				return;
			}
		);
	}
	
	fillSiteNavigationItems() {
		var accountAndSitesSettings = this.$scope.settings[2];
		for(let shipTo of this.sellToAccount.shipToList) {
			accountAndSitesSettings.subNavItems.push({subNavItemName:shipTo.name, id:shipTo.id});
		}
	}
	
	$onInit() {
		this.$rootScope.$broadcast('showHeader');
		
		this.platformSelectorService.registerPlatformTypeChangeEvent((newPlatform) => {
			// If changed to tablet or desktop and we are showing a site detail page, show the header
			this.$rootScope.$broadcast('showHeader');
		});
	}
}