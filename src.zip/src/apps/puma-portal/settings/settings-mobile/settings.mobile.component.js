/**
 * @ngdoc directive
 * @name settings-mobile
 * @restrict 'E'
 * @param {text} router - Router text for settings-mobile page navigation
 * @description
 * Includes settings page with a sub menu and menu item contents (e.g. profile settings, account and sites pages etc.)
 * Each settigs view consist of information of sell to and ship to accounts
 */

import '../settings.sass';
import template from './settings.mobile.tpl.html';
import SettingsMobileController from './settings.mobile.controller.js';

let settingsMobile = {
	template: template,
	controller: SettingsMobileController,
	bindings: {
		$router: '<'
	}
};

export default settingsMobile;