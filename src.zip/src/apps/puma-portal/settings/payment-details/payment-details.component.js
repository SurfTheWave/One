import './payment-details.sass';
import template from './payment-details.tpl.html';
import PaymentDetailsController from './payment-details.controller.js';

let paymentDetails = {
	template: template,
	controller: PaymentDetailsController
};

export default paymentDetails;