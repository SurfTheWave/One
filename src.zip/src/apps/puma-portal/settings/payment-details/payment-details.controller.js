import SettingsBase from '../settingsBase.class.js';

export default class PaymentDetailsController extends SettingsBase {
	constructor($rootScope, accountService, platformSelectorService, platformType) {
		'ngInject';
		
		super($rootScope, platformSelectorService, platformType);
		
		this.accountService = accountService;
	}
	
	$onInit() {
		let self = this;
		this.accountService.getSellToAccount().then((account) => {
			self.sellToAccount = account;
		});
	}
}