import SettingsBase from '../settingsBase.class.js';
import AppHelper from '../../app/app.helper.class.js';


export default class TankInformationController extends SettingsBase {
	constructor($rootScope, tankInformationTankDialogService, $filter, platformSelectorService, platformType) {
		'ngInject';
		
		super($rootScope, platformSelectorService, platformType);
		
		this.tankInformationTankDialogService = tankInformationTankDialogService;
		this.$filter = $filter;
		this.platformSelectorService = platformSelectorService;
		this.appHelper = new AppHelper($filter);
	}
	
	/**
	* @ngdoc function
	* @name openEditTankDialog
	* @param {object} tank
	* @description
	* This function aims that open an ng dialog that includes tank information, by the help of tankInformationTankDialogService 
	*/
	openEditTankDialog(tank) {
		this.tankInformationTankDialogService.openEditTankDialog(this.shipToAccount, tank);
	}
	
	/**
	* @ngdoc function
	* @name getLastDeepReadingDateTime
	* @param {object} tank
	* @description
	* This function aims that return last dip reading date of a tank which is given as parameter 
	* Date filter format: dd.MM.yyyy hh:mm (e.g. 05.15.2016 8:30)
	*/
	getLastDeepReadingDateTime(tank)
	{
		return this.appHelper.getLastDeepReadingDateTime(tank);
	}
}