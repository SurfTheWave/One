/**
 * @ngdoc directive
 * @name tank-information
 * @restrict 'E'
 * @param {object} tankList - Tank objects' array
 * @description
 * The tank information component which includes tank related information (e.g. name, product, capacity etc.)
 * All tank information is placed in a table
 */

import './tank-information.sass';
import template from './tank-information.tpl.html';
import TankInformationController from './tank-information.controller.js';

let tankInformation = {
	template: template,
	controller: TankInformationController,
	bindings: {
		shipToAccount: '='
	}
};

export default tankInformation;