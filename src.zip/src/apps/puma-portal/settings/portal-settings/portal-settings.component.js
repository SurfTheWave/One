import './portal-settings.sass';
import template from './portal-settings.tpl.html';
import PortalSettingsController from './portal-settings.controller.js';

let portalSettings = {
	template: template,
	controller: PortalSettingsController
};

export default portalSettings;