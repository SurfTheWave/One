import SettingsBase from '../settingsBase.class.js';

export default class PortalSettingsController extends SettingsBase {
	constructor($rootScope, platformSelectorService, platformType) {
		'ngInject';
		
		super($rootScope, platformSelectorService, platformType);
	}
}