import settings from './settings.component.js';
import profileSettings from './profile-settings/profile-settings.component.js';
import paymentDetails from './payment-details/payment-details.component.js';
import highLevelBankAccount from './account-and-sites/high-level-bank-account/high-level-bank-account.component.js';
import contractDetails from './contract-details/contract-details.component.js';
import accountAndSites from './account-and-sites/account-and-sites.component.js';
import accountAndSitesList from './account-and-sites-list/account-and-sites-list.component.js';
import bankAccount from './account-and-sites/bank-account/bank-account.component.js';
import tankInformation from './tank-information/tank-information.component.js';
import siteDetail from './site-detail/site-detail.component.js';
import tankDetailMobile from './tank-detail-mobile/tank-detail-mobile.component.js';
import portalSettings from './portal-settings/portal-settings.component.js';
import settingsNavItem from './settings-nav-item/settings-nav-item.component.js';
import settingsSubNavItem from './settings-sub-nav-item/settings-sub-nav-item.component.js';
import settingsNavItemMobile from './settings-nav-item-mobile/settings-nav-item-mobile.component.js';
import settingsMobile from './settings-mobile/settings.mobile.component.js';
import confirmDialog from 'youOne/components/base-dialog/confirm-dialog/confirm-dialog.component.js';
import thankYouDialog from 'youOne/components/base-dialog/thank-you-dialog/thank-you-dialog.component.js';

// Import services
import editAccountInformationDialogService from './account-and-sites/edit-account-information-dialog/edit-account-information-dialog.service.js';
import siteDetailInformationDialogService from './account-and-sites/site-detail-information-dialog/site-detail-information-dialog.service.js';
import tankInformationTankDialogService from './account-and-sites/tank-information-dialog/tank-information-dialog.service.js';
import bankAccountInformationDialogService from './account-and-sites/bank-account-information-dialog/bank-account-information-dialog.service.js';


import 'youOne/services/modal-dialog/modal-dialog.js';

import angular from 'angular';

angular.module('app.settings', ['modal-dialog'])
	.component('settings', settings)
	.component('settingsMobile', settingsMobile)
	.component('settingsNavItem', settingsNavItem)
	.component('settingsSubNavItem', settingsSubNavItem)
	.component('bankAccount', bankAccount)
	.component('siteDetail', siteDetail)
	.component('tankInformation', tankInformation)
	.component('tankDetail', tankDetailMobile)
	.component('accountAndSites', accountAndSites)
	.component('accountAndSitesList', accountAndSitesList)
	.component('contractDetails', contractDetails)
	.component('paymentDetails', paymentDetails)
	.component('highLevelBankAccount', highLevelBankAccount)
	.component('portalSettings', portalSettings)
	.component('profileSettings', profileSettings)
	.component('settingsNavItemMobile', settingsNavItemMobile)
	.component('confirmDialog', confirmDialog)
	.component('thankYouDialog', thankYouDialog)
	.service('editAccountInformationDialogService', editAccountInformationDialogService)
	.service('siteDetailInformationDialogService', siteDetailInformationDialogService)
	.service('tankInformationTankDialogService', tankInformationTankDialogService)
	.service('bankAccountInformationDialogService',bankAccountInformationDialogService);