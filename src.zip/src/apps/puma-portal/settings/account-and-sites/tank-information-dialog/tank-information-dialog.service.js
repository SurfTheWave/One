import './tank-information-dialog.sass';
import TankInformationDialogController from './tank-information-dialog.controller.js';
import TankInformationDialogTemplate from './tank-information-dialog.tpl.html';

export default class TankInformationDialogService {
	constructor($log, ngDialog) {
		'ngInject';
		
		this.$log = $log;
		this.ngDialog = ngDialog;
	}

	/**
	* @ngdoc function
	* @name open
	* @param {object} shipToAccount
	* @param {object} tankId
	* @description
	* This function aims to open an ngDialog that includes tank detail information edit form or new form.
	* Takes a tank id and ship to account object and  create or update.
	* If tankId is given as a undefined/null it opens dialog with new tank object.
	*/
	open(shipToAccount, tankId) {
		// Flag for enable/disable to close dialog instance 
		var disableClose = true;
		var initialDialogHeight=null;
		this.dialogInstance = this.ngDialog.open({
			template: TankInformationDialogTemplate,
			plain: true,
			className: 'ngdialog-theme-default add-tank-dialog',
			controller: TankInformationDialogController,
			controllerAs: '$ctrl',
			showClose: false,
			data: {
				tankId: tankId,
				shipTo: shipToAccount,
				closeDialog: () => {
					disableClose = false;
					this.dialogInstance.close(this.dialogInstance.id);
				},
				enableClose: () => {
					disableClose = false;
				},
				getInitialHeight: () => {
					if(!initialDialogHeight) {
						initialDialogHeight = angular.element( document.getElementsByClassName('ngdialog-content')).outerHeight();
					}
					return initialDialogHeight;
				}
			}, 
			// preCloseCallback function is called before the this.dialogInstance is closed 
			preCloseCallback: () => {
				if(disableClose)
				{
					return false;
				}
				return true;
			}
		});
	}

	close() {
		if(this.dialogInstance) {
			this.dialogInstance.close();
		}
	}
	
	openNewTankDialog(shipTo) {
		this.open(shipTo, null);
	}
	
	openEditTankDialog(shipTo, tank) {
		this.open(shipTo, tank.Id);
	}
	
}