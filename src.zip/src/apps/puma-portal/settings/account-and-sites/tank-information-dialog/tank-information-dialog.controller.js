import Account from 'youOne/services/account/account.class.js';
import Tank from 'youOne/services/account/tank/tank.class.js';
import BaseDialogController from 'youOne/components/base-dialog/base-dialog.class.js';
import angularMask from 'angularMask';

export default class TankInformationDialogController extends BaseDialogController {

	constructor($scope, $locale, $filter, $log, tankService, accountService) {
		'ngInject';
		
		super('past', ...arguments);
		
		$log.debug('Tank information dialog controller is created.');
			
		this.$scope = $scope;
		this.$filter = $filter;
		this.tankService = tankService;
		this.accountService = accountService;
		this.$log = $log;
				
		// Get status from tank object: 
		// Operational: 'Operational', Stopped: 'Stopped', Decomissioned: 'Decomissioned'
		this.statusList = _.values(Account.ShipTo.Tank.Status);
		
		// Error message parameters
		this.errorMessage = '';
		this.formStatus = true;
		
		this.getTank();
		this.getProducts();

		/******* Dialog configurations for base dialog controller ********/
		// Initialize state to submission state
		this.state = this.states.Submission;
		
		// It is used to set minimize height of dialog for success/confirmation state
		this.successDialogMinimizePercent=0.55;
		this.confirmationDialogMinimizePercent=0.45;
		/*****************************************************************/
	}
	
	/**
	* @ngdoc function
	* @name getProducts
	* This function get available products with API call fron tank service.
	*/	
	getProducts() {
		this.tankService.getAvailableProducts(this.$scope.ngDialogData.shipTo.id).then((products) => {
			this.productList = products;
			return;
			}
		);		
	}
	
	/**
	* @ngdoc function
	* @name getTank
	* This function set controller tank object
	* If tankId is defined in ngDialog parameters, get tank from ship to account with id and get copy of it,
	* If tankId is not defined or does not exist in given ship to account's tank list, it creates new tank,
	*/	
	getTank() {
		let tankId = this.$scope.ngDialogData.tankId;
		this.shipToAccount = this.$scope.ngDialogData.shipTo;
		
		if(tankId) {
			this.tankNotModified = this.shipToAccount.tanks.find(x => x.Id === tankId);
			this.tank = angular.copy(this.tankNotModified);
		} else {
			this.tank = new Tank();
			this.tank.shipToId = this.shipToAccount.id;	
		}
	}

	/**
	* @ngdoc function
	* @name validateFields
	* This function check validation of tank capacity, safeFillLevel, deadStockLevel fields.
	*/
	validateFields(formTank) {
		//--
		let formStatus = true;
		let errorMessage='';
		let capacity = parseInt(this.tank.capacity);
		let safeFillLevel = parseInt(this.tank.safeFillLevel);
		let deadStockLevel = parseInt(this.tank.deadStockLevel);
		//--
		if ( capacity <= 0) {
			errorMessage = 'Tank\'s capacitiy must be higher than zero !';
			formTank.tankCapacity.$setValidity('invalid-value', false);
			formStatus = false;
		} else if ( safeFillLevel <= 0) {
			errorMessage = 'Tank\'s safe fill level must be higher than zero !';
			formTank.tankSafeFillLevel.$setValidity('invalid-value', false);
			formStatus = false;
		} else if ( deadStockLevel <= 0) {
			errorMessage = 'Tank\'s dead stock level must be higher than zero !';
			formTank.tankDeadStockLevel.$setValidity('invalid-value', false);
			formStatus = false;
		} else if (safeFillLevel > capacity) {
			formTank.tankSafeFillLevel.$setValidity('invalid-value', false);
			formTank.tankCapacity.$setValidity('invalid-value', false);
			errorMessage = 'Tank\'s Safe Fill Level can not be higher than tank\'s capacitiy !';
			formStatus = false;
		} else if (safeFillLevel < deadStockLevel) {
			errorMessage = 'Tank\'s Safe Fill Level can not be lower than tank\'s dead stock level !';
			formTank.tankSafeFillLevel.$setValidity('invalid-value', false);
			formTank.tankDeadStockLevel.$setValidity('invalid-value', false);
			formStatus = false;
		} else {
			formTank.tankCapacity.$setValidity('invalid-value', true);
			formTank.tankSafeFillLevel.$setValidity('invalid-value', true);
			formTank.tankDeadStockLevel.$setValidity('invalid-value', true);			
		}
		this.formStatus = formStatus;
		this.errorMessage = errorMessage;
		return formStatus;
	}

	/**
	* @ngdoc function
	* @name addTank
	* This function call add new tank to API with tank object whihc is currently binded to tank dialogue page.
	*/
	addTank() {
			//-- Save Tank
		this.tankService.requestNewTank(this.tank).then((response) => {
			if(response.body[0].success === true)  {
				this.$log.debug('TANK is successfully created for ship to id:' + this.shipToAccount.id);
				//change state to success
				this.changeState(this.states.Success);
				// Update current ship to tanks
				this.accountService.getSellToAccount().then((sellToAccount) => {
					this.shipToAccount.tanks = sellToAccount.shipToList.find(x =>  x.id == this.shipToAccount.id).tanks;
					return;	
				});
			} else {
				this.changeState(this.states.Failure);
				this.$log.debug('TANK create request could not be created:'+ JSON.stringify(response));						
			}
		});
	}

	/**
	* @ngdoc function
	* @name updateTank
	* This function call ship to update API with ship to account currently binded to edit dialogue page.
	*/
	updateTank() {
		this.tankService.updateTank(this.tankNotModified.getChangeRequestForUpdate(this.tank)).then((response) => {			
			if(response.body[0].success === true) {
				this.changeRequestId = response.body[0].record.Name;
				this.$log.debug('TANK update request succesfully created with change request id:'+response.changeRequestId);
				//change state to success
				this.changeState(this.states.Success);
			} else {
				this.changeState(this.states.Failure);
				this.$log.debug('TANKt update request could not be created:'+ JSON.stringify(response));				
			}
		});
	}
	
	addOrUpdateTank(formTank) {
		this.$log.debug('TANK dialog save button clicked.');
		if (formTank.$valid){
			if(this.tank.Id) {
				this.updateTank();
			} else {
				this.addTank();
			}
		} else  {
			this.$log.debug('TANK data is not valid!');
		}
	}

	/**
	* @ngdoc function
	* @name getThankYouMessage
	* Produce success message
	*/	
	getThankYouMessage() {
		let thankYouMessageText;
		if(this.tank.Id) {
			thankYouMessageText = 'YOUR NEW TANK TO UPDATE REQUEST CREATED, CHANGE REQUEST ID :'+ this.changeRequestId;
		} else {
			thankYouMessageText = 'NEW TANK IS ADDED SUCCESSFULLY.';
		}
		
		return thankYouMessageText;
	}

	/**
	* @ngdoc function
	* @name getConfirmationQuestion
	* Produce confirmation question
	*/	
	getConfirmationMessage() {
		let confirmText;
		if(this.shipToAccount.id) {
			confirmText = 'Are you sure you want to close edit tank dialog?';
		} else {
			confirmText = 'Are you sure you want to close new tank dialog?';
		}
		
		return confirmText;
	}
}
