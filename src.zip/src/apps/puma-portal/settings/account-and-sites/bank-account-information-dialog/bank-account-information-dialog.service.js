import './bank-account-information-dialog.sass';
import BankAccountInformationDialogController from './bank-account-information-dialog.controller.js';
import BankAccountInformationDialogTemplate from './bank-account-information-dialog.tpl.html';

export default class BankAccountInformationDialogService {
	constructor($log, ngDialog) {
		'ngInject';
		
		this.$log = $log;
		this.ngDialog = ngDialog;
	}

	/**
	* @ngdoc function
	* @name open
	* @param {object} shipToAccount
	* @param {object} tankId
	* @description
	* This function aims to open an ngDialog that includes tank detail information edit form or new form.
	* Takes a tank id and ship to account object and  create or update.
	* If tankId is given as a undefined/null it opens dialog with new tank object.
	*/
	open(sellToAccount, bankAccountId) {
		// Flag for enable/disable to close dialog instance 
		var disableClose = true;
		var initialDialogHeight = null;
		this.dialogInstance = this.ngDialog.open({
			template: BankAccountInformationDialogTemplate,
			plain: true,
			className: 'ngdialog-theme-default bank-account-information-dialog',
			controller: BankAccountInformationDialogController,
			controllerAs: '$ctrl',
			showClose: false,
			data: {
				sellToAccount: sellToAccount,
				bankAccountId: bankAccountId,
				closeDialog: () => {
					disableClose = false;
					this.dialogInstance.close(this.dialogInstance.id);
				},
				enableClose: () => {
					disableClose = false;
				},
				getInitialHeight: () => {
					if(!initialDialogHeight) {
						initialDialogHeight = angular.element( document.getElementsByClassName('ngdialog-content')).outerHeight();
					}
					return initialDialogHeight;
				}
			}, 
			preCloseCallback: () => {
				if(disableClose)
					return false;
				return true;
			}
		});
	}

	close() {
		if(this.dialogInstance) {
			this.dialogInstance.close();
		}
	}
	
	openNewBankAccountDialog(sellTo) {
		this.open(sellTo, null);
	}
	
	openEditBankAccountDialog(sellTo, bankAccountId) {
		this.open(sellTo, bankAccountId);
	}
	
}