import Account from 'youOne/services/account/account.class.js';
import countriesJson from 'youOne/services/account/account.countries.json';
import BaseDialogController from 'youOne/components/base-dialog/base-dialog.class.js';
import angularMask from 'angularMask';
import angularUIMask from 'angularUIMask';

export default class BankAccountInformationDialogController extends BaseDialogController {

	constructor($scope, $locale, $filter, $log, accountService, bankAccountService) {
		'ngInject';
		super('past', ...arguments);
			
		this.$scope = $scope;
		this.$filter = $filter;
		this.accountService = accountService;
		this.bankAccountService = bankAccountService;
		this.$log = $log;
		
		// Error message parameters
		this.errorMessage = '';
		this.formStatus = true;
		
		// Temporary country list as a json file
		this.countries = countriesJson;
		
		this.getBankAccount();

		/******* Dialog configurations for base dialog controller ********/
		// Initialize state to submission state
		this.state = this.states.Submission;
		
		// It is used to set minimize height of dialog for success/confirmation state
		this.successDialogMinimizePercent=0.65;
		this.confirmationDialogMinimizePercent=0.55;
		/*****************************************************************/
	}
	
	/**
	* @ngdoc function
	* @name getBankAccount
	* This function set bank account object by using bankAccountId and sellToAccount ngDialog parameters.
	* If bankAccountId is not defined or does not exist in given sell to account's bank account list, it creates new,
	* If there is a bank account with given id, it copy that object and open dialog with copy object.
	*/	
	getBankAccount() {
		let bankAccountId = this.$scope.ngDialogData.bankAccountId;
		this.sellToAccount = this.$scope.ngDialogData.sellToAccount;
		
		if(bankAccountId) {
			// TODO : Implement it later. @Alper
			this.bankAccount = undefined;
		}
		
		if(!this.bankAccount) {
			this.bankAccount = new Account.SellTo.BankAccount();
		} else {
			this.bankAccount = angular.copy(this.bankAccount);
		}
	}
	
	/**
	* @ngdoc function
	* @name addTank
	* //TODO 
	*/
	addBankAccount() {
		this.$log.debug('Bank account create save button clicked.');
		this.bankAccountService.addNewBankAccount(this.bankAccount, this.sellToAccount).then((response) => {
			if(_.isArray(response.body) && !_.isEmpty(response.body)) {
				response = response.body[0];
			} else if(response.body) {
				response = response.body;
			} else {
				response = undefined;
			}
			if(response && response.success === true) {
				this.$log.debug('Bank account succesfully created.');
				//change state to success
				this.changeState(this.states.Success);
				// Update current ship to list
				this.accountService.getSellToAccount().then((sellToAccount) => {
					this.sellToAccount.getBillingData().highLevelBankAccounts = sellToAccount.getBillingData().highLevelBankAccounts;
					return;	
				});
				
			} else {
				this.changeState(this.states.Failure);
				this.$log.debug('Bank account create request could not be created!!');					
			}
		});		
	}

	/**
	* @ngdoc function
	* @name updateBankAccount
	* //TODO
	*/
	updateBankAccount() {
		this.log.debug('Update Bank Account : Not Implemented Yet.');
	}
	
	addOrUpdateBankAccount(formBankAccount) {
//		if(not valid) {
//			this.$log.debug('Bank Account data is not valid!');
//			return;
//		}
		if (this.bankAccount.id){
			this.updateBankAccount();
		} else  {
			this.addBankAccount();
		}
	}
	
	/**
	* @ngdoc function
	* @name getThankYouMessage
	* Produce success message
	*/	
	getThankYouMessage() {
		let thankYouMessageText;
		if(this.tmpSuccessControl) {
			thankYouMessageText = 'YOUR NEW BANK ACCOUNT UPDATE REQUEST CREATED, CHANGE REQUEST ID :'+ this.changeRequestId;
		} else {
			thankYouMessageText = 'NEW BANK ACCOUNT IS ADDED SUCCESSFULLY.';
		}
		
		return thankYouMessageText;
	}
	
	/**
	* @ngdoc function
	* @name getConfirmationQuestion
	* Produce confirmation question
	*/	
	getConfirmationMessage() {
		let confirmText;
		if(this.tmpConfirmControl) {
			confirmText = 'Are you sure you want to close edit bank account dialog?';
		} else {
			confirmText = 'Are you sure you want to close new bank account dialog?';
		}
		
		return confirmText;
	}
}
