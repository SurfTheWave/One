
export default class BankAccountController {
	constructor() {
	}
}