import './bank-account.sass';
import template from './bank-account.tpl.html';
import BankAccountController from './bank-account.controller.js';

let bankAccount = {
	template: template,
	controller: BankAccountController,
	bindings: {
		bankName: '<',
		bankBranch: '<',
		accountNo: '<',
		ibanNo: '<',
		swiftNo: '<'
	}
};

export default bankAccount;