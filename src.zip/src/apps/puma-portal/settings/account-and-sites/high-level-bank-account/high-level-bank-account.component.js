import './high-level-bank-account.sass';
import template from './high-level-bank-account.tpl.html';

let highLevelBankAccount = {
	template: template,
	bindings: {
		name			: '<',
		cardNumber		: '<',
		status			: '<',
		type			: '<',
		editFunction	: '&'
	}
};

export default highLevelBankAccount;