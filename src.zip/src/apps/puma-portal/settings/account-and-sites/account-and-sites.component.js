import './account-and-sites.sass';
import template from './account-and-sites.tpl.html';
import AccountAndSitesController from './account-and-sites.controller.js';

let accountAndSites = {
	template: template,
	controller: AccountAndSitesController,
	bindings: {
		$router: '<'
	}
};

export default accountAndSites;