import '../settings.js';

describe('Component: account-settings', () => {
	var $scope, editAccountInformationDialogService;
	var sellToAccount = {
		shipToList: [
			{
				Name:"Test-Site-1"
			},
			
			{
				Name:"Test-Site-2"
			}
		]
	};
	
	// Implement mock services used by alerts controller
	beforeEach(() => {
		angular.mock.module('app.settings');
		
		// Provide will help us create fake implementations for our dependencies
		angular.mock.module(($provide) => {
		
			// Mock accountService
			$provide.service('accountService', () => {
				return {
					getSellToAccount: () => {
						return {
							then: (callback) => {
								return callback(sellToAccount);
							}
						};
					}
				};
			});
			
			// Mock missingTankDipDatesDialogService service
			$provide.service('editAccountInformationDialogService', () => {
				return {
					open: () => {
						
					},
					
					close: () => {
						
					}
				};
			});
		});
	});
	
	// Assign injected services to local instances
	beforeEach(angular.mock.inject((_editAccountInformationDialogService_) => {
		editAccountInformationDialogService = _editAccountInformationDialogService_;
	}));
	
	// Create a new scope and create alerts component with newly created scope
	beforeEach(angular.mock.inject((_$rootScope_, _$componentController_) => {
		$scope = _$rootScope_.$new();
		
		_$componentController_('accountAndSites', {
			$scope: $scope
		});
	}));
	
	it('is supposed to fill $ctrl.sellToAccount with shipToList of sellToAccount', () => {
		expect($scope.$ctrl.sellToAccount).toEqual(sellToAccount);
	});
	
	it('is supposed to open edit account information dialog when openEditDialog', () => {
		spyOn(editAccountInformationDialogService, 'open');
		
		$scope.$ctrl.openEditDialog(sellToAccount);
		expect(editAccountInformationDialogService.open).toHaveBeenCalled();
	});
	
});