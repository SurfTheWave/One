import './site-detail-information-dialog.sass';
import SiteDetailInformationController from './site-detail-information-dialog.controller.js';
import SiteDetailInformationTemplate from './site-detail-information-dialog.tpl.html';

export default class SiteDetailInformationDialogService {
	constructor($log, ngDialog) {
		'ngInject';
		
		this.$log = $log;
		this.ngDialog = ngDialog;
	}

	/**
	* @ngdoc function
	* @name open
	* @param {object} sellToAccount
	* @param {object} shipToId
	* @description
	* This function aims to open an ngDialog that includes site detail information edit form or new form.
	* Takes a ship to id and sell to account object and create or update
	* If shipToId is given as a undefined/null it opens dialog with new ship to object.
	*/
	open(sellToAccount, shipToId) {
		// Flag for enable/disable to close dialog instance 
		var disableClose = true;
		var initialDialogHeight=null;
		this.dialogInstance = this.ngDialog.open({
			template: SiteDetailInformationTemplate,
			plain: true,
			className: 'ngdialog-theme-default edit-site-information',
			controller: SiteDetailInformationController,
			controllerAs: '$ctrl',
			showClose: false,
			data: {
				shipToId: shipToId,
				sellToAccount: sellToAccount,
				closeDialog: () => {
					disableClose = false;
					this.dialogInstance.close(this.dialogInstance.id);
				},
				enableClose: () => {
					disableClose = false;
				},
				getInitialHeight: () => {
					if(!initialDialogHeight) {
						initialDialogHeight = angular.element( document.getElementsByClassName('ngdialog-content')).outerHeight();
					}
					return initialDialogHeight;
				}
			},
			preCloseCallback: () => {
				if(disableClose)
				{
					return false;
				}
				return true;
			}
		});
	}

	close() {
		if(this.dialogInstance) {
			this.dialogInstance.close();
		}
	}
	
	openEditDialog(sellToAccount, shipToId) {
		this.open(sellToAccount, shipToId);
	}
	
	openNewDialog(sellToAccount) {
		this.open(sellToAccount, null);
	}
	
}
