import Account from 'youOne/services/account/account.class.js';
import BaseDialogController from 'youOne/components/base-dialog/base-dialog.class.js';
import countriesJson from 'youOne/services/account/account.countries.json';

export default class AccountInformationController extends BaseDialogController {
	
	constructor($scope, $log, accountService) {
		'ngInject';
		
		super('past', ...arguments);
		
		$log.debug('Site detail information edit dialog controller is created.');
		
		this.$scope = $scope;
		this.accountService = accountService;
		this.$log = $log;
		
		// Values of Automatic: 'Automatic Dip Entry' ,  Portal: 'Portal Dip Entry' 
		this.tankDipEntryModes = _.values(Account.TankDipEntryMode);
		
		// Temporary country list as a json file
		this.countries = countriesJson;
		
		this.getShipTo();
		
		/******* Dialog configurations for base dialog controller ********/
		// Initialize state to submission state
		this.state = this.states.Submission;
		
		// It is used to set minimize height of dialog for success/confirmation state
		this.successDialogMinimizePercent=0.65;
		this.confirmationDialogMinimizePercent=0.55;
		/*****************************************************************/
	}
	
		
	/**
	* @ngdoc function
	* @name getShipTo
	* This function set ship to account object by using shipToId and sellToAccount ngDialog parameters.
	* If shipToId is not defined or does not exist in given sell to account's ship to list, it creates new,
	* If there is a ship to with given id, it copy ship to object and open dialog with copy object.
	*/	
	getShipTo() {
		let shipToId = this.$scope.ngDialogData.shipToId;
		this.sellToAccount = this.$scope.ngDialogData.sellToAccount;
		
		if(shipToId) {
			this.shipToAccountNotModified =  this.sellToAccount.shipToList.find(x => x.id === shipToId);
			this.shipToAccount = angular.copy(this.shipToAccountNotModified);
		}else {
			this.shipToAccount = new Account.ShipTo();
		}
	}
	
	/**
	* @ngdoc function
	* @name updateShipToAccount
	* This function call ship to update API with ship to account currently binded to edit dialogue page.
	*/
	updateShipToAccount() {
		this.$log.debug('Ship To account update Submit button clicked.');
		let changeRequest = this.shipToAccountNotModified.getChangeRequestForUpdate(this.shipToAccount);
		
		this.accountService.updateShipToAccount(changeRequest).then((response) => {
			if(response.body[0].success === true) {
				this.changeRequestId = response.body[0].record.Name;
				this.$log.debug('Ship To account update request succesfully created with change request id:'+this.changeRequestId);
				//change state to success
				this.changeState(this.states.Success);
			} else {
				this.changeState(this.states.Failure);	
				this.$log.debug('Ship To account update request could not be created:'+JSON.stringify(response));				
			}
		});
		}
		
	/**
	* @ngdoc function
	* @name addShipToAccount
	* This function call add new ship to API with ship to account currently binded to edit dialogue page.
	*/
	addShipToAccount() {
		this.$log.debug('Ship To account create save button clicked.');
		this.accountService.addShipToAccount(this.sellToAccount.id, this.shipToAccount).then((response) => {
			if(response.body[0].success === true) {
				this.$log.debug('Ship To account succesfully created.');
				this.changeRequestId = response.changeRequestId;
				//change state to success
				this.changeState(this.states.Success);
				// Update current ship to list
				this.accountService.getSellToAccount().then((sellToAccount) => {
					this.sellToAccount.shipToList = sellToAccount.shipToList;
					return;	
				});
			} else {
				this.changeState(this.states.Failure);
				this.$log.debug('Ship To account create request could not be created:'+ JSON.stringify(response));					
			}
		});
		}
	
	/**
	* @ngdoc function
	* @name addOrUpdateShipToAccount
	* This function update or add current ship to account which is binded to dialog.
	*/	
	addOrUpdateShipToAccount() {
		if(this.shipToAccount.id) {
			this.updateShipToAccount();
		} else {
			this.addShipToAccount();
		}
	}
	
	/**
	* @ngdoc function
	* @name getThankYouMessage
	* Produce success message
	*/	
	getThankYouMessage() {
		let thankYouMessageText;
		if(this.shipToAccount.id) {
			thankYouMessageText = 'YOUR SHIP TO UPDATE REQUEST CREATED, CHANGE REQUEST ID: '+ this.changeRequestId;
		} else {
			thankYouMessageText = 'YOUR NEW SHIP TO IS SUCCESSFULLY CREATED.';
		}
		
		return thankYouMessageText;
	}
	
	/**
	* @ngdoc function
	* @name getConfirmationQuestion
	* Produce confirmation question
	*/	
	getConfirmationMessage() {
		let confirmText;
		if(this.shipToAccount.id) {
			confirmText = 'Are you sure you want to close edit ship to account dialog?';
		} else {
			confirmText = 'Are you sure you want to close new ship to account dialog?';
		}
		
		return confirmText;
	}
		
	
}
