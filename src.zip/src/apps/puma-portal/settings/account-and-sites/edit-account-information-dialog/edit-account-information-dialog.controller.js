import countriesJson from 'youOne/services/account/account.countries.json';
import BaseDialogController from 'youOne/components/base-dialog/base-dialog.class.js';

export default class EditAccountInformationController extends BaseDialogController {
	
	constructor($scope, $log, accountService) {
		'ngInject';
		
		super('past', ...arguments);
		
		$log.debug('Account information edit dialog controller is created. Account Number: ' + $scope.ngDialogData.sellToAccount.accountNumber);			
		
		this.$scope = $scope;
		this.accountService = accountService;
		this.$log = $log;
		
		this.sellToAccountNotModified = $scope.ngDialogData.sellToAccount;
		this.sellToAccount = angular.copy(this.sellToAccountNotModified);
		
		// Temporary country list as a json file
		this.countries = countriesJson;
		
		/******* Dialog configurations for base dialog controller ********/
		// Initialize state to submission state
		this.state = this.states.Submission;
		
		// It is used to set minimize height of dialog for success/confirmation state
		this.successDialogMinimizePercent=0.65;
		this.confirmationDialogMinimizePercent=0.55;
		/*****************************************************************/
	}
	
	/**
	* @ngdoc function
	* @name updateSellToAccount
	* This function call sell to update API with sell to account currently binded to edit dialogue page.
	*/	
	updateSellToAccount() {
		this.$log.debug('Sell To account update Submit button clicked.');
		
		let changeRequest = this.sellToAccountNotModified.getChangeRequestForUpdate(this.sellToAccount);
		this.accountService.updateSellToAccount(changeRequest).then((response) => {
			if(response.body[0].success === true) {
				this.changeRequestId = response.body[0].record.Name;
				this.$log.debug('Sell To account update request succesfully created with change request id:'+ this.changeRequestId);
				//change state to success
				this.changeState(this.states.Success);
			} else {
				this.changeState(this.states.Failure);
				this.$log.debug('Sell To account update request could not be created:'+ JSON.stringify(response));			
			}
		});
	}
		
	/**
	* @ngdoc function
	* @name getThankYouMessage
	* Produce success message
	*/	
	getThankYouMessage() {
		let thankYouMessageText = 'YOUR SELL TO UPDATE REQUEST CREATED, CHANGE REQUEST ID :'+ this.changeRequestId;
		
		return thankYouMessageText;
	}
	
	/**
	* @ngdoc function
	* @name getConfirmationQuestion
	* Produce confirmation question
	*/	
	getConfirmationMessage() {
		let confirmText = 'Are you sure you want to close edit sell to account dialog?';
		
		return confirmText;
	}	
}
