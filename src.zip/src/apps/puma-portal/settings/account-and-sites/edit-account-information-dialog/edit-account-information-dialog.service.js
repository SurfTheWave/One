import './edit-account-information-dialog.sass';
import EditAccountInformationController from './edit-account-information-dialog.controller.js';
import editAccountInformationTemplate from './edit-account-information-dialog.tpl.html';

export default class EditAccountInformationDialogService {
	constructor($log, ngDialog) {
		'ngInject';
		
		this.$log = $log;
		this.ngDialog = ngDialog;
	}

	/**
	* @ngdoc function
	* @name open
	* @param {object} sellToAccount
	* @description
	* This function aims to open an ngDialog that includes account information edit form. 
	* Takes a sell to account object and update
	* Additionally, it opens a confirmation dialog also when dialog's close button clicked.
	*/
	open(sellToAccount) {
		// Flag for enable/disable to close dialog instance 
		var disableClose = true;
		var initialDialogHeight = null;
		this.dialogInstance = this.ngDialog.open({
			template: editAccountInformationTemplate,
			plain: true,
			className: 'ngdialog-theme-default edit-account-information',
			controller: EditAccountInformationController,
			controllerAs: '$ctrl',
			showClose: false,
			data: {
				sellToAccount: sellToAccount,
				closeDialog: () => {
					disableClose = false;
					this.dialogInstance.close(this.dialogInstance.id);
				},
				enableClose: () => {
					disableClose = false;
				},
				getInitialHeight: () => {
					if(!initialDialogHeight) {
						initialDialogHeight = angular.element( document.getElementsByClassName('ngdialog-content')).outerHeight();
					}
					return initialDialogHeight;
				}
			},
			preCloseCallback: () => {
				if(disableClose)
				{
					return false;
				}
				return true;
			}
			
		});
	}

	close() {
		if(this.dialogInstance) {
			this.dialogInstance.close();
		}
	}
}