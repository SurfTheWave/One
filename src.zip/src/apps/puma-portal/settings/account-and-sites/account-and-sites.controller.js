import SettingsBase from '../settingsBase.class.js';

export default class AccountAndSitesController extends SettingsBase {
	constructor($rootScope, $scope, accountService, bankAccountService, editAccountInformationDialogService, bankAccountInformationDialogService,  platformSelectorService, platformType) {
		'ngInject';
		
		super($rootScope, platformSelectorService, platformType);
		
		this.$scope = $scope;
		this.accountService = accountService;
		this.bankAccountService = bankAccountService;
		this.accountInformationEditDialogService = editAccountInformationDialogService;
		this.bankAccountInformationDialogService = bankAccountInformationDialogService;

		// Get site id as a site URL parameter when selecting a site to show detail.
		this.$routerOnActivate = function(next, previous) {	
			$scope.shipToId = next.params.id;
		};
	}
	
	$onInit() {
		super.$onInit();
		
		let self = this;
		this.accountService.getSellToAccount().then((account) => {
			self.sellToAccount = account;
		});
	}
	
	/**
	* @ngdoc function
	* @name openEditDialog
	* This function call open function from sell to account dialog service.
	*/	
	openEditDialog() {
		if(this.sellToAccount) {
			this.accountInformationEditDialogService.open(this.sellToAccount);
		}
	}
	
    isEmpty(value){
  	 return (!value || value.length === 0);
	}

	openAddBankAccountDialog(){
		this.bankAccountInformationDialogService.openNewBankAccountDialog(this.sellToAccount);
	}
	
	
	openEditBankAccountDialog(){
		this.bankAccountInformationDialogService.openNewBankAccountDialog(this.sellToAccount);
	}
}