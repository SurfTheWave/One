/**
 * @ngdoc directive
 * @name site-detail
 * @restrict 'E'
 * @param {string} shipToId - Id for ship to account (ship to account == site)
 * @description
 * The site detail component includes site related information (e.g. site address, site's tank information etc.)
 */

import './site-detail.sass';
import template from './site-detail.tpl.html';
import SiteDetailController from './site-detail.controller.js';

let siteDetail = {
	template: template,
	controller: SiteDetailController,
	bindings: {
		$router: '<'
	}
};

export default siteDetail; 