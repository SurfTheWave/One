import SettingsBase from '../settingsBase.class.js';

export default class SiteDetailController extends SettingsBase {
	constructor($rootScope, $scope, accountService, siteDetailInformationDialogService, tankInformationTankDialogService, platformSelectorService, platformType) {
		'ngInject';
		
		super($rootScope, platformSelectorService, platformType);
		
		this.$scope = $scope;
		this.accountService = accountService;
		this.siteDetailInformationDialogService = siteDetailInformationDialogService;
		this.tankInformationTankDialogService = tankInformationTankDialogService;
		this.platformSelectorService = platformSelectorService;
		
		this.$routerOnActivate = function(next) {	
			this.shipToId = next.params.id;
			//this.getShipTo(this.shipToId);	
		};	
	}
	
	$onInit() {
		super.$onInit();
		
		this.accountService.getSellToAccount().then((sellToAccount) => {
			this.sellToAccount = sellToAccount;
			this.shipToAccount = sellToAccount.shipToList.find(x => x.id === this.shipToId);
		});
	}
	
	/**
	* @ngdoc function
	* @name openEditDialog
	* This function call open function from ship to account dialog service.
	*/	
	openEditDialog() {
		if(this.shipToAccount)
		{
			this.siteDetailInformationDialogService.openEditDialog(this.sellToAccount, this.shipToAccount.id);
		}
	}
	
	openAddTankDialog() {
		this.tankInformationTankDialogService.openNewTankDialog(this.shipToAccount);
	}
}
