/**
 * @ngdoc directive
 * @name tank-detail
 * @param {object} tank - Tank object of a shipto account
 * @description
 * The tank detail component which includes tank related information (e.g. name, product, capacity etc.) for mobile view
 */

import './tank-detail-mobile.sass';
import template from './tank-detail-mobile.tpl.html';
import TankDetailMobileController from './tank-detail-mobile.controller.js';

let tankDetailMobile = {
	template: template,
	controller: TankDetailMobileController
};

export default tankDetailMobile;