import SettingsBase from '../settingsBase.class.js';
import AppHelper from '../../app/app.helper.class.js';

export default class TankDetailMobileController extends SettingsBase {
	constructor($rootScope, tankInformationTankDialogService, accountService, $filter, platformSelectorService, platformType) {
		'ngInject';
		
		super($rootScope, platformSelectorService, platformType);
		
		this.tankInformationTankDialogService = tankInformationTankDialogService;
		this.accountService = accountService;
		this.$filter = $filter;
		this.platformSelectorService = platformSelectorService;
		
		this.$routerOnActivate = function(next) {
			this.shipToId = next.params.shipToId;
			this.tankId = next.params.tankId;
		};
		
		this.appHelper = new AppHelper($filter);
	}
	
	$onInit() {
		super.$onInit();
		this.accountService.getSellToAccount().then((sellToAccount) => {
			this.sellToAccount = sellToAccount;
			this.shipToAccount = sellToAccount.shipToList.find(x => x.id === this.shipToId);
			this.tank = this.shipToAccount.tanks.find(x => x.Id === this.tankId);
			this.lastDeepReadingDateTime = this.appHelper.getLastDeepReadingDateTime(this.tank);
		});
	}
	
	/**
	* @ngdoc function
	* @name openEditTankDialog
	* @description
	* This function aims that open an ng dialog to edit tank information, by the help of tankInformationTankDialogService 
	*/
	openEditTankDialog() {
		this.tankInformationTankDialogService.openEditTankDialog(this.shipToAccount, this.tank);
	}
}