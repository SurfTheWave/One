
export default class SettingsNavItemController {
	constructor($log, siteDetailInformationDialogService, accountService) {
		'ngInject';
		this.$log = $log;
		if(this.route) {
			this.text = this.route.replace(/([A-Z])/g, ' $1').trim();
		}
		this.siteDetailInformationDialogService = siteDetailInformationDialogService;
	}
	
	/**
	 * @ngdoc function
	 * @name isRouteActive
	 * @param {string} primaryRoute - Primary navigation route name (e.g. AccountAndSites )
	 * @param {string} secondaryRoute - Secondary navigation route name (e.g. SiteDetails)
	 * @description
	 * This function checks that route is active or not. 
	 * @returns {Boolean} If primary or secondary route is active, the function returns true, otherwise returns false.
	 */
	isRouteActive(primaryRoute, secondaryRoute) {
		
		var isRouteActive = false;
		if(this.subNavItems){
			for(let subItem of this.subNavItems){
				isRouteActive |= this.$router.isRouteActive(this.$router.generate(['./' + secondaryRoute, {id:subItem.id}]));
			}
		}
		return isRouteActive || this.$router.isRouteActive(this.$router.generate(['./' + primaryRoute]));
	}
	
	/**
	 * @ngdoc function
	 * @name openNewSiteDialog
	 * @description
	 * This function opens an ngDialog to add a new site by the help of siteDetailInformationDialogService 
	 */
	openNewSiteDialog() {
		this.siteDetailInformationDialogService.openNewDialog(this.sellToAccount);
	}
}