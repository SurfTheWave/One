import './settings-nav-item.sass';
import template from './settings-nav-item.tpl.html';
import SettingsNavItemController from './settings-nav-item.controller.js';

let settingsNavItem = {
	template: template,
	controller: SettingsNavItemController,
	bindings: {
		route: '<',
		$router: '<',
		subNavItems: '<',
		subRoute: '<',
		sellToAccount: '='
	}
};

export default settingsNavItem;
