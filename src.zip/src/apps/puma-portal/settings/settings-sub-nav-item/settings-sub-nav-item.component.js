import './settings-sub-nav-item.sass';
import template from './settings-sub-nav-item.tpl.html';
import SettingsSubNavItemController from './settings-sub-nav-item.controller.js';

let settingsSubNavItem = {
	template: template,
	controller: SettingsSubNavItemController,
	bindings: {
		name: '<',
		id: '<',
		route: '<',
		$router: '<'
	}
};

export default settingsSubNavItem;