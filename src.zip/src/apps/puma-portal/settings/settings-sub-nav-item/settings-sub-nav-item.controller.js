export default class SettingsSubNavItemController {
	constructor() {
	}
	
	isRouteActive(myRoute, id) {
		return this.$router.isRouteActive(this.$router.generate(['./' + myRoute, {id:id}]));
	}
}