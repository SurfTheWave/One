import './settings-nav-item-mobile.sass';
import template from './settings-nav-item-mobile.tpl.html';
import SettingsNavItemMobileController from './settings-nav-item-mobile.controller.js';

let settingsNavItemMobile = {
	template: template,
	controller: SettingsNavItemMobileController,
	bindings: {
		name: '<',
		description: '<'
	}
};

export default settingsNavItemMobile;