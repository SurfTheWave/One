export default class SettingsNavItemMobileController {
	constructor() {
		if(this.name) {
			this.text = this.name.replace(/([A-Z])/g, ' $1').trim();
		}
	}

}