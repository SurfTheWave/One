import './profile-settings.sass';
import template from './profile-settings.tpl.html';
import ProfileSettingsController from './profile-settings.controller.js';

let profileSettings = {
	template: template,
	controller: ProfileSettingsController
};

export default profileSettings;