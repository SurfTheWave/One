export default class SettingsController {
	constructor($rootScope, $scope, $log, $window, accountService) {
		'ngInject';
		this.visibilityState = 'closed';
		
		this.$rootScope = $rootScope;
		this.$scope = $scope;
		this.accountService = accountService;
		this.sellToAccount = null; // Sell to account which is showing
		
		// Setting menu and component configurations
		// TODO: We can move configurations different place. @AlperG.
		this.$scope.settings = [{
			name:'ProfileSettings',
			componentName:'profile-settings',
			description:'Profile Picture, Personal Information, Contact Adress'
		}, {
			name: 'PaymentDetails',
			componentName:'payment-details',
			description:'Payment Details'
		}, {
			name:'AccountAndSites',
			componentName:'account-and-sites', 
			description:'Site Manager, Site Address, Tank Information, Site Pictures',
			subNavItems: [],
			subRoute: 'SiteDetails'
		}, {
			name:'ContractDetails',
			componentName:'contract-details',
			description:'Sales terms, Site Maintanance'
		}, {
			name:'PortalSettings',
			componentName:'portal-settings',
			description:'Notification, Authorizatiohn, Conversation and Portal Language settings'
		}];
		
		this.$scope.$on('$destroy', () => {
			console.debug('Settings controller destroyed.');
			
			// If scope is destroyed (view is changed) and we are showing a site detail page, show the header
			this.$rootScope.$broadcast('showHeader');
		});
	}
	
	$onInit() {
		this.fillNavItemsAndGetSellTo();
		this.$scope.$watchCollection('$ctrl.sellToAccount.shipToList', (newValue, oldValue) => {	
			if (newValue != oldValue){
				this.fillSiteNavigationItems(); // fill nav site items with new ship-to's
			}
		});
	}
	
	fillNavItemsAndGetSellTo() {
		var self = this;
		return this.accountService.getSellToAccount().then(
			function onSuccess(sellToAccount) {
				self.sellToAccount = sellToAccount;
				self.fillSiteNavigationItems();
				return;
			}
		);
	}
	
	fillSiteNavigationItems() {
		var accountAndSitesSettings = this.$scope.settings[2];
		accountAndSitesSettings.subNavItems = [];
		for(let shipTo of this.sellToAccount.shipToList) {
			accountAndSitesSettings.subNavItems.push({subNavItemName:shipTo.name, id:shipTo.id});
		}
	}
	
	toggleVisibilityState() {
		this.visibilityState = this.visibilityState === 'open' ? 'closed' : 'open';
	}
	
	collapseMenu() {
		if(this.visibilityState === 'open') {
			this.visibilityState = 'closed';
		}
	}
}