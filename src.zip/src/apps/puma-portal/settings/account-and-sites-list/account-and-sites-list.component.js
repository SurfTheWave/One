import template from './account-and-sites-list.tpl.html';
import AccountAndSitesListController from './account-and-sites-list.controller.js';

let accountAndSitesList = {
	template: template,
	controller: AccountAndSitesListController,
	bindings: {
		$router: '<'
	}
};

export default accountAndSitesList;