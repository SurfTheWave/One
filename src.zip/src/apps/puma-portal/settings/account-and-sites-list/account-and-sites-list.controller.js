import SettingsBase from '../settingsBase.class.js';

export default class AccountAndSitesListController extends SettingsBase {
	constructor($rootScope, $scope, accountService, siteDetailInformationDialogService, platformSelectorService, platformType) {
		'ngInject';
		
		super($rootScope, platformSelectorService, platformType);
		
		this.$scope = $scope;
		this.$scope.name = 'Account Details';
		this.accountService = accountService;
		this.siteDetailInformationDialogService = siteDetailInformationDialogService;
	}
	
	$onInit() {
		super.$onInit();
		
		this.accountService.getSellToAccount().then((account) => {
			this.$scope.sellToAccount = account;
			this.$scope.description = this.$scope.sellToAccount.name;
		});
	}
	
	openNewSiteDialog() {
		this.siteDetailInformationDialogService.openNewDialog(this.$scope.sellToAccount);
	}
}