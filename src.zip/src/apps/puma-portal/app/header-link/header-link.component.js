import './header-link.sass';
import template from './header-link.tpl.html';
import HeaderLinkController from './header-link.controller.js';

let headerLink = {
	bindings: {
		link: '<',
		link2: '<',
		class: '<'
	},
	template: template,
	controller: HeaderLinkController,
	transclude: true
};

export default headerLink;