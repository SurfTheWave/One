export default class AppHelper {
	constructor($filter) {
		this.$filter = $filter;
	}
	
	/**
	* @ngdoc function
	* @name getLastDeepReadingDateTime
	* @param {object} tank
	* @description
	* This function aims that return last dip reading date of a tank which is given as parameter 
	* Date filter format: dd.MM.yyyy hh:mm (e.g. 05.15.2016 8:30)
	*/
	getLastDeepReadingDateTime(tank) {
		let lastDipReadingDateTime = new Date(tank.getLastDipReadingDate());
		let filteredDateTime = this.$filter('date')(lastDipReadingDateTime, 'MM.dd.yyyy hh:mm');
		return filteredDateTime;
	}
}