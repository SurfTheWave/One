import template from './app.tpl.html';
import AppController from './app.controller.js';

let appComponent = {
	template: template,
	controller: AppController,
	$routeConfig: [{
		path: '/dashboard/...',
		name: 'Dashboard',
		component: 'dashboard',
		useAsDefault: true
	}, {
		path: '/my-sites',
		name: 'MySites',
		component: 'mySites'
	},{
		path: '/help/...',
		name: 'Help',
		component: 'help'
	},{
		path: '/settings/...',
		name: 'Settings',
		component: 'settings'
	}, {
		path: '/_ui/system/security/ChangePassword',
		name: 'ChangePassword',
		component: 'changePassword'
	},{
		path: '/*otherwise',
		redirectTo: ['Dashboard']
	}]
};

export default appComponent;