/*@ngInject*/
export default function run(store, pumaConnector, accountService, $window, $log, OrderStatusListService) {
	
	'ngInject'
	store.start().then((values) => {
		//console.log('store values', values);
	});

	//Temporary included just to debug puma connector in browser console
	$window.puma = pumaConnector;
	$window.accountService = accountService;
	$window.Demo = {
		demoMultiShipToDeliveryAccount: function() {
			accountService.defaultSellToIndex = 0;
		},
		demoExRackAccount: function() {
			accountService.defaultSellToIndex = 1;
		},
		demoSingleShipToDeliveryAccount: function() {
			accountService.defaultSellToIndex = 2;
		}
	};

	console.error = function() {

		$log.error(...arguments);
	};

	$window.onerror = function() {

		if (angular.isDefined(arguments[4]) && arguments[4] !== null) {

			$log.error({
				description: arguments[4].message,
				errorDetail: arguments[4].stack,
				wasHandled: false
			});
		} else {

			$log.error(...arguments);
		}
	}
}