class FooterLinkController {
	constructor($rootRouter){
		'ngInject';
		this.router = $rootRouter;
	}
	
	isRouteActive(myRoute) {
		return this.router.isRouteActive(this.router.generate(['/' + myRoute]));
	}
}

export default FooterLinkController;