import './footer-link.sass';
import template from './footer-link.tpl.html';
import FooterLinkController from './footer-link.controller.js';

let footerLink = {
	bindings: {
		link: '<',
		class: '<'
	},
	template: template,
	controller: FooterLinkController
};

export default footerLink;