import './app.sass';

import 'acnCore/connector';
import 'coreapi';
import coreConfig from './config.coffee';

import run from './app.run.js';
import app from './app.component.js';
import headerLink from './header-link/header-link.component.js';
import footerLink from './footer-link/footer-link.component.js';
import changePassword from './change-password/change-password.component.js';
import logoutComponent from './logout/logout.component.js';
import loadingSpinner from 'youOne/components/loading-spinner/loading-spinner.component.js';
import slidingArea from './sliding-area/sliding-area.component.js';

import httpInterceptor from './http.interceptor.js';
import OrderStatusListService from 'youOne/services/orderStatusList/orderStatusList.service.js';

import angular from 'angular';
import angularMask from 'angularMask';
import angularUIMask from 'angularUIMask';
import angularDynamicLocale from 'angularDynamicLocale';

// Include puma connector module
import 'puma-connector';
import 'youOne/services/change-request/change-request.js';
import 'youOne/services/order/order.js';
import 'youOne/services/site/site.js';
import 'youOne/services/account/bank-account/bank-account.js';
import 'youOne/services/account/account.js';
import 'youOne/services/account/tank/tank.js';
import 'youOne/services/transaction/transaction.js';
import 'youOne/services/store/store.js';
import 'youOne/services/platformSelector/platformSelector.js';

import 'youOne/services/help-service/help-service.js';

// Include modal-dialog module
import 'youOne/services/modal-dialog/modal-dialog.js';

import 'youOne/services/puma-errorDecorator/puma-errorDecorator.js';
import 'datepicker';
import '../dashboard/dashboard.js';
import '../my-sites/my-sites.js';
import '../help/help.js';
import '../settings/settings.js';

import 'youOne/services/translator/translator.js';

function config($locationProvider, $provide, $httpProvider, tmhDynamicLocaleProvider) {
	'ngInject';
	
	tmhDynamicLocaleProvider.localeLocationPattern('/angular-locale_{{locale}}.js');

	$locationProvider.html5Mode(true);

	$provide.decorator('$log', function($delegate, pumaErrorDecoratorService) {

		return pumaErrorDecoratorService.decorateError($delegate);
	});

	$provide.decorator('$exceptionHandler', function($delegate) {

		let exceptionHandler = (exception, cause) => {
			exception.decoratorErrorType = 'exception';
			$delegate(exception, cause);
		};

		for (let key of Object.keys($delegate)) {

			exceptionHandler[key] = $delegate[key];
		}

		return exceptionHandler;
	});

	// Broadcasts the required event on which the spinner component is listening
	$httpProvider.interceptors.push(httpInterceptor);
}

export default angular.module('app', [
	'puma.store',
	'ngComponentRouter',
	'puma.connector',
	'puma.changeRequests',
	'puma.account',
	'puma.bankAccount',
	'puma.order',
	'puma.site',
	'puma.helpService',
	'puma.tank',
	'puma.transaction',
	'puma.errorDecorator',
	'puma.platformSelector',
	'angularjs-datetime-picker',
	'modal-dialog',
	
	// App modules. We reference the app.login, see the "login" folder.
	'app.dashboard',
	'app.my-sites',
	'app.help',
	'app.settings',
	
	// Translation module
	'app.translate',
	'ui.utils.masks',
	'ui.mask',
	'tmh.dynamicLocale'
	
])
	.config(config)
	
	.run(run)

	// We tell the router what is the base/root component (see below)
	.value('$routerRootComponent', 'app')
	
	.component('app', app)
	.component('changePassword', changePassword)
	.component('headerLink', headerLink)
	.component('footerLink', footerLink)
	//--
	.component('logout', logoutComponent)
	.component('loadingSpinner', loadingSpinner)
	.component('slidingArea', slidingArea)
	.service('OrderStatusListService', OrderStatusListService);

