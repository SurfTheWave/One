let interceptor = ($q, $rootScope, pumaErrorDecoratorService) => {

	'ngInject'
	let request = config => {
		
		$rootScope.$broadcast('spinnerLoading');
		return config;
	}

	let requestError = rejection => {

		$rootScope.$broadcast('spinnerStop');
		return $q.reject(rejection);
	}

	let response = response => {

		$rootScope.$broadcast('spinnerStop');
		return response
	}

	let responseError = rejection => {
		
		pumaErrorDecoratorService.publishError('http', rejection)
		$rootScope.$broadcast('spinnerStop');
		return $q.reject(rejection);
	}

	return {
		'request': request,
		'requestError': requestError,
		'response': response,
		'responseError': responseError
	}
}

export default interceptor