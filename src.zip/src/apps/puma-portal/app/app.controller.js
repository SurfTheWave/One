/*@ngInject*/ 
export default class AppController {
	constructor($scope, $rootScope, platformSelectorService, tmhDynamicLocale) {
		'ngInject';
		
		let supportedLocales = [ 'af', 'af-na', 'af-za', 'en', 'en-au', 'en-gb', 'en-us'];
		//--
		let userLanguage = window.navigator.language || window.navigator.userLanguage;
		userLanguage = userLanguage.toLowerCase();
		//--
		if(this.isValueBelongToList(supportedLocales, userLanguage)){
			tmhDynamicLocale.set(userLanguage);
		}else{
			tmhDynamicLocale.set('en-gb');
		} 
		//--
		this.$scope = $scope;
		this.$rootScope = $rootScope;
		this.platformSelectorService = platformSelectorService;
		
		this.displayHeader = true;
		
		this.$rootScope.$on('showHeader', () => {
			this.displayHeader = true;
			this.$scope.$evalAsync();
		});
		
		this.$rootScope.$on('hideHeader', () => {
			this.displayHeader = false;
			this.$scope.$evalAsync();
		});
	}
	
	isValueBelongToList(list, controlValue){
		let i = 0;
		for(i=0;i<list.length; i++){
			if(list[i] == controlValue){
				return true;
			}
		}
		return false;
	}
}