import './logout.sass';
import template from './logout.tpl.html';
import LogOutController from './logout.controller.js';

let logout = {
	bindings: {
		title: '@',
		message: '@'
	},
	template: template,
	controller: LogOutController
};

export default logout;