/**
 * @ngdoc overview
 * @name logout
 * @param {String} title the title which is displayed on top of the modal dialog
 * @param {String} message the message which will be displayed to the user
 * @description
 * Controller for the logout Component which redirects the user to the sfdc logout url
 */
class LogOutController {

	constructor(modalDialog, $window) {

		'ngInject'
		this.modalDialog = modalDialog;
		this.window = $window;
		this.title = this.title || 'Confirm your Decision';
		this.message = this.message || 'Do you really want to logout?';
	}

	/**
	 * @ngdoc function
	 * @name showConfirmDialog
	 * @description
	 * gets called if user clicks on the logout section and redirect the user to the logout page
	 * on confirmation and if the application is not in visualforce context
	 */
	showConfirmDialog() {

		this.modalDialog('alert', 'yesno', this.message, this.title).then((resolve) => {
			
			if (this.window.visualForceExecution !== '{!\'TRUE\'}' && resolve === 'yes') {
				
				this.window.location.href = this.window.accentureONECore.siteUrl + '/secur/logout.jsp';
			}
		})
	}
}

export default LogOutController;