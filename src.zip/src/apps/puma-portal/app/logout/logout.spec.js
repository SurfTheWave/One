import '../app.js';
import '@angular/router/angular1/angular_1_router.js';

describe('Component: Logout', () => {
	var component, scope, $componentController, deferred;

	let defaultTitle = 'Confirm your Decision';
	let defaultMessage = 'Do you really want to logout?';

	beforeEach(angular.mock.module('app'));

	beforeEach(angular.mock.inject((_$rootScope_, _$componentController_, _$q_) => {

		scope = _$rootScope_.$new();
		$componentController = _$componentController_;
		component = $componentController(
			'logout', {
				$scope: scope
			},
			{
				title: defaultTitle,
				message: defaultMessage
			}
		);

		deferred = _$q_.defer();
	}));

	describe('Component API', () => {

		it('should have a showConfirmDialog method', () => {

			expect(component.showConfirmDialog).toBeDefined();
		});
	});

	describe('Component Usage', () => {

		it('should have proper default values', () => {

			expect(component.title).toBe(defaultTitle);
			expect(component.message).toBe(defaultMessage);
		});

		it('should use proper bindings', () => {

			expect(component.title).toBe(defaultTitle);
			expect(component.message).toBe(defaultMessage);

			component = $componentController(
				'logout',
				{
					$scope: scope
				},
				{
					title: 'Testtitle',
					message: 'Testmessage'
				}
			);

			expect(component.title).toBe('Testtitle');
			expect(component.message).toBe('Testmessage');
		});

		it('should create a modal confirm dialog', () => {

			spyOn(component, 'modalDialog').and.returnValue(deferred.promise);
			component.showConfirmDialog();
			expect(component.modalDialog).toHaveBeenCalledWith('alert', 'yesno', defaultMessage, defaultTitle);
		});

		it('should ignore a local context', () => {

			component.window.visualForceExecution = '{!\'TRUE\'}';
			deferred.resolve('yes');
			spyOn(component, 'modalDialog').and.returnValue(deferred.promise);

			let oldUrl = component.window.location.href;

			component.showConfirmDialog();
			scope.$digest()

			expect(component.window.location.href).toBe(oldUrl);
		});

		it('should stay on the same URL if User declines', () => {

			component.window.visualForceExecution = true;
			deferred.resolve('no');
			spyOn(component, 'modalDialog').and.returnValue(deferred.promise);

			let oldUrl = component.window.location.href;

			component.showConfirmDialog();
			scope.$digest()

			expect(component.window.location.href).toBe(oldUrl);

		});
	});
});