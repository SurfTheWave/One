import './change-password.sass';
import template from './change-password.tpl.html';
import ChangePasswordController from './change-password.controller.js';

let changePassword = {
	template: template,
	controller: ChangePasswordController,
	bindings: {
		$router: '<'
	}
};

export default changePassword;