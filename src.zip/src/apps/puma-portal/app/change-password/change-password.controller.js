class ChangePasswordController {
	constructor(modalDialog) {
		'ngInject';
		this.modalDialog = modalDialog;
		this.isProcessing = false;
	}

	changePassword() {
		this.isProcessing = true;
		TQAppController.changePassword(
			this.newPassword||'',
			(result, event) => {
				if (event.status) {
					if(result) {
						this.modalDialog('alert', 'ok', result).finally(() => {
							this.isProcessing = false;
						});
					} else {
						this.modalDialog('confirm', 'ok', 'Your password has been changed').finally(() => {
							this.isProcessing = false;
						});
						this.$router.navigateByUrl('/');
					}
				} else {
					//we have a login error
					this.modalDialog('alert', 'ok', 'Unknown error').finally(() => {
						this.isProcessing = false;
					});
				}
			}, {
				escape: false
			}
		);
	}
}

export default ChangePasswordController;