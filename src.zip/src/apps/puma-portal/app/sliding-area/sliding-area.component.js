import './sliding-area.sass';
import template from './sliding-area.tpl.html';
import SlidingAreaController from './sliding-area.controller.js';

let slidingArea = {
	template: template,
	controller: SlidingAreaController,
	transclude: true,
	bindings: {
		topPosition: '<'
	}
};

export default slidingArea;