class SlidingAreaController {

	constructor($scope) {
		'ngInject';
		this.menuStatus = false;
		this.slideStatus = '';
	}
	
	openSlideMenu() {
		
		if(!this.menuStatus) {
			this.slideStatus = '-open';
			this.menuStatus = true;
		}
		
		else {
			this.slideStatus = '';
			this.menuStatus = false;
		}
	}
}

export default SlidingAreaController;