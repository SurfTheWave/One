import 'angular';
import 'angular-mocks';
import 'babel-polyfill';
// import 'coffee-namespace';
// import 'localstorage-store';
// import 'ydn';
// import 'salesforce';

// require all modules ending in ".spec.js" from the
// current directory and all subdirectories
let context = require.context('./apps/puma-portal', true, /\.spec\.js$/);
context.keys().forEach(context);

context = require.context('./you-one/', true, /\.spec\.js$/);
context.keys().forEach(context);

