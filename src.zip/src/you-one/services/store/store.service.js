/**
 * Called when the app starts to load several data or called whenever the application requires cached data.
 * Translations, OrderStatusListService and orders (active / past / alerts) are implemented.
 */

const STORE_KEY_PREFIX = 'pumaStore__';

export default class store {
	constructor(pumaConnector, $window, $q, $rootScope) {
		'ngInject';
		this.pumaConnector = pumaConnector;
		this.$window = $window;
		this.$q = $q;
		this.$rootScope = $rootScope;
		this.store = {};
		this.bootstrapPromise = null;
	}
	
	/**
	 * to return the store whenever a part of the application may require it
	 */
	getStore(storeType) {
		return this.$q.when(storeType && this.store[storeType] || this.store);
	}
	
	/**
	 * called by the run method of the root application. should be called once, but supports also multiple call
	 * in parallel (other requests are simply queued awaiting the resolution of the first request)
	 */
	start() {
		//Specifing promise in class variable will guarantee that call will be executed only once during page life cycle
		if (!this.bootstrapPromise){
			this.bootstrapPromise = this.$q.all([
				this.getTranslations(),
				this.getBootstrapData()
			]);
		}
		return this.bootstrapPromise;
	}
	
	/**
	 * called for getting all the translations of the application. if something is found in the localstorage, it will
	 * be used. Otherwise, we do one, and only one, request to Salesforce.
	 */
	getTranslations() {
		const storeName = 'translations';
		return doingRequest.call(this, storeName, () => {
			return this.pumaConnector.post(
				'/translations', {
					language: 'fr',
					labels: [
						'EP_Acc_Setup_Err_Msg',
						'EP_Acknowledgement_WS_URL',
						'EP_Action_Confirmation_Dialogue'
					],
					fields: [{
						type: 'Account',
						field: 'Name'
					}]
				}
			);
		});
	}

	getBootstrapData() {
		return doingRequest.call(this, 'bootstrap', () => {
			return this.pumaConnector.get('/Bootstrap/');
		}, false); //Bootstrap call should not be saved in localstorage because it contains dynamical data
	}
}

/**
 * helper function to retrieve data in localstorage in safe way
 * should be done in try catch block because of Safari private browsing limitation
 * https://slashdot.io/blog/local-storage-is-not-supported-with-safari-in-private-mode-1274581356
 */
function storageSafeDataRetrieve(storage, key){
	var result = null;
	try {
		result = JSON.parse(storage.getItem(STORE_KEY_PREFIX + key));
	} catch (e) {
		result = null;
	}
	return result;
}

function storageSafeSave(storage, key, value){
	var successfull = true;
	try {
		if (storage){ storage.setItem(STORE_KEY_PREFIX + key, JSON.stringify(value)); }
	} catch(e){
		successfull = false;
	}
	return successfull;
}

/**
 * helper function used for avoiding sending multiple time the same request to Salesforce.
 * The biggest advantage of $q.when that it works the same way with deferred, promises and objects
 */
function doingRequest(requestType, executingMethod, cacheInLocalStorage = true){
	//Check if data or executing promise is already located in storage
	if (!this.store[requestType]){
		let storage = this.$window.localStorage;
		//Doing two operations, first trying to get data from localstorage in other case do execution of method
		//Or operation prevents executing second block if first is fine
		//If data in localstorage we return data, if no, we return executing promise
		this.store[requestType] = (cacheInLocalStorage && storageSafeDataRetrieve(storage, requestType)) ||
			executingMethod.call(this).then((result) => {
				if (cacheInLocalStorage) { storageSafeSave(storage, requestType, result); }
				return result;
			}, (error) => {
				//Failed responses shouldn't be cached to give them ability to be called again
				delete this.store[requestType];
				return error;
			});
	}
	return this.$q.when(this.store[requestType]);
}