export default {
	'hasManageOrderPermission ': true,
	'hasNewSiteRequestPermission': true
}