import 'puma-connector';
import store from './store.service.js';
import mocksConfig from './store.mock.js';
import OrderStatusListService from 'youOne/services/orderStatusList/orderStatusList.service.js';

export default angular.module('puma.store', ['puma.connector'])
	.config(mocksConfig)
	.service('store', store)
	.service('OrderStatusListService', OrderStatusListService);