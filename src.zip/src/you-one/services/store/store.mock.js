import orderStatusList from 'youOne/services/orderStatusList/orderStatusList.js';

import dictionary from './store.dictionary.js';
import dashboard from './store.dashboard.js';
import permissions from './store.permissions.js';

/*@ngInject*/
export default function mockConfig(pumaMockServiceProvider) {

	pumaMockServiceProvider.setMockResponses([{
		method: 'POST',
		path: '/translations',
		response: () => {

			return [{
				'EP_Acc_Setup_Err_Msg': 'dummy'
			}, {
				'EP_Acknowledgement_WS_URL': 'google.com'
			}, {
				'EP_Action_Confirmation_Dialogue': 'Sure?'
			}, {
				'Account.Name': 'Le nom de notre compte'
			}];
		},
		useByDefault: false
	}, {
		method: 'GET',
		path: '/orderStatusList',
		response: () => {
			return {
				status: 200,
				errors: null,
				data: orderStatusList
			};
		},
		useByDefault: true
	}, {
		method: 'GET',
		path : '/Bootstrap/',
		response: function (response){
			var accountData = this.getMockResponseData('GET', '/Account/List/');

			return {
				status : 200,
				errors : [],
				sellToList : accountData.sellToList,
				statusMap : orderStatusList,
				dictionary: dictionary,
				dashboard: dashboard,
				permissions: permissions
			};
		},
		useByDefault : true
	}]);
}