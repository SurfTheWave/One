export default {
	/*Common */
	'ep_fe_common_': '',
	/*MySites */
	'ep_fe_mysites_overallstatus': 'OVERALL STATUS',
	'ep_fe_mysites_sitecount': '({{siteCount}} SITES)',
	'ep_fe_mysites_accountsummary': 'ACCOUNT SUMMARY',
	'ep_fe_mysites_ordersummary': 'ORDER SUMMARY',
	'ep_fe_mysites_inventorylevel': 'INVENTORY LEVEL',
	'ep_fe_mysites_enterlevelbtntxt': 'ENTER LEVEL',
	'ep_fe_mysites_missingtankdipalert': 'You have missing dips!',
	'ep_fe_mysites_tanklastupdatecaption': 'LAST UPDATE:',
	'ep_fe_mysites_tankdiptimecaption': 'DIP TIME',
	'ep_fe_mysites_inactivesitecaption': 'Site {{siteName}} is not active yet.'
};