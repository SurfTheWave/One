export default {
	alertOrderAmount: 0,
	activeOrderAmount: 0,
	pastOrderAmount: 0,
	
	pastDueInvoices: [
		{
			'InvoiceNumber': 'I1234567890',
			'DueDate': '2016-07-05T17:00:00.000Z',
			'InvoiceAmount': 106456.0,
			'IssueDate': '2016-05-05T17:00:00.000Z',
			'RemainingBalance': 206456.0,
			'LinkToPDF': 'https://gradcollege.okstate.edu/sites/default/files/PDF_linking.pdf',
			'Status': 'Unpaid'
		},
		{
			'InvoiceNumber': 'I1234567891',
			'DueDate': '2016-07-06T17:00:00.000Z',
			'InvoiceAmount': 102759.0,
			'IssueDate': '2016-05-06T17:00:00.000Z',
			'RemainingBalance': 202759.0,
			'LinkToPDF': 'https://gradcollege.okstate.edu/sites/default/files/PDF_linking.pdf',
			'Status': 'Unpaid'
		},
		{
			'InvoiceNumber': 'I1234567892',
			'DueDate': '2016-07-07T17:00:00.000Z',
			'InvoiceAmount': 95221.0,
			'IssueDate': '2016-05-07T17:00:00.000Z',
			'RemainingBalance': 195221.0,
			'LinkToPDF': 'https://gradcollege.okstate.edu/sites/default/files/PDF_linking.pdf',
			'Status': 'Unpaid'
		},
		{
			'InvoiceNumber': 'I1234567893',
			'DueDate': '2016-07-08T17:00:00.000Z',
			'InvoiceAmount': 106456.0,
			'IssueDate': '2016-05-08T17:00:00.000Z',
			'RemainingBalance': 206456.0,
			'LinkToPDF': 'https://gradcollege.okstate.edu/sites/default/files/PDF_linking.pdf',
			'Status': 'Unpaid'
		},
		{
			'InvoiceNumber': 'I1234567894',
			'DueDate': '2016-07-09T17:00:00.000Z',
			'InvoiceAmount': 124000.0,
			'IssueDate': '2016-05-09T17:00:00.000Z',
			'RemainingBalance': 224000.0,
			'LinkToPDF': 'https://gradcollege.okstate.edu/sites/default/files/PDF_linking.pdf',
			'Status': 'Unpaid'
		},
		{
			'InvoiceNumber': 'I1234567895',
			'DueDate': '2016-07-10T17:00:00.000Z',
			'InvoiceAmount': 106446.0,
			'IssueDate': '2016-05-10T17:00:00.000Z',
			'RemainingBalance': 206446.0,
			'LinkToPDF': 'https://gradcollege.okstate.edu/sites/default/files/PDF_linking.pdf',
			'Status': 'Unpaid'
		},
		{
			'InvoiceNumber': 'I1234567896',
			'DueDate': '2016-07-11T17:00:00.000Z',
			'InvoiceAmount': 103456.0,
			'IssueDate': '2016-05-11T17:00:00.000Z',
			'RemainingBalance': 203456.0,
			'LinkToPDF': 'https://gradcollege.okstate.edu/sites/default/files/PDF_linking.pdf',
			'Status': 'Unpaid'
		}
	]
}