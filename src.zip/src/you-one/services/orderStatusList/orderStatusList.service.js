/**
 * @ngdoc service
 * @name OrderStatusListService
 * @description
 * A Service which retrieves the Mappingfile for the Order Status and expose Information about Steps, Captions and so on
*/
class OrderStatusListService {

	constructor(pumaConnector, $q, $log, store) {

		'ngInject'
		this.pumaConnector = pumaConnector;
		this.$q = $q;
		this.orderStatusList = null;
		this.$log = $log;
		this.store = store;

		this.hasError = false;
		this.customerType = 'Ex-Rack';
		this.paymentType = 'Prepayment';
		this.steps = [];
	}

	/**
	 * @ngdoc function
	 * @name loadOrderStatusList
	 * @description
	 * get called in store service and loads the Mappingfile for the Order Statuses
	*/
	loadOrderStatusList() {

		return this.pumaConnector.get('/orderStatusList').catch((error) => {

			this.$log.error({
				'description': 'Data loading Error, ' + error.message,
				'errorDetail': error.stack,
				'performedAction': 'Error occured while loading the orderStatusList initially',
				'wasHandled': true
			});
			this.hasError = true;
			return null;
		});
	}

	/**
	 * @ngdoc function
	 * @name getOrderStatusList
	 * @description
	 * gets the Mapping File for the Order Statuses of the boostrap service
	*/
	getOrderStatusList() {

		return this.store.getBootstrapData().then((values) => {
				let list = values.statusMap;

				if (angular.isUndefined(list) || list === null) {

					this.$log.error({
						'description': 'There was no store entry for the OrderStatusListService',
						'errorDetail': 'List undefined or null: ',// + list,
						'performedAction': 'Error while accessing the boostrap value to retrieve the order status list',
						'wasHandled': true
					});
					this.hasError = true;
					return null;
				} else {

					this.orderStatusList = list;

					return list;
				}
		}).catch((error) => {

			this.$log.error({
				'description': 'Data loading Error, ' + error.message,
				'errorDetail': error.stack,
				'performedAction': 'Error occured while loading the order status list from the boostrap service',
				'wasHandled': true
			});
			this.hasError = true;
			return null;
		});
	}

	/**
	 * @ngdoc function
	 * @name getTotalStepNumber
	 * @param {Object} the Mapping File for the Order Statuses, default: the orderStatusList in the this context
	 * @description
	 * returns an Integer which represents the total amount of overall Order Steps
	*/
	getTotalStepNumber(statusList = this.orderStatusList, type = this.customerType, payment = this.paymentType) {

		if (!this.hasError) {

			try {

				/** if required load the mapping file for order statuses */
				if (statusList) {
					let stepArray = [];

					//New format doesn't contain labels just array of values, so we just need to take information
					//for specific payment type and delivery type
					if (statusList[type] && Array.isArray(statusList[type][payment])){
						stepArray = statusList[type][payment];
					}

					/** fills the steps array as the stepArray represents all Step Captions */
					if (stepArray.length > 0) {
						this.steps = stepArray;
					}

					return stepArray.length;
				} else {
					return this.getOrderStatusList().then((response) => {
						return this.getTotalStepNumber(response.orderStatusList);
					})
				}
			} catch (exception) {

				debugger;
				this.$log.error({
					'description': 'Unexpected Customer or Payment Type, ' + exception.message,
					'errorDetail': exception.stack,
					'performedAction': 'Error while accessing the orderStatusList to retrieve total Step numbers with keys '
					+ type + ', ' + payment,
					'wasHandled': true
				});
				this.hasError = true;
				return -1;
			}
		} else {

			return -1;
		}
	}

	/**
	 * @ngdoc function
	 * @name getStepNumber
	 * @param {String} a string value which represents one of the main step values (meaning one of the step captions)
	 * @param {Object} the Mapping File for the Order Statuses, default: the orderStatusList in the this context
	 * @param {String} the type of the customer delivery (e. g. 'Ex-Rack'), default: customerType in the this context
	 * @param {String} the payment term (e. g. 'Prepayment'), default: paymentType in the this context
	 * @description
	 * returns an Integer which represents on which of the steps the order is currently in
	*/
	getStepNumber(status, statusList = this.orderStatusList, type = this.customerType, payment = this.paymentType) {

		if (!this.hasError) {

			try {

				/** if required load the mapping file for order statuses */
				if (statusList) {

					/** There have to be an entry in the mapping file to proceed, else throw an error */
					let index = statusList[type][payment].indexOf(status);

					//Try catch block is commented because angular stop foreach execution if exception is thrown
					/*if (index === -1) {

						throw new Error('Status ' + status + ' was not found in the order Status list: ' + angular.toJson(statusList, true));
					}*/

					/** we increment the integer value as a step number begins with 1 */
					return (index === -1) ? -1 :index + 1;
				} else {

					return this.getOrderStatusList().then((response) => {

						return this.getStepNumber(status, response.orderStatusList);
					})
				}
			} catch (exception) {

				debugger;
				this.$log.error({
					'description': 'Unexpected Customer, Payment or Status Type,' + exception.message,
					'errorDetail': exception.stack,
					'performedAction': 'Error while accessing the orderStatusList to retrieve the actual step number with keys '
					+ type + ', ' + payment + ', ' + status,
					'wasHandled': true
				});
				this.hasError = true;
				return -1;
			}
		} else {

			return -1;
		}
	}

	/**
	 * @ngdoc function
	 * @name getStepLabels
	 * @param {Object} the Mapping File for the Order Statuses, default: the orderStatusList in the this context
	 * @description
	 * returns an Array of the Order Status Captions
	*/
	getStepLabels(statusList = this.orderStatusList, type = this.customerType, payment = this.paymentType) {

		if (!this.hasError) {

			try {

				/** if required load the mapping file for order statuses */
				if (statusList) {

					/** returns the array which is filled by the method getTotalStepNumber, else throw an error */
					if (Array.isArray(statusList[type][payment])) {
						return statusList[type][payment];
					} else {

						throw new Error('Steps Array was found empty. Make Sure to call getTotalStepNumber before trying to access the Captions');
					}
				} else {

					return this.getOrderStatusList().then((response) => {
						return this.getStepLabels(response.orderStatusList);
					})
				}
			} catch (exception) {
				this.$log.error({
					'description': 'Unexpected Customer or Payment Type, ' + exception.message,
					'errorDetail': exception.stack,
					'performedAction': 'Error while accessing the orderStatusList to retrieve step labels with keys '
					+ this.customerType + ', ' + this.paymentType,
					'wasHandled': true
				});
				this.hasError = true;
				return -1;
			}

		} else {

			return -1;
		}
	}

	/**
	 * @ngdoc function
	 * @name setTypeData
	 * @param {String} a string value which stands for the DeliveryType(e. g. Ex-Rack) and is used as First Key in the Mapping File
	 * @param {String} a string value which stands for the PaymentType(e. g. Prepayment) and is used as Second Key in the Mapping File
	 * @description
	 * sets the required contextual Data which is used to retrieve Data from the Mapping File 
	*/
	setTypeData(customer = this.customerType, payment = this.paymentType) {

		this.customerType = customer;
		this.paymentType = payment;
	}
}

export default OrderStatusListService;