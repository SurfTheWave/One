import 'app/app.js';
import '@angular/router/angular1/angular_1_router.js';
import orderStatusList from './orderStatusList.js'

describe('Service OrderStatusList', () => {

	let service, deferred, $rootScope, $log, pumaConnector;
	let exRackSteps = 4;
	let exRackStep = 'Scheduled';
	let exRackStepNumber = 2;
	let exRackStepCaptions = ['Ordered', 'Scheduled', 'Loaded', 'Invoiced'];
	let deliverySteps = 5;
	let deliveryStep = 'Ordered';
	let deliveryStepNumber = 1;
	let deliveryStepCaptions = ['Ordered', 'Scheduled', 'Loaded', 'Delivered', 'Invoiced'];

	beforeEach(angular.mock.module('app'));

	beforeEach(angular.mock.inject((_$rootScope_, _$q_, _$log_, _OrderStatusListService_, _pumaConnector_) => {

		service = _OrderStatusListService_;
		$rootScope = _$rootScope_;
		$log = _$log_;
		pumaConnector = _pumaConnector_
		deferred = _$q_.defer();
		service.orderStatusList = orderStatusList;
	}));

	describe('Service API', () => {

		it('should have a loadOrderStatusList method', () => {

			expect(service.loadOrderStatusList).toBeDefined();
		})

		it('should have a getOrderStatusList method', () => {

			expect(service.getOrderStatusList).toBeDefined();
		})

		it('should have a getTotalStepNumber method', () => {

			expect(service.getTotalStepNumber).toBeDefined();
		})

		it('should have a getStepNumber method', () => {

			expect(service.getStepNumber).toBeDefined();
		})

		it('should have a getStepLabels method', () => {

			expect(service.getStepLabels).toBeDefined();
		})

		it('should have a setTypeData method', () => {

			expect(service.setTypeData).toBeDefined();
		})

		it('should have proper default values', () => {

			expect(service.hasError).toBe(false);
			expect(service.customerType).toEqual('Ex-Rack');
			expect(service.paymentType).toEqual('Prepayment');
			expect(service.steps.length).toBe(0);
		})
	});

	describe('Service Usage', () => {

		it('should catch an Error while loading the MappingFile via loadOrderStatusList', () => {

			expect($log.error.logs.length).toBe(0);

			deferred.reject('An Error occured');
			spyOn(pumaConnector, 'get').and.returnValue(deferred.promise);

			service.loadOrderStatusList();
			$rootScope.$digest();

			expect($log.error.logs.length).toBe(1);
			expect($log.error.logs[0][0].performedAction).toEqual('Error occured while loading the orderStatusList initially');

		});

		it('should return the MappingFile via getOrderStatusList', () => {

			let returnList = service.getOrderStatusList();
			$rootScope.$digest();

			expect(returnList.$$state.value).toEqual(orderStatusList);
		});

		it('should set the correct TypeData via setTypeData', () => {

			expect(service.customerType).toEqual('Ex-Rack');
			expect(service.paymentType).toEqual('Prepayment');

			service.setTypeData('Delivery', 'Postpayment');

			expect(service.customerType).toEqual('Delivery');
			expect(service.paymentType).toEqual('Postpayment');
		});

		it('should load the orderlist as required and get the correct StepNumbers for an Order', () => {

			service.orderStatusList = null;

			let result = service.getTotalStepNumber();

			$rootScope.$digest();
			expect(result.$$state.value).toEqual(exRackSteps);
		});

		it('should get the correct StepNumbers for an Ex-Rack Order', () => {

			let result = service.getTotalStepNumber();

			expect(result).toEqual(exRackSteps);
		});

		it('should get the correct StepNumbers for an Delivery Order', () => {

			service.setTypeData('Delivery', 'Postpayment');

			let result = service.getTotalStepNumber();

			expect(result).toEqual(deliverySteps);
		});

		it('should return 0 for StepNumbers for non existing Values', () => {

			service.setTypeData('NotExisting', 'TestStuff');
			let result = service.getTotalStepNumber();

			expect(result).toEqual(0);
		});

		it('should load the orderlist as required and get the correct StepNumber for an Status', () => {

			service.orderStatusList = null;

			let result = service.getStepNumber(exRackStep);

			$rootScope.$digest();
			expect(result.$$state.value).toEqual(exRackStepNumber);
		});

		it('should get the correct StepNumber for an Ex-Rack Order', () => {

			let result = service.getStepNumber(exRackStep);
			expect(result).toEqual(exRackStepNumber);
		});

		it('should get the correct StepNumber for an Delivery Order', () => {

			service.setTypeData('Delivery', 'Postpayment');
			let result = service.getStepNumber(deliveryStep);

			expect(result).toEqual(deliveryStepNumber);
		});

		it('should catch an Error while getting the StepNumber', () => {

			expect($log.error.logs.length).toEqual(0);
			expect(service.hasError).toEqual(false);

			let result = service.getStepNumber('TestStep', 'NotExisting', 'TestStuff');

			expect(result).toEqual(-1);
			expect($log.error.logs.length).toEqual(1);
			expect(service.hasError).toEqual(true);
		});

		it('should load the orderlist as required and return the correct Step Captions', () => {

			service.orderStatusList = null;
			service.getTotalStepNumber();
			let result = service.getStepLabels();

			$rootScope.$digest();
			expect(result.$$state.value).toEqual(exRackStepCaptions);
		});

		it('should return the correct Step Captions for an Ex-Rack Order', () => {
			
			service.getTotalStepNumber();
			let result = service.getStepLabels();
			expect(result).toEqual(exRackStepCaptions);
		});

		it('should return the correct Step Captions for an Delivery Order', () => {

			service.setTypeData('Delivery', 'Postpayment');
			service.getTotalStepNumber();
			let result = service.getStepLabels();

			expect(result).toEqual(deliveryStepCaptions);
		});

		it('should catch an Error while getting the StepNumber', () => {

			expect($log.error.logs.length).toEqual(0);
			expect(service.hasError).toEqual(false);
			service.setTypeData('NotExisting', 'TestStuff');
			let result = service.getStepLabels();

			expect(result).toEqual(-1);
			expect($log.error.logs.length).toEqual(1);
			expect(service.hasError).toEqual(true);
		});
	});
})