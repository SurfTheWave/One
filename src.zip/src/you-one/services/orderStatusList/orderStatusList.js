/** Mocking File for OrderStatusList Mapping */
let orderStatusList = {
	'Ex-Rack': {
		'Prepayment': [
			'Ordered',
			'Scheduled',
			'Loaded',
			'Invoiced'
		],
		'Postpayment': [
			'Ordered',
			'Scheduled',
			'Loaded',
			'Invoiced'
		]
	},
	'Delivery': {
		'Prepayment': [
			'Ordered',
			'Scheduled',
			'Loaded',
			'Delivered',
			'Invoiced'
		],
		'Postpayment': [
			'Ordered',
			'Scheduled',
			'Loaded',
			'Delivered',
			'Invoiced'
		]
	}
};

export default orderStatusList;