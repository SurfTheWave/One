import '../puma-connector/puma-connector.js';
import PumaErrorDecoratorService from './puma-errorDecorator.service.js';
import mocksConfig from './puma-errorDecorator.mock.js';

export default angular.module('puma.errorDecorator', [])
	.service('pumaErrorDecoratorService', PumaErrorDecoratorService)
	.config(mocksConfig);
