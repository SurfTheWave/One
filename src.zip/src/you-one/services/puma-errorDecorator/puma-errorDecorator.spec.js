import 'app/app.js';
import '@angular/router/angular1/angular_1_router.js';

describe('Component: ErrorDecorator', () => {

	let pumaErrorDecoratorService, $log, pumaConnector, $window, expectedErrorObject, $exceptionHandler,
		$timeout, $http, $httpBackend;

	let ua = 'TestBrowser';
	let sfAppId = 'DecoratorTest';
	let device = 'placeholder';
	let appVersion = '1.3';
	let userId = '1';
	let errorMessageOne = 'Testerror';
	let errorMessageTwo = 'TesterrorTwo';
	let errorMessageThree = 'TesterrorThree';
	let errorObject = {
		errorData: 'ErrorData',
		errorCause: 'ErrorCause'
	}
	let definedErrorObject = {

		'description': 'Defined Error',
		'errorDetail': 'Defined Detail',
		'performedAction': 'Defined Action',
		'wasHandled': false
	};
	let testException = {
		message: 'This is an Testexception',
		stack: 'Testexception: This is an Testexception\nat Line 1\nand Line2\nand Line3'

	}

	beforeEach(angular.mock.module('app'));

	beforeEach(angular.mock.module(function ($exceptionHandlerProvider) {

		$exceptionHandlerProvider.mode('log');

	}));

	beforeEach(angular.mock.inject((_$rootScope_, _$componentController_, _pumaErrorDecoratorService_,
		_$log_, _$window_, _pumaConnector_, _$exceptionHandler_, _$timeout_, _$http_, _$httpBackend_) => {

		$window = _$window_;
		$window.ua = ua;
		$window.sfAppId = sfAppId;
		$window.device = device;
		$window.appVersion = appVersion;
		$window.accentureONECore = {
			userId: userId
		};

		pumaErrorDecoratorService = _pumaErrorDecoratorService_;
		$log = _$log_;
		pumaConnector = _pumaConnector_;
		$exceptionHandler = _$exceptionHandler_;
		$timeout = _$timeout_;

		expectedErrorObject = {

			'description': '',
			'errorDetail': '',
			'performedAction': '',
			'wasHandled': true,
			'browser': ua,
			'component': sfAppId,
			'device': device,
			'operatingSystem': $window.navigator.platform,
			'version': appVersion,
			'user': userId
		};

		$http = _$http_;
		$httpBackend = _$httpBackend_;
		$httpBackend.whenGET('/notExisting').respond(404, errorMessageOne);
		$httpBackend.whenGET('/Existing').respond(200);

		spyOn(pumaErrorDecoratorService, 'publishError').and.callThrough();
		spyOn(pumaConnector, 'post');

	}));

	describe('Component API', () => {

		it('should have a decorateError method', () => {

			expect(pumaErrorDecoratorService.decorateError).toBeDefined();
		});

		it('should have a publishError method', () => {

			expect(pumaErrorDecoratorService.publishError).toBeDefined();
		});

		it('should have a logToLocalStorage method', () => {

			expect(pumaErrorDecoratorService.logToLocalStorage).toBeDefined();
		});
	});

	describe('Component Usage', () => {

		it('should log a single Error Message', () => {

			expectedErrorObject.description = errorMessageOne;
			expectedErrorObject.errorDetail = errorMessageOne;

			$log.error(errorMessageOne);

			expect($log.error.logs).toEqual([[errorMessageOne]]);
			expect(pumaErrorDecoratorService.publishError).toHaveBeenCalledWith('error', [errorMessageOne]);
			//With('error', [errorMessageOne]);
			expect(pumaConnector.post).toHaveBeenCalledWith('/logError', expectedErrorObject);
		});

		it('should concatenate multiple Error Messages', () => {

			expectedErrorObject.errorDetail = errorMessageOne + ' ' + errorMessageTwo + ' ' + errorMessageThree + ' '

			$log.error(errorMessageOne, errorMessageTwo, errorMessageThree);

			expect($log.error.logs).toEqual([[errorMessageOne, errorMessageTwo, errorMessageThree]]);
			expect(pumaErrorDecoratorService.publishError).toHaveBeenCalledWith('error', [errorMessageOne, errorMessageTwo, errorMessageThree]);
			expect(pumaConnector.post).toHaveBeenCalledWith('/logError', expectedErrorObject);
		});

		it('should log an Object in JSON', () => {

			expectedErrorObject.errorDetail = angular.toJson(errorObject, true);

			$log.error(errorObject);

			expect($log.error.logs).toEqual([[errorObject]]);
			expect(pumaErrorDecoratorService.publishError).toHaveBeenCalledWith('error', [errorObject]);
			expect(pumaConnector.post).toHaveBeenCalledWith('/logError', expectedErrorObject);
		});

		it('should log error messages and objects together', () => {

			expectedErrorObject.errorDetail = errorMessageOne + ' ' + angular.toJson(errorObject, true);

			$log.error(errorMessageOne, errorObject);

			expect($log.error.logs).toEqual([[errorMessageOne, errorObject]]);
			expect(pumaErrorDecoratorService.publishError).toHaveBeenCalledWith('error', [errorMessageOne, errorObject]);
			expect(pumaConnector.post).toHaveBeenCalledWith('/logError', expectedErrorObject);
		});

		it('should map Data of the defined error Object to the correct fields', () => {

			expectedErrorObject.description = definedErrorObject.description;
			expectedErrorObject.errorDetail = definedErrorObject.errorDetail + ' ';
			expectedErrorObject.performedAction = definedErrorObject.performedAction;
			expectedErrorObject.wasHandled = definedErrorObject.wasHandled;

			$log.error(definedErrorObject);

			expect($log.error.logs).toEqual([[definedErrorObject]]);
			expect(pumaErrorDecoratorService.publishError).toHaveBeenCalledWith('error', [definedErrorObject]);
			expect(pumaConnector.post).toHaveBeenCalledWith('/logError', expectedErrorObject);
		});

		it('should combine Data of the defined error Object and other arguments', () => {

			expectedErrorObject.description = definedErrorObject.description;
			expectedErrorObject.errorDetail = definedErrorObject.errorDetail + ' ' + errorMessageOne + ' ';
			expectedErrorObject.performedAction = definedErrorObject.performedAction;
			expectedErrorObject.wasHandled = definedErrorObject.wasHandled;

			$log.error(errorMessageOne, definedErrorObject);

			expect($log.error.logs).toEqual([[errorMessageOne, definedErrorObject]]);
			expect(pumaErrorDecoratorService.publishError).toHaveBeenCalledWith('error', [errorMessageOne, definedErrorObject]);
			expect(pumaConnector.post).toHaveBeenCalledWith('/logError', expectedErrorObject);
		});

		it('should capture calls to console.error', () => {

			expectedErrorObject.description = errorMessageOne;
			expectedErrorObject.errorDetail = errorMessageOne;

			console.error(errorMessageOne);

			expect($log.error.logs).toEqual([[errorMessageOne]]);
			expect(pumaErrorDecoratorService.publishError).toHaveBeenCalledWith('error', [errorMessageOne]);
			expect(pumaConnector.post).toHaveBeenCalledWith('/logError', expectedErrorObject);
		});

		it('should capture exceptions', () => {

			expectedErrorObject.description = testException.message;
			expectedErrorObject.errorDetail = testException.stack;
			expectedErrorObject.performedAction = testException.stack.split('\n')[0] + ' ' + testException.stack.split('\n')[1];
			expectedErrorObject.wasHandled = false;

			$timeout(() => {
				throw testException;
			})

			expect($exceptionHandler.errors).toEqual([]);
			$timeout.flush();

			expect($exceptionHandler.errors).toEqual([[testException, undefined]]);
			expect($exceptionHandler.errors[0][0].decoratorErrorType).toEqual('exception');

		});

		it('should capture http errors', () => {

			let httpResponse = {};

			expectedErrorObject.description = errorMessageOne;
			expectedErrorObject.errorDetail = errorMessageOne + ', 404, ';
			expectedErrorObject.performedAction = 'HTTP GET Call';
			expectedErrorObject.wasHandled = false;

			$http.get('/notExisting').catch((error) => {

				httpResponse = error;
			})

			$http.get('/Existing');

			$httpBackend.flush();

			expect(pumaErrorDecoratorService.publishError).toHaveBeenCalledWith('http', httpResponse);
			expect(pumaErrorDecoratorService.publishError.calls.count()).toBe(1);
			expect(pumaConnector.post).toHaveBeenCalledWith('/logError', expectedErrorObject);
		});
	});
});