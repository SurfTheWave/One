/*@ngInject*/
export default function mockConfig(pumaMockServiceProvider) {

	'ngInject'
	pumaMockServiceProvider.setMockResponse('POST','/logError',{isLogged: true}, true);
}
