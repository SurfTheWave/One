/**
 * @ngdoc service
 * @name pumaErrorDecoratorService
 * @description
 * A Decoratorservice to log Errors of the Application and save it to the SFDC Backend. It covers
 * calls to console.error, $log.error with custom object, string parameter or multiple arguments and 
 * unhandled Exceptions after Initialization.
 * @example
 * $log.error('errorMessage');
 * @example
 * $log.error('errorMessage', errorObject, 'moreDetail');
 * @example
 * $log.error({
 *		description: 'User tried an illegal Operation',
 *		errorDetail: 'Operation save is not allowed in this context',
 *		performedAction: 'SaveController call to saveObject method',
 *		wasHandled: true
 * });
 * @example
 * NotExistingArray.push(ThisWillThrowAnError);
 * 
 */
class PumaErrorDecoratorService {

	constructor($injector, $window) {

		'ngInject'
		this.$injector = $injector;
		this.$window = $window;
	}

	/**
	 * @ngdoc function
	 * @name decorateError
	 * @param {Object} $delegate the original $log service instance which will be decorated
	 * @description
	 * A Decoratorservice for the $log Service which assign the Log Functionality to its error-Method.
	 */
	decorateError($delegate) {

		let errorFn = $delegate.error;
		let decoratorService = this;
		let oldDecorator = {};

		/** keeps additional stuff (e. g. additional log array of ngMock) so we can add it back later */
		for (let key of Object.keys($delegate.error)) {

			oldDecorator[key] = $delegate.error[key];
		}

		/** Assign the new functionaliy to the error method */
		$delegate.error = function () {

			let decoratorErrorType = undefined;
			if (angular.isDefined(arguments[0]) && arguments[0] !== null) {

				/** decoratorErrorType will be set in the $exceptionhandler which gets called for an Exception */
				({ decoratorErrorType } = arguments[0]);

				decoratorErrorType = decoratorErrorType || 'error';
				decoratorService.publishError(decoratorErrorType, Array.prototype.slice.call(arguments, 0));
			}

			/** Apply to original function */
			errorFn(...arguments);
		};

		/** adds everything back but keeps the new function definiton */
		for (let key of Object.keys(oldDecorator)) {

			$delegate.error[key] = oldDecorator[key];
		}

		return $delegate;
	}

	/**
	 * @ngdoc function
	 * @name publishError
	 * @param {String} errorType specifies the Type for data mapping, can be exception, error or http
	 * @param {Array Object} errorData contains the original arguments Array
	 * @description
	 * Maps the Errordata to a Object which will be send to the SFDC Backend in order to save an Error to the ExceptionLog Object
	 */
	publishError(errorType, errorData) {

		/** TODO remove later when LocalStorage is used */
		let $log = this.$injector.get('$log');
		try {
			
			/** Represents the Request Data Fields */
			let description, errorDetail, performedAction, wasHandled

			let pumaConnector = this.$injector.get('pumaConnector');

			/** Maps the Data based on the errorType */
			if (errorType === 'exception') {

				description = errorData[0].message;

				if (angular.isDefined(errorData[0].stack) && errorData[0].stack !== null) {

					performedAction = errorData[0].stack.split('\n')[0] + ' ' + errorData[0].stack.split('\n')[1];
				}

				errorDetail = errorData[0].stack;
				wasHandled = false;

			} else if (errorType === 'error') {

				let detail = '';

				if (errorData.length === 1 && angular.isString(errorData[0])) {

					description = errorData[0];
					errorDetail = errorData[0];
				} else {

					for (let arg of errorData) {

						if (angular.isObject(arg)) {

							({ description, errorDetail, performedAction, wasHandled } = arg);

							detail = errorDetail ? (angular.isObject(errorDetail)) ? angular.toJson(errorDetail, true).concat(' ' + detail) : String(errorDetail).concat(' ' + detail) : detail.concat(angular.toJson(arg, true));

						} else {

							detail = detail.concat(arg + ' ');
						}
					}

					errorDetail = detail;
				}

				description = description || '';
				errorDetail = errorDetail || '';
				performedAction = performedAction || '';
				wasHandled = (angular.isDefined(wasHandled) && wasHandled !== null) ? wasHandled : true;

			} else if (errorType === 'http') {

				description = errorData.data;
				performedAction = 'HTTP ' + errorData.config.method + ' Call';
				errorDetail = errorData.data + ', ' + errorData.status + ', ' + errorData.statusText;
				wasHandled = false;
			}

			let errorRequestData = {

				'description': description,
				'errorDetail': errorDetail,
				'performedAction': performedAction,
				'wasHandled': wasHandled
			};

			/** Fills Context Data */
			errorRequestData.browser = this.$window.ua;
			errorRequestData.component = this.$window.sfAppId;
			errorRequestData.device = 'placeholder';
			errorRequestData.operatingSystem = this.$window.navigator.platform;
			errorRequestData.version = this.$window.appVersion;
			errorRequestData.user = this.$window.accentureONECore.userId;

			// Log will be replaced later by localstorage.. for now it goes to console for debugging
			//this.logToLocalStorage(errorRequestData, errorRequestData.component + '_errors');
			pumaConnector.post('/logError', errorRequestData).catch((error) => {

				$log.log('An Error occured: ', error);
			})

		} catch (error) {

			$log.log('Error on Datacreation: ', error);
		}
	}

	/**
	 * @ngdoc function
	 * @name logToLocalStorage
	 * @param {Object} errorData an Object which holds ErrorData in it
	 * @param {String} key a String value which will be used as Key for the localStorage
	 * @description
	 * Converts the ErrorData to a JSON String and adds it for later use to the localStorage
	 */
	logToLocalStorage(errorData, key) {

		let tempList = this.$window.localStorage.getItem(key);
		let errorList = [];

		if (angular.isDefined(tempList) && (tempList !== null)) {

			errorList = angular.fromJson(tempList);
		}

		errorList.push(errorData);
		this.$window.localStorage.setItem(key, angular.toJson(errorList));
	}
}

export default PumaErrorDecoratorService;