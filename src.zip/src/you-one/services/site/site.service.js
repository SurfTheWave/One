class SiteService {
	constructor(pumaConnector){
		this.pumaConnector = pumaConnector;
		}

	getShipToData(shipToIds){
		return this.pumaConnector.get('/em_getShipToData', {shipToIds: shipToIds});
	}
	
	getTankData(shipToId, dipDate){
		return this.pumaConnector.get('/em_getTankDipEntryData', {shipToId: shipToId, dipDate: dipDate});
	}

	submitTankDips(tankDips){
		return this.pumaConnector.post('/em_submitTankDips', tankDips);
	}
}

SiteService.$inject = ['pumaConnector'];

export default SiteService;