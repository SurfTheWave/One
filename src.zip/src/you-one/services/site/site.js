import angular from 'angular';

import '../puma-connector/puma-connector.js';

import siteService from './site.service.js';
import mocksConfig from './site.mocks.js';

export default angular.module('puma.site', ['puma.connector'])
	.service('siteService', siteService)
	
	// Include mock responses
	.config(mocksConfig);