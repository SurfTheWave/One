class Mapping {
	constructor(frontEndName, backEndName, isUpdateField, isInsertField, isLookUpField) {
		this.frontEndName = frontEndName;
		this.backEndName = backEndName;
		this.isUpdateField = isUpdateField;
		this.isInsertField = isInsertField;
		this.isLookUpField = isLookUpField;
	}
}

export default Mapping;