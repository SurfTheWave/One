let ApiHelper = {
	convertDateToAPIDateString : function(value){
		return new Date(value).toISOString();
	},

	getAddressString : function(record, addressType = ''){
		let fieldName = addressType + 'Address';
		if (record[fieldName]){
			let addressData = record[fieldName];
			let addressKeys = ['street', 'city', 'state', 'country', 'postalCode'];
			let orderComponents = [];
			for (let addressComponentKey of addressKeys){
				if (addressData[addressComponentKey] && addressData[addressComponentKey].trim() != ''){
					orderComponents.push(addressData[addressComponentKey]);
				}
			}

			if (orderComponents.length){
				return orderComponents.join(' ');
			}
		}
		return null;
	},

	getBillingAddressString : function(record){
		return this.getAddressString(record, 'Billing');
	},

	getShippingAddressString : function(record){
		return this.getAddressString(record, 'Shipping');
	}
};

export default ApiHelper;