let encodeGetParameters = function (parameters) {
	let headerArray = [];
	for (let key in parameters) {
		var value;
		if (parameters[key] !== undefined && parameters[key] !== null) {
			value = encodeURIComponent(parameters[key]);
		} else {
			value = '';
		}
		headerArray.push(encodeURIComponent(key) + '=' + value);
	}

	if (headerArray.length > 0) {
		return '?' + headerArray.join('&');
	} else {
		return '';
	}
};

class PumaDirectConnector {
	constructor(tqCoreConnector) {
		'ngInject'
		this.tqCoreConnector = tqCoreConnector;
		this.apexMethodPreffix = '/FE/V1';
	}

	apexPath(path) {
		return this.apexMethodPreffix + path;
	}

	//Get Id of current user
	getUserId() {
		return this.tqCoreConnector.user.getId();
	}

	//Send GET request to Salesforce web service
	get(path, parameters, options) {
		if (parameters) {
			path += encodeGetParameters(parameters);
		}
		return this.tqCoreConnector.rest.get(this.apexPath(path), parameters, options);
	}

	//Send POST request to Salesforce web service
	post(path, body, options) {
		return this.tqCoreConnector.rest.post(this.apexPath(path), body, options);
	}

	//Send PUT request to Salesforce web service
	put(path, body, options) {
		return this.tqCoreConnector.rest.put(this.apexPath(path), body, options);
	}

	//Execute SOQL query to get list of objects
	query(query, includeDeleted) {
		return this.tqCoreConnector.storage.find(query, includeDeleted);
	}

	//Execute SOQL query to get single object
	queryOne(query, includeDeleted) {
		return this.tqCoreConnector.storage.findOne(query, includeDeleted);
	}

	upsert(data) {
		return this.tqCoreConnector.storage.upsert(data);
	}
	getTrackedObjectRecordInstance(apiName) {
		return this.tqCoreConnector.record.getTrackedObjectRecordInstance(apiName);
	}
}

PumaDirectConnector.$inject = ['tqCoreConnector'];

export default PumaDirectConnector;
