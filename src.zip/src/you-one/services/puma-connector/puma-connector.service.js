import PumaDirectConnector from './puma-direct-connector.service.js';
import MockHelper from '../puma-mock/mock-helper.class.js';

class PumaConnector extends PumaDirectConnector {
	constructor(tqCoreConnector, pumaMockService) {
		'ngInject';
		super(tqCoreConnector);
		
		this.mockService = pumaMockService;
	}

	get(path, parameters, options) {
		if (this.mockService.shouldUseMockResponse('GET', path)) {
			return this.mockService.getMockResponse('GET', path, parameters, options);
		} else {
			return super.get(path, parameters, options);
		}
	}

	post(path, body, options) {
		if (this.mockService.shouldUseMockResponse('POST', path)) {
			return this.mockService.getMockResponse('POST', path, body, options);
		} else {
			return super.post(path, body, options);
		}
	}

	put(path, body, options) {
		if (this.mockService.shouldUseMockResponse('PUT', path)) {
			return this.mockService.getMockResponse('PUT', path, body, options);
		} else {
			return super.put(path, body, options);
		}
	}
	
	getUserId() {
		return super.getUserId();
	}
	
	upsert(data) {
		var apiName;
		if(!_.isArray(data)) {
			apiName = data.objectApiName.replace(/_/g,'');
		}
		else { // For change reuqest updates maybe we can find another way @Alper
			apiName = 'EP_ChangeRequest__c'.replace(/_/g,'');
		}

		if(this.mockService.shouldUseMockResponse('UPSERT', apiName)) {
			return this.mockService.getMockResponse('UPSERT', apiName, data);
		}
		else {
			return super.upsert(data);
		}
	}

	getTrackedObjectRecordInstance(apiName) {
		return super.getTrackedObjectRecordInstance(apiName);
	}
}

PumaConnector.$inject = ['tqCoreConnector', 'pumaMockService'];

export default PumaConnector;