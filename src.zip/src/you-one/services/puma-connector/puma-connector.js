import 'coreapi';
import '../puma-mock/puma-mock.js';

import pumaConnector from './puma-connector.service.js';
//import pumaConnector from './puma-direct-connector.service.js';

export default angular.module('puma.connector', ['tq.coreapi', 'puma.connector.mocks'])
                    .service('pumaConnector', pumaConnector);
