export default {
	MOBILE: 1,
	TABLET: 2,
	DESKTOP: 3,
	
	// Returns with string representation of given platform type
	toString: (type) => {
		if(type === 1) {
			return 'Mobile';
		}
		
		else if(type === 2) {
			return 'Tablet';
		}
		
		else {
			return 'Desktop';
		}
	}
}