import platformType from './platformType.value.js';
import platformSelectorService from './platformSelector.service.js';

export default angular.module('puma.platformSelector',[])
	.value('platformType', platformType)
	.service('platformSelectorService', platformSelectorService);