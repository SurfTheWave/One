class PlatformSelectorService {
		
	constructor($window, $rootScope, platformType, $log) {
		'ngInject';
		
		this.$window = $window;
		this.$rootScope = $rootScope;
		this.platformType = platformType;
		this.$log = $log;
		
		// Device dimensions (taken from variables.sass)
		this.maxMobileWidth = 736;
		this.maxTabletWidth  = 1200;
		
		// Current window width and platform type
		this.currentWidth = this.$window.innerWidth;
		this.currentPlatform = this.getCurrentPlatform();
		
		// Listener callbacks to call on platform type change
		this.listenersToCallOnPlatformChange = [];
		
		// Register window resize event to handle device type change
		angular.element(this.$window).bind('resize', () => {
			this.currentWidth = this.$window.innerWidth;
			
			let newPlatform = this.getCurrentPlatform();
			
			// Call registered observers
			if(this.currentPlatform !== newPlatform) {
				this.currentPlatform = newPlatform;
				this.$log.debug('Platform type changed to ' + this.platformType.toString(newPlatform));
				
				_.forEach(this.listenersToCallOnPlatformChange, (callback) => {
					callback(newPlatform);
				});
			}
		});
	}
	
	registerPlatformTypeChangeEvent(callback) {
		this.listenersToCallOnPlatformChange.push(callback);
	}
	
	getCurrentPlatform() {
		if(this.isDesktop()) {
			return this.platformType.DESKTOP;
		}
		
		else if(this.isTablet()) {
			return this.platformType.TABLET;
		}
		
		else {
			return this.platformType.MOBILE;
		}
	}
	
	isMobile() {
		return this.currentWidth <= this.maxMobileWidth;
	}
	
	isTablet() {
		return this.maxMobileWidth < this.currentWidth && this.currentWidth <= this.maxTabletWidth;
	}
	
	isDesktop() {
		return this.currentWidth > this.maxTabletWidth;
	}
}

export default PlatformSelectorService;