/*@ngInject*/
export default function mockConfig(pumaMockServiceProvider) {
	'ngInject';
	
	pumaMockServiceProvider.setMockResponses({
		method: 'UPSERT',
		path: ('EP_ChangeRequest__c'.replace(/_/g,'')),
		response: function(requestBody) {
			alert('Mock update');
			return {
				status: 0,
				error: null,
				body: [{
					success: true,
					objectApiName: 'EP_ChangeRequest__c',
					
					record: {Name:'CR8722A'}
				}]
			};
		},
		useByDefault: true
	});
	
}