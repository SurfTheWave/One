import angular from 'angular';
import ChangeRequestLine from './change-request-line.class.js';


class ChangeRequest {
	constructor(id, type) {
		this.updateId =id;
		this.updateType = type;
		this.changeRequestLines = [];
	}
	
	addChangeRequestLine(objTypeName, objFieldLabel, origValue, newValue, origRefValue, newRefValue){
		
		let change = new ChangeRequestLine(objTypeName, objFieldLabel, origValue, newValue, origRefValue, newRefValue);
		this.changeRequestLines.push(change);
	}
}

export default ChangeRequest;

