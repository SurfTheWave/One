import '../puma-connector/puma-connector.js';

import changeRequestService from './change-request-service.js';
import mocksConfig  from './change-request.mock.js';

export default angular.module('puma.changeRequests', ['puma.connector'])
	.service('changeRequestService', changeRequestService)
	.config(mocksConfig);