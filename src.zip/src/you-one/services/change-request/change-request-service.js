
class ChangeRequestService {
	constructor(pumaConnector, $q) {
		this.pumaConnector = pumaConnector;
		this.$q = $q;
	}

	submitRequest(changeRequest) {

		let requests = [];
		var newChangeRequest = this.pumaConnector.getTrackedObjectRecordInstance('EP_ChangeRequest__c');

		newChangeRequest.rawRecord.EP_Reason__c = 'Front end portal update request';
		newChangeRequest.rawRecord.EP_Object_ID__c = changeRequest.updateId;
		newChangeRequest.rawRecord.EP_Object_Type__c = changeRequest.updateType;

		//currently CR is available for Account and Tank others should be added later on
		if (changeRequest.updateType === 'EP_Tank__c') {
			newChangeRequest.rawRecord.EP_Tank__c = changeRequest.updateId;
		} else if (changeRequest.updateType === 'Account') {
			newChangeRequest.rawRecord.EP_Account__c = changeRequest.updateId;
		}
		newChangeRequest.rawRecord.EP_Request_Status__c = 'Open';
		newChangeRequest.rawRecord.EP_Requestor__c = this.pumaConnector.getUserId();
		newChangeRequest.rawRecord.EP_Request_Date__c = Date.now();
		newChangeRequest.rawRecord.EP_Operation_Type__c = 'Update';
		requests.push(newChangeRequest);

		for (let change of changeRequest.changeRequestLines) {
			let changeRequestLine = this.pumaConnector.getTrackedObjectRecordInstance('EP_ChangeRequestLine__c');

			changeRequestLine.rawRecord.EP_Change_Request__c = newChangeRequest.rawRecord.Id;
			changeRequestLine.rawRecord.EP_Source_Field_API_Name__c = change.objTypeName;
			changeRequestLine.rawRecord.EP_Source_Field_Label__c = change.objFieldLabel;
			changeRequestLine.rawRecord.EP_Original_Value__c = change.origValue;
			changeRequestLine.rawRecord.EP_New_Value__c = change.newValue;
			//for the lookups
			changeRequestLine.rawRecord.EP_Reference_Value__c = change.newRefValue;
			changeRequestLine.rawRecord.EP_Original_Reference_Value__c = change.origRefValue;
			requests.push(changeRequestLine);
		}

		let changeRequestPromise = this.pumaConnector.upsert(requests).then(
			function onSuccess(response) {
				console.log('success:' + response);
				//todo all the items should be checked
			return response;
			}, function onError(error) {
				console.log('Trial has been failed because of error: ' + error);
				return error;
			});
		return changeRequestPromise;
	}
}

ChangeRequestService.$inject = ['pumaConnector', '$q'];

export default ChangeRequestService;