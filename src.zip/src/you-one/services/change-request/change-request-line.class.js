import angular from 'angular';


class ChangeRequestLine {
	constructor(objTypeName, objFieldLabel, origValue, newValue, origRefValue, newRefValue) {
		this.objTypeName =objTypeName;
		this.objFieldLabel = objFieldLabel;
		this.origValue = origValue;
		this.newValue = newValue;
		this.origRefValue = origRefValue;
		this.newRefValue = newRefValue;
	}
}

export default ChangeRequestLine;