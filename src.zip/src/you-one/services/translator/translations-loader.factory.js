function translationsLoaderFactory($http, $q, store, $log) {
	'ngInject';
	
	return function(options) {
		var deferred = $q.defer();
		
		store.getBootstrapData()
			.then(function(response) {
				deferred.resolve(response.dictionary);
				// $log.debug(response.dictionary);
			})
			.catch(function(error) {
				deferred.reject(error);
				// $log.error(error);
			});
		
		// $http.get('' + options.key + '.json')
		// 	.then(function(response) {
		// 		// console.log('Response: ' + JSON.stringify(response));
		//
		// 		store.getTranslations()
		// 		.then((backendTranslationsResponse) => {
		// 			_.forEach(backendTranslationsResponse, function(backEndTranslation) {
		// 				_.extend(response.data, backEndTranslation);
		// 			});
		//
		// 			deferred.resolve(response.data);
		// 			console.log(response.data);
		// 		})
		// 		.catch((error) => {
		// 			deferred.resolve(response.data);
		// 			console.error(error);
		// 		});
		// 	})
		// 	.catch(function(error) {
		// 		deferred.reject(error);
		// 	});
		
		return deferred.promise;
	};
}

export default translationsLoaderFactory;