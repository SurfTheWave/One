class translatorService {
	constructor($filter) {
		'ngInject';
		this.$filter = $filter;
	}
	
	translate(key) {
		return this.$filter('translate')(key);
	}
}

export default translatorService;