// We should define the function explicitly, otherwise we got an injection error like this:
// function($translateProvider) is not using explicit annotation and cannot be invoked in strict mode
function translatorConfig($translateProvider) {
	'ngInject';

	// Register custom translations loader
	$translateProvider.useLoader('translationsLoader');
	
	// // Register static files loader
	// $translateProvider.useStaticFilesLoader({
	// 	prefix: '',
	// 	suffix: '.json'
	// });
	
	// Set preferred language and default language
	// We can access preferred language in custom loader with options.key
	$translateProvider.preferredLanguage(getUserLanguage());
	$translateProvider.fallbackLanguage('en-US');
	
	// Returns with user language code
	function getUserLanguage() {
		var userLanguage = window.navigator.language || window.navigator.userLanguage;
	
		if (_.startsWith(userLanguage, 'en')) {
			return 'en-US';
		}
	
		if (_.startsWith(userLanguage, 'es')) {
			return 'es-ES';
		}
	
		return userLanguage;
	}
}

export default translatorConfig;