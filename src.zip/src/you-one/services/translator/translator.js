import 'angular';
import 'angularTranslate';

import translator from './translator.service.js';
import translationsLoader from './translations-loader.factory.js';
import translatorConfig from './translator.config.js';

export default angular.module('app.translate', ['pascalprecht.translate'])
	.service('translator', translator)
	.factory('translationsLoader', translationsLoader)
	.config(translatorConfig);