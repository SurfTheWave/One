import '../puma-connector/puma-connector.js';

import TransactionService from './transaction.service.js';
import mockConfig  from './transaction.mocks.js';

/*let runMethod = function(transactionService){
    'ngInject';
    transactionService.loadSellToAccounts();
};*/

export default angular.module('puma.transaction', ['puma.connector'])
    .service('transactionService', TransactionService)
    .config(mockConfig);
    //.run(runMethod);