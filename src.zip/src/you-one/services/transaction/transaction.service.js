export default class TransactionService {
	constructor(pumaConnector) {
		'ngInject';
		this.pumaConnector = pumaConnector;
	}
	
	getInvoices(){
		return this.pumaConnector.get('/Invoice/List');
	}
	
	getPayments(){
		return this.pumaConnector.get('/Payment/List');
	}
}