import invoiceJSON from './transaction.invoice.json';
import paymentJSON from './transaction.payment.json';

let invoiceList = invoiceJSON;
let paymentList = paymentJSON;

/*@ngInject*/
export default function mockConfig(pumaMockServiceProvider) {
	'ngInject';
	
	pumaMockServiceProvider.setMockResponses([
	{
		method: 'GET',
		path: '/Invoice/List',
		response: function() {
			
			return {
				status: 200,
				errors: null,
				invoiceList: invoiceList
			};
		},
		useByDefault: true
	}, {
		method: 'GET',
		path: '/Payment/List',
		response: function() {
			
			return {
				status: 200,
				errors: null,
				paymentList: paymentList
			};
		},
		useByDefault: true
	}]);
}