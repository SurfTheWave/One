import '../puma-connector/puma-connector.js';

import orderService from './order.service.js';
import mocksConfig  from './order.mocks.js';
import listMocksConfig from './order-list.mocks.js';

export default angular.module('puma.order', ['puma.connector'])
    .service('orderService', orderService)
    //Mock responses Include
    .config(mocksConfig)
	.config(listMocksConfig)