import orderStatusList from '../orderStatusList/order-status-with-labels.json';
import MockHelper from '../puma-mock/mock-helper.class.js';
import Account from '../account/account.class.js';

/*@ngInject*/
export default function mockConfig(pumaMockServiceProvider) {

	let orders = {
		active: [],
		past: [],
		alert: []
	};

	pumaMockServiceProvider.setMockResponses([{
		method: 'GET',
		path: '/order/list/',
		response: ({offset, limit, type, sellTo, shipTo}) => {
			//Generate list of orders with pagenation to retrieve full data
			if (orders[type].length === 0) {
				orders[type] = createOrdersForType(type, sellTo, shipTo);
			}
			return {
				orderList: orders[type].slice(offset, limit),
				done: orders.length <= offset + limit
			};
		},
		useByDefault:true
	}]);
}

function createOrdersForType(type, sellTo, shipTo) {
	let orders = [];
	let startDate = new Date();
	let eta, addMonthValue, hour, startHour, endHour, customerTypeIndex, paymentTypeIndex;

	/** Create a random date in the future for type active and random date in the past for type past */
	if (type === 'active') {
		addMonthValue = startDate.getMonth() + parseInt(Math.random() * 11);
		addMonthValue = addMonthValue > 11 ? 11 : addMonthValue;
	} else {
		addMonthValue = startDate.getMonth() - parseInt(Math.random() * 11);
		addMonthValue = addMonthValue < 0 ? 0 : addMonthValue;
	}

	for (let i = 0; i < 10000; i++) {

		eta = new Date(startDate.getTime() + Math.random() * (new Date().setMonth(addMonthValue) - startDate.getTime()));

		/** Random Time Window */
		hour = eta.getHours();
		startHour = hour > 17 || hour < 8 ? parseInt(Math.random() * 9 + 8) : hour;
		eta.setHours(startHour);
		endHour = startHour > 8 ? String(startHour + 1) + ':00' : '0' + String(startHour + 1) + ':00';
		startHour = startHour > 9 ? String(startHour) + ':00-' : '0' + String(startHour) + ':00-';

		/** Selects a Random DeliveryType and PaymentTerm for the Order Object */
		customerTypeIndex = Object.keys(orderStatusList)[parseInt(Math.random() * Object.keys(orderStatusList).length)];
		paymentTypeIndex = Object.keys(orderStatusList[customerTypeIndex])[parseInt(Math.random() * Object.keys(orderStatusList[customerTypeIndex]).length)];

		let statusData = generateRandomStatus(eta, type, customerTypeIndex, paymentTypeIndex);
		
		let isConsignmentOrder = Math.random() < 0.15;

		orders.push({
			EffectiveDate: eta.toISOString(),
			EP_ShipTo__r : {
				Id: 'Order' + MockHelper.randomInt(100000, 1234567890),
				Name :'SITE:' + parseInt(Math.random() * 10),
				Ship_To_Type__c : isConsignmentOrder ? Account.ShipToType.Consignment : Account.ShipToType.NonConsignment
			},
			OrderNumber: 'A' + MockHelper.randomInt(1234567890, 9876543210),
			EP_Requested_Delivery_Date__c: eta.getTime() - parseInt(Math.random() * 1000000000 + 300000000),
			OrderItems: generateOrderItemsResponse(),
			TotalAmount: isConsignmentOrder ? null : (106456 + i),
			EP_Order_Status_Caption__c: statusData.subStatus,
			EP_Order_Customer_Status__c: statusData.statusCaption,
			EP_Order_With_Alert__c : (statusData.statusType == 'alert'),
			Id: String(i),
			ShippingAddress: MockHelper.randomSalesforceAddress(),
			BillingAddress: MockHelper.randomSalesforceAddress(),
			EP_Delivery_Type__c: customerTypeIndex,
			EP_Payment_Term__c: paymentTypeIndex,
			Stock_Holding_Location__r : {
				Name: 'Terminal' + parseInt(Math.random() * 10)
			},
			EP_Truck_Licence_Plate__c: 'TR' + parseInt(Math.random() * 99999 + 10000)
		});
	}
	
	return orders;
}

function generateOrderItemsResponse(){
	var productNames = ['Regular', 'Premium', 'Diesel'];
	var orderItems = {
		records: [],
		total: 3
	};

	for (let productName of productNames){
		
		let unitPrice = parseFloat(Math.random() * 2).toFixed(2);
		let quantitity = MockHelper.randomInt(1, 200) * 1000;
		
		orderItems.records.push({
			Id : 'OrderItem' + MockHelper.randomInt(),
			EP_Unit_of_Measure__c: 'LT',
			PricebookEntry: {
				Id: 'PricebookEntry' + MockHelper.randomInt(),
				Product2 : {
					Id : 'Product' + MockHelper.randomInt(),
					Name: productName,
					CurrencyIsoCode: 'AUD',
					UnitPrice: unitPrice,
					EP_Total_Price__c: unitPrice * quantitity
				}
			},
			Quantity: quantitity
		});
	}
	return orderItems;
}

/** Creates a randomized Status Value of the Mocklist orderStatusList */
function generateRandomStatus(etaDate, type, customerTypeIndex, paymentTypeIndex) {
	let orderSteps = getOrderSteps(orderStatusList[customerTypeIndex][paymentTypeIndex], type);

	/** skip Final Status for active Orders */
	if (type === 'active') {
		orderSteps = orderSteps.slice(0, orderSteps.length - 1);
	} else {
		orderSteps = new Array(orderSteps[orderSteps.length - 1]);
		addErrorSteps(orderStatusList[customerTypeIndex][paymentTypeIndex], orderSteps);
	}

	let stepIndex, subStatusIndex, status, substatus, statusType;

	stepIndex = parseInt(Math.random() * orderSteps.length);

	/** Type past can either be the last defined step or a error status */
	if (type === 'past') {
		//Randonly generate step for data amount
		if (parseInt(Math.random() * 2 + 1) % 2 === 0) {
			stepIndex = stepIndex || 1;
		} else {
			stepIndex = 0;
		}
	}

	status = orderSteps[stepIndex];
	let statusData = orderStatusList[customerTypeIndex][paymentTypeIndex][status];
	subStatusIndex = parseInt(Math.random() * Object.keys(statusData).length);
	substatus = Object.keys(statusData)[subStatusIndex];
	statusType = orderStatusList[customerTypeIndex][paymentTypeIndex][status][substatus].type;
	substatus = substatus.replace('{{etaDate}}', etaDate.toDateString());

	return {
		statusCaption: status,
		subStatus: substatus,
		statusType: statusType
	}
}

/** Returns a list of all Steps which has at least one non Error Step in it and is therefore an order step */
function getOrderSteps(dataList) {
	let stepArray = [];

	for (let key of Object.keys(dataList)) {
		for (let subKey of Object.keys(dataList[key])) {
			if (dataList[key][subKey].type !== 'error') {
				stepArray.push(key);
				break;
			}
		}
	}

	return stepArray;
}

/** Adds all Steps which have just Error Steps in it and are handled therefore as error to a given Array */
function addErrorSteps(dataList, addToArray) {

	let isErrorStep;

	for (let key of Object.keys(dataList)) {

		isErrorStep = true;

		for (let subKey of Object.keys(dataList[key])) {
			if (dataList[key][subKey].type !== 'error') {
				isErrorStep = false;
				break;
			}
		}

		if (isErrorStep) {
			addToArray.push(key);
		}
	}
}
