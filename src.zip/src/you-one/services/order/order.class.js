import ApiHelper from '../puma-connector/api-helper.class.js';
import Account from '../account/account.class.js';

let getProductsQuantitiesMap = function (apiResponse, currencyMap) {
	if (apiResponse.OrderItems && angular.isArray(apiResponse.OrderItems.records)) {
		let productsMap = apiResponse.OrderItems.records.map(({Quantity, PricebookEntry: {Product2: {Name, CurrencyIsoCode, UnitPrice, EP_Total_Price__c}}, EP_Unit_of_Measure__c}) => {
			
			return {
				productName: Name,
				quantity: Quantity,
				unit: EP_Unit_of_Measure__c,
				currency: currencyMap[CurrencyIsoCode] || CurrencyIsoCode,
				price: UnitPrice,
				totalPrice: EP_Total_Price__c
			}
		})

		return productsMap;

	} else {
		return null;
	}
};

let getOrderStatusData = function (apiResponse) {
	return {
		statusCaption: apiResponse.EP_Order_Customer_Status__c,
		statusType: apiResponse.EP_Order_With_Alert__c ? 'alert' : 'step',
		subStatus: apiResponse.EP_Order_Status_Caption__c
	};
};

let getProductCurrency = (apiResponse, currencyMap) => {

	if (apiResponse.OrderItems && angular.isArray(apiResponse.OrderItems.records)) {
		
		let currency = apiResponse.OrderItems.records.find(({PricebookEntry: {Product2: {CurrencyIsoCode}}}) => {return CurrencyIsoCode});
		currency = currency && currency.PricebookEntry.Product2.CurrencyIsoCode;
		currency = currencyMap[currency] || currency;
		
		return currency;
	} else {
		
		return null;
	}
}

//Class created to wrap original API call in existing response
export default class Order {
	constructor(apiResponse, currencyMap) {
		
		this.billingAddress = ApiHelper.getBillingAddressString(apiResponse);
		this.deliveryType = apiResponse.EP_Delivery_Type__c;
		this.etaDate = new Date(apiResponse.EffectiveDate);
		this.etaTime = null;
		this.id = apiResponse.Id;
		this.orderDate = new Date(apiResponse.EP_Requested_Delivery_Date__c);
		this.orderNumber = apiResponse.OrderNumber;
		this.customerOrderNumber = 'CUST' + apiResponse.OrderNumber;
		this.paymentTerm = apiResponse.EP_Payment_Term__c;
		this.shipTo = apiResponse.EP_ShipTo__r ? apiResponse.EP_ShipTo__r.Name : null;
		this.shippingAddress = ApiHelper.getShippingAddressString(apiResponse);
		this.products = getProductsQuantitiesMap(apiResponse, currencyMap);
		this.productCurrency = getProductCurrency(apiResponse, currencyMap);
		this.status = getOrderStatusData(apiResponse);
		this.total = apiResponse.TotalAmount;
		this.terminal = apiResponse.Stock_Holding_Location__r ? apiResponse.Stock_Holding_Location__r.Name : null;
		this.pickUpWindow = '10:00-10:30';
		this.truckLicensePlate = apiResponse.EP_Truck_Licence_Plate__c;
		if (apiResponse.EP_ShipTo__r) {
			this.isConsignmentOrder = apiResponse.EP_ShipTo__r.Ship_To_Type__c == Account.ShipToType.Consignment;
		} else {
			this.isConsignmentOrder = false;
		}
	}
}