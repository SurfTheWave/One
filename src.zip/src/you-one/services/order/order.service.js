import NewOrderInfo from './new-order-info.class.js';
import Order from './order.class.js';

class OrderService {
	constructor(pumaConnector, currencyMap){
		
		'ngInject'
		this.pumaConnector = pumaConnector;
		this.currencyMap = currencyMap;
	}

	getNewOrderInfo(sellToId){
		return this.pumaConnector.get('/order/info/', {sellToId: sellToId}).then(function(response){
			return new NewOrderInfo(response);
		});
	}

    //Input is instance of class OrderComponent
    calculateOrderPrice(orderComponent){
        return this.pumaConnector.post('/order/pricing/', {request : orderComponent.toPricingJSON()}).then(
			function(response){
            	return response;
        	}
		);
    }

	createNewOrder(orderComponentList){
		var orderJSONList = [];
		if (!Array.isArray(orderComponentList)){
			orderComponentList = [orderComponentList];
		}
		for (let orderComponent of orderComponentList){
			orderJSONList.push(orderComponent.toJSON());
		}
		return this.pumaConnector.post('/postOrder', orderJSONList).then(function(response){
			return response;
		});
	}

	getOrderList(parameters){
		
		let map = this.currencyMap;
		
		return this.pumaConnector.get('/order/list/', parameters).then(
			function onSuccess(response){
				let result = [];
				for (var orderData of response.orderList){
					result.push(new Order(orderData, map));
				}
				return result;
			}
		);
	}
}

export default OrderService;