import MockHelper from '../puma-mock/mock-helper.class.js';
import Account from '../account/account.class.js';

let productList = [
    {
        productId : 'product1',
        productName : 'NORMAL',
        unitOfMeasurement: 'Lt',
        maximalProductAmount : 10000,
        defaultProductAmount : 2000,
        productPrice : 1.25
    },
    {
        productId : 'product2',
        productName : 'PREMIUM',
        unitOfMeasurement: 'Lt',
        maximalProductAmount : 9000,
        defaultProductAmount : 3000,
        productPrice : 1.5
    },
    {
        productId : 'product3',
        productName : 'DIESEL',
        unitOfMeasurement: 'Lt',
        maximalProductAmount : null,
        defaultProductAmount : null,
        productPrice : 1.0
    }
];

let terminalInfoList = [{
	terminalId: 'terminal1',
	terminalName: 'Terminal 1',
	availableDateTimeList: [],
	availableProductIds: ['product1']
},{
	terminalId: 'terminal2',
	terminalName: 'Terminal 2',
	availableDateTimeList: [],
	availableProductIds: ['product1', 'product2']
},{
	terminalId: 'terminal3',
	terminalName: 'Terminal 3',
	availableDateTimeList: [],
	availableProductIds: ['product2', 'product3']
}];

let productMap = {'product1' : productList[0],  'product2' : productList[1],  'product3' : productList[2]};
let prices = {'product1' : 1.25,  'product2' : 1.5,  'product3' : 1.0};

/*@ngInject*/
export default function mockConfig(pumaMockServiceProvider){
    'ngInject'
    pumaMockServiceProvider.setMockResponses([{
        method: 'GET',
        path: '/order/info/',
        response:function(requestBody){
            let result = {
                deliveryType: 'Ex-Rack',
                currencyCode: '$',

                terminalInfoList: terminalInfoList,
                shipToList: [],
                cutOffTime: '6:00',
                cutOffTimeReached: true,

                productInfoList: productList
            };

			//Generate random available dates and times
			var day = 24 * 60 * 60 * 1000;
			var currentDate = new Date();
			for (let terminalInfo of result.terminalInfoList){
				var date = new Date(currentDate);
				for (let dateIndex = 0; dateIndex < 7; dateIndex++){
					if (dateIndex != 4){
						let timePeriods = [], startTime = Math.round(Math.random() * 5 + 7),
							endTime = Math.round(Math.random() * 4 + 16);
						for (let time = startTime; time < endTime; time = time + 1) {
							timePeriods.push({
								startTime : time + ':00:00.000Z',
								endTime : (time + 1) + ':00:00.000Z'
							});
						}
						terminalInfo.availableDateTimeList.push({
							workingDate: date.toISOString().substr(0,10),
							timePeriods : timePeriods
						});
					}
					date = new Date(date.getTime() + day);
				}
				currentDate = new Date(currentDate.getTime() + day);
			}

			//Get information about sellTo from selected mock
			var sellToData = this.getMockResponseData('GET', '/Account/List/'), sellTo = null;
			for (let sellToAccount of sellToData.sellToList){
				if (sellToAccount.record.Id == requestBody.sellToId){
					sellTo = sellToAccount;
					break;
				}
			}
			//Specify information about shipTo's for object based on other mock response
            if (sellTo){
                var sellToAccount = new Account.SellTo(sellTo);
                result.deliveryType = sellToAccount.getDeliveryType();
                if (result.deliveryType == 'Delivery' && sellToAccount.shipToList){
                    for (var shipToAccount of sellToAccount.shipToList){
                        result.shipToList.push({
                            shipToId : shipToAccount.Id,
                            shipToName : shipToAccount.Name,
                            shipToAddress : shipToAccount.ShippingAddress,
                            availableProductIds: ['product1', 'product2', 'product3']
                        });
                    }
                }
            }

            return result;
        },
        useByDefault: true
    },{
        method: 'POST',
        path: '/order/pricing/',
        response: function(requestBody){
            let grandTotal = 0, pricePerLiter = 1;
            let result = {
                status: '200',
                errors: [],
                currencyCode: '$',
                productAmounts : [],
				taxItems: [
                    {name: 'Lorem Tax', amount: 200},
                    {name: 'Ipsum Tax', amount: 400}
                ]
            };

            for (let productAmount of requestBody.request.productAmounts){
                let productData = productMap[productAmount.productId];
                let price = productAmount.amount * prices[productAmount.productId];
                result.productAmounts.push({
                    name: productData.productName,
					amount : productAmount.amount,
					freightPrice : 1400,
					pricePerUnit : prices[productAmount.productId],
					price: price
                });
                grandTotal += price;
            }

			result.totalAmount = grandTotal + 600;
            if (requestBody.deliveryType == Account.DeliveryType.Delivery){
                result.taxes.push({
                   name: 'Transportation', amount: 400
                });
				result.totalAmount = grandTotal + 400;
            }

            return result;
        },
		useByDefault: true
    }, {
        method: 'POST',
        path: '/postOrder',
        response: {
            isSuccess: true,
            newOrderId: 'order1',
            newOrderNumber: 'ORD1231'
        },
		useByDefault: false
    }]);
};
