export default class OrderComponent{
	constructor (deliveryType, productIds){
		this.deliveryType = deliveryType;
		this.sellToId = null;
		this.shipToId = null;
		this.terminalId = null;
		this.productIds = [];
		this.productAmounts = {};
		this.orderDate = null;
		this.orderTime = null;
		this.truckPlate = null;

		for (var productId of productIds){
			this.productIds.push(productId);
			this.productAmounts[productId] = null;
		}
	}

	getSelectedProductIds(){
		var selectedProductList = [];
		if (this.productAmounts) {
			for (var productId in this.productAmounts) {
				if (this.productAmounts[productId] &&
					!isNaN(this.productAmounts[productId])) {
					selectedProductList.push(productId);
				}
			}
		}
		return selectedProductList;
	}

	toPricingJSON(){
		var json = {
			orderDate : this.orderDate,
			orderTime : this.orderTime,
			sellToId : this.sellToId,
			shipToId : this.shipToId || null,
			terminalId : this.terminalId || null,
			productAmounts: []
		};

		for (var productId of this.productIds){
			var amount = Number(this.productAmounts[productId]);
			if (amount && !isNaN(amount)){
				json.productAmounts.push({
					productId : productId,
					amount : amount
				});
			}
		}

		return json;
	}

	toJSON(){
		var json = {
			deliveryType : this.deliveryType,
			orderDate : this.orderDate,
			orderTime : this.orderTime,
			sellToId : this.sellToId,
			shipToId : this.shipToId || null,
			terminalId : this.terminalId || null,
			truckPlate : this.truckPlate || null,
			productAmounts: []
		};

		for (var productId of this.productIds){
			var amount = Number(this.productAmounts[productId]);
			if (amount && !isNaN(amount)){
				json.productAmounts.push({
					productId : productId,
					amount : amount
				});
			}
		}

		return json;
	}
}