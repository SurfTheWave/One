import OrderComponent from './order-component.class.js';
import ApiHelper from '../puma-connector/api-helper.class.js';

export default class NewOrderInfo{
	constructor(apiResponse){
		for (var key in apiResponse){
			this[key] = apiResponse[key];
		}

		this.currencyCode = apiResponse.currencyCode || '$';
		if (Array.isArray(apiResponse.shipToList)){
			for (let shipTo of apiResponse.shipToList) {
				shipTo.shipToAddress = ApiHelper.getAddressString(shipTo, 'shipTo');
			}
		}
	}

	getTerminalsForProductIds(selectedProductsIds){
		var availableTerminalList = [];
		for (var terminalInfo of this.terminalInfoList) {
			let terminalIsAvailable = true;

			for (let productId of selectedProductsIds) {
				if (!terminalInfo.availableProductIds ||
					terminalInfo.availableProductIds.indexOf(productId) === -1) {
					terminalIsAvailable = false;
					break;
				}
			}

			if (terminalIsAvailable){
				availableTerminalList.push(terminalInfo);
			}
		}
		return availableTerminalList;
	}

	getTerminalInfo(terminalId){
		if (Array.isArray(this.terminalInfoList)) {
			for (var terminalInfo of this.terminalInfoList) {
				if (terminalInfo.terminalId === terminalId) {
					return terminalInfo;
				}
			}
		}
		return null;
	}

	getTerminalDayData(terminalId, selectedDay){
		var terminalInfo = this.getTerminalInfo(terminalId);
		if (terminalInfo){
			if (!angular.isDate(selectedDay)){
				selectedDay = new Date(selectedDay);
			} else {
				//Prevent problems with timezone when it's not UTC. Timezone offset should be removed first
				selectedDay = new Date(selectedDay.getTime() - selectedDay.getTimezoneOffset()*60000);
			}
			var selectedDayString = selectedDay.toISOString().substr(0,10);
			for (var dayData of terminalInfo.availableDateTimeList){
				if (dayData.workingDate == selectedDayString){
					return dayData;
				}
			}
		}
		return null;
	}

	getNewOrderComponent(){
		let productIds = [];
		for (let productInfo of this.productInfoList) {
			productIds.push(productInfo.productId);
		}

		return new OrderComponent(this.deliveryType, productIds);
	}
}