import template from './modal-dialog.tpl.html';

class ModalDialogProvider {
	constructor(){
	
		this.$get = function(ngDialog, $q) {
			'ngInject';
			
			/* Shows a modal dialog by using ngDialog module.
				function parameters: 
				- dialog type as: 'alert', 'info' or 'confirm'
				- dialog buttons as: 'yesno' or 'ok', default behaviour is 'ok'
				- dialog detail text
				- dialog title text
				
				modal dialog promises:
				- 'yes' when yes button clicked
				- 'no' when no button clicked
				- 'ok' when ok button clicked
				- 'close' when modal dialog is closed from close(X) button
			*/
			return function (type, buttons, detail, title ) {
					
				var deferForCallback = $q.defer();
				
				let modalDialog = ngDialog.open({ 
					plain: true,
					template: template, 
					className: 'ngdialog-theme-default custom-modal-dialog', 
					closeByDocument : false, 
					controller: ['$scope', function($scope) {
						
						$scope.modalTitle = title;
						$scope.modalDetail = detail;
						$scope.modalType = type;
						$scope.okButtonVisibility = true;
						$scope.yesnoButtonVisibility = false;
						
						if( buttons === 'yesno' )
						{
							$scope.okButtonVisibility = false;
							$scope.yesnoButtonVisibility = true;
						}
						
						$scope.callYes = function() {
							modalDialog.close();
							return deferForCallback.resolve('yes');
						};
						
						$scope.callNo = function() {
							modalDialog.close();
							return deferForCallback.reject('no');
						};
						
						$scope.callOk = function() {
							modalDialog.close();
							return deferForCallback.resolve('ok');
						};
					}]});
					
				modalDialog.closePromise.then(function () {
					deferForCallback.resolve('close');
				});
				
				return deferForCallback.promise;
			}
		};
	}
}

export default ModalDialogProvider