import ngDialog from 'ngDialog';
import modalDialogProvider from './modal-dialog.provider.js';

export default angular.module('modal-dialog', ['ngDialog'])
	.provider('modalDialog', modalDialogProvider)
