import MockHelper from '../../puma-mock/mock-helper.class.js';
import productJson from './product.json';

let productList = productJson;

/*@ngInject*/
export default function mockConfig(pumaMockServiceProvider) {
	'ngInject'


	var yesterday = new Date();
	yesterday = yesterday.setDate(yesterday.getDate() - 1);
	var twoDaysAgo = new Date();
	twoDaysAgo = twoDaysAgo.setDate(twoDaysAgo.getDate() - 2);
	var threeDaysAgo = new Date();
	threeDaysAgo = threeDaysAgo.setDate(threeDaysAgo.getDate() - 3);
	var fourDaysAgo = new Date();
	fourDaysAgo = fourDaysAgo.setDate(fourDaysAgo.getDate() - 4);

	pumaMockServiceProvider.setMockResponses([
		{
			method: 'GET',
			path: '/em_getTankDipEntryData',
			response: function (requestBody) {
				var sellTo = MockHelper.getValue('currentSellto');
				let shipTo = _.find(sellTo.shipToList, function (site) { return site.record.Id === requestBody.shipToId; });

				return {
					status: 200,
					errors: null,
					tanks: shipTo.tanks
				};
			},
			useByDefault: true
		},
		{
			method: 'POST',
			path: '/em_submitTankDips',
			response: function (requestBody) {
				let sellTo = MockHelper.getValue('currentSellto');
				var sites = sellTo.shipToList;
				var wanted = sites.filter(function (site) { return (site.record.Id === requestBody.shipToId); });
				if (wanted.length === 0) {
					return {
						status: 404,
						errors: null
					};
				}
				_.forEach(requestBody.tanks, function (tankToUpdate) {
					var tankData = wanted[0].tanks.filter(function (tank) { return (tank.Id === tankToUpdate.Id); });
					if (tankData.length === 0) {

						return {
							status: 404,
							errors: null
						};
					}
					tankData[0].EP_Last_Dip_Reading__c = tankToUpdate.dipLevel;
					tankData[0].EP_Last_Dip_Reading_Date__c = tankToUpdate.lastMeasurementTime;
				});
				sellTo.shipToList = sites;
				MockHelper.setValue('currentSellto', sellTo);
				return {
					status: 200,
					errors: null
				};
			},
			useByDefault: true
		},
		{
			method: 'GET',
			path: '/em_getAvailableProducts',
			response: function (requestBody) {
				//var sellTo = MockHelper.getValue('currentSellto');
				//let shipTo =  _.find(sellTo.shipToList, function(site) { return site.record.Id === requestBody.shipToId; });
				return {
					status: 200,
					errors: null,
					productList: productList
				};
			},
			useByDefault: true
		},
		{
			method: 'POST',
			path: '/em_tankUpdate',
			response: function (requestBody) {
				return {
					status: 200,
					errors: null,
					changeRequestId: '4RED4M'
				};
			},
			useByDefault: true
		},
		{
			method: 'POST',
			path: '/em_requestNewTank',
			response: function (requestBody) {
				let sellTo = MockHelper.getValue('currentSellto');
				var sites = sellTo.shipToList;
				var wanted = sites.filter(function (site) { return (site.record.Id === requestBody.ShipToId); });
				if (wanted.length === 0) {
					return {
						status: 404,
						errors: [-1]
					};
				}
				let tank = {
					Id: 'TN - 01089' + Date.now(),
					Name: requestBody.Name,
					EP_Unit_Of_Measure__c: 'LT',
					EP_Capacity__c: requestBody.Capacity,
					EP_Safe_Fill_Level__c: requestBody.SafeFillLevel,
					EP_Deadstock__c: requestBody.DeadStockLevel,
					EP_Last_Dip_Reading__c: 0,
					EP_Product__r: productList.find(x => x.Id === requestBody.ProductId),
					//EP_Last_Dip_Reading_Date__c: ,
					// delete me TOP
					EP_Tank_Status__c: requestBody.Status,
					EP_Tank_Missing_Dip_For_Today__c: false
				};

				wanted[0].tanks.push(tank);
				MockHelper.setValue('currentSellto', sellTo);
				return {
					status: 200,
					errors: null
				};
			},
			useByDefault: true
		}]);
}
