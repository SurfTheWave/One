import angular from 'angular';

class Product{
	constructor(productData){
		//angular.copy(productData, this);
		if(productData) {
			this.color = productData.EP_Product_Colour__c;
			this.Id = productData.Id;
			this.Name = productData.Name;
			this.shortName = productData.EP_Short_Name__c;
			this.unitOfMeasure  = productData.EP_Unit_of_Measure__c;
		}
	}
	getColor(){
		return this.color;
	}
	
	getShortName(){
		return this.shortName;
	}

}

export default Product;