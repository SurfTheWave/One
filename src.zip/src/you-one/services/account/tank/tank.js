import '../../puma-connector/puma-connector.js';

import tankService from './tank.service.js';
import mocksConfig  from './tank.mocks.js';


export default angular.module('puma.tank', ['puma.connector'])
    .service('tankService', tankService)
    .config(mocksConfig);