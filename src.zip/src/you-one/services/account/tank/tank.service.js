import Tank from './tank.class.js';
import Product from './product.class.js';

class TankService {
	constructor(changeRequestService, pumaConnector, $q) {
		'ngInject';
		this.pumaConnector = pumaConnector;
		this.$q = $q;
		this.changeRequestService = changeRequestService;
	}
	
	getTankData(shipToId, dipDate){
		let tankDataDeferred =  this.pumaConnector.get('/em_getTankDipEntryData', {shipToId: shipToId, dipDate: dipDate}).then(function(response){
			let result = [];
			for (let tankData of response.tanks){
				let tank = new Tank(tankData);
				result.push(tank);
			}
			return result;
		});
		return tankDataDeferred;
	}

	submitTankDips(tankDips){
		return this.pumaConnector.post('/em_submitTankDips', tankDips);
	}
	
	getAvailableProducts(shipToId){
		let availableProductsDataDeferred =  this.pumaConnector.get('/em_getAvailableProducts', {shipToId: shipToId}).then(function(response){
			let result = [];
			for (let productData of response.productList){
				let product = new Product(productData);
				result.push(product);
			}
			return result;
		});
		return availableProductsDataDeferred;
	}
	
	updateTank(changeRequest) {
		return this.changeRequestService.submitRequest(changeRequest);
	}
	
	requestNewTank(tank) {
		let newTank = this.pumaConnector.getTrackedObjectRecordInstance('EP_Tank__c');
		
		//newTank.rawRecord.Code = 'test';
		newTank.rawRecord.EP_Ship_To__c = tank.shipToId;
		newTank.rawRecord.EP_Tank_Code__c = tank.code;
		newTank.rawRecord.EP_Tank_Alias__c = tank.alias;
		
		newTank.rawRecord.EP_Capacity__c = tank.capacity;
		newTank.rawRecord.EP_Safe_Fill_Level__c= tank.safeFillLevel;
		newTank.rawRecord.EP_Deadstock__c = tank.deadStockLevel;
		newTank.rawRecord.EP_Product__c = tank.product.Id;
		newTank.rawRecord.EP_Tank_Status__c = 'Stopped'; 
		newTank.rawRecord.EP_Reason_Blocked__c = 'Maintenance';
		
		//console.log (newTank);
		
		return this.pumaConnector.tqCoreConnector.storage.upsert(newTank);
		//return this.pumaConnector.post('/em_requestNewTank', tank.toNewJsonData());
	}
}

//TankService.$inject = ['pumaConnector', '$q'];

export default TankService;