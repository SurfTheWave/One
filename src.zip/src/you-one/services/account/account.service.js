import Account from './account.class.js';

class AccountService {
	constructor(pumaConnector, $q, store, changeRequestService) {
		'ngInject';
		this.pumaConnector = pumaConnector;
		this.$q = $q;
		this.changeRequestService = changeRequestService;

		this.accountFields = ['Id', 'Name', 'AccountNumber', 'RecordType.DeveloperName',
			'ParentId', 'EP_Billing_Method__c', 'EP_Payment_Term_Name__c',
			'EP_Billing_Frequency__c', 'EP_Ship_To_Type__c', 'EP_Delivery_Type__c'];
		
		this.loadSellToPromise = null;
		this.sellToAccounts = null;
		this.sellToAccountsMap = {};
		this.store = store;
		
		this.defaultSellToId = null;
		this.defaultSellToIndex = 0;
	}

	_getAccountsList(query) {
		return this.pumaConnector.query(query).then(function (accounts) {
			let result = [];
			for (let accountData of accounts) {
				result.push(new Account(accountData));
			}
			return result;
		});
	}

	loadSellToAccounts() {
		var self = this;
		this.sellToAccounts = null;
		this.sellToAccountsMap = {};
		this.loadSellToPromise = this.store.getBootstrapData().then(function (response) {
			//console.log(response);
			let result = [];
			if (Array.isArray(response.sellToList)) {
				for (let accountData of response.sellToList) {
					let account = new Account.SellTo(accountData, response.permissions);
					result.push(account);
					self.sellToAccountsMap[account.Id] = account;
				}
			}
			self.sellToAccounts = result;
			return self.sellToAccounts;
		});
		return this.loadSellToPromise;
	}

	getSellToAccounts() {
		/*
		if (this.loadSellToPromise) {
			return this.$q.when(this.loadSellToPromise);
		} else {
			return this.loadSellToAccounts();
		}*/
		return this.loadSellToAccounts();
	}

	getShipToAccounts(sellToId) {
		var self = this;
		return this.getSellToAccounts().then(function () {
			var sellTo = self.sellToAccountsMap[sellToId];
			return sellTo ? sellTo.shipToList : null;
		});
	}

	getSellToAccount(sellToId) {
		var self = this;
		return this.getSellToAccounts().then(() => {
			var selectedSellToId = sellToId || this.defaultSellToId;
			if (this.sellToAccountsMap[selectedSellToId]) {
				return this.sellToAccountsMap[selectedSellToId];
			} else {
				var sellToIndex = (self.defaultSellToIndex < this.sellToAccounts.length) ? self.defaultSellToIndex : 0;
				return this.sellToAccounts[sellToIndex];
			}
		});
	}

	getShipToAccountMissingDates(shipToId) {
		return this.getSellToAccount().then((sellToAccount) => {
			for (let shipTo of sellToAccount.shipToList) {
				if (shipTo.id === shipToId) {
					return shipTo.missingTankDipDates;
				}
			}
			return [];
		});
	}

	/*
	'newShipToInfo' is supposed to be an key-value object with keys:
			Name, ShippingStreet, ShippingCity, ShippingState, ShippingCountry, ShippingPostalCode, EP_Ship_To_Opening_Days__c
	*/
	addShipToAccount(sellToId, shipTo) {
			
		let newAccount = this.pumaConnector.getTrackedObjectRecordInstance('Account');
		
		newAccount.rawRecord.ParentId = sellToId;
		newAccount.rawRecord.Name = shipTo.name;
		newAccount.rawRecord.EP_Pumps__c = shipTo.numberOfPumps;
		newAccount.rawRecord.EP_Number_of_Hoses__c = shipTo.numberOfHoses;
		newAccount.rawRecord.EP_Tank_Dip_Entry_Mode__c = shipTo.tankDipEntryMode;
		newAccount.rawRecord.ShippingStreet = shipTo.shippingStreet;
		newAccount.rawRecord.ShippingCity = shipTo.shippingCity;
		newAccount.rawRecord.ShippingState = shipTo.shippingState;
		newAccount.rawRecord.ShippingCountry = shipTo.shippingCountry;
		newAccount.rawRecord.ShippingPostalCode = shipTo.shippingPostalCode;

		//todo find a good way of getting this
		newAccount.rawRecord.EP_Ship_To_Opening_Days__c = '';
		//todo this should be retrieved from bootstrap since it will change in another sandbox!!!
		newAccount.rawRecord.RecordTypeId = '012240000006nS2AAI';
		
		//console.log (newAccount);
		
		return this.pumaConnector.tqCoreConnector.storage.upsert(newAccount);
		
		
	}
	
	updateSellToAccount(sellToChangeRequest) {
		return this.changeRequestService.submitRequest(sellToChangeRequest);
	}

	updateShipToAccount(shipToChangeRequest) {
		return this.changeRequestService.submitRequest(shipToChangeRequest);
	}

}

export default AccountService;