import MockHelper from '../../puma-mock/mock-helper.class.js';
import HighLevelBankAccount from './high-level-bank-account.class.js';
import bankAccountJSON from './bank-account.json';
import highLevelBankAccountJSON from './high-level-bank-account.json';

let bankAccountList = bankAccountJSON;
let highLevelBankAccountList = highLevelBankAccountJSON;

/*@ngInject*/
export default function mockConfig(pumaMockServiceProvider) {
	'ngInject';
	
	pumaMockServiceProvider.setMockResponses({
		method: 'UPSERT',
		path: ('EP_Bank_Account__c'.replace(/_/g,'')),
		response: function(requestBody) {
			let sellToAccount = MockHelper.getValue('currentSellto');
			let rawRecord = requestBody.rawRecord;
			if(sellToAccount) {
				rawRecord.Id = MockHelper.randomId();
				highLevelBankAccountData = {
					id: rawRecord.Id,
					name: rawRecord.EP_Bank_Name__c,
					type:'visa',
					status:rawRecord.EP_Bank_Account_Status__c,
					maskedAccountNumber:'1234 **** 91234'
				};
				var newBankAccount = new HighLevelBankAccount(highLevelBankAccountData);
				
				sellToAccount.highLevelBankAccounts.push(newBankAccount);
				MockHelper.setValue('currentSellto', sellToAccount);
			}
			return {
				status: 0,
				error: null,
				body: [{
					success: true,
					objectApiName: 'EP_Bank_Account__c',
					record: rawRecord
				}]
			};
		},
		useByDefault: true
	});
	
}