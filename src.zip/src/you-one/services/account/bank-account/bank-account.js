import '../../puma-connector/puma-connector.js';

import bankAccountService from './bank-account.service.js';
import mocksConfig  from './bank-account.mock.js';

export default angular.module('puma.bankAccount', ['puma.connector'])
    .service('bankAccountService', bankAccountService)
    .config(mocksConfig);