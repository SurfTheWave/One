import angular from 'angular';

class HighLevelBankAccount{
    constructor(bankAccountData){
		if(bankAccountData) {
			this.id = bankAccountData.id;
			this.name = bankAccountData.name;
			this.type = bankAccountData.type;
			this.maskedAccountNumber = bankAccountData.maskedAccountNumber;
			this.status = bankAccountData.status;
			
		}
    }
}

export default HighLevelBankAccount;