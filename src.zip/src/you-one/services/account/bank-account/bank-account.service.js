import BankAccount from './bank-account.class.js';
import HighLevelBankAccount from './high-level-bank-account.class.js';

class BankAccountService {
    constructor(pumaConnector, $q){
		'ngInject';
				
        this.pumaConnector = pumaConnector;
        this.$q = $q;
    }
	
	addNewBankAccount(bankAccount, sellTo) {
		let newBankAccount = this.pumaConnector.getTrackedObjectRecordInstance('EP_Bank_Account__c');
		let ownerId = this.pumaConnector.getUserId();
		let accountId = sellTo.getBillingData().id;
		
		bankAccount.fillNewBankAccountRawRecord(newBankAccount.rawRecord, ownerId, accountId);
		
		return this.pumaConnector.upsert(newBankAccount);
	}
}

export default BankAccountService;