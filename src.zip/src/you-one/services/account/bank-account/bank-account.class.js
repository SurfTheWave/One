import angular from 'angular';

class BankAccount{
    constructor(bankAccountData){
		if(bankAccountData) {
			this.id = bankAccountData.Id;
			this.name = bankAccountData.EP_Bank_Name__c;
			this.branch = bankAccountData.EP_Bank_Branch_No__c;
			this.accountNumber = bankAccountData.EP_Bank_Account_No__c;
			this.IBAN = bankAccountData.EP_IBAN__c;
			this.swift = bankAccountData.EP_Swift_Code__c;
			this.status = bankAccountData.EP_Bank_Account_Status__c;
			this.country = bankAccountData.EP_Country_Code__c;
		}
    }
	
	fillNewBankAccountRawRecord(rawRecord, ownerId, accountId) {
		rawRecord.OwnerId = ownerId;
		rawRecord.EP_Account__c= accountId;
		rawRecord.EP_Bank_Name__c = this.name;
		rawRecord.EP_IBAN__c = this.IBAN;
		rawRecord.EP_Bank_Account_No__c = this.accountNumber;
		rawRecord.EP_Bank_Branch_No__c = this.branch;
		rawRecord.EP_Swift_Code__c = this.swift;
		rawRecord.EP_Country_Code__c = this.country;
		rawRecord.EP_Bank_Account_Status__c = BankAccount.Status.Inactive;
		return rawRecord;
	}
}

BankAccount.Status = {
	Active: 'Active',
	Inactive: 'Inactive'
};

export default BankAccount;