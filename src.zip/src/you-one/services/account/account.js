import '../puma-connector/puma-connector.js';

import accountService from './account.service.js';
import mocksConfig  from './account.mocks.js';

let runMethod = function(accountService){
    'ngInject';
    accountService.loadSellToAccounts();
};

export default angular.module('puma.account', ['puma.store'])
    .service('accountService', accountService)
    .config(mocksConfig)
    .run(runMethod);