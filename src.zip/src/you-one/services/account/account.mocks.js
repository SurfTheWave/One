import sellToJSON from './account.sellto.json';
import shipToJSON from './account.shipto.json';
import tankJSON from './tank/tank.json';
import MockHelper from '../puma-mock/mock-helper.class.js';
import highLevelBankAccountJSON from './bank-account/high-level-bank-account.json';

let sellToList = sellToJSON;
let shipToList = shipToJSON;
let tankList = tankJSON;
let highLevelBankAccountList = highLevelBankAccountJSON;

/*
* Mock description
* 1. Sell To Account Delivery with multiple ship to's
* 2. Sell To Account Ex-Rack with multiple ship to's
* 3. Sell To Account Delivery with one ship to
* 4. Sell To Account Ex-Rack no ship to's
* 5. Sell To Account Delivery no ship to's
* 6. Sell To Account Not Have Access to sell to account details with one ship to
*/


/*@ngInject*/
export default function mockConfig(pumaMockServiceProvider) {
	'ngInject';
	
	/*****************	CONFIGURATIONS	*******************/
	
	/*
	* Choose mock sell to account with index as a current sell to account:
	* 		0 -> Sell To Account Delivery with multiple ship to's
	* 		1 -> Sell To Account Ex-Rack with multiple ship to's
	* 		2 -> Sell To Account Delivery with one ship to
	* 		3 -> Sell To Account Ex-Rack no ship to's
	* 		4 -> Sell To Account Delivery no ship to's
	* 		5 -> Sell To Account Not Have Access to sell to account details with one ship to
	*/
	var currentSelltoIndex = 0;
	
	/* Add missing tank dip dates for the first ship to of ship to's
	*	If set true, it will add missing dip dates for the first ship to item
	*	If not, there is no missing date on mock ship to's
	*/
	var addMissingTankDipDates = true;
	
	
	/*****************	END	*******************/
	
	
	// Add missing tank dip dates to first ship to
	if(addMissingTankDipDates) {
		var yesterday = new Date().setDate(new Date().getDate() - 1);
		var twoDaysAgo = new Date().setDate(new Date().getDate() - 2);	
		shipToList[0].missingTankDipDates.push(yesterday);
		shipToList[0].missingTankDipDates.push(twoDaysAgo);	
	}
	
	// Add mock tanks to ship to's
	for (let shipToData of shipToList) {
		shipToData.tanks = angular.copy(tankList);
	}
	
	pumaMockServiceProvider.setMockResponses([{
		method: 'GET',
		path: '/Account/List/',
		response: function() {
			var response = [], sellToIndex = 0;
			
			// Check if current sell to index out of sell to list size
			if(currentSelltoIndex >= sellToList.length) {
				currentSelltoIndex = sellToList.length - 1;
			}
				
			for (let sellToData of sellToList) {
				if(sellToIndex == currentSelltoIndex && MockHelper.getValue('currentSellto')) {
					sellToIndex++;
					response.push(MockHelper.getValue('currentSellto'));
				}
				else {
					var sellTo = {
						record: sellToData,
						highLevelBankAccounts: highLevelBankAccountList,
						shipToList: [],
						terminalList: null,
						billTo: null
					};

					if (sellToIndex <= 1) {
						sellTo.shipToList = shipToList;
					}
					else if (sellToIndex == 2) {
						sellTo.shipToList = [shipToList[0]];
					}
					else if (sellToIndex == 5) {
						sellTo.record = null;
						sellTo.shipToList = [shipToList[0]];
					}

					if (sellTo.EP_Delivery_Type__c == 'Ex-Rack') {
						sellTo.terminalList = [];
						for (let index = 1; index <= 3; index++) {
							sellTo.terminalList.push({
								terminalId: index,
								terminalName: 'Terminal ' + index
							});
						}
					}
					sellToIndex++;
					response.push(sellTo);
				}
			}
			
			MockHelper.setValue('currentSellto', response[currentSelltoIndex]);
			
			return {
				status: 200,
				errors: null,
				sellToList: response
			};
		},
		useByDefault: true
	}, {
		method: 'GET',
		path: '/Invoice/List',
		response: function() {
			
			return {
				status: 200,
				errors: null,
				invoiceList: invoiceList
			};
		},
		useByDefault: true
	}, {
		method: 'GET',
		path: '/Payment/List',
		response: function() {
			
			return {
				status: 200,
				errors: null,
				paymentList: paymentList
			};
		},
		useByDefault: true
	}, {
		method: 'POST',
		path: '/addShipto',
		response: function(requestBody) {
			var updatedSellto;
			
			// Create dummy shipToId
			var now = new Date();
			var newShipToId = new String(now.getHours() + now.getMinutes()+requestBody.Name).hashCode();
			
			if (MockHelper.getValue('currentSellto')) {
				updatedSellto = MockHelper.getValue('currentSellto');
				updatedSellto.shipToList.push({
					missingTankDipDates: [],
					record: {
						Id: newShipToId,
						AccountNumber: 'LDXZXSF3',
						Name: requestBody.Name,
						ShippingAddress: {
							street: requestBody.ShippingStreet,
							city: requestBody.ShippingCity,
							state: requestBody.ShippingState,
							country: requestBody.ShippingCountry,
							postalCode: requestBody.ShippingPostalCode,	
						},
						EP_Ship_To_Opening_Days__c: requestBody.OpeningDays,
						EP_Pumps__c : requestBody.NumberOfPumps,
						EP_Number_of_Hoses__c: requestBody.NumberOfHoses,
						EP_Tank_Dip_Entry_Mode__c: requestBody.TankDipEntryMode,
						EP_Ship_To_Current_Date_Time__c: "2016-05-05T11:03:37.801Z"
					},
					tanks: []
				});				
				MockHelper.setValue('currentSellto', updatedSellto);
				return {
					status: 200,
					errors: null,
					isSuccess: true
				};
			} else {
				return {
					status: 400,
					errors: null, // TODO: define sellto not found error
					isSuccess: false
				};
			}
		},
		useByDefault: true
	}, {
		method: 'POST',
		path: '/updateSellto',
		response: function(requestBody){
			return {
				status: 200,
				errors: null,
				isSuccess: true,
				changeRequestId: 'L832NS'
			};
		},
		useByDefault: true
	}, {
		method: 'POST',
		path: '/updateShipto',
		response: function(requestBody) {
			return {
				status: 200,
				errors: null,
				isSuccess: true,
				changeRequestId: '3RED4M'
			};
		},
		useByDefault: true
	}]);
	
String.prototype.hashCode = function(){
    if (Array.prototype.reduce){
        return this.split("").reduce(function(a,b){a=((a<<5)-a)+b.charCodeAt(0);return a&a},0);              
    } 
    var hash = 0;
    if (this.length === 0) return hash;
    for (var i = 0; i < this.length; i++) {
        var character  = this.charCodeAt(i);
        hash  = ((hash<<5)-hash)+character;
        hash = hash & hash; // Convert to 32bit integer
    }
    return hash;
};

}