import angular from 'angular';
import ApiHelper from '../puma-connector/api-helper.class.js';

import HighLevelBankAccount from './bank-account/high-level-bank-account.class.js';
import Tank from './tank/tank.class.js';
import BankAccount from './bank-account/bank-account.class.js';
import ChangeRequest from '../change-request/change-request.class.js';
import Mapping from '../mapping.class.js';


let getShipToOpeningDays = function (apiResponse) {
	let weekDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
	var openingDays = [];
	for (let weekDay of weekDays) {
		if (apiResponse && apiResponse.EP_Ship_To_Opening_Days__c && apiResponse.EP_Ship_To_Opening_Days__c.includes(weekDay)) {
			openingDays.push({ name: weekDay, isOpen: true });
		} else {
			openingDays.push({ name: weekDay, isOpen: false });
		}
	}
	return openingDays;
};

class Account {
	constructor(accountData) {
		if (accountData)
			this.constructWithAccountData(accountData);
		else
			this.constructEmptyAccount();
	}

	constructEmptyAccount() {
		this.shipToOpeningDays = getShipToOpeningDays();
		this.status = '05-Inactive';
		this.shipToDateTime='2016-05-03T11:03:37.801Z';
	}

	constructWithAccountData(accountData) {
		//angular.copy(accountData, this);	

		this.id = accountData.Id;
		this.name = accountData.Name;
		this.accountNumber = accountData.AccountNumber;
		
		if (accountData.EP_Bill_To_Account__r || accountData.billTo) {
			if(accountData.billTo) {
				this.billTo = new Account(accountData.billTo);
			}
			else {
				this.billTo = new Account(accountData.EP_Bill_To_Account__r);
			}
		}
		
		this.shipToDateTime = accountData.EP_Ship_To_Current_Date_Time__c;
		this.deliveryType = accountData.EP_Delivery_Type__c;
		this.shipToType = accountData.EP_Ship_To_Type__c;
		this.taxNumber = accountData.EP_Company_Tax_Number;
		this.mobile = accountData.EP_Mobile_Phone;
		this.email = accountData.EP_Email__c;
		this.status = accountData.EP_Status__c || Account.Status.Inactive;
		this.reasonBlocked = accountData.EP_Reason_Blocked__c;
		this.paymentMethod = accountData.EP_Payment_Method__c;
		this.website = accountData.Website;
		this.phone = accountData.Phone;
		this.fax = accountData.Fax;
		this.shipToOpeningDays = getShipToOpeningDays(accountData);
		this.recordType = accountData.RecordType;
		this.paymentType = accountData.EP_Payment_Type__c;
		this.numberOfPumps = accountData.EP_Pumps__c;
		this.numberOfHoses = accountData.EP_Number_of_Hoses__c;
		this.tankDipEntryMode = accountData.EP_Tank_Dip_Entry_Mode__c;
		// Billing address
		if (accountData.BillingAddress) {
			this.billingStreet = accountData.BillingAddress.street;
			this.billingCity = accountData.BillingAddress.city;
			this.billingState = accountData.BillingAddress.state;
			this.billingCountry = accountData.BillingAddress.country;
			this.billingPostalCode = accountData.BillingAddress.postalCode;
		}
		// Shipping address
		if (accountData.ShippingAddress) {
			this.shippingStreet = accountData.ShippingAddress.street;
			this.shippingCity = accountData.ShippingAddress.city;
			this.shippingState = accountData.ShippingAddress.state;
			this.shippingCountry = accountData.ShippingAddress.country;
			this.shippingPostalCode = accountData.ShippingAddress.postalCode;
		}
	}
	
	getChangeRequestForUpdate(accountCopy) {
		let apiName = 'Account';
		let changeRequest = new ChangeRequest(this.id, apiName);
		let mappings = this.getMappings();
		//(frontEndName, backEndName, isUpdateField, isInsertField, isLookUpField) 
		for(var i=0; i < mappings.length; i++) {
			let mapping = mappings[i];
			if(mapping.isUpdateField) {
				let fieldName = mapping.frontEndName;
				if(mapping.isLookUpField){
					if(this[fieldName] && this[fieldName].id !== accountCopy[fieldName].id){
						changeRequest.addChangeRequestLine(apiName, mapping.backEndName, this[fieldName].Id, accountCopy[fieldName].Id, this[fieldName].Name, accountCopy[fieldName].Name);
					}
				}else {
					if(this[fieldName] !== accountCopy[fieldName]){
						changeRequest.addChangeRequestLine(apiName, mapping.backEndName, this[fieldName], accountCopy[fieldName],'','');
					}
				}
			}
		}
		console.log(changeRequest);
		return changeRequest;
	}
	
	getMappings() {
		let mappings = [];
		return mappings;
	}

	getBillingData() {
		return this.billTo || this;
	}

	isSellTo() {
		return this.recordType && this.recordType.DeveloperName == Account.RecordType.SellTo;
	}

	isShipTo() {
		return this.recordType && (this.recordType.DeveloperName == Account.RecordType.ShipTo.VMI ||
			this.recordType.DeveloperName == Account.RecordType.ShipTo.NonVMI);
	}

	isBillTo() {
		return this.recordType && this.recordType.DeveloperName == Account.RecordType.BillTo;
	}

	isActive() {
		return this.status == Account.Status.Active;
	}

	isVMI() {
		return this.recordType && this.recordType.DeveloperName === Account.RecordType.ShipTo.VMI;
	}

	isConsignment() {
		return this.shipToType === Account.ShipToType.Consignment;
	}

	// Prev. Impl. : Will be removed after sync with Stream1
	getDeliveryType() {
		return this.deliveryType;
	}

	getPaymentType() {
		return this.getBillingData().paymentType;
	}

	getBillingAddress() {
		return this.getAddressString('billing');
	}

	getShippingAddress() {
		return this.getAddressString('shipping');
	}

	getAddressString(addressType) {
		let addressParamList = [];
		let addressKeys = ['Street', 'City', 'State', 'Country', 'PostalCode'];
		for (let addressComponentKey of addressKeys) {
			let fieldName = addressType + addressComponentKey;
			if (this[fieldName] && this[fieldName].trim() !== '') {
				addressParamList.push(this[fieldName]);
			}
		}

		if (addressParamList.length) {
			return addressParamList.join(' ');
		}

		return null;
	}
}

class SellToAccount extends Account {
	constructor(accountData, permissions) {
		super(accountData.record);
		this.permissions = permissions;

		if (Array.isArray(accountData.shipToList)) {
			this.shipToList = [];
			for (let shipToData of accountData.shipToList) {
				this.shipToList.push(new ShipToAccount(shipToData));
			}
		}

		if (accountData.billTo) {
			accountData.billTo = new Account(accountData.billTo);
		}
		
		if(accountData.highLevelBankAccounts) {
			this.highLevelBankAccounts = [];
			for(let bankAccount of accountData.highLevelBankAccounts) {
				this.highLevelBankAccounts.push(new HighLevelBankAccount(bankAccount));
			}
			
		}
		
		this.terminalList = accountData.terminalList;
	}
	
	

	
	getMappings(){
		let mappings = [];
		//Mapping(frontEndName, backEndName, isUpdateField, isInsertField, isLookUpField)
		mappings.push(new Mapping('Name','Name', true, true, false));
		mappings.push(new Mapping('taxNumber','EP_Company_Tax_Number', true, true, false));
		mappings.push(new Mapping('mobile','EP_Mobile_Phone', true, true, false));
		mappings.push(new Mapping('email','EP_Email__c', true, true, true));
		mappings.push(new Mapping('website','Website', true, true, false));
		mappings.push(new Mapping('phone','Phone', true, true, false));
		mappings.push(new Mapping('fax','Fax', true, true, false));
		mappings.push(new Mapping('billingStreet','BillingStreet', true, false, false));
		mappings.push(new Mapping('billingCity','BillingCity', true, false, false));
		mappings.push(new Mapping('billingState','BillingState', true, false, false));
		mappings.push(new Mapping('billingCountry','BillingCountry', true, false, false));
		mappings.push(new Mapping('billingPostalCode','BillingPostalCode', true, false, false));
		
		return mappings;
	}
	
	

	isMultiSite() {
		return this.shipToList && this.shipToList > 1;
	}

	canCreateOrder() {
		if (this.getDeliveryType() == Account.DeliveryType.ExRack) {
			return true;
		} else {
			if (Array.isArray(this.shipToList)) {
				for (var shipToAccount of this.shipToList) {
					if (shipToAccount.canCreateOrder()) {
						return true;
					}
				}
			}
			return false;
		}
	}

	toUpdateJsonData() {
		return {
			Id: this.id,
			Name: this.name,
			BillingStreet: this.billingStreet,
			BillingCity: this.billingCity,
			BillingState: this.billingState,
			BillingCountry: this.billingCountry,
			BillingPostalCode: this.billingPostalCode,
			EP_Company_Tax_Number: this.taxNumber,
			EP_Mobile_Phone: this.mobile,
			Email: this.email,
			Website: this.website,
			Phone: this.phone,
			Fax: this.fax
		};
	}
}

class ShipToAccount extends Account {
	constructor(accountData) {
		if (accountData) {
			super(accountData.record);
			
			this.missingTankDipDates = [];
			this.tanks = [];
			if (Array.isArray(accountData.tanks)) {
				for (let tankData of accountData.tanks) {
					this.tanks.push(new Tank(tankData));
				}
				this.missingTankDipDates = accountData.missingTankDipDates;
			}
		} else {
			super();
		}
	}
	
	getMappings(){
		let mappings = [];
		//Mapping(frontEndName, backEndName, isUpdateField, isInsertField, isLookUpField)
		mappings.push(new Mapping('Name','Name', true, true, false));

		//mappings.push(new Mapping('openingDays','EP_Ship_To_Opening_Days__c', false, false, false));
		mappings.push(new Mapping('numberOfPumps','EP_Pumps__c', true, true, false));
		mappings.push(new Mapping('numberOfHoses','EP_Number_of_Hoses__c', true, false, false));
		//mappings.push(new Mapping('tankDipEntryMode','EP_Tank_Dip_Entry_Mode__c', false, false, false));
		mappings.push(new Mapping('shippingStreet','ShippingStreet', true, false, false));
		mappings.push(new Mapping('shippingCity','ShippingCity', true, false, false));
		mappings.push(new Mapping('shippingState','ShippingState', true, false, false));
		mappings.push(new Mapping('shippingCountry','ShippingCountry', true, false, false));
		mappings.push(new Mapping('shippingPostalCode','ShippingPostalCode', true, false, false));
		
		return mappings;
	}

	canCreateOrder() {
		return !this.isVMI() && this.isActive() && !this.isConsignment();
	}

	// Prev. Impl. : Will be removed after sync with Stream1
	isMultiSite() {
		return false;
	}

	toUpdateJsonData() {
		return {
			Id: this.id,
			Name: this.name,
			ShippingStreet: this.shippingStreet,
			ShippingCity: this.shippingCity,
			ShippingState: this.shippingState,
			ShippingCountry: this.shippingCountry,
			ShippingPostalCode: this.shippingPostalCode,
			OpeningDays: this.shipToOpeningDays.filter((x) => { return x.isOpen; }).map((x) => { return x.name; }).join(';'),
			NumberOfPumps: this.numberOfPumps,
			NumberOfHoses: this.numberOfHoses,
			TankDipEntryMode: this.tankDipEntryMode
		};
	}
	
	toAddNewJsonData( sellToId) {
		return {
			SellToId: sellToId,
			Name: this.name,
			ShippingStreet: this.shippingStreet,
			ShippingCity: this.shippingCity,
			ShippingState: this.shippingState,
			ShippingCountry: this.shippingCountry,
			ShippingPostalCode: this.shippingPostalCode,
			OpeningDays: this.shipToOpeningDays.filter((x) => { return x.isOpen; }).map((x) => { return x.name; }).join(';'),
			NumberOfPumps: this.numberOfPumps,
			NumberOfHoses: this.numberOfHoses,
			TankDipEntryMode: this.tankDipEntryMode
		};
	}
}

Account.SellTo = SellToAccount;
Account.SellTo.BankAccount = BankAccount;
Account.ShipTo = ShipToAccount;
Account.ShipTo.Tank = Tank;

Account.RecordType = {
	SellTo: 'EP_Sell_To',
	BillTo: 'EP_Bill_To',
	ShipTo: {
		VMI: 'EP_VMI_Ship_To',
		NonVMI: 'EP_Non_VMI_Ship_To'
	}
};

Account.DeliveryType = {
	ExRack: 'Ex-Rack',
	Delivery: 'Delivery'
};

Account.PaymentType = {
	PrePayment: 'Pre-payment',
	Credit: 'Credit'
};

Account.ShipToType = {
	Consignment: 'Consignment',
	NonConsignment: 'Non-Consignment'
};

Account.Status = {
	Active: '03-Active',
	Inactive: '05-Inactive'
};

Account.TankDipEntryMode = {
	Automatic: 'Automatic Dip Entry',
	Portal: 'Portal Dip Entry'
};

export default Account;