import mostpopulartDialogTemplate from './most-popular-dialog.tpl.html';
import MostPopularController from './most-popular-dialog.controller.js';
import './most-popular-dialog.sass';

class mostpopularDialogService {
	constructor($log, ngDialog) {
		'ngInject';
		
		this.$log = $log;
		this.ngDialog = ngDialog;
	}

	open(site, fromDashboard) {
		this.dialogInstance = this.ngDialog.open({
			template: mostpopulartDialogTemplate,
			plain: true,
			className: 'ngdialog-theme-default cmd-tank-dip-dates-dialog',
			controller: MostPopularController,
			closeByDocument: false,
			data: {
				site: site,
				fromDashboard: fromDashboard
			}
		});
	}

	close() {
		if(this.dialogInstance) {
			this.dialogInstance.close();
		}
	}
}

export default mostpopularDialogService;