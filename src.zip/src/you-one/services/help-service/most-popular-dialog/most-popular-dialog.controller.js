class MostPopularController {
	
	constructor($scope, $log, tankDipLevelDialogService, mostpopularDialogService) {
		'ngInject';
		
		this.$log = $log;
		this.$scope = $scope;
		this.tankDipLevelDialogService = tankDipLevelDialogService;
		//this.missingTankDipDatesDialogService = missingTankDipDatesDialogService;
		this.mostpopularDialogService = mostpopularDialogService ;
		
		this.$log.debug('Missing tank dip dates dialog controller created. Site name: ' + this.$scope.ngDialogData.site.Name);
	
		this.$scope.onEnterLevelForTodayClick = () => {
			this.$log.debug('User clicked Enter Level for Today button');
			
			this.tankDipLevelDialogService.open(this.$scope.ngDialogData.site, null);
			
			this.mostpopularDialogService.close();
			
		};
		
		this.$scope.onEnterLevelForMissingDateClick = (date) => {
			this.$log.debug('User clicked Enter Level for Missing Date button');
			
			this.tankDipLevelDialogService.open(this.$scope.ngDialogData.site, date);
		
			this.mostpopularDialogService.close();
		};
		
		
	}
	onsubmitButtonClick(site) {
		this.$log.debug('User clicked Enter Level button');		
		//this.missingTankDipDatesDialogService.open(site, true);
		this.CaseResolutionThankyouDialogService.open(site, true);
	}
	onUploadButtonClick(){
		
	}
}

export default MostPopularController;


