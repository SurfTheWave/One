import '../puma-connector/puma-connector.js';

import helpService from './help-service.service.js';
//import tankDipLevelDialogService from './tank-dip-level-dialog/tank-dip-level-dialog.service.js';
import siteManagementDialogService from './site-management-dialog/site-management-dialog.service.js';
import caseManagementDialogService from './case-management-dialog/case-management-dialog.service.js';
import caseConfirmDialogService from './case-confirm-dialog/case-confirm-dialog.service.js';
import caseResolutionDialogService from './case-resolution/case-resolution-dialog.service.js';
import caseResolutionThankyouDialogService from './case-resolution-thankyou/case-resolution-thankyou-dialog.service.js';
import mocksConfig from './help-service.mocks.js';
import caseRecordInfoDialogService from './case-record-info-dialog/case-record-info-dialog.service.js';
import mostpopularDialogService from './most-popular-dialog/most-popular-dialog.service.js';
import contactThankYouDialogService from './contact-thank-you-dialog/contact-thank-you-dialog.service.js';
import 'youOne/services/modal-dialog/modal-dialog.js';
import caseService from './Case/Case.service.js';
import caseCommentsService from './case-comments/case-comments.service.js';
import userService from './user/user.service.js';
import caseThankYouDialogService from './case-thank-you-dialog/case-thank-you-dialog.service.js';


export default angular.module('puma.helpService', ['puma.connector','modal-dialog'])
	.service('helpService', helpService)
	//.service('tankDipLevelDialogService', tankDipLevelDialogService)
	.service('siteManagementDialogService', siteManagementDialogService)
	.service('caseManagementDialogService', caseManagementDialogService)
	.service('caseConfirmDialogService', caseConfirmDialogService)
    .service('caseResolutionDialogService', caseResolutionDialogService)
	.service('caseResolutionThankyouDialogService', caseResolutionThankyouDialogService)
	.service('caseRecordInfoDialogService', caseRecordInfoDialogService)
	.service('mostpopularDialogService', mostpopularDialogService)
	.service('contactThankYouDialogService', contactThankYouDialogService)
	.service('caseThankYouDialogService', caseThankYouDialogService)
	.service('caseService', caseService)
	.service('userService', userService)
	.service('caseCommentsService', caseCommentsService)
	// Include mock responses
	.config(mocksConfig);
