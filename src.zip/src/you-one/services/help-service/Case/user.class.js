import angular from 'angular';

class UserData {
	constructor(userData) {
		if (userData) {
			this.Id = userData.Id;
			this.Name = userData.Name;
		} else {
			console.log("userData in else",userData);
		}
	}
}
export default UserData;

