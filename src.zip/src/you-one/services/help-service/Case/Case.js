import '../../puma-connector/puma-connector.js';

import caseService from './Case.service.js';
//import mocksConfig  from './tank.mocks.js';


export default angular.module('puma.case', ['puma.connector'])
    .service('caseService', caseService);
   // .config(mocksConfig);