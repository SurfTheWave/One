import angular from 'angular';

class Case {
	constructor(caseData) {
		
		if (caseData) {
			this.Id = caseData.Id;
			this.CaseNumber = caseData.CaseNumber;
			this.CaseNumber = caseData.CaseNumber;
			this.Description = caseData.Description;
			this.CreatedDate = caseData.CreatedDate;
			this.Status = caseData.Status;
			this.Subject = caseData.Subject;
			this.LastModifiedDate = caseData.LastModifiedDate;	
			this.CaseComments = [];
			if(caseData.Description != null){
				this.ShortDesc =  caseData.Description.split(/\s+/).slice(0,3).join(" ");					
			}	
			else{
				this.ShortDesc='';
			}	
		} else {
			console.log("caseData i n else",caseData);
			//this.status = Tank.Status.Stopped;
		}
	}
}


export default Case;

