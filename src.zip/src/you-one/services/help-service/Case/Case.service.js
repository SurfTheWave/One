import Case from './Case.class.js';
import CaseCommentData from './case-comments.class.js'
import UserData from './user.class.js'

class CaseService {
	constructor(changeRequestService, pumaConnector, $q,tqCoreConnector) {
		'ngInject';

		this.pumaConnector = pumaConnector;
		this.$q = $q;
		this.changeRequestService = changeRequestService;
		this.tqCoreConnector = tqCoreConnector;
		this.casesForCaseManagement = null;
	}

	// Sync All Cases Comments for respective CaseId from Puma connector
	getCaseCommentsForCaseId(caseId){ 
		var self = this; 
		let caseCommentsDataDeferred =  this.pumaConnector.query({objectApiName: 'CaseComment', fields:['Id','ParentId','CommentBody','CreatedById','CreatedDate','LastModifiedDate','CreatorName','LastModifiedById'],orderby: 'CreatedDate asc',where: {'ParentId' :  {$eq : caseId}}}).then(function(response){ 
			let comments = []; 
			for (let caseCommentData of response){ 
				let caseCommentRec = new CaseCommentData(caseCommentData); 
				comments.push(caseCommentRec); 
			} 
			return comments;
		}); 
								
		return caseCommentsDataDeferred; 
	}

	// Sync All Cases from Puma connector
	getCases(){
		var self = this;
		let caseDataDeferred =  this.pumaConnector.query({objectApiName: 'Case', fields:['Id','CaseNumber','Description','CreatedDate','Status','Subject','LastModifiedDate'],orderby: 'CreatedDate desc',where: {'IsDeleted' : {$eq : false}}}).then(function(response){
			let cases = [];
			//console.log("case response",response);
			for (let caseData of response){
				let caseRec = new Case(caseData);
				cases.push(caseRec);
			}
			return cases;
		});
					
		return caseDataDeferred;
	}

	// Sync All Users from Puma connector
	getUsers(){
		var self = this;
		let userDataDeferred =  this.pumaConnector.query({objectApiName: 'User', fields:['Id','CreatedDate','Name','LastModifiedDate','LastModifiedById']}).then(function(response){
			let users = [];
			for (let userData of response){
				let userRec = new UserData(userData);
				users.push(userRec);
			}
			return users;
		});
					
		return userDataDeferred;
	}

	// Sync Cases, Users and Case comments from Puma connector
	// and fill respective objects into other
	getCaseManagementData()
	{
		console.log("sync Cases for Case Management Tab");
		let deferedCases = this.getCases().then((caseDataList) => {// retrieve cases
			let deferedUsers = this.getUsers().then((users) => {// retrieve all users
					var userList = users;
					_.forEach(caseDataList, (caseObject) => {// iterate cases
						// fetch case comments for respective case id
						this.getCaseCommentsForCaseId(caseObject.Id).then((casecomments) =>{
							_.forEach(casecomments, (caseCommentObject) => { // iterate casecomments	
								for (let i = 0; i < userList.length - 1; i++){// iterate users
									// filter case comment user
									if(userList[i] && ( caseCommentObject.CreatedById == userList[i].Id)){
										//fill userinfo into case commentobject
										caseCommentObject.userDetails = userList[i].Name;
										break;
									}
								}
								caseObject.CaseComments = casecomments; //fill case comments into case object
							});
						});
					});
					// get the complete data into local object
					this.casesForCaseManagement = caseDataList;
					return this.casesForCaseManagement;
				});
				return deferedUsers;
			});
		return deferedCases; 
	}

	// TODO: Retrieve cases data list
	getCasesData(){
		return this.casesForCaseManagement;
	}
	
	// Retrieve open case count from Case list
	getOpenCases(){
		let caseDefered = this.getCases().then((caseDataList) => {
			var caseCount = 0;
			_.forEach(caseDataList, (caseObject) => {
				if(caseObject.Status == 'New Application'){
					caseCount++;	
					}}); 
				return caseCount;
		});
		return caseDefered;
	}

	updateCase(changeRequest) {
		return this.changeRequestService.submitRequest(changeRequest);
	}
	
	requestNewCase(Case) {
		let newCase = this.pumaConnector.getTrackedObjectRecordInstance('Case');
		
		//newTank.rawRecord.Code = 'test';
		newCase.rawRecord.Description = Case.description;
		newCase.rawRecord.Status = Case.status;
		
		
		//console.log (newTank);
		
		return this.pumaConnector.tqCoreConnector.storage.upsert(newCase);
		//return this.pumaConnector.post('/em_requestNewTank', tank.toNewJsonData());
	}
	createCaseCommentsData(caseId,userComment){
		var self = this;

		this.createCaseComment = this.tqCoreConnector.record.getTrackedObjectRecordInstance('CaseComment');
		this.createCaseComment.rawRecord.ParentId =  caseId;
		this.createCaseComment.rawRecord.CommentBody =  userComment;
		if (this.createCaseComment){
			return this.tqCoreConnector.storage.upsert(this.createCaseComment);
		} 	
		
	}
	updateCaseRecord(CaseId){

		this.createCaseRec = this.tqCoreConnector.record.getTrackedObjectRecordInstance('Case');
		this.createCaseRec.rawRecord.Id =  CaseId;
		this.createCaseRec.rawRecord.Status =  'Closed - Application Accepted';		
		
		if (this.createCaseRec){
			return this.tqCoreConnector.storage.upsert(this.createCaseRec);
		}
		//this.caseResolutionDialogService.open(this.CaseNumber);
        //this.caseRecordInfoDialogService.close();

	}

	
}

//TankService.$inject = ['pumaConnector', '$q'];

export default CaseService;