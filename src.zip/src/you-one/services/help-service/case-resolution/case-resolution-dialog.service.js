import CaseResolutionDialogTemplate from './case-resolution-dialog.tpl.html';
import CaseResolutionController from './case-resolution-dialog.controller.js';
import './case-resolution.sass';

class CaseResolutionDialogService {
	constructor($log, ngDialog) {
		'ngInject';
		
		this.$log = $log;
		this.ngDialog = ngDialog;
	}

	open(cRec) {
		console.log(cRec);
		var disableClose = true;
		var initialDialogHeight = null;
		this.dialogInstance = this.ngDialog.open({
			template: CaseResolutionDialogTemplate,
			plain: true,
			className: 'ngdialog-theme-default case-resolution-dialog',
			controller: CaseResolutionController,
			controllerAs:'$ctrl',
			showClose: false,
			data: {
				//site: site,
				cRec: cRec
			,closeDialog: () => {
					disableClose = false;
					this.dialogInstance.close(this.dialogInstance.id);
				},
				enableClose: () => {
					disableClose = false;
				},
				getInitialHeight: () => {
					if(!initialDialogHeight) {
						initialDialogHeight = angular.element( document.getElementsByClassName('ngdialog-content')).outerHeight();
					}
					return initialDialogHeight;
					}
				},
				preCloseCallback: () => {
				if(disableClose)
				{
					return false;
				}
				return true;
			}
			});
		}
	

	close() {
		if(this.dialogInstance) {
			this.dialogInstance.close();
		}
	}
}

export default CaseResolutionDialogService;