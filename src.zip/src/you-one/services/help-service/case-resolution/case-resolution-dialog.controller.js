import BaseDialogController from 'youOne/components/base-dialog/base-dialog.class.js';

export default class CaseResolutionController extends BaseDialogController{	
	constructor($window, $timeout, $log, $scope, caseResolutionDialogService) {
		'ngInject';
		super('past', ...arguments);		
		this.$window = $window;
		this.$timeout = $timeout;
		
		this.$log = $log;
		this.$scope = $scope;
		
		this.state = this.states.Submission;
		this.caseResolutionDialogService = caseResolutionDialogService;
	}
		
	done() {
		this.$scope.ngDialogData.closeDialog();
	}
		
	
}

