import MockHelper from '../puma-mock/mock-helper.class.js';

/*@ngInject*/
export default function mockConfig(pumaMockServiceProvider) {
	'ngInject'


	var yesterday =  new Date();
	yesterday = yesterday.setDate(yesterday.getDate() - 1);
	var twoDaysAgo =   new Date();
	twoDaysAgo = twoDaysAgo.setDate(twoDaysAgo.getDate() - 2);
	var threeDaysAgo = new Date();
	threeDaysAgo = threeDaysAgo.setDate(threeDaysAgo.getDate() - 3);
	var fourDaysAgo = new Date();
	fourDaysAgo = fourDaysAgo.setDate(fourDaysAgo.getDate() - 4);

	var sites = [{
		shipToId: 'A4F32ED2',
		shipToName: 'Site 1',
		missingTankDipDates: [twoDaysAgo, threeDaysAgo],
		tanks: [
			{
				Id: 'TN-01088',
				Name: 'TANK 1',
				measurementUnit: 'LT',
				capacity : 40000,
				safeFillLevel: 40000,
				deadStockLevel: 642,
				dipLevel: 24586,
				product: {
					Id:'',
					Name:'REGULAR',
					Color:'',
					Code:'',
					ShortName:''
				},
				lastMeasurementTime: fourDaysAgo,
				tankStatus: 'Operational',
				tankDipMissing: true
			}, {
				Id: 'TN-01089',
				Name: 'TANK 2',
				measurementUnit: 'LT',
				capacity : 26000,
				safeFillLevel: 26000,
				deadStockLevel: 296,
				dipLevel: 9805,
				product: {
					Id:'',
					Name:'PREMIUM',
					Color:'',
					Code:'',
					ShortName:''
				},
				lastMeasurementTime: fourDaysAgo,
				tankStatus: 'Operational',
				tankDipMissing: true
			}, {
				Id: 'TN-01090',
				Name: 'TANK 3',
				measurementUnit: 'LT',
				capacity : 39000,
				safeFillLevel: 38950,
				deadStockLevel: 601,
				dipLevel: 35844,
				product: {
					Id:'',
					Name:'DIESEL',
					Color:'',
					Code:'',
					ShortName:''
				},
				lastMeasurementTime: fourDaysAgo,
				tankStatus: 'Operational',
				tankDipMissing: true
			}, {
				Id: 'TN-01091',
				Name: 'TANK 4',
				measurementUnit: 'LT',
				capacity : 46000,
				safeFillLevel: 45900,
				deadStockLevel: 704,
				dipLevel: 34085,
				product: {
					Id:'',
					Name:'DIESEL',
					Color:'',
					Code:'',
					ShortName:''
				},
				lastMeasurementTime: fourDaysAgo,
				tankStatus: 'Operational',
				tankDipMissing: true
			}, {
				Id: 'TN-01092',
				Name: 'TANK 5',
				measurementUnit: 'LT',
				capacity : 31500,
				safeFillLevel: 31500,
				deadStockLevel: 510,
				dipLevel: 600,
				product: {
					Id:'',
					Name:'REGULAR',
					Color:'',
					Code:'',
					ShortName:''
				},
				lastMeasurementTime: fourDaysAgo,
				tankStatus: 'Operational',
				tankDipMissing: true
			}
		]
	}, {
		shipToId: '98D2IE1R',
		shipToName: 'Site 2',
		missingTankDipDates: [yesterday, twoDaysAgo],
		tanks: [
			{
				Id: 'TN-01093',
				Name: 'TANK 1',
				measurementUnit: 'LT',
				capacity : 40000,
				safeFillLevel: 40000,
				deadStockLevel: 680,
				dipLevel: 26922,
				product: {
					Id:'',
					Name:'REGULAR',
					Color:'',
					Code:'',
					ShortName:''
				},
				lastMeasurementTime: threeDaysAgo,
				tankStatus: 'Operational',
				tankDipMissing: true
			}, {
				Id: 'TN-01094',
				Name: 'TANK 2',
				measurementUnit: 'LT',
				capacity : 40000,
				safeFillLevel: 40000,
				deadStockLevel: 670,
				dipLevel: 18055,
				product: {
					Id:'',
					Name:'PREMIUM',
					Color:'',
					Code:'',
					ShortName:''
				},
				lastMeasurementTime: threeDaysAgo,
				tankStatus: 'Operational',
				tankDipMissing: true
			}, {
				Id: 'TN-01095',
				Name: 'TANK 3',
				measurementUnit: 'LT',
				capacity : 36000,
				safeFillLevel: 36000,
				deadStockLevel: 583,
				dipLevel: 208,
				product: {
					Id:'',
					Name:'DIESEL',
					Color:'',
					Code:'',
					ShortName:''
				},
				lastMeasurementTime: threeDaysAgo,
				tankStatus: 'Operational',
				tankDipMissing: true
			}
		]
	}, {
		shipToId: 'A4F32ED4',
		shipToName: 'Site 3',
		missingTankDipDates: [],
		tanks: [
			{
				Id: 'TN-01096',
				Name: 'TANK 1',
				measurementUnit: 'LT',
				capacity : 42000,
				safeFillLevel: 42000,
				deadStockLevel: 670,
				dipLevel: 117,
				product: {
					Id:'',
					Name:'REGULAR',
					Color:'',
					Code:'',
					ShortName:''
				},
				lastMeasurementTime: yesterday,
				tankStatus: 'Operational',
				tankDipMissing: true
			}, {
				Id: 'TN-01097',
				Name: 'TANK 2',
				measurementUnit: 'LT',
				capacity : 50000,
				safeFillLevel: 49950,
				deadStockLevel: 702,
				dipLevel: 9821,
				product: {
					Id:'',
					Name:'PREMIUM',
					Color:'',
					Code:'',
					ShortName:''
				},
				lastMeasurementTime: yesterday,
				tankStatus: 'Operational',
				tankDipMissing: true
			}, {
				Id: 'TN-01098',
				Name: 'TANK 3',
				measurementUnit: 'LT',
				capacity : 45000,
				safeFillLevel: 44950,
				deadStockLevel: 350,
				dipLevel: 37037,
				product: {
					Id:'',
					Name:'DIESEL',
					Color:'',
					Code:'',
					ShortName:''
				},
				lastMeasurementTime: yesterday,
				tankStatus: 'Operational',
				tankDipMissing: true
			}
		]
	}, {
		shipToId: 'A4F32ED5',
		shipToName: 'Site 4',
		missingTankDipDates: [],
		tanks: [
			{
				Id: 'TN-01099',
				Name: 'TANK 1',
				measurementUnit: 'LT',
				capacity : 39000,
				safeFillLevel: 39000,
				deadStockLevel: 436,
				dipLevel: 22000,
				product: {
					Id:'',
					Name:'REGULAR',
					Color:'',
					Code:'',
					ShortName:''
				},
				lastMeasurementTime: yesterday,
				tankStatus: 'Operational',
				tankDipMissing: true
			}, {
				Id: 'TN-01100',
				Name: 'TANK 2',
				measurementUnit: 'LT',
				capacity : 40000,
				safeFillLevel: 40000,
				deadStockLevel: 500,
				dipLevel: 30199,
				product: {
					Id:'',
					Name:'PREMIUM',
					Color:'',
					Code:'',
					ShortName:''
				},
				lastMeasurementTime: yesterday,
				tankStatus: 'Stopped',
				tankDipMissing: true
			}, {
				Id: 'TN-01101',
				Name: 'TANK 3',
				measurementUnit: 'LT',
				capacity : 35000,
				safeFillLevel: 35000,
				deadStockLevel: 497,
				dipLevel: 6054,
				product: {
					Id:'',
					Name:'DIESEL',
					Color:'',
					Code:'',
					ShortName:''
				},
				lastMeasurementTime: yesterday,
				tankStatus: 'Operational',
				tankDipMissing: true
			}
		]
	}];
	MockHelper.setValue('sites', sites);

	pumaMockServiceProvider.setMockResponses([{
		method: 'GET',
		path: '/em_getShipToData',
		response: function(requestBody) {
			if (requestBody.shipToIds.length === 0) {
				return MockHelper.getValue('sites');
			}
			var sites = MockHelper.getValue('sites');
			var sitesRequested = [];
			_.forEach(sites, function(site) {
				if (_.indexOf(requestBody.shipToIds, site.shipToId) > -1) {
					sitesRequested.push(site);
				}
			});
			return sitesRequested;
			},
		useByDefault: true
	},
	{
		method: 'GET',
		path: '/em_getTankDipEntryData',
		response: function(requestBody) {
			var sites = MockHelper.getValue('sites');
			return  _.find(sites, function(site) { return site.shipToId === requestBody.shipToId; });
		},
		useByDefault: true
	},
	{
		method: 'POST',
		path: '/em_submitTankDips',
		response: function(requestBody) {

			var sites = MockHelper.getValue('sites');

			var wanted = sites.filter(function(site) { return (site.shipToId === requestBody.shipToId); });
			if (wanted.length === 0) {
				return {
					'id': requestBody.shipToId,
					success: false
				};
			}

			_.forEach(requestBody.tanks, function(tankToUpdate) {
				var tankData = wanted[0].tanks.filter(function(tank) { return (tank.Id === tankToUpdate.Id); });
				if (tankData.length === 0) {
					return {
						'id': requestBody.shipToId,
						success: false
					};
				}
				tankData[0].dipLevel = tankToUpdate.dipLevel;
				tankData[0].lastMeasurementTime = tankToUpdate.lastMeasurementTime;
			});
			MockHelper.setValue('sites', sites);

			return {
				'id': requestBody.shipToId,
				success: true
			};
		},
		useByDefault: true
	}]);
}
