import CaseResolutionThankyouDialogTemplate from './case-resolution-thankyou-dialog.tpl.html';
import CaseResolutionThankyouController from './case-resolution-thankyou-dialog.controller.js';
import './case-resolution.sass';

class CaseResolutionThankyouDialogService {
	constructor($log, ngDialog) {
		'ngInject';
		
		this.$log = $log;
		this.ngDialog = ngDialog;
	}

	open(site,fromDashboard) {
		this.dialogInstance = this.ngDialog.open({
			template: CaseResolutionThankyouDialogTemplate,
			plain: true,
			className: 'ngdialog-theme-default case-resolution-thankyou-dialog',
			controller: CaseResolutionThankyouController,
			closeByDocument: false,
			data: {
				site: site,
				fromDashboard: fromDashboard
			}
		});
	}

	close() {
		if(this.dialogInstance) {
			this.dialogInstance.close();
		}
	}
}

export default CaseResolutionThankyouDialogService;