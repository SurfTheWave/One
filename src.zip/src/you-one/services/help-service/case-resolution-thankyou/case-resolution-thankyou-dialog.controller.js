class CaseResolutionThankyouController {
	
	constructor($scope, $log, caseResolutionThankyouDialogService) {
		'ngInject';
		
		this.$log = $log;
		this.$scope = $scope;
		
		this.caseResolutionThankyouDialogService = caseResolutionThankyouDialogService;
	}
}

export default CaseResolutionThankyouController;