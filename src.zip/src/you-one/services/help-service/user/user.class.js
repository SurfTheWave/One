import angular from 'angular';
//import Product from './product.class.js';
//import ChangeRequest from '../../change-request/change-request.class.js';
//import Mapping from '../../mapping.class.js';

class User {
	constructor(userData) {
		//angular.copy(tankData, this);
		//this.dipLevel = this.EP_Last_Dip_Reading__c;
		if (userData) {
			this.Id = userData.Id;
			this.Name = userData.Name;
			/*this.ParentId = caseCommentsData.ParentId;
			this.CommentBody = caseCommentsData.CommentBody;
			this.CreatedById = caseCommentsData.CreatedById;
			this.CreatedDate = caseCommentsData.CreatedDate;
			this.LastModifiedDate = caseCommentsData.LastModifiedDate;
			this.CreatorName = caseCommentsData.CreatorName;
			this.LastModifiedById = caseCommentsData.LastModifiedById;		*/
		} else {
			console.log("userData i n else",userData);
			//this.status = Tank.Status.Stopped;
		}
	}
	
/*	getChangeRequestForUpdate(tankCopy) {
		let apiName = 'EP_Tank__c';
		let changeRequest = new ChangeRequest(this.Id, apiName);
		let mappings = this.getMappings();
		//(frontEndName, backEndName, isUpdateField, isInsertField, isLookUpField) 
		for(var i=0; i < mappings.length; i++) {
			let mapping = mappings[i];
			if(mapping.isUpdateField) {
				let fieldName = mapping.frontEndName;
				if(mapping.isLookUpField){
					if(this[fieldName] && this[fieldName].Id !== tankCopy[fieldName].Id){
						changeRequest.addChangeRequestLine(apiName, mapping.backEndName, this[fieldName].Id, tankCopy[fieldName].Id, this[fieldName].Name, tankCopy[fieldName].Name);
					}
				}else {
					if(this[fieldName] !== tankCopy[fieldName]){
						changeRequest.addChangeRequestLine(apiName, mapping.backEndName, this[fieldName], tankCopy[fieldName],'','');
					}
				}
			}
		}
		console.log(changeRequest);
		return changeRequest;
	}
	
	getMappings(){
		let mappings = [];
		//Mapping(frontEndName, backEndName, isUpdateField, isInsertField, isLookUpField)
		mappings.push(new Mapping('Id','Id', false, false, false));
		mappings.push(new Mapping('Name','Name', true, true, false));
		mappings.push(new Mapping('code','EP_Tank_Code__c', true, true, false));
		mappings.push(new Mapping('alias','EP_Tank_Alias__c', true, true, false));
		mappings.push(new Mapping('product','EP_Product__r', true, true, true));
		mappings.push(new Mapping('capacity','EP_Capacity__c', true, true, false));
		mappings.push(new Mapping('deadStockLevel','EP_Deadstock__c', true, true, false));
		mappings.push(new Mapping('dipLevel','EP_Last_Dip_Reading__c', true, true, false));
		mappings.push(new Mapping('missingTankDipCount','EP_Missing_Tank_Dip_Nr__c', false, false, false));
		mappings.push(new Mapping('safeFillLevel','EP_Safe_Fill_Level__c', true, true, false));
		mappings.push(new Mapping('status','EP_Tank_Status__c', true, false, false));
		mappings.push(new Mapping('lasDipReadingDate','EP_Last_Dip_Reading_Date__c', false, false, false));
		mappings.push(new Mapping('isTankDipMissingToday','EP_Tank_Missing_Dip_For_Today__c', false, false, false));
		mappings.push(new Mapping('shipToId','EP_Ship_To__c', true, true, false));
		mappings.push(new Mapping('unitOfMeasure','EP_Unit_Of_Measure__c', false, false, false));
		return mappings;
	}

	toUpdateJsonData() {
		return {
			Id: this.Id,
			Name: this.Name,
			Alias: this.alias,
			SafeFillLevel: this.safeFillLevel,
			Capacity: this.capacity,
			ProductId: this.getProduct().Id,
			DeadStockLevel: this.deadStockLevel,
			Status: this.status
		};
	}

	toNewJsonData() {
		return {
			Name: this.Name,
			Alias: this.alias,
			SafeFillLevel: this.safeFillLevel,
			Capacity: this.capacity,
			ProductId: this.getProduct().Id,
			DeadStockLevel: this.deadStockLevel,
			ShipToId: this.shipToId,
			Status: this.status
		};
	}

	getCapacity() {
		return this.capacity;
	}

	getDeadStockLevel() {
		return this.deadStockLevel;
	}

	getDipLevel() {
		return this.dipLevel;
	}
	setDipLevel(dipLevel) {
		this.dipLevel = dipLevel;
	}
	getLastDipReadingDate() {
		return this.lasDipReadingDate;
	}
	getSafeFillLevel() {
		return this.safeFillLevel;
	}
	getMissingTankDipCount() {
		return this.missingTankDipCount;
	}
	getProduct() {
		return this.product;
	}
	getStatus() {
		return this.status;
	}
	isTankDipMissingForToday() {
		return this.isTankDipMissingToday;
	}
	getShipToId() {
		return this.shipToId;
	}
	getUnitOfMeasure() {
		return this.unitOfMeasure;
	}
	isActive(){
		if(this.getStatus() === Tank.Status.Operational){
			return true;
		}
		return false;
	}*/
}


export default User;

