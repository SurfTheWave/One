import User from './user.class.js';
//import Product from './product.class.js';

class UserService {
	constructor(changeRequestService, pumaConnector, $q,tqCoreConnector) {
		'ngInject';
		this.pumaConnector = pumaConnector;
		this.$q = $q;
		this.changeRequestService = changeRequestService;
		this.userDataList = null;
		this.tqCoreConnector = tqCoreConnector;

	}
	
	getUserData(userId){
		console.log("userId",userId);
		var self = this;
		let userDataDeferred =  this.pumaConnector.query({objectApiName: 'User', fields:['Id','CreatedDate','Name','LastModifiedDate','LastModifiedById'],where: {'Id' :  {$eq : userId}},limit : 1}).then(function(response){
			let result = [];
			for (let userData of response){
				let userRec = new User(userData);
				result.push(userRec);
				
			}
			console.log("result",result);
			self.userDataList = result;
			return self.userDataList;
		});
					
		return userDataDeferred;
	}
	
	getUserData1(usersId){ 
                console.log("usersId",usersId); 
                var self = this; 
                let userDataDeferred =  this.pumaConnector.query({objectApiName: 'User', fields:['Id','CreatedDate','Name','LastModifiedDate','LastModifiedById'],where: {'Id' :  {$in : usersId}}}).then(function(response){ 

                        let result = []; 
                        for (let userData of response){ 
                                let userRec = new User(userData); 
                                result.push(userRec); 
                                
                        } 
                        console.log("result in getUserData1",result); 
                        self.userDataList = result; 
                        return self.userDataList; 
                }); 
                                        
                return userDataDeferred; 
        }


	
	/*submitTankDips(tankDips){
		return this.pumaConnector.post('/em_submitTankDips', tankDips);
	}
	
	getAvailableProducts(shipToId){
		let availableProductsDataDeferred =  this.pumaConnector.get('/em_getAvailableProducts', {shipToId: shipToId}).then(function(response){
			let result = [];
			for (let productData of response.productList){
				let product = new Product(productData);
				result.push(product);
			}
			return result;
		});
		return availableProductsDataDeferred;
	}
	
	updateTank(changeRequest) {
		return this.changeRequestService.submitRequest(changeRequest);
	}
	
	requestNewTank(tank) {
		let newTank = this.pumaConnector.getTrackedObjectRecordInstance('EP_Tank__c');
		
		//newTank.rawRecord.Code = 'test';
		newTank.rawRecord.EP_Ship_To__c = tank.shipToId;
		newTank.rawRecord.EP_Tank_Code__c = tank.code;
		newTank.rawRecord.EP_Tank_Alias__c = tank.alias;
		
		newTank.rawRecord.EP_Capacity__c = tank.capacity;
		newTank.rawRecord.EP_Safe_Fill_Level__c= tank.safeFillLevel;
		newTank.rawRecord.EP_Deadstock__c = tank.deadStockLevel;
		newTank.rawRecord.EP_Product__c = tank.product.Id;
		newTank.rawRecord.EP_Tank_Status__c = 'Stopped'; 
		newTank.rawRecord.EP_Reason_Blocked__c = 'Maintenance';
		
		//console.log (newTank);
		
		return this.pumaConnector.tqCoreConnector.storage.upsert(newTank);
		//return this.pumaConnector.post('/em_requestNewTank', tank.toNewJsonData());
	}*/
}

//TankService.$inject = ['pumaConnector', '$q'];

export default UserService;