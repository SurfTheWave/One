import '../../puma-connector/puma-connector.js';

import userService from './user.service.js';
//import mocksConfig  from './tank.mocks.js';


export default angular.module('puma.user', ['puma.connector'])
    .service('userService', userService);
   // .config(mocksConfig);