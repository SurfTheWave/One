import HelpBase from '../helpBase.class.js';

class HelpServiceConroller extends HelpBase{
	
	constructor($scope, $log, tankDipLevelDialogService, caseManagementDialogService,caseConfirmDialogService,  platformSelectorService, platformType) {
		'ngInject';
		
		this.$log = $log;
		this.$scope = $scope;
		this.sampleText = "Hello";
		this.tankDipLevelDialogService = tankDipLevelDialogService;
		this.caseManagementDialogService = caseManagementDialogService ;
		this.caseConfirmDialogService = caseConfirmDialogService;
		
		
		
	}
	onsubmitButtonClick() {
		this.$log.debug('User clicked Enter Level button');		
		//this.missingTankDipDatesDialogService.open(site, true);
		this.caseConfirmDialogService.open(true);
	}
	
}

export default CaseManagementController;


