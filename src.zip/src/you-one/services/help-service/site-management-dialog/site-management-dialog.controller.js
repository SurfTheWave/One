class SiteManagementController {
	
	constructor($scope, $log,siteManagementDialogService,pumaConnector,userService,$sce) {
		'ngInject';
		
		this.$log = $log;
		this.$scope = $scope;
		this.siteManagementDialogService = siteManagementDialogService;
		this.userService = userService;
		this.pumaConnector = pumaConnector;
		this.$sce = $sce;
		
		this.articleId = this.$scope.ngDialogData.FAQ.Id;
		this.CreatedById = this.$scope.ngDialogData.FAQ.CreatedById;
		this.question = this.$scope.ngDialogData.FAQ.Question__c;		
		this.articleBody = $sce.trustAsHtml(this.$scope.ngDialogData.FAQ.EP_FE_Article_Body__c);
		// this.src = this.articleBody.find('img:first').html('src');
		console.log('arcilebdy ' + this.articleBody);
		
		this.LastPublishedDate = this.$scope.ngDialogData.FAQ.LastPublishedDate;
		
				
		let userDataDeferred = this.userService.getUserData(this.CreatedById).then((userDataList) => {
		console.log("userDataList",userDataList);
		
		for (let userRec of userDataList){              
			console.log("userRec.name",userRec.Name);
			this.$scope.UserName = userRec.Name;			
		}
		});
		
	}	
	}	

export default SiteManagementController;