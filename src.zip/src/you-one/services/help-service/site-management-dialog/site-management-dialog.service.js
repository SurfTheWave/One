import SiteManagementDialogTemplate from './site-management-dialog.tpl.html';
import SiteManagementController from './site-management-dialog.controller.js';
import './site-management-dialog.sass';

class SiteManagementDialogService {
	constructor($log, ngDialog) {
		'ngInject';
		
		this.$log = $log;
		this.ngDialog = ngDialog;
	}

	open(FAQ,fromDashboard) {
		console.log("FAQ " + FAQ);
		this.dialogInstance = this.ngDialog.open({
			template: SiteManagementDialogTemplate,
			plain: true,
			className: 'ngdialog-theme-default sm-mgmt-dialog',
			controller: SiteManagementController,
			controllerAs:'$ctrl',
			closeByDocument: false,
			data: {
				FAQ: FAQ,
				fromDashboard: fromDashboard				
			}
		});
	}

	close() {
		if(this.dialogInstance) {
			this.dialogInstance.close();
		}
	}
}

export default SiteManagementDialogService;