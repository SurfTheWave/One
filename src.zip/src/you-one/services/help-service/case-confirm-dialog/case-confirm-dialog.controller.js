class CaseConfirmDialogController {
	
	constructor($window, $timeout,$scope, $log, caseConfirmDialogService) {
		'ngInject';
		
		this.$window = $window;
		this.$timeout = $timeout;
		
		this.$log = $log;
		this.$scope = $scope;
		//this.tankDipLevelDialogService = tankDipLevelDialogService;
		this.caseConfirmDialogService = caseConfirmDialogService;
	}
	
	done() {
		this.$scope.ngDialogData.closeDialog();
	}
}

export default CaseConfirmDialogController;
