class TankDipLevelDialogController {
	
	constructor($scope, $log) {
		'ngInject';
		
		$log.debug('Tank dip level dialog controller created. Site name: ' + $scope.ngDialogData.site.Name);
	}
}

export default TankDipLevelDialogController;