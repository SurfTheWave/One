import TankDipLevelDialogTemplate from './tank-dip-level-dialog.tpl.html';
import TankDipLevelDialogController from './tank-dip-level-dialog.controller.js';
import './tank-dip-level-dialog.sass';

class TankDipLevelDialogService {
	constructor($log, accountService, ngDialog, modalDialog) {
		'ngInject';
		
		this.$log = $log;
		this.accountService = accountService;
		this.ngDialog = ngDialog;
		this.modalDialog = modalDialog;
	}

	open(site, missingDate) {
		// Flag for submitTankDipLevelDialog whether it is closed
		var isConfirmationDialogOpened = false;
		var isTankDipLevelSubmitted = false;
		console.log(site);
		
		this.dialogInstance = this.ngDialog.open({
			template: TankDipLevelDialogTemplate,
			plain: true,
			className: 'ngdialog-theme-default dip-level-entry-dialog',
			controller: TankDipLevelDialogController,
			closeByDocument: false,
			data: {
				site: site,
				missingDate: missingDate,
				onSubmitTankDipSuccess: () => {
					this.$log.debug('Successfully submitted tank dip levels. Retrieving up-to-date site...');
					this.accountService.getSellToAccount().then((sellToAccount) => {
					let shipTo = sellToAccount.shipToList.filter(function(shipTo) { return (shipTo.Id === site.Id); });
					site.tanks = shipTo[0].tanks;
				});
					/*
					this.siteService.getShipToData([site.shipToId]).then((newMySitesData) => {
						this.$log.debug('Done. ' + newMySitesData.length + ' sites retrieved.');
						if(site.shipToId === newMySitesData[0].shipToId && newMySitesData.length === 1) {
							this.$log.debug('Tanks updated!');
							site.tanks = newMySitesData[0].tanks;
						} else {
							this.$log.debug('Tanks not updated!');
						}
					});
					*/
					isTankDipLevelSubmitted = true;
					this.dialogInstance.close();
				}
			}, 
			
			// preCloseCallback function is called before the this.dialogInstance is closed 
			preCloseCallback: () => {
				
				if(isConfirmationDialogOpened === false && isTankDipLevelSubmitted === false) {
					this.modalDialog('confirm', 'yesno', 'Are you sure want to close edit tank dip level dialog?')
					.then(
						(data) => {
							if (data === 'yes') {
								isConfirmationDialogOpened = true;
								//close this.dialogInstance which is parent dialog of the confirmation dialog:
								this.dialogInstance.close();
							}
						},
						(err) => {
							this.$log.debug('modal dialog is closed with: ' + err);
						}
					);
					return false; //return false statement holds the this.dialogInstance open
				}
			}
		});
	}

	close() {
		if(this.dialogInstance) {
			this.dialogInstance.close();
		}
	}
}

export default TankDipLevelDialogService;