import caseThankyouDialogTemplate from './case-thank-you-dialog.tpl.html';
import CaseThankYouDialogController from './case-thank-you-dialog.controller.js';
import './case-thank-you-dialog.sass';

class CaseThankYouDialogService {
	constructor($log, ngDialog) {
		'ngInject';
		
		this.$log = $log;
		this.ngDialog = ngDialog;
	}

	open(cnum) {
		var disableClose = true;
		var initialDialogHeight = null;
		console.log('111111111' + cnum );
		this.dialogInstance = this.ngDialog.open({
			template: caseThankyouDialogTemplate,
			plain: true,
			className: 'ngdialog-theme-default case-thank-you-dialog',
			controller: CaseThankYouDialogController,
			controllerAs: '$ctrl',
			showClose: false,
			
			data: {
				//site: site,
				cnum: cnum
				
			,closeDialog: () => {
					disableClose = false;
					this.dialogInstance.close(this.dialogInstance.id);
				},
				enableClose: () => {
					disableClose = false;
				},
				getInitialHeight: () => {
					if(!initialDialogHeight) {
						initialDialogHeight = angular.element( document.getElementsByClassName('ngdialog-content')).outerHeight();
					}
					return initialDialogHeight;
					}
				},
				preCloseCallback: () => {
				if(disableClose)
				{
					return false;
				}
				return true;
			}
			});
		}
	
	close() {
		if(this.dialogInstance) {
			this.dialogInstance.close();
		}
	}
}
export default CaseThankYouDialogService;