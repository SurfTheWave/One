export default class CaseThankYouDialogController{	
	constructor($window, $timeout, $log, $scope, contactThankYouDialogService) {
		'ngInject';
		
		this.$window = $window;
		this.$timeout = $timeout;
		
		this.$log = $log;
		this.$scope = $scope;
		
		this.contactThankYouDialogService = contactThankYouDialogService;
		

	}
	
	done() {
		this.$scope.ngDialogData.closeDialog();
	}
	
}

