import Case from './case-comments.class.js';
//import Product from './product.class.js';

class CaseCommentsService {
	constructor(changeRequestService, pumaConnector, $q,tqCoreConnector) {
		'ngInject';
		this.pumaConnector = pumaConnector;
		this.$q = $q;
		this.changeRequestService = changeRequestService;
		this.caseCommentDataList = null;
		this.tqCoreConnector = tqCoreConnector;

	}
	
	getCaseCommentsData(caseId){ 
		console.log("caseId",caseId); 
		var self = this; 
		let caseCommentsDataDeferred =  this.pumaConnector.query({objectApiName: 'CaseComment', fields:['Id','ParentId','CommentBody','CreatedById','CreatedDate','LastModifiedDate','CreatorName','LastModifiedById'],orderby: 'CreatedDate desc',where: {'ParentId' :  {$eq : caseId}},limit : 3}).then(function(response){ 

				let result = []; 
				for (let caseCommentData of response){ 
						let caseCommentRec = new Case(caseCommentData); 
						result.push(caseCommentRec); 
						
				} 
				console.log("result",result); 
				self.caseCommentDataList = result; 
				return self.caseCommentDataList; 
		}); 
								
		return caseCommentsDataDeferred; 
}
	
	createCaseCommentsData(caseId,userComment){ 
		console.log("caseId",caseId); 
		console.log("userComment",userComment); 
		var self = this;  

		this.createCaseComment = this.tqCoreConnector.record.getTrackedObjectRecordInstance('CaseComment'); 
		this.createCaseComment.rawRecord.ParentId =  caseId; 
		this.createCaseComment.rawRecord.CommentBody =  userComment; 
				//$scope.CaseRec.CaseNumber =  $scope.category; 
				console.log('$scope.createCaseComment', this.createCaseComment); 
				console.log('$scope.createCaseComment.rawRecord', this.createCaseComment.rawRecord); 
		

		if (this.createCaseComment){ 
				this.tqCoreConnector.storage.upsert(this.createCaseComment); 
				console.log('Update is here', this.createCaseComment); 
		} 
	}
}

export default CaseCommentsService;


	/*submitTankDips(tankDips){
		return this.pumaConnector.post('/em_submitTankDips', tankDips);
	}
	
	getAvailableProducts(shipToId){
		let availableProductsDataDeferred =  this.pumaConnector.get('/em_getAvailableProducts', {shipToId: shipToId}).then(function(response){
			let result = [];
			for (let productData of response.productList){
				let product = new Product(productData);
				result.push(product);
			}
			return result;
		});
		return availableProductsDataDeferred;
	}
	
	updateTank(changeRequest) {
		return this.changeRequestService.submitRequest(changeRequest);
	}
	
	requestNewTank(tank) {
		let newTank = this.pumaConnector.getTrackedObjectRecordInstance('EP_Tank__c');
		
		//newTank.rawRecord.Code = 'test';
		newTank.rawRecord.EP_Ship_To__c = tank.shipToId;
		newTank.rawRecord.EP_Tank_Code__c = tank.code;
		newTank.rawRecord.EP_Tank_Alias__c = tank.alias;
		
		newTank.rawRecord.EP_Capacity__c = tank.capacity;
		newTank.rawRecord.EP_Safe_Fill_Level__c= tank.safeFillLevel;
		newTank.rawRecord.EP_Deadstock__c = tank.deadStockLevel;
		newTank.rawRecord.EP_Product__c = tank.product.Id;
		newTank.rawRecord.EP_Tank_Status__c = 'Stopped'; 
		newTank.rawRecord.EP_Reason_Blocked__c = 'Maintenance';
		
		//console.log (newTank);
		
		return this.pumaConnector.tqCoreConnector.storage.upsert(newTank);
		//return this.pumaConnector.post('/em_requestNewTank', tank.toNewJsonData());
	}*/


//TankService.$inject = ['pumaConnector', '$q'];

