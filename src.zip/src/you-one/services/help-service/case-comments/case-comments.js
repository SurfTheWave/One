import '../../puma-connector/puma-connector.js';

import caseCommentsService from './case-comments.service.js';
//import mocksConfig  from './tank.mocks.js';


export default angular.module('puma.case-comments', ['puma.connector'])
    .service('caseCommentsService', caseCommentsService);
   // .config(mocksConfig);