import angular from 'angular';
//import Product from './product.class.js';
//import ChangeRequest from '../../change-request/change-request.class.js';
//import Mapping from '../../mapping.class.js';

class CaseComments {
	constructor(caseCommentsData) {
		//angular.copy(tankData, this);
		//this.dipLevel = this.EP_Last_Dip_Reading__c;
		if (caseCommentsData) {
			this.Id = caseCommentsData.Id;
			this.ParentId = caseCommentsData.ParentId;
			this.CommentBody = caseCommentsData.CommentBody;
			this.CreatedById = caseCommentsData.CreatedById;
			this.CreatedDate = caseCommentsData.CreatedDate;
			this.LastModifiedDate = caseCommentsData.LastModifiedDate;
			this.CreatorName = caseCommentsData.CreatorName;
			this.LastModifiedById = caseCommentsData.LastModifiedById;			
		} else {
			console.log("caseData i n else",caseCommentsData);
			//this.status = Tank.Status.Stopped;
		}
	}
}


export default CaseComments;

