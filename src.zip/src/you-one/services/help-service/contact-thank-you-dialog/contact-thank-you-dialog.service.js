import contactThankyouDialogTemplate from './contact-thank-you-dialog.tpl.html';
import ContactThankYouDialogController from './contact-thank-you-dialog.controller.js';
import './contact-thank-you-dialog.sass';

class ContactThankYouDialogService {
	constructor($log, ngDialog) {
		'ngInject';
		
		this.$log = $log;
		this.ngDialog = ngDialog;
	}

	open(fromDashboard) {
		var disableClose = true;
		var initialDialogHeight = null;
		this.dialogInstance = this.ngDialog.open({
			template: contactThankyouDialogTemplate,
			plain: true,
			className: 'ngdialog-theme-default contact-thank-you-dialog',
			controller: ContactThankYouDialogController,
			controllerAs: '$ctrl',
			showClose: false,
			data: {
				//site: site,
				fromDashboard: fromDashboard
			,closeDialog: () => {
					disableClose = false;
					this.dialogInstance.close(this.dialogInstance.id);
				},
				enableClose: () => {
					disableClose = false;
				},
				getInitialHeight: () => {
					if(!initialDialogHeight) {
						initialDialogHeight = angular.element( document.getElementsByClassName('ngdialog-content')).outerHeight();
					}
					return initialDialogHeight;
					}
				},
				preCloseCallback: () => {
				if(disableClose)
				{
					return false;
				}
				return true;
			}
			});
		}
	
	close() {
		if(this.dialogInstance) {
			this.dialogInstance.close();
		}
	}
}
export default ContactThankYouDialogService;