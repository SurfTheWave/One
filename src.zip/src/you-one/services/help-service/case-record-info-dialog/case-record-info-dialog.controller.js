class CaseRecordInfoDialogController {
	
	constructor($scope, $log,$route,caseService,tqCoreConnector,caseRecordInfoDialogService,caseResolutionDialogService ) {
		'ngInject';
			
		this.$log = $log;
		this.$scope = $scope;
		this.tqCoreConnector = tqCoreConnector;
		this.caseRecordInfoDialogService = caseRecordInfoDialogService;

		this.caseRecord =this.$scope.ngDialogData.cRec;
		this.caseCommentList = this.caseRecord.CaseComments;
		this.CaseNumber = this.caseRecord.CaseNumber;
		this.CaseId = this.caseRecord.Id;

		this.caseResolutionDialogService = caseResolutionDialogService;
		this.caseService = caseService;
		this.result = [];
		this.commentTime = '';
		this.userComment = null;
		
		$scope.maxLength = 1000;
		$scope.remaining = function(){
			 return $scope.maxLength - angular.element(document).find('textarea')[0].value.length;
		}
		// apply changes when section gets loaded
		$scope.afterload = function(){
  			var scroller = document.getElementById("scrollSection");
			scroller.scrollTop = scroller.scrollHeight;
		}
	}
	
	createCaseCommentRecord(userComment){
		console.log("userComment",userComment);
		var newCommList = [];
		this.caseService.createCaseCommentsData(this.CaseId,userComment).then((response) => {
				if(response.body[0].success){
					console.log("responseData.body[0]",response.body[0].record);
					this.caseCommentList.push(response.body[0].record);
					this.$scope.userComment = null;
					this.$scope.$apply();
				}
		});
	}
	
	updateCaseRecord(){
		
		this.createCaseRec = this.tqCoreConnector.record.getTrackedObjectRecordInstance('Case');
		this.createCaseRec.rawRecord.Id =  this.CaseId;
		this.createCaseRec.rawRecord.Status =  'Closed - Application Accepted';		
		
		if (this.createCaseRec){
			this.tqCoreConnector.storage.upsert(this.createCaseRec);
		}
		this.caseResolutionDialogService.open(this.CaseNumber);
        this.caseRecordInfoDialogService.close();

	}
	
	getDateDiff(createdDate){
		
		var commentTimeDiff = '';

		var date1 = new Date(createdDate);
		var date2 = new Date();
		
		// get total seconds between the times
		var delta = Math.abs(date2 - date1) / 1000;

		// calculate (and subtract) whole days
		var days = Math.floor(delta / 86400);
		delta -= days * 86400;

		// calculate (and subtract) whole hours
		var hours = Math.floor(delta / 3600) % 24;
		delta -= hours * 3600;

		// calculate (and subtract) whole minutes
		var minutes = Math.floor(delta / 60) % 60;
		delta -= minutes * 60;

		// what's left is seconds
		var seconds = delta % 60; 
		
		if(days){
			commentTimeDiff = days +' days ';	
		}		
		else if(hours){
			commentTimeDiff += hours+' hours '; 	
		}
		else if(minutes){
			commentTimeDiff += minutes + ' minutes ';	
		}
		else if(seconds){
            commentTimeDiff += 'few seconds ';
        }
		commentTimeDiff += 'ago'; 
		
		return commentTimeDiff;
	}
}

export default CaseRecordInfoDialogController;