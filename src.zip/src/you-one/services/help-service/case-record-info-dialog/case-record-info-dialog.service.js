import caseRecordInfoDialogTemplate from './case-record-info-dialog.tpl.html';
import CaseRecordInfoDialogController from './case-record-info-dialog.controller.js';
import './case-record-info-dialog.sass';

class CaseRecordInfoDialogService {
	constructor($log, ngDialog) {
		'ngInject';
		
		this.$log = $log;
		this.ngDialog = ngDialog;
	}

	open(cRec) {
		console.log(cRec);
		var disableClose = true;
		var initialDialogHeight = null;
		this.dialogInstance = this.ngDialog.open({
			template: caseRecordInfoDialogTemplate,
			plain: true,
			className: 'ngdialog-theme-default csid-tank-dip-dates-dialog',
			controller: CaseRecordInfoDialogController,
			controllerAs:'$ctrl',
			closeByDocument: false,
			data: {
				cRec: cRec
			
			}
			});
		}
	
	close() {
		if(this.dialogInstance) {
			this.dialogInstance.close();
		}
	}
}

export default CaseRecordInfoDialogService;