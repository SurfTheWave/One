import caseManagementDialogTemplate from './case-management-dialog.tpl.html';
import CaseManagementDialogController from './case-management-dialog.controller.js';
import './case-management-dialog.sass';

class caseManagementDialogService {
	constructor($log, ngDialog) {
		'ngInject';
		
		this.$log = $log;
		this.ngDialog = ngDialog;
	}
	
	open(cnum) {
		//console.log(cRec);
		var disableClose = true;
		var initialDialogHeight = null;
		this.dialogInstance = this.ngDialog.open({
			template: caseManagementDialogTemplate,
			plain: true,
			className: 'ngdialog-theme-default case-management-dialog',
			controller: CaseManagementDialogController,
			controllerAs:'$ctrl',
			closeByDocument: false,
			data: {
				cnum: cnum			
			}
			});
		}

	close() {
		if(this.dialogInstance) {
			this.dialogInstance.close();
		}
	}
}

export default caseManagementDialogService;