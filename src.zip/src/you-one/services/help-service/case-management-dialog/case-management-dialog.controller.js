
class CaseManagementDialogController {
                
	constructor($scope, $log, tankDipLevelDialogService,tqCoreConnector,pumaConnector,
	caseManagementDialogService,caseConfirmDialogService,caseThankYouDialogService,$rootScope) {
					'ngInject';
					
					this.$log = $log;
					this.$scope = $scope;
					this.tankDipLevelDialogService = tankDipLevelDialogService;
					this.caseManagementDialogService = caseManagementDialogService ;
					this.caseConfirmDialogService = caseConfirmDialogService;
					this.caseThankYouDialogService = caseThankYouDialogService;
					this.pumaConnector = pumaConnector;
					window.tqCoreConnector = tqCoreConnector;
					this.$rootScope = $rootScope;					
					$scope.maxLength = 240;
					$scope.remaining = function(){
					return $scope.maxLength - angular.element(document).find('textarea')[0].value.length;
					}
													
	}
	
					
	onsubmitButtonClick() {
					this.$log.debug('User clicked Enter Level button');                           
					//this.missingTankDipDatesDialogService.open(site, true);
					this.caseConfirmDialogService.open(true);
	}
	
	addCase() {
		this.$log.debug('add case on Submit button clicked.');
				
		let cnum;           
		this.getUpsertcase().then((responseData)=>{

		if(responseData.body[0].success){
				this.result=responseData.body[0].record.CaseNumber;
				 if(responseData.body[0].record.Status == 'New' || responseData.body[0].record.Status == 'New Application'){
                    
                     this.$rootScope.noOfOpenCases++;
                }

			}

		this.cnum=this.result;

		this.caseThankYouDialogService.open(this.cnum);
		this.caseManagementDialogService.close(true);																										

		});
	}
	
	        
	
getUpsertcase(){
	let CaseRec = this.pumaConnector.getTrackedObjectRecordInstance('Case');
									
	CaseRec.rawRecord.Description =  this.$scope.textareaText;
	CaseRec.rawRecord.Status =  this.$scope.category;
					
	return this.pumaConnector.tqCoreConnector.storage.upsert(CaseRec);  																								

}

}

export default CaseManagementDialogController;


