import angular from 'angular';
import ApiHelper from '../puma-connector/api-helper.class.js';


import Tank from './tank/tank.class.js';
	
let getShipToOpeningDays = function(apiResponse) {
	if(!apiResponse.EP_Ship_To_Opening_Days__c)
		return null;
	var openingDaysString = apiResponse.EP_Ship_To_Opening_Days__c.trim();
	if (openingDaysString[openingDaysString.length - 1] === ';') {
		openingDaysString = openingDaysString.substring(0, openingDaysString.length - 1);
	}

	return openingDaysString.split(';');
};

class Contact {
	constructor(contactData) {
		if(contactData)
			this.constructWithContactData(contactData);
	}
	
	constructWithContactData(contactData) {
		//angular.copy(contactData, this);	
			
		//this.id = contactData.Id;
		this.name = contactData.Name;
		//this.accountNumber = contactData.AccountNumber;
		
		this.email = contactData.EP_Email__c;                                          
		this.status = contactData.EP_Status__c;
		this.company = contactData.EP_Company;
		this.contactname = contactData.EP_ContactName;
		this.designation = contactData.EP_Designation;
		this.phone = contactData.Phone;
		
		// Shipping address
		this.shippingStreet = contactData.ShippingStreet;
		this.shippingStreet1 = contactData.ShippingStreet1;
		this.shippingCity = contactData.ShippingCity;
		this.shippingState = contactData.ShippingState;
		this.shippingCountry = contactData.ShippingCountry;
		this.shippingPostalCode = contactData.ShippingPostalCode;
	}
	
	
	
	// Prev. Impl. : Will be removed after sync with Stream1
	getName() {
		return this.name;
	}
	
	
	getBillingData() {
		// Previous implementation:
		// return this.billTo || this;
		return this.billTo;
	}

	
	getStatus(){
		return this.status;
	}


	getBillingAddress() {
		return ApiHelper.getBillingAddressString(this.getBillingData());
	}

	getShippingAddress() {
		return ApiHelper.getShippingAddressString(this);
	}

	// Prev. Impl. : Will be removed after sync with Stream1
	getEmail() {
		return this.email;
	}

	
	// Prev. Impl. : Will be removed after sync with Stream1
	getPhone() {
		return this.phone;
	}

	
}

class SellToAccount extends Account {
	constructor(contactData) {
		super(contactData.record);
	
		if (Array.isArray(contactData.shipToList)) {
			this.shipToList = [];
			for (let shipToData of contactData.shipToList) {
				this.shipToList.push(new ShipToAccount(shipToData));
			}
		}

		if (contactData.billTo) {
			contactData.billTo = new Account(contactData.billTo);
		}
		
		// Has multi site
		this.isMultiSite = this.shipToList && this.shipToList > 1;
		
		this.terminalList = contactData.terminalList;
	}
	
	// Prev. Impl. : Will be removed after sync with Stream1
	isMultiSite() {
		return this.shipToList && this.shipToList > 1;
	}
	
	canCreateOrder(){
		if (this.getDeliveryType() == Account.DeliveryType.ExRack){
			return true;
		} else {
			if (Array.isArray(this.shipToList)) {
				for (var shipToAccount of this.shipToList){
					if (shipToAccount.canCreateOrder()){
						return true;
					}
				}
			}
			return false;
		}
	}
	
	
	}
}

Contact.Status = {
	Active: '03-Active',
	Inactive: '05-Inactive'
};

export default Contact;