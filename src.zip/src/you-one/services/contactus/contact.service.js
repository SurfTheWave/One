import Account from './account.class.js';

class AccountService {
	constructor(pumaConnector, $q, store) {
		'ngInject';
		this.pumaConnector = pumaConnector;
		this.$q = $q;

		this.contactFields = ['Name', 
			'EP_Billing_Method__c', 'EP_Payment_Term_Name__c',
			'EP_Billing_Frequency__c', 'EP_Delivery_Type__c', 'ShippingStreet', 'ShippingStreet1', 'ShippingCity', 'ShippingState' , 'ShippingCountry', 
			'ShippingPostalCode', 'EP_Status__c', 'EP_Email', 'EP_Phone', 'EP_Company', 'EP_ContactName', 'EP_Designation',
			'EP_Delivery_Type__c'];
		
		this.loadContactToPromise = null;
		this.sellToAccounts = null;
		this.sellToAccountsMap = {};
		this.store = store;
		
		this.defaultSellToId = null;
		this.defaultSellToIndex = 0;
	}

	_getAccountsList(query) {
		return this.pumaConnector.query(query).then(function (accounts) {
			let result = [];
			for (let accountData of accounts) {
				result.push(new Account(accountData));
			}
			return result;
		});
	}

	loadSellToAccounts() {
		var self = this;
		this.sellToAccounts = null;
		this.sellToAccountsMap = {};
		this.loadContactToPromise = this.store.getBootstrapData().then(function (response) {
			let result = [];
			if (Array.isArray(response.sellToList)) {
				for (let cocntactData of response.sellToList) {
					let account = new Account.SellTo(accountData);
					result.push(account);
					self.sellToAccountsMap[account.Id] = account;
				}
			}
			self.sellToAccounts = result;
			return self.sellToAccounts;
		});
		return this.loadSellToPromise;
	}

	getSellToAccounts() {
		/*
		if (this.loadSellToPromise) {
			return this.$q.when(this.loadSellToPromise);
		} else {
			return this.loadSellToAccounts();
		}*/
		return this.loadSellToAccounts();
	}

	getShipToAccounts(sellToId) {
		var self = this;
		return this.getSellToAccounts().then(function () {
			var sellTo = self.sellToAccountsMap[sellToId];
			return sellTo ? sellTo.shipToList : null;
		});
	}

	getSellToAccount(sellToId) {
		return this.getSellToAccounts().then(() => {
			var selectedSellToId = sellToId || this.defaultSellToId;
			if (this.sellToAccountsMap[selectedSellToId]) {
				return this.sellToAccountsMap[selectedSellToId];
			} else {
				var sellToIndex = (self.defaultSellToIndex < this.sellToAccounts.length) ? self.defaultSellToIndex : 0;
				return this.sellToAccounts[sellToIndex];
			}
		});
	}

	/*
	'newShipToInfo' is supposed to be an key-value object with keys:
			Name, ShippingStreet, ShippingCity, ShippingState, ShippingCountry, ShippingPostalCode, EP_Ship_To_Opening_Days__c
	*/
	addShipToAccount(sellToId, newShipToInfo) {
		return this.pumaConnector.post('/addShipto', {
			SellToId: sellToId,
			//Name: newShipToInfo.Name,
			ShippingStreet: newShipToInfo.ShippingStreet,
			ShippingCity: newShipToInfo.ShippingCity,
			ShippingState: newShipToInfo.ShippingState,
			ShippingCountry: newShipToInfo.ShippingCountry,
			ShippingPostalCode: newShipToInfo.ShippingPostalCode,
			OpeningDays: newShipToInfo.EP_Ship_To_Opening_Days__c
		});
	}
	
	updateSellToAccount(sellTo) {
		return this.pumaConnector.post('/updateSellto', sellTo.toUpdateJsonData());
	}

	updateShipToAccount(shipTo) {
		return this.pumaConnector.post('/updateShipto', shipTo.toUpdateJsonData());
	}

}

export default AccountService;