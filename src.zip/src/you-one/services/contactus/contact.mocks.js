import contactJSON from './contact.json';
import MockHelper from '../puma-mock/mock-helper.class.js';

let contactList = contactJSON;


/*@ngInject*/
export default function mockConfig(pumaMockServiceProvider) {
	'ngInject';
	
	// Add mock tanks to ship to's
	for (let contactData of contactList) {
		contactData.tanks = tankList;
	}
	// Add empty sell to account to mock wihout account detail just ship to's to mock sell to account
	sellToList.push({}); 
	
	pumaMockServiceProvider.setMockResponses([{
		method: 'GET',
		path: '/Account/List/',
		response: function() {
			var response = [], sellToIndex = 0;
			if (MockHelper.getValue('currentSellto')) {
				response[0] = MockHelper.getValue('currentSellto');
			} else {
				for (let sellToData of sellToList) {
					var sellTo = {
						record: sellToData,
						shipToList: [],
						terminalList: null,
						billTo: null
					};

					if (sellToIndex <= 1) {
						sellTo.shipToList = shipToList;
					}
					else if (sellToIndex == 2) {
						sellTo.shipToList = [shipToList[0]];
					}
					else if (sellToIndex == 5) {
						sellTo.record = null;
						sellTo.shipToList = [shipToList[0]];
					}

					if (sellTo.EP_Delivery_Type__c == 'Ex-Rack') {
						sellTo.terminalList = [];
						for (let index = 1; index <= 3; index++) {
							sellTo.terminalList.push({
								terminalId: index,
								terminalName: 'Terminal ' + index
							});
						}
					}
					sellToIndex++;
					response.push(sellTo);
				}
				if(currentSelltoIndex >= sellToIndex)
					currentSelltoIndex = sellToIndex - 1;
				MockHelper.setValue('currentSellto', response[currentSelltoIndex]);
			}
			return {
				status: 200,
				errors: null,
				sellToList: response
			};
		},
		useByDefault: true
	}]);
}