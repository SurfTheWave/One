import '../puma-connector/puma-connector.js';

import contactService from './contact.service.js';
import mocksConfig  from './contact.mocks.js';

let runMethod = function(contactService){
    'ngInject';
    contactService.loadSellToAccounts();
};

export default angular.module('puma.account', ['puma.store'])
    .service('contactService', contactService)
    .config(mocksConfig)
    .run(runMethod);