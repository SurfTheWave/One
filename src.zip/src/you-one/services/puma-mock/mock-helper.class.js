let MockHelper = {
    mockData : {},

    setValue : function(key, value){
        let keyComponents = (typeof key === 'string') ? key.split('.') : [key];
        var object = this.mockData;
        for (var index = 0; index < keyComponents.length - 1; index++){
            if (!object[keyComponents[index]]){
                object[keyComponents[index]] = {};
            }
            object = object[keyComponents[index]];
        }
        return (object[keyComponents[index]] = value);
    },

    getValue : function(key){
        let keyComponents = (typeof key === 'string') ? key.split('.') : [key];
        var object = this.mockData;
        for (let index = 0; index < keyComponents.length && object; index++){
            object = object[keyComponents[index]];
        }
        return object;
    },

    randomString : function(length){
        length = length || 20;
        var chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz'.split('');

        if (! length) {
            length = Math.floor(Math.random() * chars.length);
        }

        var str = '';
        for (var i = 0; i < length; i++) {
            str += chars[Math.floor(Math.random() * chars.length)];
        }
        return str;
    },

    randomId : function(){
        return this.randomString(18);
    },

    randomInt : function(min, max) {
        min = min || 0;
        max = max || 1000000;
        return Math.floor(Math.random() * (max - min + 1)) + min;
    },

	randomBoolean: function(){
		return !!Math.round(Math.random())
	},

	randomSalesforceAddress: function(){
		return {
			"street": this.randomInt(1, 120) + (this.randomBoolean() ? " Testfield Street" : " Longfield St"),
			"city": this.randomBoolean() ? "Lodnon" : "Default City",
			"state": this.randomBoolean() ? "LO" : null,
			"country": "United Kingdom",
			"postalCode": "NW" + this.randomInt(1,9) + " " + this.randomInt(100,500)
		};
	}
};

export default MockHelper;