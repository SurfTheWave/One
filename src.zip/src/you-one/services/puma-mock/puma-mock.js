import pumaMockProvider from './puma-mock.provider.js'


export default angular.module('puma.connector.mocks', [])
    .provider('pumaMockService', pumaMockProvider);
