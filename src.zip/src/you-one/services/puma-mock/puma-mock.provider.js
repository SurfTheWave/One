import PumaMockService from './puma-mock.service.js'

class PumaMockServiceProvider {
    constructor(){
        this.mockResponses = {
            'GET' : {},
            'POST' : {},
            'PUT' : {},
			'UPSERT': {}
        };

        this.alwaysUseMockResponses = IS_TEST_EXECUTION;
    }

    setMockResponse(method, path, response, useByDefault, delay){
        this.mockResponses[method][path] = {response: response, useByDefault: useByDefault, delay: delay};
    }

    setMockResponses(mockResponses){
        if (!Array.isArray(mockResponses)) {
            mockResponses = [mockResponses];
        }

        mockResponses.forEach((mockResponseConfig) => {
            this.setMockResponse(mockResponseConfig.method, mockResponseConfig.path, mockResponseConfig.response,
								mockResponseConfig.useByDefault, mockResponseConfig.delay);
        });
    }

	startTestMode(){
		this.alwaysUseMockResponses = true;
	}

    $get($q, $timeout){
        'ngInject';
        return new PumaMockService(this.mockResponses, this.alwaysUseMockResponses, $q, $timeout);
    }
}

PumaMockServiceProvider.$inject = [];

export default PumaMockServiceProvider;