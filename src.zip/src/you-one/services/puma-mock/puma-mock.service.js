import angular from 'angular';

export default class PumaMockService {
    constructor(mockResponses, alwaysUseMockResponses, $q, $timeout) {
        this.mockResponses = mockResponses;
        this.alwaysUseMockResponses = alwaysUseMockResponses;
        this.$q = $q;
		this.$timeout = $timeout;
    }

	startTestMode(){
		this.alwaysUseMockResponses = true;
	}

	getResponseMockConfiguration(method, path){
		if (this.mockResponses[method] && this.mockResponses[method][path]) {
			return this.mockResponses[method][path];
		} else {
			return null;
		}
	}

    shouldUseMockResponse(method, path){
        if (this.alwaysUseMockResponses){
            return true;
        } else {
			let mockConfiguration = this.getResponseMockConfiguration(method, path);
            return mockConfiguration && mockConfiguration.useByDefault === true;
        }
    }

    getServer404Error(){
        let ajaxError = {
            status: 404,
            statusText: "Not Found",
            responseJSON: [{
                errorCode: "NOT_FOUND",
                message: "Could not find a match for URL"
            }]
        };
        ajaxError.responseText = JSON.stringify(ajaxError.responseJSON);
        return ajaxError;
    }

    getMockResponseData(method, path, body, options){
        let responseConfig = this.mockResponses[method][path];
        if (responseConfig){
            let responseData = responseConfig.response;
            if (angular.isFunction(responseData)){
                return responseData.call(this, body, options);
            } else {
                return responseData;
            }
        } else {
            let error = this.getServer404Error();
            return error;
        }
    }

    getMockResponse(method, path, body, options){
		let responseConfig = this.mockResponses[method][path];
		let defer = this.$q.defer();
		if (responseConfig && responseConfig.delay && !IS_TEST_EXECUTION){
			this.$timeout(() => {
				defer.resolve(this.getMockResponseData(method, path, body, options));
			}, responseConfig.delay);
		} else {
			defer.resolve(this.getMockResponseData(method, path, body, options));
		}
		return defer.promise;
    }
}