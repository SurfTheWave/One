import 'app/app.js';
import '@angular/router/angular1/angular_1_router.js';

describe('Component: Loading-Spinner', () => {

	let component, scope, $rootScope, $componentController, $timeout;

	beforeEach(angular.mock.module('app'));

	beforeEach(angular.mock.inject((_$rootScope_, _$componentController_, _$timeout_) => {

		$rootScope = _$rootScope_
		scope = $rootScope.$new();
		$componentController = _$componentController_;
		component = $componentController(
			'loadingSpinner', {
				$scope: scope
			}
		);
		$timeout = _$timeout_;
	}));

	describe('Component Usage', () => {

		it('should have proper default values', () => {

			expect(component.delay).toBe(500);
			expect(component.loading).toBe(false);
			expect(component.isSpinnerAnimationRequired).toBe(true);
		});

		it('should use proper bindings', () => {

			expect(component.delay).toBe(500);
			expect(component.loading).toBe(false);
			expect(component.isSpinnerAnimationRequired).toBe(true);

			component = $componentController(
				'loadingSpinner',
				{
					$scope: scope
				},
				{
					delay: 10000
				}
			);

			expect(component.delay).toBe(10000);
		});

		it('reacts to the related Spinner Events', () => {

			expect(component.loading).toBe(false);
			$rootScope.$broadcast('spinnerLoading');

			$timeout.flush();

			expect(component.loading).toBe(true);

			$rootScope.$broadcast('spinnerStop');
			expect(component.loading).toBe(false);
			expect(component.isSpinnerAnimationRequired).toBe(false);
		});

		it('should respect a delay', () => {

			expect(component.loading).toBe(false);
			
			$rootScope.$broadcast('spinnerStop');
			$timeout(() => {
				$rootScope.$broadcast('spinnerLoading');	
			}, 0)
			
			$timeout.flush();
			
			expect(component.loading).toBe(false);
		});
	});
});