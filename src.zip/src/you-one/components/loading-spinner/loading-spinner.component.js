import template from './loading-spinner.tpl.html';
import LoadingSpinnerController from './loading-spinner.controller.js';

let loadingSpinner = {
	
	template: template,
	controller: LoadingSpinnerController,
	bindings: {
		delay: '@'
	}
};

export default loadingSpinner;