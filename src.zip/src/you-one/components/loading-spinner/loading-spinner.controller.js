/**
 * @ngdoc overview
 * @name loadingSpinner
 * @param {Integer} delay determines the amount of time in milliseconds which have to pass before the spinner is displayed (default 500 ms)
 * @description
 * Controller for the loadingSpinner Component which is displayed for every HTTP Call to the Backend
 */
class LoadingSpinnerController {
	
	constructor($rootScope, $timeout) {
		
		'ngInject'
		this.rootScope = $rootScope;	
		this.timeout = $timeout;
		this.delay = isNaN(this.delay) ? 500 : this.delay;
		this.loading = false;
		this.isSpinnerAnimationRequired = true;
		this.initialDisplayIsOver = true;
		
		/** listener for the spinnerLoading event which will be broadcasted at the beginning of an HTTP Request */
		this.rootScope.$on('spinnerLoading', () => {
			
			this.isSpinnerAnimationRequired = true;
			$timeout (() => {

				/** checks if a the request already finished before the defined time is passed */
				if (this.isSpinnerAnimationRequired) {
					
					this.loading = true;
				}	
			}, this.delay)	
			
		})
		
		/** listener for the spinnerStop event which will be broadcasted after getting requestErrors, response and responseErrors*/
		this.rootScope.$on('spinnerStop', () => {
			
			/** this value will prevent triggering the spinner display */
			this.isSpinnerAnimationRequired = false;
			this.loading = false;
		})
	}
}

export default LoadingSpinnerController