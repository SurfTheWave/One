import './footer.sass';
import template from './footer.tpl.html';

let footer = {
	template: template
};

export default footer;