import './thank-you-dialog.sass';
import template from './thank-you-dialog.tpl.html';

let thankyouDialog = {
	template: template,
	bindings: {
		getThankYouMessage: '&',
		getThankYouDetailMessage: '&',
		done: '&'
	}
};

export default thankyouDialog;