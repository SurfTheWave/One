import './confirm-dialog.sass';
import template from './confirm-dialog.tpl.html';

let confirmDialog = {
	template: template,
	bindings: {
		getConfirmationMessage: '&',
		getConfirmationDetailMessage: '&',
		confirmYes: '&',
		confirmNo: '&'
	}
};

export default confirmDialog;