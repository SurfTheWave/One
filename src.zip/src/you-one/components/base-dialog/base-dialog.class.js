export default class BaseDialogController {
	
	constructor($scope,$log) {
		// State: other uses: 'success', 'failure' (not necessary for now)
		this.states={Submission:'submission', Success: 'success', Confirmation: 'confirmation', Failure: 'failure'};	
		this.$log = $log;
		this.successDialogMinimizePercent=0.65;
		this.confirmationDialogMinimizePercent=0.50;
		
		// Its full size of ng-content, it will dynamically getting from css height property of 'ng-diallog content size'
		this.initialHeight=null;
	}
	
	/**
	* @ngdoc function
	* @name changeState
	* Change state of the dialog by given state parameter.
	*/	
	changeState(state) {
		if(!this.initialHeight) {
			this.initialHeight = this.$scope.ngDialogData.getInitialHeight();
		}
		
		if(this.initialHeight) {		
			let ngDialogContentDiv = angular.element( document.getElementsByClassName('ngdialog-content'));
			switch(state) {
				case this.states.Success:
					this.$scope.ngDialogData.enableClose();
					ngDialogContentDiv.stop().animate({'height': (this.initialHeight*this.successDialogMinimizePercent)+'px'}, 500);
				break;
				case this.states.Confirmation:
					ngDialogContentDiv.stop().animate({'height':(this.initialHeight*this.confirmationDialogMinimizePercent)+'px'}, 500);
				break;
				case this.states.Submission:
					ngDialogContentDiv.stop().animate({'height':(this.initialHeight)+'px'}, 500);
				break;
				case this.states.Failure:
					this.$scope.ngDialogData.enableClose();
				break;
			}
			this.state = state;
		} else {
			this.$log.debug('initialHeight property should be defiend to change state!!!');
		}
	}
	
	/**
	* @ngdoc function
	* @name closeDialog
	* Check dialog state, if state is not success, change state to confirmation.
	* if state is success, close the dialog.
	*/	
	closeDialog() {
		if(this.state !== this.states.Success) {
			this.changeState(this.states.Confirmation);			
		}
		else {
			this.$scope.ngDialogData.closeDialog();		
		}
	}

	/**
	* @ngdoc function
	* @name confirmYes
	* When confirmation response with yes, close the dialog.
	*/	
	confirmYes() {
		console.log(this.$scope);
		this.$scope.ngDialogData.closeDialog();
	}

	/**
	* @ngdoc function
	* @name confirmNo
	* When confirmation response with no, change state of dialog to submission state
	*/	
	confirmNo() {
		this.changeState(this.states.Submission);
	}
	
	/**
	* @ngdoc function
	* @name done
	* Call back for success, it closes the dialog.
	*/	
	done() {
		this.$scope.ngDialogData.closeDialog();
	}
}