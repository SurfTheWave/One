class ListController {
	constructor() {
		this.loadMore();
	}

	loadMore() {
		var it = this.iterator.next();
		console.log('it', it);
		it.value.then((res) => {
			this.records({orders: res.orders});
			this.showLoadMore = !res.done;
		});
	}
}

export default ListController;