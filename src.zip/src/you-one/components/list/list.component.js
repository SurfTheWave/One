import './list.sass';
import template from './list.tpl.html';
import ListController from './list.controller.js';

let pumaList = {
	bindings: {
		iterator: '<',
		records: '&',
		delegateHandle: '@?'
	},
	template: template,
	controller: ListController,
	transclude: true
};

export default pumaList;