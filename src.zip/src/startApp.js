// import the CSS
//import 'acnNg/main.sass';
//import 'youOne/main.sass';
//import 'app/app.sass';

// temp fix
//import 'jquery';
import 'angular';
import 'angularTranslate';
import 'angularTranslateLoaderStaticFiles';
import 'angularTranslateLoaderUrl';
import 'router';
import app from 'app/app';
// import ngDialog.js and ngDialog css files:
import acnCore from 'acnCore/connector';
import 'ng-dialog';
import 'ng-dialog/css/ngDialog.css';
import 'ng-dialog/css/ngDialog-theme-default.css';
import './you-one/ng-dialog-custom.sass';
import './you-one/services/modal-dialog/modal-dialog.sass';

//This is running on a device
if (typeof cordova !== 'undefined') {
	document.addEventListener('deviceready', function() {
		window.console.info('Setting screen orientation through Cordova plugin to ', window.tqScreenOrientation);
		window.cordova.plugins.screenorientation.setOrientation(window.tqScreenOrientation);
		startApp();
	});
} else {
	//Running on a browser
	startApp();
}

function startApp() {
	console.log('AppName', app);
	if (window.visualForceExecution === 'TRUE') {
		//TQ.config.Core.setOnlineMode(true);
	}
	
	TQ.Connector.session.login().done(function() {
		angular.bootstrap(document, [app['name']], {
			strictDi: true
		});
	});
}

