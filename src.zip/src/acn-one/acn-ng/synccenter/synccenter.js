import template from './synccenter.tpl.html';
define(['angular', 'uiRouter', 'coreapi'], function () {
	return angular.module('tq.synccenter', ['ui.router', 'tq.coreapi'])

		// module routing
		.config(function ($stateProvider) {
			// note '.' means substate
			$stateProvider.state('tqsynccenter', {
				url: '/tqsynccenter',
                cache: false,
				controller: 'TqSyncCtrl',
				template: template,
				data: {pageTitle: 'Sync'}
			});
		})

		.controller('TqSyncCtrl', function TqSyncController($rootScope, $scope, $timeout, $state, tqCoreConnector) {
			// init values from core (every time init the ui according to values coming from core)
			$scope.notForcedOffline = !tqCoreConnector.appstatus.getIsOfflineForced();
			$scope.errorMessage = tqCoreConnector.syncstatus.getSyncErrorMessage();
			$scope.showRefreshAuthBtn = false;
			$scope.showFeedbackBtn = false;

			// load appropriate error messages on screen
			$scope.calculateErrorSection = function () {
				// read from appstatus
				var appstatus = tqCoreConnector.appstatus.getErrorStatus();

				// exception => refresh token expired
				if (appstatus.action === tqCoreConnector.appstatus.PERFORM_LOGOUT) {
					$scope.errorMessage = 'Your access has expired. It is required to re-authenticate in order to continue using the app. Your data is not going to be lost';
					// custom show the logout button through UI
					$scope.showRefreshAuthBtn = true;

					// standard error scenario
				} else {
					$scope.errorMessage = tqCoreConnector.syncstatus.getSyncErrorMessage();
					$scope.showFeedbackBtn = true;
				}
			};

			$scope.submitFeedback = function () {
				// navigate to feedback module
				$state.go('tqfeedback');
			};

			$scope.toggleForceOffline = function () {
				// toggle core values
				tqCoreConnector.appstatus.toggleForceOffline();
				$scope.notForcedOffline = !$scope.notForcedOffline;
			};

			// on sync events, reload the list
			var reloadList = function () {
				$scope.load();
			};
			tqCoreConnector.schedule.onJobSuccess('Sync', reloadList);
			tqCoreConnector.schedule.onJobFail('Sync', reloadList);

			// watch return the function to call when we want to stop watching for variables
			var unwatchErrorMessage = $rootScope.$watch('syncErrorMessage', function () {
				// when syncErrorMessage changes, update the error message section values
				$scope.calculateErrorSection();
				$timeout(function () {
					$scope.$apply();
				});
			});

			$scope.isSyncing = function (currentSyncStatus) {
				return currentSyncStatus === tqCoreConnector.syncstatus.SYNCHRONIZING;
			};

			$scope.sync = function () {
				// check on online status otherwise user will see a warning message printed right away at the top of the synccenter
				if (tqCoreConnector.appstatus.isOnline()) {
					tqCoreConnector.sync.startSync();
				}
			};

			$scope.edit = function (syncItem) {
				$state.go('tqedit', {objectapiname: syncItem.objectApiName, recordid: syncItem.id});
			};

			$scope.reset = function (syncItem, index) {
				tqCoreConnector.storage.findRecordById(syncItem.objectApiName, syncItem.id, true).then(function (recordList) {
						var recordToReset = recordList[0];
						tqCoreConnector.storage.resetLocalChanges(recordToReset).then(
							// move back to list on success
							function success() {
								if (!index) {
									index = $scope.syncItemList.indexOf(syncItem);
								}
								$scope.syncItemList.splice(index, 1);
							},
							// display error
							function error(err) {
								console.log('angular:records:delete:error');
							}
						);
					},
					function error(err) {
						console.log('angular:records:delete:error');
					}
				);
			};

			// TODO use list directive instead
			$scope.load = function () {

				$scope.syncItemList = [];

				// TODO we cannot access directly the syncStatus like this but should access through connector
				return tqCoreConnector.sync.getQueue().then(function (recordList) {
					$scope.syncItemList = [];
					_.each(recordList, function (record) {
						var status;
						if (record.rawRecord.IsDeleted === true) {
							status = 'Deleted';
						} else if (record.syncStatus === "AWAITING_SYNCHRONISATION") {
							status = 'Pending';
						} else {
							status = 'Error';
						}

                        // display Name field
                        var nameField = tqCoreConnector.metadata.getNameField(record.objectApiName);
                        var syncItem = record;
                        syncItem.name = nameField ? record.rawRecord[nameField] : record.objectApiName;
                        syncItem.status = status;
                        $scope.syncItemList.push(syncItem);

						$timeout(function () {
							$scope.$apply();
						});
					});
				});
			};

			// load list on page load
			$scope.load();

			// calculate custom message
			$scope.calculateErrorSection();

            // clear the event listeners when leaving the page
            $scope.$on('$destroy', function() {
                unwatchErrorMessage();
                tqCoreConnector.schedule.offJobSuccess('Sync', reloadList);
                tqCoreConnector.schedule.offJobFail('Sync', reloadList);
            });

            $scope.appVersion = window.appVersion;

            // bug investigation functionality
            $scope.showAlert = function(record) {
                $scope.record = record;
                var alertPopup = $ionicPopup.alert({
                    scope: $scope,
                    template: '{{record|json}}'
                });
                alertPopup.then(function() {
                    if(record.errorList.length > 0){
                        tqCoreConnector.logger.info({
                            namespace: 'ticket-completion',
                            labels: 'synccenter-confirm-alert',
                            details: record.errorList,
                            message: record.name
                        });
                    }
                });
            };
        });
});
