import template from './details.tpl.html';
define(['angular',
	'ionic',
	'uiRouter',
	'coreapi',
	'components/recorddetail/recorddetail',
	'components/list/related/related',
	'components/list/attachment/attachment'], function (angular) {

	return angular.module('tq.details',
		['ui.router',
			'tq.coreapi',
			'ionic',
			'tq.recorddetail',
			'tq.list.related',
			'tq.list.attachment'])

		// module routing
		.config(function ($stateProvider) {
			// note '.' means substate
			$stateProvider.state('tqdetails', {
				url: '/tqdetails/:objectapiname/:recordid',
                cache: false,
				controller: 'TqDetailsCtrl', //The same customization could be with controller, we can write method here
				template: template,
				data: {pageTitle: 'Details'}
			});
		})

		.controller('TqDetailsCtrl', function TqDetailsController($scope, $state, $location, $stateParams, $ionicActionSheet, tqCoreConnector, $ionicScrollDelegate, $timeout) {
			$scope.objectApiName = $stateParams.objectapiname;
			$scope.objectLabel = tqCoreConnector.metadata.getTrackedObjectLabel($scope.objectApiName);
			$scope.objectNameField = tqCoreConnector.metadata.getNameField($scope.objectApiName);
			$scope.record = {};
			$scope.headerTitle = '';
			$scope.recordId = $stateParams.recordid;

			// store doesn't exist (is not synchronised)
			if (!tqCoreConnector.storage.storeExist($scope.objectApiName)) {
				tqCoreConnector.logger.warn({
					message: 'object ' + $scope.objectApiName + ' is not synchronized'
				});
			} else {
				// get the record from storage
				tqCoreConnector.storage.findRecordById($scope.objectApiName, $scope.recordId)
					.then(
					function (record) {
						// save record and raw counter part
						$scope.record = record[0];
						$scope.headerTitle = $scope.record.rawRecord[$scope.objectNameField] || $scope.objectLabel;
						// apply
						$timeout(function () {
							$scope.$apply();
						});
					}
				);
			}

            $scope.isObjectAvailable = function(objectApiName){
                return !!tqCoreConnector.metadata.getTrackedObjectMetadata(objectApiName);
            };

			$scope.showEditSheet = function () {

				// Show the action sheet
				var hideSheet = $ionicActionSheet.show({
					buttons: [
						{text: 'Edit'}
					],
					destructiveText: 'Delete',
					destructiveButtonClicked: function () {
						// remove
						tqCoreConnector.storage.remove($scope.record).then(
							// move back to list on success
							function success() {
								$state.go('tqrecords', {objectapiname: $scope.objectApiName});
							},
							// display error
							function error(err) {
								// TODO
								console.log('angular:details:delete:error');
							}
						);

						return true;
					},
					cancelText: 'Cancel',
					cancel: function () {
						// add cancel code..
					},
					buttonClicked: function (index) {
						if (index === 0) {
							$state.go('tqedit', {objectapiname: $scope.objectApiName, recordid: $scope.recordId});
						}
						return true;
					}
				});
			};
		});
});
