import template from './edit.tpl.html';
define(['angular',
	'ionic',
	'uiRouter',
	'coreapi',
	'components/input/lookup/lookup',
	'components/input/select/select',
	'components/input/multiselect/multiselect',
	'components/input/date/date',
	'components/input/datetime/datetime'
], function (angular) {
	return angular.module('tq.edit',
		['ui.router',
			'tq.coreapi',
			'ionic',
			'tq.input.lookup',
			'tq.input.select',
			'tq.input.multiselect',
			'tq.input.date',
			'tq.input.datetime'])

		// module routing
		.config(function ($stateProvider) {
			// note '.' means substate
			$stateProvider.state('tqnew', {
				url: '/tqnew/:objectapiname/:prepopulationRawRecordMap',
				controller: 'TqEditCtrl',
				template: template,
				data: {pageTitle: 'Edit'}
			})
				.state('tqedit', {
					url: '/tqedit/:objectapiname/:recordid',
					controller: 'TqEditCtrl',
					template: template,
					data: {pageTitle: 'Edit'}
				});
		})

		.controller('TqEditCtrl', function TqEditController($scope, $state, $stateParams, $ionicPopup, $ionicModal, $window, tqCoreConnector, $ionicScrollDelegate) {
			$scope.objectApiName = $stateParams.objectapiname;
			$scope.objectLabel = tqCoreConnector.metadata.getTrackedObjectLabel($scope.objectApiName);
			$scope.recordLabelsMap = {};
			$scope.errorList = [];
			$scope.headerTitle = '';
			$scope.prepopulationRawRecordMap = $stateParams.prepopulationRawRecordMap;
			$scope.objectNameField = tqCoreConnector.metadata.getNameField($scope.objectApiName);
			var objectMetadata = tqCoreConnector.metadata.getTrackedObjectMetadata($scope.objectApiName);
			//If we recordId is not set or it's local Id, it means that we should display create fieldSet
			//While object hasn't been created successfully on salesforce, user should have ability to modify creatable fields
			if ($stateParams.recordid && $stateParams.recordid.indexOf('Local') === -1) {
				$scope.displayFieldSet = objectMetadata.editFieldSet;
			} else {
				$scope.displayFieldSet = objectMetadata.createFieldSet;
			}

			$scope.prepopulateRawRecord = function () {

				// if has been passed as parameter
				if ($scope.prepopulationRawRecordMap !== undefined) {
					var prepopulationRawRecordMap = JSON.parse($scope.prepopulationRawRecordMap);
					// check existence and that there is at least one key
					if (!_.isEmpty(prepopulationRawRecordMap)) {
						// where there are keys within prepopulationRawRecordMap, we have something to pre-populate the rawRecord with
						_.forEach(prepopulationRawRecordMap, function (fieldValue, fieldApiName) {
							// sanity check on the existence of the field on the model
							if (tqCoreConnector.metadata.getFieldMetadata($scope.objectApiName, fieldApiName)) {
								// if we are passing date or datetime we need to convert it back to Date object because this is what the UI is expecting (same as when loaded from storage)
								if ($scope.getFieldType(fieldApiName) == 'date' || $scope.getFieldType(fieldApiName) == 'datetime') {
									fieldValue = new Date(fieldValue);
								}

								$scope.record.rawRecord[fieldApiName] = fieldValue;
							} else {
								console.log('edit:error:trying toprepopulate a field that is not in the ' + $scope.objectApiName + ' model');
							}
						});
					}
				}
			};

			$scope.getFieldType = function (fieldApiName) {
				return tqCoreConnector.metadata.getFieldMetadata($scope.objectApiName, fieldApiName).type;
			};

			$scope.isEdit = function () {
				return $stateParams.recordid !== undefined && $stateParams.recordid.indexOf('Local') === -1;
			};

			// edit > get existing record
			if ($stateParams.recordid) {
				// NOTE for a new record, a following update (before sync) falls under edit as on the server (we keep same experience)
				// This means that if a field is not updatable, even if the record is still not inserted on the server, we consider it as created
				// User finds the same experience he has on the server, and if he wants to change something after the create, he needs to delete and recreate the record as he would do on server
				tqCoreConnector.storage.findRecordById($scope.objectApiName, $stateParams.recordid).then(function (record) {
					$scope.record = record[0];
					$scope.errorList = $scope.record.errorList;
					// create field labels map
					$scope.recordLabelsMap = tqCoreConnector.metadata.getFieldApiNameLabelsMap($scope.record, $scope.objectApiName);
					// show record Name or object api name when not present
					$scope.headerTitle = $scope.record.rawRecord[$scope.objectNameField] || 'Edit ' + $scope.objectLabel;
				});

				// new > get new record instance
			} else {
				$scope.record = tqCoreConnector.record.getTrackedObjectRecordInstance($scope.objectApiName);
				// form prepopulation when map is passed
				$scope.prepopulateRawRecord();
				// NOTE once the raw record has all the extra fields added then get the labels based on the record.rawRecord
				$scope.recordLabelsMap = tqCoreConnector.metadata.getFieldApiNameLabelsMap($scope.record, $scope.record.objectApiName);
				$scope.headerTitle = 'New ' + $scope.objectLabel;
			}

			$scope.isFieldRequired = function (fieldApiName) {
				return tqCoreConnector.metadata.getTrackedObjectRequiredFieldsMap($scope.objectApiName)[fieldApiName];
			};

			$scope.isUpdatable = function (fieldApiName) {
				return tqCoreConnector.metadata.isUpdatable($scope.objectApiName, fieldApiName);
			};

			$scope.isCreatable = function (fieldApiName) {
				return tqCoreConnector.metadata.isCreatable($scope.objectApiName, fieldApiName);
			};

			$scope.hasError = function () {
				return tqCoreConnector.record.hasError($scope.record);
			};

			//////////////////////////////////////////////////
			// TODO
			//
			// ALL THIS OUT OF EDIT AND INSIDE DIRECTIVE
			$scope.openModal = function (key) {
				$scope.picklistItems = tqCoreConnector.metadata.getActivePicklistValues($scope.objectApiName, key);
				var fieldLabel = $scope.recordLabelsMap[key];
				var templatePrefix = '<ion-modal-view><ion-header-bar class="tq-modal-header"><div class="buttons"><button class="button" ng-click="closeModal()">Cancel</button></div><h1 class="title">' + fieldLabel + '</h1></ion-header-bar><ion-content><tq-input-select sortable="false" object-api-name="\'' + $scope.objectApiName + '\'" ';
				var templatePostfix = ' item-change="closeModal()"></tq-input-select></ion-content></ion-modal-view>';
				var templatePicklist = 'item-list="picklistItems"' + ' selected-item="record.rawRecord[\'' + key + '\']"';
				var template = templatePrefix + templatePicklist + templatePostfix;

				$scope.modal = $ionicModal.fromTemplate(template, {
					scope: $scope,
					backdropClickToClose: false,
					animation: 'slide-in-up'
				});
				$scope.modal.show();
			};

			$scope.closeModal = function () {
				$scope.modal.hide();
			};

			$scope.multi = {};
			$scope.multi.openModal = function (key) {
				$scope.multi.key = key;
				$scope.multi.itemList = tqCoreConnector.metadata.getActivePicklistValues($scope.objectApiName, key);
				$scope.multi.selectedItems = $scope.record.rawRecord[key] ? $scope.record.rawRecord[key].split(';') : [];
				var fieldLabel = $scope.recordLabelsMap[key];
				var templatePrefix = '<ion-modal-view><ion-header-bar class="tq-modal-header"><div class="buttons"><button class="button" ng-click="multi.cancel()">Cancel</button></div><h1 class="title">' + fieldLabel + '</h1><div class="buttons"><button class="button" ng-click="multi.done()">Done</button></div></ion-header-bar><ion-content><tq-input-multiselect sortable="false" object-api-name="\'' + $scope.objectApiName + '\'" ';
				var templatePostfix = ' done="done()" cancel="cancel()"></tq-input-multiselect></ion-content></ion-modal-view>';
				var templatePicklist = 'item-list="multi.itemList"' + ' selected-items="multi.selectedItems"';
				var template = templatePrefix + templatePicklist + templatePostfix;

				$scope.multi.modal = $ionicModal.fromTemplate(template, {
					scope: $scope,
					backdropClickToClose: false,
					animation: 'slide-in-up'
				});
				$scope.multi.modal.show();
			};

			$scope.multi.done = function () {
				// build selection array
				var orderedSelectedItems = _.filter($scope.multi.itemList, function (item) {
					return _.includes($scope.multi.selectedItems, item);
				});
				// user has selected something
				if (orderedSelectedItems.length > 0) {
					$scope.record.rawRecord[$scope.multi.key] = orderedSelectedItems.join(';');
					// no selection
				} else {
					$scope.record.rawRecord[$scope.multi.key] = null;
				}

				$scope.multi.modal.hide();
			};
			$scope.multi.cancel = function () {
				$scope.multi.modal.hide();
			};
			//
			// ALL THIS OUT OF EDIT AND INSIDE DIRECTIVE
			//////////////////////////////////////////////////

			$scope.save = function () {
				var validationErrors = tqCoreConnector.storage.validateRecord($scope.record);
				if (validationErrors.length === 0) {
					tqCoreConnector.storage.upsert($scope.record).then(function () {
						$window.history.back();
					});
				} else {
					// update scope
					$scope.errorList = validationErrors;
					// scroll up to show error
					$ionicScrollDelegate.$getByHandle('ionContentScrollHandle').scrollTop(true);
				}
			};
		});
});
