This folder contains reusable code across the entire application.
Some examples can be
-angular-ui components
-jquery components (calendar)
-custom angular component (alert banner)

Inside the acn-one folder you can find our own created components