import template from './records.tpl.html';
define(['angular', 'uiRouter', 'coreapi', 'components/list/list', 'components/list/item/item'], function (angular) {
	return angular.module('tq.records', ['ui.router', 'tq.coreapi', 'tq.list', 'tq.list.item'])

		// module routing
		.config(function ($stateProvider) {
			// note '.' means substate
			$stateProvider.state('tqrecords', {
				url: '/tqrecords/:objectapiname',
                cache: false,
				controller: 'TqRecordsCtrl',
				template: template,
				data: {pageTitle: 'Records'}
			});
		})

		.controller('TqRecordsCtrl', function TqRecordsController($scope, $state, $stateParams, tqCoreConnector) {
			$scope.objectApiName = $stateParams.objectapiname;
			$scope.objectLabel = tqCoreConnector.metadata.getTrackedObjectLabel($scope.objectApiName);

			$scope.addNewRecord = function () {
				// NOTE if we don't pass the prepopulationRawRecordMap we lose the animation
				// EX of passing a field:value for prepopulation on NEW
				// var params = {objectapiname: $scope.objectApiName, prepopulationRawRecordMap: $scope.getPrepopulationRawRecordMapAsParam({Survey_Date__c: new Date()})};
				var params = {
					objectapiname: $scope.objectApiName,
					prepopulationRawRecordMap: $scope.getPrepopulationRawRecordMapAsParam({})
				};
				$state.go('tqnew', params);
			};

			// abstract the stringify
			$scope.getPrepopulationRawRecordMapAsParam = function (prepopulationRawRecordMap) {
				return JSON.stringify(prepopulationRawRecordMap);
			};
		});
});
