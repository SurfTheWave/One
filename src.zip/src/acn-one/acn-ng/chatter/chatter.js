import template from './chatter.tpl.html';
define(['angular',
	'uiRouter',
	'coreapi',
	'components/chatter/feed/feed',
    'components/chatter/post/post',
    'components/chatter/feeditem/feeditem'

], function (angular) {
	return angular.module('tq.chatter', [
		'ui.router',
		'tq.coreapi',
		'tq.chatter.feed',
        'tq.chatter.post',
        'tq.chatter.feedItem'
	])
		// module routing
		.config(function ($stateProvider) {
			// note '.' means substate
			$stateProvider.state('tqchatter', {
				url: '/tqchatter',
                cache: false,
				controller: 'TqChatterCtrl',
				template: template,
				data: {
					pageTitle: 'Chatter'
				}
			});

		})

		.controller('TqChatterCtrl', function TqChatterController($scope, tqCoreConnector, $ionicScrollDelegate, $timeout) {
			////////////////////////////////////////////////////
			// TEST EXAMPLE
			//
			// this will display only user feed
			//$scope.parentId = tqCoreConnector.user.getId();
			// this will display home feed

			// set to the booking component of the trip product

			$scope.parentId = tqCoreConnector.user.getId();

			// this will display record feed
			//$scope.parentId = SOME-ACCOUNT-RECORD.Id;
			//
			// TEST EXAMPLE
			////////////////////////////////////////////////////
		});
});
