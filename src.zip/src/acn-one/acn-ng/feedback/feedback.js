import template from './feedback.tpl.html';
define(['angular', 'uiRouter', 'coreapi'], function (angular) {

	return angular.module('tq.feedback', ['ui.router', 'tq.coreapi'])

		// module routing
		.config(function ($stateProvider) {
			// note '.' means substate
			$stateProvider.state('tqfeedback', {
				url: '/tqfeedback',
				controller: 'TqFeedbackCtrl',
				template: template,
				data: {pageTitle: 'Contact AccentureONE Team'}
			});
		}).service('TqFeedbackUtils', function () {

			var getDeviceType = function () {
				if (navigator.userAgent.indexOf("Android") > 0) {
					return 'Android';
				} else if (navigator.userAgent.indexOf("iPhone") > 0) {
					return 'iPhone';
				} else if (navigator.userAgent.indexOf("iPod") > 0) {
					return 'iPod';
				} else if (navigator.userAgent.indexOf("iPad") > 0) {
					return 'iPad';
				} else {
					return window.device.model;
				}
			};

			var getDeviceVars = function () {
				if (window.device) {
					return {
						cordova: window.device.cordova,
						model: window.device.model,
						platform: window.device.platform,
						uuid: window.device.uuid,
						version: window.device.version,
						device: getDeviceType()
					};
				}
				return false;
			};

			return {
				getDeviceVars: getDeviceVars
			};

		})

		.controller('TqFeedbackCtrl', function TqFeedbackController($scope, tqCoreConnector, $ionicScrollDelegate, $timeout, tqFeedbackUtils) {
			$scope.record = tqCoreConnector.record.getTrackedObjectRecordInstance('Case');
			$scope.errorList = [];
			$scope.sendSuccess = false;
			$scope.caseRecordType = 'TQONE_Issue';
			$scope.recordTypeId = tqCoreConnector.metadata.getRecordTypeId('Case', $scope.caseRecordType);
			$scope.version = window.appVersion;

			$scope.getDeviceType = tqFeedbackUtils.getDeviceType;

			$scope.getDeviceType = tqFeedbackUtils.getDeviceVars;

			$scope.initCaseValues = function (rawCase) {
				rawCase.Subject = '';
				rawCase.Description = '';
				rawCase.Origin = 'AccentureONE';
				rawCase.Type = 'Problem';

				if ($scope.recordTypeId) {
					rawCase.RecordTypeId = $scope.recordTypeId;
				}

				var deviceVars = FeedbackUtils.getDeviceVars;
				if (deviceVars) {
					rawCase.TQ1_Cordova_Version__c = deviceVars.cordova;
					rawCase.TQ1_Device_Model__c = deviceVars.model;
					rawCase.TQ1_Platform__c = deviceVars.platform;
					rawCase.TQ1_UUID__c = deviceVars.uuid;
					rawCase.TQ1_OS_Version__c = deviceVars.version;
					rawCase.TQ1_Device_Type__c = deviceVars.device;
				}
				else {
					rawCase.TQ1_Device_Model__c = 'Desktop ' + navigator.appCodeName;
					rawCase.TQ1_Platform__c = navigator.platform;

					//Put in device version name of the browser + brovser version, cut another data
					var deviceVersion = navigator.appCodeName + ' ' + navigator.appVersion;
					if (deviceVersion.indexOf(')') > 0) {
						deviceVersion = deviceVersion.substring(0, deviceVersion.indexOf(')') + 1);
					}
					rawCase.TQ1_Device_Type__c = deviceVersion;
				}
			};

			$scope.initCaseValues($scope.record.rawRecord);

			$scope.reportIssue = function () {
				$scope.sendSuccess = false;
				var contentScroller = $ionicScrollDelegate.$getByHandle('ionContentScrollHandle');

				if ($scope.validateCase()) {
					var uploadDef = tqCoreConnector.sync.immediateUpload($scope.record);
					uploadDef.then(function (response) {
							if (response && response.body && response.body[0].success === false) {
								console.log(response.body[0]);
								$scope.errorList = ['Failed to send your message. Please check internet connection and try again.'];
							}
							else {
								$scope.sendSuccess = true;
								$scope.record = tqCoreConnector.metadata.getTrackedObjectRecordInstance('Case');
								$scope.initCaseValues($scope.record.rawRecord);

								$timeout(function () {
									$scope.sendSuccess = false;
								}, 3000);
							}
							contentScroller.scrollTop(true);
						},
						function (error) {
							console.log(error);
							$scope.errorList = ['Failed to send your message. Please check internet connection and try again.'];
							contentScroller.scrollTop(true);
						});
				} else {
					contentScroller.scrollTop(true);
				}
			};

			$scope.validateCase = function () {
				$scope.errorList = [];

				if (!$scope.record.rawRecord.Subject || $scope.record.rawRecord.Subject === '') {
					$scope.errorList.push('Please enter Subject of your message');
				}

				if (!$scope.record.rawRecord.Description || $scope.record.rawRecord.Description === '') {
					$scope.errorList.push('Please enter Description of your problem');
				}

				return ($scope.errorList.length === 0);
			};
		});

});
