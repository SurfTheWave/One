import template from './home.tpl.html';
define([
	'angular',
	'uiRouter',
	'coreapi',
	'components/bootstrap/bootstrap'], function (angular) {

	return angular.module('tq.home', [
		'ui.router',
		'tq.coreapi',
		'tq.bootstrap'])

		// module routing
		.config(function ($stateProvider) {
			// note '.' means substate
			$stateProvider.state('tqhome', {
				url: '/tqhome',
				controller: 'TqHomeCtrl',
				template: template,
				data: {pageTitle: 'Home'}
			});
		})

		// module controller
		.controller('TqHomeCtrl', function TqHomeController($scope, tqCoreConnector) {
		});
});
