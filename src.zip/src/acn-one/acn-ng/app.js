//import template from 'app/index.tpl.html';
define([
    'angular',
//	'templatesApp',
//	'templatesCommon',
	'uiRouter',
	'coreapi',
    'components/bootstrap/bootstrap',
	'components/redirector/redirector',
    'components/auth/auth'//,
	//'acnNg/login/login',
	//'acnNg/activation/activation'
], function () {

	return angular.module('acnone', [
//		'templates-app',
//		'templates-common',
		//'ui.router',
		'tq.coreapi',
        'tq.bootstrap',
        'tq.auth',
		'tq.login',
		'tq.activation'
	])

    .constant('tqScreenBreakpoints', {
        GRID_RESPONSIVE_SM_BREAK: 567
    })

    .config(function ($compileProvider, $locationProvider) {
        var isDevEnvironment = ENV_VARS.deploymentEnv === 'develop';
        window.console.info('Environment:', ENV_VARS.deploymentEnv);
        window.console.info('DebugInfoEnabled: ', isDevEnvironment);
        $compileProvider.debugInfoEnabled(isDevEnvironment);
		$locationProvider.html5Mode(true);
    })

    // framework start
    .run(function run(
        $rootScope,
        $location,
        $state,
        $timeout,
        $ionicPopup,
        tqCoreConnector,
        tqPopupCriticalError,
        tqRedirector,
        tqScreenBreakpoints,
        tqAuth,
        tqBootstrap,
        tqLoading,
        $window){

        window.tqCoreConnector = tqCoreConnector;

        // kick start the app
    //    tqBootstrap.start();

        // init app wide variables
        $rootScope.offlineForced = tqCoreConnector.appstatus.getIsOfflineForced();
        $rootScope.backButtonHidden = false;
        $rootScope.showFooter = true;

        $rootScope.online = tqCoreConnector.appstatus.isOnline();
        tqCoreConnector.appstatus.connectionStatusChanged(function (isOnline) {
            $rootScope.online = isOnline;
            $rootScope.$evalAsync();
        });

        // set animation (only possible via vanilla JS)
        var animation = tqCoreConnector.config.getEnableAnimations(),
            view = document.getElementsByTagName("ion-nav-view")[0];
        if (!animation) {
            view.setAttribute('animation', 'no-animation');
        }

        // device type detection
        /*function isPhone() {
            if ($('body').width() < tqScreenBreakpoints.GRID_RESPONSIVE_SM_BREAK) {
                $rootScope.isPhone = true;
            }
            else {
                $rootScope.isPhone = false;
            }
        }*/

        //angular.element($window).resize(isPhone).trigger('resize');

        // observe the sync status in order to update UI variables
        // other services, modules can then observe these rootScoped variables to update their pages in real time
        tqCoreConnector.syncstatus.onSyncStatusChange(function (eventData) {

            $rootScope.syncStatus = eventData.syncStatus;

            // successType 'activation' means to route to the activation state
            if (eventData.successType === tqCoreConnector.sync.type.ACTIVATION) {
                // save current state in order to go back from activation to it on sync success
                // activation screen registers the onSyncStatusChange('SyncSuccess') in order to go back to preActivationState
                tqRedirector.saveCurrentState();
                // route to activation
                $location.path('/tqactivation');

            // std success or error
            }
            else {
                $rootScope.syncErrorMessage = eventData.syncErrorMessage;
                $rootScope.recordErrorCount = eventData.recordErrorCount;
                $rootScope.pendingRecordCount = eventData.pendingRecordCount;
            }

            $rootScope.$evalAsync();
        });

        // interceptor
        $rootScope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
            // call the standard redirection service
            tqRedirector.processRequset(event, toState, toParams, fromState, fromParams);
            // where to show footer
			$rootScope.showAppLayout = $rootScope.showFooter = !(toState.name == 'tqlogin' || toState.name == 'tqhome' || toState.name == 'tqactivation' || toState.name == 'register');
        });

        // logout available through all tpls
        $rootScope.logout = function () {
            tqAuth.logout();
        };

        // re-login available through all tpls
        $rootScope.refreshAuth = function () {
            tqCoreConnector.session.refreshAuth();
        };

        // available environments
        $rootScope.ENV_VARS = window.ENV_VARS;

        //Set app version inside Root Scope
        $rootScope.appVersion = window.appVersion;

        // app version used in
        $rootScope.frameworkVersion = window.frameworkVersion;

        //Specify main template needs to be included in index.html file
    //    $rootScope.rootTemplate = template;

        tqCoreConnector.logger.log('frameworkVersion: ' + $rootScope.frameworkVersion);
    })
    .controller('AcnCtrl', function AcnCtrl() {
    });

});
