define([
    'angular',
    'uiRouter',
    'coreapi',
    'components/bootstrap/bootstrap',
    'components/redirector/redirector',
    'components/auth/auth',
    'acnNg/home/home',
    'acnNg/login/login',
    'acnNg/activation/activation',
    'acnNg/feedback/feedback',
    'acnNg/chatter/chatter',
    'acnNg/objects/objects',
    'acnNg/records/records',
    'acnNg/details/details',
    'acnNg/synccenter/synccenter',
    'acnNg/edit/edit'
], function () {

    return angular.module('acnone.demo', [
        'ui.router',
        'tq.coreapi',
        'tq.bootstrap',
        'tq.auth',
        'tq.home',
        'tq.login',
        'tq.activation',
        'tq.objects',
        'tq.records',
        'tq.details',
        'tq.synccenter',
        'tq.edit',
        'tq.feedback',
        'tq.chatter',
        'tq.redirector'
    ]);
});
