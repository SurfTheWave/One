import template from './login.tpl.html';
define([
	'angular',
	//'uiRouter',
	'coreapi',
	'components/bootstrap/bootstrap'], function (angular) {

	return angular.module('tq.login', [
		//'ui.router',
		'tq.coreapi',
		'tq.bootstrap',
		'tq.analytics'])

		// module routing
		// .config(function ($stateProvider) {
		// 	// note '.' means substate
		// 	$stateProvider.state('tqlogin', {
		// //		url: '/tqlogin',
		// 		cache: false,
		// 		controller: 'TqLoginCtrl',
		// 		template: template,
		// 		data: {pageTitle: 'Login'}
		// 	});
		// })

		// .controller('TqLoginCtrl', function TqLoginController($scope, $state, $q, $location, tqCoreConnector, tqBootstrap, $ionicHistory, tqLoading) {

		// 	tqLoading.hide();

        //     $ionicHistory.nextViewOptions({
		// 		disableBack: true
		// 	});

        //     var selectedEnvironment = tqCoreConnector.session.getSelectedEnvironment();
        //     $scope.selectedOption = null;
        //     $scope.environmentOptions  = tqCoreConnector.session.getEnvironmentsList();
        //     _.each($scope.environmentOptions, function(option){
        //         if (option.environment == selectedEnvironment.environment){
        //             $scope.selectedOption = option;
        //         }
        //     });

        //     $scope.change = function(selectedOption){
        //         $scope.selectedOption = selectedOption;
        //     };

		// 	$scope.login = function () {
		// 		// login environment
        // var environmentURL = $scope.selectedOption ? $scope.selectedOption.loginURL : null;
		// 		// start core login
		// 		tqBootstrap.authenticate(environmentURL);
		// 	};
		// });
});
