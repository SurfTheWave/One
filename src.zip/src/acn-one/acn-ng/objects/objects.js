import template from './objects.tpl.html';
define([
	'angular',
	'uiRouter',
	'coreapi',
	'acnNg/showroom/showroom'], function () {

	return angular.module('tq.objects', [
		'ui.router',
		'tq.coreapi',
		'tq.showroom'])

		// module routing
		.config(function ($stateProvider) {
			// note '.' means substate
			$stateProvider.state('tqobjects', {
				url: '/tqobjects',
                cache: false,
				controller: 'TqObjectsCtrl',
				template: template,
				data: {pageTitle: 'Objects'}
			});
		})

		.controller('TqObjectsCtrl', function TqObjectsController($scope, tqCoreConnector) {
			$scope.objects = [];

			tqCoreConnector.getTrackedObjectsList().then(function (objects) {
				$scope.objects = objects;
			});
		});
});
