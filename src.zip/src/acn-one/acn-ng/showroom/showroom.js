import template from './showroom.tpl.html';
define([
	'angular',
	'uiRouter',
	'coreapi',
	'components/lazysrc/lazysrc',
	'components/list/related/related',
	'components/list/attachment/attachment'], function (angular) {

	return angular.module('tq.showroom', [
		'ui.router',
		'tq.coreapi',
		'tq.lazysrc',
		'tq.list.related',
		'tq.list.attachment'])

		// module routing
		.config(function ($stateProvider) {
			// note '.' means substate
			$stateProvider.state('tqshowroom', {
				url: '/tqshowroom',
				controller: 'TqShowroomCtrl',
				template: template,
				data: {pageTitle: 'Showroom'}
			});
		})

		// module view model
		.controller('TqShowroomCtrl', function TqShowroomController($scope, tqCoreConnector, $timeout) {
			// nav header label
			$scope.headerTitle = 'Showroom';

			/////////////////////////////////////////////////////////////
			// tq-list-related && tq-list-attachment
			// in this example we show the optional where condition together with the async loading of the parentRecordId value

			// required
			$scope.relatedObjectApiName = 'Attachment';
			// optional where condition
			$scope.relatedObjectWhere = {
				Name: {
					$eq: 'amazing.png'
				}
			};
			// async loading test
			var query = {
				objectApiName: 'Contact',
				where: {
					Id: {
						// 0032000001JsZCq => 0032000001JsZCqAAN contact record on demo org 'Nicola Lamborghini'
						$eq: '0032000001JsZCqAAN'
					}
				}
			};
			tqCoreConnector.storage.find(query)
				.then(
				function (result) {
					$scope.parentRecordId = result[0].rawRecord.Id;
				}
			);

			// // tq-list-related only
			//$scope.childFieldPrepopulationMap = {
			//    Description: 'Alessio Test'
			//};

			//
			/////////////////////////////////////////////////////////////
		});
});
