import template from './activation.tpl.html';
define(['angular',
	'uiRouter',
	//'angularRoundProgress',
	'components/bootstrap/bootstrap',
	'components/auth/auth',
	'components/popup/criticalerror/criticalerror',
    'components/translations/translations'], function (angular) {

	return angular.module('tq.activation', [
		'ui.router',
		//'angular.directives-round-progress',
		'tq.bootstrap',
		'tq.analytics',
		'tq.translations',
		'tq.auth',
		'tq.popup.criticalerror'])

		// module routing
		.config(function ($stateProvider) {
			// note '.' means substate
			$stateProvider.state('tqactivation', {
				url: '/tqactivation',
				cache: false,
				controller: 'TqActivationCtrl',
				template: template,
				data: {pageTitle: 'Activation'}
			});
		})

		.controller('TqActivationCtrl', function TqActivationController($scope,
																		$location,
																		$rootScope,
																		tqCoreConnector,
																		tqPopupCriticalError,
																		tqBootstrap,
																		$timeout,
																		$translate,
																		$ionicPopup,
																		tqRedirector,
                                                                        $ionicHistory,
																		tqAuth,
                                                                        tqLoading,
																		tqAnalytics) {
            $ionicHistory.nextViewOptions({
				disableBack: true
			});
			$scope.activating = false;
			$scope.backButtonHidden = true;

			$scope.roundProgressData = {
				label: 'Initializing',
				percentage: 0.0
			};

			// update the progression icon on download progression
			$scope.$watch('roundProgressData', function (newValue, oldValue) {
				if (newValue.percentage > 0) {
					newValue.label = newValue.percentage > 1 ? 'Processing' : (Math.ceil(newValue.percentage * 100)) + '%';
				}
			}, true);

			var activationCancelled = false;

			var popup;
			function _getPopup(){
				if (popup){
					return popup;
				} else {
					popup = $ionicPopup.show({
						title: 'Cancelled',
						template: 'You cannot use the app without full synchronisation. Please try again',
						buttons: [ {
							text: 'Logout',
							type: 'tq-popup-criticalerror-btn',
							onTap: function(){
								tqCoreConnector.sync.cancelActivation();
								activationCancelled = true;
								popup.close();
								tqLoading.show();
								return tqAuth.directLogout();
							}
						}, {
							text: 'Cancel',
							type: 'button-cancel',
							onTap: function(e) {
								return false;
							}
						}]
					});
					return popup;
				}

			}
			$scope.cancelActivation = function () {
				return _getPopup();
			};

			// user presses the activation btn
			$scope.activate = function () {

				// remove btn and show progression
				$scope.activating = true;

				// sync success
				function successCallback(result) {

					// for vanilla version go to tqObjects
					if ($rootScope.preActivationState === '/tqobjects' ||
						TQ.config.Client.defaultStartState === '/tqobjects') {
						// run the count as part of the activation so /objects will use the cache instead
					  return tqCoreConnector.getTrackedObjectsList();


			        // otherwise avoid count
					}
					else {
						// route to previousState (if we got asked to run activation) or
						return;
					}
				}

				// sync fails
				function failCallback(err) {
					// back to initial status
					$scope.activating = false;
					$scope.roundProgressData.percentage = 0;

					// critical alert + restart ONLY when is not a connection related error
					if (!tqCoreConnector.utils.connectivity.isTimeoutError(err.error) && !tqCoreConnector.utils.connectivity.isOfflineError(err.error) && !activationCancelled
					) {
						tqPopupCriticalError.show({
							title: '',
							message: $translate.instant('REPORT_IF_ISSUE_PERSISTS')
						});

					}

					else if (activationCancelled) {
						tqLoading.hide();
					}

                    $scope.$evalAsync();
				}

				// progression
				function notifyCallback(downloadProgressPercent) {
					$scope.roundProgressData.percentage = Math.ceil(downloadProgressPercent) / 100;
					if (downloadProgressPercent == 100) {
						setTimeout(function () {
							$scope.roundProgressData.percentage = 1.01;
						}, 400);
					}
				}

				function finishActivation() {
                    tqBootstrap.executePostActivationTasks(true);
				}

				// schedule an immediate sync job
				tqCoreConnector.sync.startSync()
					.then(successCallback, failCallback, notifyCallback)
					.then(finishActivation);
			};
		});
});
