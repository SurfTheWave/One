define(['angular', 'coreapi', 'angularGoogleMaps', 'lodash'], function (angular) {
	// note avoid loading google-maps api when offline (would break startup)
	// TODO reload the map as soon as we go online and we return to the page
	return angular.module('tq.map', navigator.onLine ? ['google-maps'] : [])
		.directive('tqMap', function () {
			return {
				restrict: 'E',
				scope: {
					zoom: '=',
					recordList: '=',
					pinClick: '=?',
					pinLabel: '=',
					pinLabelField: '@',
					pinLatitudeField: '@',
					pinLongitudeField: '@',
					pinIcon: '@',
					pinClass: '@',
					pinAnchor: '@',
					mapCenterLatitude: '=?',
					mapCenterLongitude: '=?'
				},
				templateUrl: 'acn-one/acn-ng/components/map/map.tpl.html',
				link: function (scope) {
					scope.$watch('recordList', function (newValue, oldValue) {
						if (newValue !== oldValue) {
							scope.displayMap();
						}
					}, true);
				},
				controller: function ($scope, $state, $timeout) {
					$scope.mapReady = false;

					// Generate and display the map
					$scope.displayMap = function () {

						// Generate one marker for each record
						$scope.markers = [];
						_.each($scope.recordList, function (record) {
							$scope.markers.push({
								id: record.rawRecord['Id'],
								coords: {
									latitude: record.rawRecord[$scope.pinLatitudeField],
									longitude: record.rawRecord[$scope.pinLongitudeField]
								},
								icon: $scope.pinIcon,
								events: {
									click: function (marker, eventName, args) {
										if ($scope.pinClick == null || $scope.pinClick) {
											$state.go('tqdetails', {
												objectapiname: args.options.objectApiName,
												recordid: args.options.recordid
											});
										}
									}
								},
								options: {
									draggable: false,
									objectApiName: record.objectApiName,
									recordid: record.rawRecord['Id']
								},
								label: $scope.pinLabel ? record.rawRecord[$scope.pinLabelField] : null
							});
						});

						// Initialize the center of the map
						if ($scope.mapCenterLatitude == null || $scope.mapCenterLongitude == null) {
							// Initialize values with London coordinates
							$scope.mapCenterLatitude = 51.50853;
							$scope.mapCenterLongitude = -0.12574;

							// set them via the service
							if (navigator.geolocation) {
								navigator.geolocation.getCurrentPosition(function (position) {
									$scope.mapCenterLatitude = position.coords.latitude;
									$scope.mapCenterLongitude = position.coords.longitude;
									$timeout(function () {
										$scope.$apply();
									});
								});

							}
						}

						// Initialize the map
						angular.extend($scope, {
							map: {
								center: {
									latitude: $scope.mapCenterLatitude,
									longitude: $scope.mapCenterLongitude
								},
								markers: $scope.markers,
								zoom: $scope.zoom
							},
							options: {scrollwheel: true}
						});

						// Display the map
						$scope.mapReady = true;
					};
				}
			};
		});
});