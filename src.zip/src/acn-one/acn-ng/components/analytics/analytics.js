define([
	'angular'
], function (angular) {
	'use strict';

	return angular.module('tq.analytics', []).config(function () {

	}).run(function () {

	}).provider('tqAnalytics', function () {

		var provider = this;
		var self = null;

		this.trackingId = '';

		this.setTrackingId = function (theTrackingId) {
			if (!angular.isString(theTrackingId)) {
				window.console.error('Invalid analytics tracking ID has been provided. Analytics will not work.');
			} else {
				provider.trackingId = theTrackingId;
			}
		};

		this.$get = function ($window, $log) {

			var TqAnalytics = function () {
			};

			/**
			 * Determines if the analytics plugin is available or not. Not being available could mean mostly two things:
			 * 1) You have issues with the plugin loading of your Cordova project
			 * 2) You are not running the application in a Cordova web view (like a desktop browser).
			 * @returns {boolean} {@code true} if the Cordova Google Analytics plugin is available, {@code false}
			 * otherwise.
			 *
			 * @private
			 */
			TqAnalytics._isAnalyticsPluginAvailable = function () {
				return angular.isObject($window.analytics);
			};

			TqAnalytics.prototype._init = function () {

				if (TqAnalytics._isAnalyticsPluginAvailable()) {

					// TODO stop pulling dependencies from the window object, create a factory that abstracts this away so
					// other modules can depend on that factory the proper angular way.
					$window.analytics.startTrackerWithId(provider.trackingId);

					$window.analytics.trackEvent('Technical', 'App-Launch', 'WebView-Load');

					self.initDebugMode();

				} else {
					$log.warn('Tracking will not work because the Cordova analytics plugin is not available. ' +
					'Ignore this if you are not running in a mobile web view.');
				}
			};

			TqAnalytics.prototype.initDebugMode = function () {
				var deploymentEnv;
				try {
					deploymentEnv = $window.ENV_VARS.deploymentEnv;
				} catch (error) {
					$log.error('Failed to retrieve the current deployment environment from $window.ENV_VARS.deploymentEnv', error);
				}
				if (deploymentEnv === 'develop') {
					$log.info('tq.analytcs - Debug mode enabled based on deployment environment:', deploymentEnv);
					$window.analytics.debugMode();
				}
			};

			var pluginAvailable = TqAnalytics._isAnalyticsPluginAvailable();

			TqAnalytics.prototype.setUserId = pluginAvailable ? $window.analytics.setUserId : angular.noop;

			TqAnalytics.prototype.trackException = pluginAvailable ? $window.analytics.trackException : angular.noop;
			TqAnalytics.prototype.trackTiming = pluginAvailable ? $window.analytics.trackTiming : angular.noop;
			TqAnalytics.prototype.trackView = pluginAvailable ? $window.analytics.trackView : angular.noop;
			TqAnalytics.prototype.trackEvent = pluginAvailable ? $window.analytics.trackEvent : angular.noop;

			TqAnalytics.prototype.addCustomDimension = pluginAvailable ? $window.analytics.addCustomDimension : angular.noop;
			TqAnalytics.prototype.addTransaction = pluginAvailable ? $window.analytics.addTransaction : angular.noop;
			TqAnalytics.prototype.addTransactionItem = pluginAvailable ? $window.analytics.addTransactionItem : angular.noop;

			if (self === null) {
				self = new TqAnalytics();
				self._init();
			}

			return self;
		};
	});
});