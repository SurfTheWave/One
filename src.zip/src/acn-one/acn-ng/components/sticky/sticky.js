define(['angular'], function (angular) {

	return angular.module('ao.ion-sticky', []).directive('acnIonSticky', function ($ionicPosition, $compile, $timeout) {

		var ACN_STICKY_CLONE = 'acn-sticky-clone';

		var createStickyClone = function (theElement) {
			var theClone = theElement.clone();
			theClone[0].className += ' ng-hide '.concat(ACN_STICKY_CLONE);
			return theClone;
		};

		var compileStickyClone = function (theClone, theScope, theScroller) {

			var scrollersDistanceFromTopInPx = $ionicPosition.position(theScroller).top + "px";

			theClone.css({
				position: 'absolute',
				top: scrollersDistanceFromTopInPx,
				left: 0,
				right: 0
			});

			theScroller.parent().append(theClone);

			// compile the clone so that anything in it is in Angular lifecycle.
			$compile(theClone)(theScope);
		};

		var linkerFn = function (theClone, $scope, $element, $attr, $ionicScroll) {

			var theScroller = angular.element($ionicScroll.element);
			var original = $element;

			var thisIsAClone = original.hasClass(ACN_STICKY_CLONE);
			if (thisIsAClone) {
				return;
			}

			compileStickyClone(theClone, $scope, theScroller);

			var hideClone = function () {
				theClone.addClass('ng-hide');
				theClone.removeClass('ng-show');
			};

			var showClone = function () {
				theClone.removeClass('ng-hide');
				theClone.addClass('ng-show');
			};

			/**
			 * If the original element is visible, hide the sticky clone, otherwise make it visible.
			 */
			var updateSticky = function () {

				var scrollersDistanceFromTop = $ionicPosition.offset(theScroller).top;
				var originalsDistanceFromTop = $ionicPosition.offset(original).top;

				var originalIsStillInViewPort = originalsDistanceFromTop - scrollersDistanceFromTop > 0;

				(originalIsStillInViewPort ? hideClone : showClone).call();
			};

			var throttledUpdateSticky = ionic.throttle(updateSticky, 150);
            var timeoutUpdateSticky = function(){
                $timeout(updateSticky, 200);
            };

			theScroller.on('scroll', throttledUpdateSticky);

            theScroller.on('scroll-resize', timeoutUpdateSticky);


            $scope.$on('$destroy', function () {

                if (theClone && angular.isFunction(theClone.remove)) {
                    theClone.remove();
                }

                theScroller.off('scroll', throttledUpdateSticky);
                theScroller.off('scroll-resize', timeoutUpdateSticky);
            });
		};

		return {
			restrict: 'A',
			require: '^$ionicScroll',
			compile: function compile($element) {

				var thisIsAClone = $element.hasClass(ACN_STICKY_CLONE);
				if (thisIsAClone) {
					return;
				}

				var clone = createStickyClone($element);

				// passing in the clone variable as a method parameter, without knowing when or where the linkerFn will
				// actually be called.
				return linkerFn.bind(null, clone);
			}
		};
	});
});