define(['angular', 'components/bootstrap/bootstrap'], function (angular) {
    return angular.module('tq.settings', ['tq.bootstrap'])

	/**
	 * Exposing the global window variable in the way AngularJS best practices suggest.
	 */
		.constant('SFDC_STATIC_RESOURCE_PATH', window.getSfdcStaticResourcePathSafe())

        .provider('$settings', function $settingsProvider() {
            var settingsMap = {
                global: {},
                theme: {},
                app: {},
                appTheme: {}
            };

            var salesforceConfig = {};

            var getAppId = function(){ return window.sfAppId; };
            var getThemeId = function(){ return window.themeId; };
            var provider = this;

            this.getAppId = getAppId;
            this.getThemeId = getThemeId;

            this.setGlobalSettings = function(settingsObject){
                angular.merge(settingsMap.global, settingsObject);
            };

            this.setAppSettings = function(settingsObject, appId){
                if (!angular.isDefined(appId)){
                    appId = getAppId();
                }

                if (!settingsMap.app[appId]){
                    settingsMap.app[appId] = {};
                }

                angular.merge(settingsMap.app[appId], settingsObject);
            };

            this.setThemeSettings = function(settingsObject, themeId){
                if (!angular.isDefined(themeId)){
                    themeId = getThemeId();
                }

                if (!settingsMap.theme[themeId]){
                    settingsMap.theme[themeId] = {};
                }

                angular.merge(settingsMap.theme[themeId], settingsObject);
            };

            this.set = function(settingsObject, themeId, appId){
                if (!angular.isDefined(appId)){
                    appId = getAppId();
                }

                if (!angular.isDefined(themeId)){
                    themeId = getThemeId();
                }

                if (!settingsMap.appTheme[appId]){
                    settingsMap.appTheme[appId] = {};
                }

                if (!settingsMap.appTheme[appId][themeId]){
                    settingsMap.appTheme[appId][themeId] = {};
                }

                angular.merge(settingsMap.appTheme[appId][themeId], settingsObject);
            };

            this.setSalesforceSettings = function(config){
                if (!config || !config.settingsApiName || !config.map){
                    return;
                }
                var stringKey = config.settingsApiName + ":" +
                     (config.appFieldApiName ? config.appFieldApiName : "") + ":" +
                     (config.themeFieldApiName ? config.themeFieldApiName : "") /*+ ":" +
                     (config.where ? config.where : "")*/;

                if (!config[stringKey]){
                    salesforceConfig[stringKey] = angular.copy(config);
                } else {
                    angular.merge(salesforceConfig[stringKey].map, config.map);
                }
            };

            this.$get = function ($q, tqCoreConnector) {
                var getAppThemeSettings = function(appId, themeId){
                    if (!settingsMap.appTheme || !settingsMap.appTheme[appId] || !settingsMap.appTheme[appId][themeId]){
                        return undefined;
                    }
                    return settingsMap.appTheme[appId][themeId];
                };

                var getSettingsInObject = function (object, keyComponents){
                    for (var index = 0; index < keyComponents.length; index++){
                        if (!!object){
                            object = object[keyComponents[index]];
                        } else {
                            return undefined;
                        }
                    }
                    return object;
                };

                //Recursively move deep inside map object to recognize which fields should be queried for custom setting
                var generateFieldsArray = function(data, fieldsArray){
                    if (angular.isString(data)){
                        var position = data.indexOf(':');
                        fieldsArray.push((position == -1) ? data : data.substring(0, position));
                    } else if (angular.isObject(data) && !angular.isDate(data)){
                        angular.forEach(data, function(value){
                            generateFieldsArray(value, fieldsArray);
                        });
                    }
                };

                var getWhereCondition = function(config){
                    var conditionsArray = [];
                    var condition;
                    if (config.appFieldApiName){
                        condition = {};
                        condition[config.appFieldApiName] = {$in : [
                            getAppId().toLowerCase(), getAppId().toUpperCase(), getAppId()
                        ]};
                        conditionsArray.push(condition);
                    }
                    if (config.themeFieldApiName){
                        condition = {};
                        condition[config.themeFieldApiName] = {$in : [
                            getThemeId().toLowerCase(), getThemeId().toUpperCase(), getThemeId()
                        ]};
                        conditionsArray.push(condition);
                    }
                    if (config.where){
                        if (angular.isFunction(config.where)){
                            conditionsArray.push(config.where(getAppId(), getThemeId()));
                        } else {
                            conditionsArray.push(config.where);
                        }
                    }
                    return (conditionsArray.length === 0) ? undefined : conditionsArray;
                };

                var setCustomSettingsToSettingsObject = function(settingsObject, settingsValues){
                    if (angular.isString(settingsObject)){
                        var components = /^([^:]*)(:(.*))?$/.exec(settingsObject);
                        var fieldName = components[1];
                        var value = settingsValues[fieldName];
                        if (components.length > 3 && angular.isString(value)){
                            if (components[3] == 'ARRAY'){
                                return value.split(',');
                            } else if (components[3] == 'JSON'){
                                return angular.fromJson(value);
                            }
                        }
                        return value;
                    }
                    if (!angular.isDate(settingsObject) && angular.isObject(settingsObject)){
                        angular.forEach(settingsObject, function(value, key){
                            settingsObject[key] = setCustomSettingsToSettingsObject(value, settingsValues);
                            if (angular.isUndefined(settingsObject[key])){
                                delete settingsObject[key];
                            }
                        });
                    }

                    return settingsObject;
                };

                var getSettingsUpdateMethod = function(config){
                    if (config.level === 'appTheme' || (config.appFieldApiName && config.themeFieldApiName)){
                        return provider.set;
                    } else if (config.level === 'app' || (config.appFieldApiName)){
                        return provider.setAppSettings;
                    } else if (config.level === 'theme' || config.themeFieldApiName) {
                        return provider.setThemeSettings;
                    } else {
                        return provider.setGlobalSettings;
                    }
                };

                return {
                    get: function(settingName, defaultValue, appId, themeId){
                        if (!angular.isDefined(appId)){
                            appId = getAppId();
                        }

                        if (!angular.isDefined(themeId)){
                            themeId = getThemeId();
                        }

                        var keyComponents = settingName.split(/\./);
                        var appThemeSettings = getAppThemeSettings(appId, themeId);

                        var settingValue = angular.copy(getSettingsInObject(settingsMap.global, keyComponents)),
                            settingLevels = [];

                        if (!!settingsMap.theme[themeId]){
                            settingLevels.push(getSettingsInObject(settingsMap.theme[themeId], keyComponents));
                        }

                        if (!!settingsMap.app[appId]){
                            settingLevels.push(getSettingsInObject(settingsMap.app[appId], keyComponents));
                        }

                        if (!!appThemeSettings){
                            settingLevels.push(getSettingsInObject(appThemeSettings, keyComponents));
                        }

                        angular.forEach(settingLevels, function(settingValueToMerge){
                            if (!angular.isUndefined(settingValueToMerge)){
                                if (angular.isObject(settingValue) && !angular.isDate(settingValue) &&
                                    angular.isObject(settingValueToMerge) && !angular.isDate(settingValueToMerge)){
                                    angular.merge(settingValue, settingValueToMerge);
                                } else {
                                    settingValue = angular.copy(settingValueToMerge);
                                }
                            }
                        });

                        if (angular.isDefined(settingValue)){
                            return settingValue;
                        } else {
                            return defaultValue;
                        }
                    },

                    loadSalesforceData: function(){
                        var deferredArray = [];

                        angular.forEach(salesforceConfig, function(config){
                            var query = {
                                objectApiName: config.settingsApiName,
                                fields: [],
                                where: getWhereCondition(config),
                                limit: 1
                            };
                            generateFieldsArray(config.map, query.fields);
                            deferredArray.push(
                                tqCoreConnector.storage.find(query).then(function(results){
                                    if (angular.isArray(results) && results.length > 0){
                                        var customSettings = results[0].rawRecord;
                                        var settingsObject = angular.copy(config.map);
                                        setCustomSettingsToSettingsObject(settingsObject, customSettings);

                                        getSettingsUpdateMethod(config).call(provider, settingsObject);
                                    }
                                })
                            );
                        });

                        return $q.all(deferredArray);
                    }
                };
            };
        })
        .config(function(tqBootstrapProvider){
            tqBootstrapProvider.addTaskOnActivationFinish(function($settings) {
                $settings.loadSalesforceData();
            });
        })
       /* .run(function ($settings, $rootScope, $timeout){
            $rootScope.$on('tqBootstrapFinished', function(){
                $settings.loadSalesforceData().finally(function(){
                    $timeout(function() {
                        $rootScope.$broadcast('tqSalesforceSettingsLoaded');
                    }, 200);
                });
            });
        })*/
        //Directive specify value from the settings specified in settings provider. If no settings is specified it uses
        //standard one inside transcluded content
        //Ex. <div tq-bind-settings="copyright.text">Copyright by NicolaTM 2015. All rights are reserved</div>
        .directive('tqBindSettings', ['$settings', function ($settings) {
            return {
                restrict: 'A',
                transclude: true,
                link: function (scope, element, attrs, controllers, transcludeFn) {
                    var defaultContent = '';
                    var dataIsCustom = false;
                    transcludeFn(scope, function(clone, scope) {
                        defaultContent = clone;
                        if (!dataIsCustom){
                            element.html(clone);
                            dataIsCustom = false;
                        }
                    });

                    //Watch changes of the directive attribute tq-lazy-src to subscribe on file load event
                    attrs.$observe('tqBindSettings', function (newKey, oldKey) {
                        if (newKey != oldKey) {
                            var dataValue = $settings.get(newKey);
                            if (angular.isDefined(dataValue)){
                                dataIsCustom = true;
                                element.html(dataValue);
                            } else {
                                if (dataIsCustom){
                                    element.html(defaultContent);
                                    dataIsCustom = false;
                                }
                            }
                        }
                    });
                }
            };
        }]);
});