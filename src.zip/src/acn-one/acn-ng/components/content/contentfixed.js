define(['angular'], function (angular) {

    return angular.module('tq.content.fixed', [])
        .directive('ionContentFixed', function () {
            return {
                restrict: 'E',
                require: '^$ionicScroll',
                transclude: true,
                link: function(scope, element, attr, $ionicScroll, transcludeFn){
                    var ionContent = angular.element($ionicScroll.element);
                    var contentToRemove = null;
                    transcludeFn(scope, function(clone, scope) {
                        contentToRemove = clone;
                        ionContent.append(clone);
                    });

                    scope.$on('$destroy', function () {
                        if (contentToRemove && angular.isFunction(contentToRemove.remove)) {
                            contentToRemove.remove();
                            contentToRemove = null;
                        }
                    });
                }
            };
        });
});