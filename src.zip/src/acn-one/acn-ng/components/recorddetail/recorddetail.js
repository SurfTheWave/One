/**
 *
 * Example usage of fieldSet property (in here each object is going to use different fieldSet

 if($scope.objectApiName === 'Account'){
        $scope.fieldSet = ['Industry', 'Mayor__c', 'Not_Existing__c'];
    }

 if($scope.objectApiName === 'Contact'){
        $scope.fieldSet = 'AccentureONEContact';
    }
 */
define(['angular', 'coreapi'], function (angular) {
	return angular.module('tq.recorddetail', [])
		.directive('tqRecorddetail', function () {
			return {
				restrict: 'E',
				templateUrl: 'acn-one/acn-ng/components/recorddetail/recorddetail.tpl.html',
				scope: {
					// record to display
					record: '=',
					/**
					 * optionally
					 * > if fieldSet is a String then load the related fieldSet from core.metadata and show these fields (where the fieldSet exists)
					 * > if fieldSet is a [] String then iterate only over these fields (where they exist in the raw record)
					 */
					fieldSet: '&?'
				},
				link: function (scope) {
					// record is loaded async by the parent page/directive. once is ready, then display the page
					scope.$watch('record', function (newValue, oldValue) {
						if (newValue !== oldValue) {
							scope.displayRecord();
						}
					}, true);
				},
				controller: function ($scope, tqCoreConnector, $ionicScrollDelegate, $timeout, $state) {
					$scope.PARENT_STORE_NOT_SYNC = -2;
					$scope.PARENT_RECORD_NOT_SYNC = -1;
					$scope.displayFieldSet = [];

					/**
					 * Create the display fieldSet based on passed fieldSet scope var
					 */
					$scope.generateDisplayFieldSet = function () {

						// prepare custom field set either from metadata (fieldSet is a string) or use the passed one as array
						var customRequestedFieldSet = null;
						if (_.isString($scope.fieldSet())) {
							customRequestedFieldSet = tqCoreConnector.metadata.getTrackedObjectFieldSet($scope.objectApiName, $scope.fieldSet());
						} else {
							customRequestedFieldSet = $scope.fieldSet();
						}

						// empty, null, not defined, passed an invalid fieldSet, fieldSet array is empty > iterate over standard displayFieldSet
						if (_.isNull($scope.fieldSet()) ||
							_.isUndefined($scope.fieldSet()) || !customRequestedFieldSet ||
							_.isEmpty($scope.fieldSet())) {

							// get directly the displayFieldSet (array) from core metadata
							$scope.displayFieldSet = tqCoreConnector.metadata.getTrackedObjectMetadata($scope.objectApiName).detailFieldSet;

							// passed a fieldSet param (already check above that they are valid) > here is an array (either custom or coming from the loaded customRequestedFieldSet)
						} else {
							_.forEach(customRequestedFieldSet, function (fieldApiName) {
								// needs to be a valid field
								if ($scope.isDisplayable(fieldApiName)) {
									$scope.displayFieldSet.push(fieldApiName);
								}
							});

							// extra check (gets here if you specify and array of fields where no one is valid for the object > use standard displayFieldSet
							if (_.isEmpty($scope.displayFieldSet)) {
								$scope.displayFieldSet = tqCoreConnector.metadata.getTrackedObjectMetadata($scope.objectApiName).detailFieldSet;
							}
						}
					};

					$scope.displayRecord = function () {
						$scope.objectApiName = $scope.record.objectApiName;
						$scope.recordLabelsMap = tqCoreConnector.metadata.getFieldApiNameLabelsMap($scope.record, $scope.objectApiName);
						$scope.parentRecordsMap = {};
						$scope.parentRecordError = false;

						// generate the display fieldSet
						$scope.generateDisplayFieldSet();

						// get data for the relationship fields
						tqCoreConnector.storage.generateParentRecordMap($scope.record).then(
							function (parentRecordMap) {
								$scope.parentRecordsMap = parentRecordMap;
								// in order to always have the reference field to show correctly the information
								$timeout(function () {
									$scope.$apply();
								});
							},
							function (err) {
								// TODO error finding any of the parent records
							}
						);
					};

					// on click of a relationship field, show parent details (where store/record exists)
					$scope.showParentDetails = function (fieldApiName) {
						var contentScroller = $ionicScrollDelegate.$getByHandle('ionContentScrollHandle');

						// if the parent store doesn't exist then show error
						if (!tqCoreConnector.storage.storeExist($scope.parentRecordsMap[fieldApiName].parentRecordObjectApiName)) {
							$scope.parentRecordError = $scope.PARENT_STORE_NOT_SYNC;
							contentScroller.scrollTop(true);
							// if the parent record doesn't exist then show error TODO use code instead of relying on label
						} else if ($scope.parentRecordsMap[fieldApiName].parentRecordName == 'Information not available') {
							$scope.parentRecordError = $scope.PARENT_RECORD_NOT_SYNC;
							contentScroller.scrollTop(true);
						} else {
							$state.go('tqdetails', {
								objectapiname: $scope.parentRecordsMap[fieldApiName].parentRecordObjectApiName,
								recordid: $scope.parentRecordsMap[fieldApiName].parentRecordId
							});
						}

						// hide msg after x secs
						$timeout(function () {
							$scope.parentRecordError = false;
						}, 3000);

					};

					$scope.isDisplayable = function (fieldApiName) {
						return tqCoreConnector.metadata.isDisplayable($scope.objectApiName, fieldApiName);
					};

					$scope.getFieldType = function (fieldApiName) {
						if (fieldApiName) {
							return tqCoreConnector.metadata.getFieldMetadata($scope.objectApiName, fieldApiName).type;
						}
					};

					$scope.openURL = function (url) {
						// append http
						url = 'https://' + url;
						// TODO abstraction to tqCoreConnector
						// browser
						if (!window.device) {
							window.open(url);
							// device (open directly in system browser)
						} else {
							window.open(url, "_system", 'location=yes');
						}
					};
				}
			};
		});
});
