define([
	'angular',
    'coreapi',
    'components/popup/criticalerror/criticalerror',
    'components/loading/loading',
    'components/bootstrap/bootstrap'
], function (angular) {
	'use strict';

	return angular.module('tq.auth', [
		'ui.router',
		'tq.coreapi',
		'tq.popup.criticalerror',
        'tq.bootstrap'

	]).service('tqAuth', function tqAuth($q,
                $log,
                $ionicLoading,
                $timeout,
                $state,
                $ionicPopup,
                tqRedirector,
                tqLoading,
                tqBootstrap,
                tqCoreConnector,
                tqPopupCriticalError) {


            var self = this;
            this.DEFAULT_POLLING_INTERVAL_MS = 500;

            /**
             * Erases the local database, and refreshes the page if there is no sync in progress.
             * In case there is a synchronisation is progress, a pop-up message will be shown to the user.
             *
             * @returns {Promise}
             */
            this.logout = function (noPopup) {

                // ask for user confirmation
                return $ionicPopup.confirm({
                    title: 'Are you sure you would like to logout?',
                    cssClass: 'tf-popup-confirm',
                    cancelType: 'button-cancel'
                }).then(function (affermative) {
                    // user confirms
                    if (affermative) {
                        // need to be online
                        if (tqCoreConnector.appstatus.isOnline()) {
                            // can't logout when syncing is in process
                            if (tqCoreConnector.syncstatus.isSyncing()) {
                                self._showSyncInProgressError();
                            } else {
                                tqLoading.show();
                                return self.directLogout();
                            }
                        } else {
                            return self._showHaveToBeOnlineMessage();
                        }
                    }
                }).then(tqLoading.hide);
            };

            /**
             * If a sync in progress, it does the right thing and waits for it to finish, instead of smashing the user's
             * face with an error pop-up that they most probably won't understand or even read at all.
             */
            this.logoutOrWaitForSync = function () {

                if (tqCoreConnector.syncstatus.isSyncing()) {
                    $ionicLoading.show();
                    $timeout(self.logoutOrWaitForSync, self.DEFAULT_POLLING_INTERVAL_MS);
                } else {
                    self.directLogout();
                }
            };

            this._showHaveToBeOnlineMessage = function () {
                return $ionicPopup.alert({
                    title: 'You have to be online in order to logout'
                });
            };

            this._showSyncInProgressError = function () {
                tqPopupCriticalError.show({
                    title: 'Logout',
                    message: 'It is not possible to logout while a sync is in process',
                    okText: 'Ok',
                    restart: false
                });
            };

            this.directLogout = function () {
                $log.info('Logging the user out now...');

                // remove the path because we don't want to restart from an old user path
                tqRedirector.clearState();
                // core logout
                return tqCoreConnector.session.logout().then(function(){
                    $location.path(tqBootstrap.getLoginPage());
                }).catch(function (err) {
                    $ionicPopup.alert({
                        title: 'Impossible to logout. Please try again'
                    });
                });
            };
        }
	);
});