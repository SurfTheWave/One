import template from './actionbuttons.tpl.html';
define(['angular', 'uiRouter', 'coreapi',
	'components/popup/photo/photo',
	'components/popup/social/social'], function (angular) {
	return angular.module('tq.chatter.actionbuttons', ['ui.router', 'tq.coreapi', 'tq.popup.social'])
		.directive('tqChatterActionButtons', function () {
			return {
				restrict: 'E',
				template: template,
				// templateUrl: function (elem, attrs) {
				// 	return attrs.templateUrl || 'acn-one/acn-ng/components/chatter/actionbuttons/actionbuttons.tpl.html';
				// },
				link: function (scope, attrs) {
					scope.actionButtons.class = attrs.iClass || "tabs-icon-left";
				},
				controller: function ($scope, tqCoreConnector, tqSocialSharePopup, $ionicPopup, $timeout) {

					$scope.actionButtons = {};
					$scope.actionButtons.comment = function () {

					};
					$scope.likeDelayed = false;

					$scope.actionButtons.toggleLike = function (record, callback) {
						if ($scope.likeDelayed) {
							return;
						}

						var isFeedItem = (record.objectApiName === 'FeedItem');
						$scope.likeDelayed = true;
						if (record.chatterData.LikedByCurrentUser) {
							tqCoreConnector.chatter.dislikeFeedEntity(record, isFeedItem).then(
								function () {
									if(!angular.isUndefined(callback)) {
										callback();
									}
								},
								function (error) {
									console.log(error);
								}
							);
						} else {
							tqCoreConnector.chatter.likeFeedEntity(record, isFeedItem).then(
								function () {
									if(!angular.isUndefined(callback)) {
										callback();
									}
								},
								function (error) {
									console.log(error);
								}
							);
						}

						$timeout(function () {
							$scope.likeDelayed = false;
						}, 800);
					};
					$scope.actionButtons.share = function (record) {
						var messageText = record.rawRecord.Body;
						var imageUrl = record.rawRecord.ContentData;
						tqSocialSharePopup.showAndShare(messageText, imageUrl).then(function () {

							},
							function (error) {

							});
					};
				}
			};
		});
});
