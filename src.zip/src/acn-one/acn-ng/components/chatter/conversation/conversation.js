define(['angular',
    'uiRouter',
    'coreapi'
], function(angular) {
    return angular.module('tq.chatter.conversation', [
        'ui.router',
        'tq.coreapi'
    ])
        .constant('TQ_CONVERSATION_PAGE_SIZE', 10)
        .constant('TQ_MAX_CONVERSATION_PAGE_SIZE', 100)
        .service('tqChatterConversationDelegate', ionic.DelegateService([
            'addItemToConversation',
            'refreshConversation',
            'bindSuccessRefresh'
        ]))
        .directive('tqChatterConversation', function($timeout) {
            return {
                restrict: 'E',
                templateUrl: 'acn-one/acn-ng/components/chatter/feed/feed.tpl.html',
                transclude: true,
                scope: {
                    conversationId: '=?',
                    delegateHandle: '@?',
                    onRefresh: '&?'
                },
                link: function link(scope, element, attrs, controller, transcludeFn) {
                    transcludeFn(scope, function(clone, scope) {
                        // transclude the html into our directive tpl
                        element.html(clone);
                    });
                },
                controller: function($rootScope, $scope, $state, $timeout, $q, tqChatterConversationDelegate, $ionicPopup,
                                     tqCoreConnector, TQ_CONVERSATION_PAGE_SIZE, TQ_MAX_CONVERSATION_PAGE_SIZE) {
                    var self = this;
                    var stopConversationObserving = null;

                    var deregisterInstance = null;
                    if (angular.isString($scope.delegateHandle) && $scope.delegateHandle !== '') {
                        deregisterInstance = tqChatterConversationDelegate._registerInstance(this, $scope.delegateHandle);
                    }

                    $scope._initList = function () {
                        $scope.messages = [];
                        $scope.messagesMap = {};
                        $scope.page = 0;
                        $scope.pagesize = TQ_CONVERSATION_PAGE_SIZE;
                        $scope.nextPageUrl = null;
                        $scope.moreDataCanBeLoaded = !!$scope.conversationId;
                        $scope.lastDeferred = null;
                    };

                    var refreshRecordWithNewValues = function(record, newValues){
                        var key;
                        for (key in newValues.rawRecord){
                            if (!_.isEqual(record.rawRecord[key], newValues.rawRecord[key])){
                                record.rawRecord[key] = newValues.rawRecord[key];
                            }
                        }

                        if (newValues.chatterData){
                            for (key in newValues.chatterData){
                                if (!_.isEqual(record.chatterData[key], newValues.chatterData[key])){
                                    record.chatterData[key] = newValues.chatterData[key];
                                }
                            }
                        }
                    };

                    var updateRecordInList = function(newRecordValues){
                        var originalRecord = $scope.messagesMap[newRecordValues.rawRecord.Id];
                        if (originalRecord){
                            refreshRecordWithNewValues(originalRecord, newRecordValues);
                        }
                    };

                    var insertRecordToList = function(newRecord, toTheTop){
                        toTheTop = !!toTheTop;

                        if (!$scope.messagesMap[newRecord.rawRecord.Id]) {
                            $scope.messagesMap[newRecord.rawRecord.Id] = newRecord;
                            if (toTheTop) {
                                $scope.messages.unshift(newRecord);
                            } else {
                                $scope.messages.push(newRecord);
                            }
                        }
                    };

                    var upsertRecordToList = function(newRecord, toTheTop){
                        if ($scope.messagesMap[newRecord.rawRecord.Id]){
                            updateRecordInList(newRecord);
                        } else {
                            insertRecordToList(newRecord, toTheTop);
                        }
                    };

                    this.addItemToConversation = function(newFeedItem){
                        insertRecordToList(newFeedItem, true);
                    };

                    var firstLoadExecution = true;
                    var latestMessageDate = null;
                    this.loadMore = $scope.loadMore = function(fullReload){
                        if ($scope.moreDataCanBeLoaded) {
                            var pageSize = $scope.pagesize;
                            if (fullReload){
                                pageSize = Math.max(
                                    Math.min($scope.messages.length, TQ_MAX_CONVERSATION_PAGE_SIZE),
                                    TQ_MAX_CONVERSATION_PAGE_SIZE
                                );
                            }

                            var conversationPage = (fullReload || !$scope.nextPageUrl) ? $scope.conversationId : $scope.nextPageUrl;
                            var currentDeferred = tqCoreConnector.chatter.getConversationPage(
                                conversationPage, pageSize, $scope.oldestMessageDate
                            );
                            $scope.lastDeferred = currentDeferred;
                            currentDeferred.then(
                                function onSuccess(responseData){
                                    if (fullReload){
                                        $scope.messages = responseData.messages;
                                    } else {
                                        var messages = responseData.messages;
                                        for (var index = 0; index < messages.length; index++){
                                            upsertRecordToList(messages[index]);
                                        }
                                        $scope.page++;

                                        if (!responseData.nextPageUrl){
                                            $scope.moreDataCanBeLoaded = false;
                                        }
                                    }
                                    $scope.nextPageUrl = responseData.nextPageUrl;
                                    if (!$scope.latestMessageDate) {
                                        $scope.latestMessageDate = responseData.latestMessageDate;
                                    }
                                    latestMessageDate = responseData.latestMessageDate;
                                    $scope.oldestMessageDate = responseData.oldestMessageDate;

                                    if (angular.isFunction($scope.onRefresh) && firstLoadExecution){
                                        $scope.onRefresh({$response: responseData});
                                    }

                                    $scope.$broadcast('scroll.infiniteScrollComplete');
                                },
                                function onError(error){
                                    console.log(error);
                                    if ($scope.lastDeferred == currentDeferred){
                                        $scope.moreDataCanBeLoaded = false;
                                        $scope.nextPageUrl = null;
                                        $scope.$broadcast('scroll.infiniteScrollComplete');
                                    }
                                }
                            ).finally(function(){
                              if ($scope.lastDeferred == currentDeferred) {
                                  if (firstLoadExecution && !stopConversationObserving && tqCoreConnector.config.isOnlineOnlyEnabled())
                                  {
                                      self.initializeObserving(latestMessageDate);
                                  }
                                  firstLoadExecution = false;
                              }
                            });
                        }
                    };

                    this.refreshWithUpdates = function(updatesData){
                        if (updatesData.messages.length >= TQ_MAX_CONVERSATION_PAGE_SIZE ||
                            (updatesData.messages.length > 0 && $scope.messages.length === 0) ||
                            updatesData.messages.length > $scope.messages.length ){
                            $scope._initList();
                            this.loadMore();
                        } else {
                            for (var index = updatesData.messages.length - 1; index >= 0; index--){
                                upsertRecordToList(updatesData.messages[index], true);
                            }
                            $scope.$evalAsync();
                        }
                        if (angular.isFunction($scope.onRefresh)){
                            $scope.onRefresh({$response: updatesData});
                        }
                    };

                    $scope._initList();


                    this.initializeObserving = function(latestMessageDate){
                        var startCallback = function(){console.log('Updating conversation');};

                        var successCallback = function(event, response){
                            self.refreshWithUpdates(response);
                        };

                        var failCallback = function(error){console.log(error);};

                        stopConversationObserving = tqCoreConnector.chatter.startConversationObserving(
                            $scope.conversationId, {when: 'every 20 seconds', latestMessageDate: latestMessageDate},
                            startCallback, successCallback, failCallback
                        );
                    };

                    this.refreshConversation = function(restartObserver){
                        $scope._initList();
                        if (restartObserver && angular.isFunction(stopConversationObserving)){
                            stopConversationObserving();
                            stopConversationObserving = null;
                        }
                        if ($scope.conversationId){
                            if (restartObserver){
                                this.initializeObserving();
                            }
                            this.loadMore();
                        }
                    };

                    $scope.shouldLoadMore = function(){
                        return !firstLoadExecution && $scope.moreDataCanBeLoaded;
                    };

                    $scope.$watch(function(){
                       return $scope.conversationId;
                    }, function(newValue, oldValue){
                        if (newValue != oldValue || newValue != $scope.conversationId){
                            $scope.conversationId = newValue;
                            self.refreshConversation(!tqCoreConnector.config.isOnlineOnlyEnabled());
                        }
                    });

                    this.refreshConversation(!tqCoreConnector.config.isOnlineOnlyEnabled());


                    $scope.$on('$destroy', function(){
                        if (angular.isFunction(stopConversationObserving)){
                            stopConversationObserving();
                        }

                        if (angular.isFunction(deregisterInstance)){
                            deregisterInstance();
                            deregisterInstance = null;
                        }
                    });
                }
            };
        });
});
