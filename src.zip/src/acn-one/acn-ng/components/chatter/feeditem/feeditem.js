import template from './feeditem.tpl.html';
define([
    'angular',
    'uiRouter',
    'coreapi',
    'components/chatter/actionbuttons/actionbuttons'
], function(angular) {
    return angular.module('tq.chatter.feedItem', [
            'ui.router',
            'tq.coreapi',
            'tq.chatter.actionbuttons'
        ])
        .directive('tqChatterFeeditem', function() {
            return {
                transclude: true,
                restrict: 'E',
                require: '^?tqChatterFeed',
                scope: {
                   record: '=',
                   deletable: '&?'
                },
                template: template,
                // templateUrl: function(attrs, elem) {
                //     return attrs.templateUrl || 'acn-one/acn-ng/components/chatter/feeditem/feeditem.tpl.html';
                // },
                link: function link(scope, elem, attrs, tqChatterFeedCtrl, transcludeFn) {
                    // transclude function needs to place the transcluded elements
                    //in the right places
                    transcludeFn(scope, function(transcludedElement) {
                        transcludedElement.each(function(index, node) {
                            switch (node.nodeName.toLowerCase()) {
                                case 'tq-chatter-action-buttons':
                                    elem.find('#actionButtonsInsert').html(node);
                                    break;
                                case 'tq-chatter-comment-list':
                                    elem.find('#commentListInsert').html(node);
                                    break;
                            }

                        });
                    });

                    scope.chatterFeedCtrl = tqChatterFeedCtrl;
                },
                controller: function($scope, $state, tqCoreConnector) {
                    $scope.deletable = angular.isUndefined($scope.deletable) ? false : !!$scope.deletable();
                    $scope.currentUserId = tqCoreConnector.user.getId();

                    $scope.textPost = function() {
                        return $scope.record.rawRecord.Type === 'TextPost';
                    };

                    $scope.deletionPossible = function(){
                        return $scope.deletable /*&& !$scope.record.chatterData.IsDeleteRescticted*/ &&
                            $scope.chatterFeedCtrl && angular.isFunction($scope.chatterFeedCtrl.deleteItem) &&
                            $scope.record.rawRecord.CreatedById === $scope.currentUserId;
                    };

                    $scope.deleteItem = function(){
                        if ($scope.chatterFeedCtrl && angular.isFunction($scope.chatterFeedCtrl.deleteItem)){
                            $scope.chatterFeedCtrl.deleteItem($scope.record);
                        }
                    };

                    $scope.chatterFormatDate = function(dateArg) {
                        var date = new Date(dateArg);
                        if (isNaN(date.getTime())){
                            return new Date().toString();
                        } else {
                            return date.toString();
                        }
                    };

                    if (_.isEmpty($scope.pictureClick)){
                        $scope.pictureClick = function(){};

                        var parentScope = $scope.$parent;
                        while (parentScope != null){
                            if (_.isFunction(parentScope.pictureClick)){
                                $scope.pictureClick = parentScope.pictureClick;
                                break;
                            }
                            parentScope = parentScope.$parent;
                        }
                    }
                }
            };
        });
});
