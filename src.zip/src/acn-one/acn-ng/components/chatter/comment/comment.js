import template from './comment.tpl.html';
define(['angular', 'uiRouter', 'coreapi'], function(angular) {
        return angular.module('tq.chatter.comment', ['ui.router', 'tq.coreapi'])
            .directive('tqChatterFeedComment', function(tqCoreConnector) {
                return {
                    transclude: true,
                    restrict: 'E',
                    require: '^?tqChatterCommentList',
                    scope: {
                        record: '=',
                        deletable: '&?'
                    },
                    template: template,
                    // templateUrl: function (attrs, elem) {
                    //     return attrs.templateUrl || 'acn-one/acn-ng/components/chatter/comment/comment.tpl.html';
                    // },
                    link: function link(scope, elem, attrs, tqCommentListController, transcludeFn) {
                        transcludeFn(scope, function (transcludedElement) {
                            transcludedElement.each(function (index, node) {
                                switch (node.nodeName.toLowerCase()) {
                                    case 'tq-chatter-action-buttons':
                                        elem.find('#actionButtonsInsert').html(node);
                                        break;
                                }
                            });
                        });
                        scope.commentListController = tqCommentListController;
                    },
                    controller: function($scope){
                        $scope.deletable = !!$scope.deletable();
                        $scope.currentUserId = tqCoreConnector.user.getId();

                        var isFeedItemOfCurrentUser = function(){
                           return $scope.commentListController &&
                               angular.isFunction($scope.commentListController.isFeedItemOwner) &&
                               $scope.commentListController.isFeedItemOwner();
                        };

                        $scope.deletionPossible = function(){
                            return $scope.deletable /*&& !$scope.record.chatterData.IsDeleteRescticted*/ &&
                                $scope.commentListController &&
                                angular.isFunction($scope.commentListController.deleteComment) &&
                                ($scope.record.rawRecord.CreatedById === $scope.currentUserId ||
                                    isFeedItemOfCurrentUser());
                        };


                        $scope.deleteComment = function(){
                            if ($scope.commentListController &&
                                angular.isFunction($scope.commentListController.deleteComment)){
                                $scope.commentListController.deleteComment($scope.record);
                            }
                        };
                    }
                };
            });
});
