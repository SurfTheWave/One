import template from './list.tpl.html';
define([
	'angular',
	'uiRouter',
	'coreapi',
	'components/list/list'
], function (angular) {

	return angular.module('tq.chatter.list', [
		'tq.list',
		'ui.router',
		'tq.coreapi'
	])

		.directive('tqChatterList', function ($timeout, $templateCache) {
			return {
				restrict: 'E',
				template: template,
				scope: {
					// required
					objectApiName: '=',
					// optionals
					delegateHandle: '@?',
					onListItemClick: '&?',
					onPullRefresh: '&?',
					pullingText: '@?',
					where: '=?',
					orderby: '=?',
					scrollHeight: '&?'
				},
				transclude: true,
				controller: 'TqListController',
				link: function (scope, elem, attrs, TqListController, transcludeFn) {
					//Change height of container to size of original list if it's less then scrollHeight
					scope.showInside = true;
					scope.showOutside = true;
					scope.fitScrollContent = function () {
						var parentContainer = elem.find('.tq-list-parent-container');
						var scrollableContent = parentContainer.find('.scroll');

						if (parentContainer.height() > scrollableContent.height()) {
							parentContainer.height(scrollableContent.height() + 10);
						}
					};
					// check that list inner content is not empty (note would be enough to read content.length)
					var isEmptyContent = function (content) {
						return content.context && content.context.wholeText &&
							content.context.wholeText.trim().length === 0 &&
							content.length <= 1;
					};

					transcludeFn(scope, function (toTransclude) {
						// finally transclude the actual list-items
						if (!isEmptyContent(toTransclude)) {
							elem.find('.tq-list-items-wrapper').html(toTransclude);
						}
					});

					// when tq-list is used inside other directives, value of where can be changing after an async load of it's parameters
					// once this happens, we need to forget the first load of tq-list and start a new one
					scope.$watch('where', function (newValue, oldValue) {
						if (newValue !== oldValue) {
							scope.refresh();
						}
					}, true);
				}
			};
		})


		.controller('TqListController', [
			'$rootScope',
			'$scope',
			'$state',
			'tqCoreConnector',
			'tqDeviceMediaPicture',
			'$timeout',
			'tqListDelegate',

			function ($rootScope, $scope, $state, tqCoreConnector, $timeout, tqListDelegate) {
				// default values for optional params
				$scope.orderby = $scope.orderby ? $scope.orderby : tqCoreConnector.metadata.getNameField($scope.objectApiName);
				$scope.onListItemClick = angular.isFunction($scope.onListItemClick) ? $scope.onListItemClick() : null;
				$scope.scrollHeight = angular.isFunction($scope.scrollHeight) ? $scope.scrollHeight() : null;
				$scope.pullingText = $scope.pullingText || 'Pull to refresh';

				var deregisterInstance = null;
				if (!_.isEmpty($scope.delegateHandle)) {
					deregisterInstance = tqListDelegate._registerInstance(this, $scope.delegateHandle);
				}

				// init generic
				$scope.objectNameField = tqCoreConnector.metadata.getNameField($scope.objectApiName);
				$scope.search = {
					keyword: ''
				};

				// init refresh
				$scope._initList = function () {
					$scope.records = [];
					$scope.page = 0;
					$scope.pagesize = 10;
					$scope.moreDataCanBeLoaded = true;
					$scope.queryDeferred = null;
				};
				$scope._initList();

				// method which prepares query for the
				function getObjectQuery(queryPage, queryPagesize) {
					var newQuery = {
						objectApiName: $scope.objectApiName
					};

					if ($scope.search.keyword) {
						var keyword = '%' + $scope.search.keyword + '%';
						var searchWhere = {
							Name: {
								'$like': keyword
							}
						};

						var whereObject;
						if ($scope.where) {
							whereObject = {
								'$and': [$scope.where, searchWhere]
							};
						} else {
							whereObject = searchWhere;
						}

						newQuery.where = whereObject;
					} else if ($scope.where) {
						newQuery.where = $scope.where;
					}

					newQuery.page = queryPage;
					newQuery.pagesize = queryPagesize;
					if ($scope.orderby) {
						newQuery.orderby = $scope.orderby;
					}

					return newQuery;
				}

				$scope.loadMore = function () {

					// only when we can load more
					if (!$scope.moreDataCanBeLoaded) {
						return;
					}

					// prepare the query
					var newQuery = getObjectQuery($scope.page, $scope.pagesize);

					// load records
					var thisDeferred = $scope.queryDeferred = tqCoreConnector.storage.find(newQuery);
					thisDeferred
						.then(
						// success
						function (records) {

							// in the case we watch 'where', once set, we call refresh() that set $scope.queryDeferred to null
							if (thisDeferred != $scope.queryDeferred) {
								return;
							}

							if (records.length > 0) {
								$scope.records = $scope.records.concat(records);
							}

							// If we have loaded number of elements less then pagesize,
							// it means that we have reached the last element, so we can stop loading
							if (records.length < $scope.pagesize) {
								$scope.moreDataCanBeLoaded = false;
							}

							$timeout(function () {
								$scope.$apply();
							});

							$scope.queryDeferred = null;
							// stop spinner
							$scope.$broadcast('scroll.infiniteScrollComplete');

							//If list contains just couple records 1-2 and scrollHeight is bigger then
							//original height of all list content the big margin will appear on UI
							//To prevent this fitScrollContent function is called
							if (!$scope.moreDataCanBeLoaded && $scope.scrollHeight) {
								$timeout(function () {
									$scope.fitScrollContent();
								}, 400);
							}
						},
						// error
						function (err) {
							$scope.moreDataCanBeLoaded = false;
							$scope.queryDeferred = null;
							// stop spinner
							$scope.$broadcast('scroll.infiniteScrollComplete');
						});

					// prepare next page load
					$scope.page++;
				};

				this.refresh = function (startLoadingManually) {
					// init the basic variables (not search)
					$scope._initList();
					if (startLoadingManually === true) {
						$scope.loadMore();
					}
					else {
						// trigger the new load
						$scope.$broadcast('scroll.infiniteScrollComplete');
					}
				};

				$scope.refresh = function () {
					this.refresh();
				};

				$scope.cancelSearch = function () {
					$scope.search.keyword = '';
					$scope.doSearch();
				};

				$scope.sort = function () {
					if ($scope.orderBy === $scope.objectNameField + ' ASC') {
						$scope.orderBy = $scope.objectNameField + ' DESC';
					} else {
						$scope.orderBy = $scope.objectNameField + ' ASC';
					}
					$scope.doSearch();
				};

				// on list item tap
				$scope.click = function (index, record) {

					// custom on click behaviour
					if ($scope.onListItemClick && _.isFunction($scope.onListItemClick)) {
						$scope.onListItemClick(record);
						// default behaviour is to route to the record detail
					} else {
						$state.go('tqdetails', {
							objectapiname: $scope.objectApiName,
							recordid: record.rawRecord.Id
						});
					}
				};

				$scope.pullRefresh = function () {
					// call passed function
					if ($scope.onPullRefresh) {
						$scope.onPullRefresh()
							.then(
							// success
							function () {
								// refresh the list
								$scope.refresh();
								$scope.$broadcast('scroll.refreshComplete');
							},
							// error
							function (err) {
								$scope.$broadcast('scroll.refreshComplete');
							}
						);
						// simply refresh list
					} else {
						$scope.refresh();
						$scope.$broadcast('scroll.refreshComplete');
					}
				};

				// note that ion-infinite-scroll directive within tpl calls the triggers the query on page opening
				$scope.$on('$destroy', function () {
					if (!_.isEmpty(deregisterInstance)) {
						deregisterInstance();
					}
				});
			}
		]);
});
