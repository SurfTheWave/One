import template from './post.tpl.html';
define(['angular', 'uiRouter', 'coreapi', 'components/popup/photo/photo', 'components/chatter/feed/feed'],
	function (angular) {
		return angular.module('tq.chatter.post', ['ui.router', 'tq.coreapi', 'tq.popup.photo', 'tq.chatter.feed'])
			.directive('tqChatterPost', function () {
				return {
					restrict: 'E',
                    require: '^tqChatterFeed',
					template: template,
					// templateUrl: function (elem, attrs) {
					// 	return attrs.templateUrl || 'acn-one/acn-ng/components/chatter/post/post.tpl.html';
					// },
					link: function (scope, $elem, attrs, tqChatterFeedCtrl) {
                        if (tqChatterFeedCtrl && angular.isFunction(tqChatterFeedCtrl.postNewItemInFeed)){
                            scope.postNewItemInFeed = function(record){
                                tqChatterFeedCtrl.postNewItemInFeed(record);
                            };
                        }
					},
					controller: function ($scope, $state, tqCoreConnector, tqPhotoPicker, $ionicPopup, $translate) {

						$scope.post = {};

						$scope.post.attachmentImageUrl = null;

						var cleanAttachmentImage = function () {
							if ($scope.post.attachmentImageUrl != null) {
								tqCoreConnector.device.file.removeFile($scope.post.attachmentImageUrl).then(function () {
									$scope.post.attachmentImageUrl = null;
								});
							}
						};

						$scope.post.removeAttachment = cleanAttachmentImage;

						$scope.post.send = function (post) {
							if (_.isEmpty(post.input) && _.isEmpty($scope.post.attachmentImageUrl)) {

								$ionicPopup.alert({
									template: $translate.instant('POST_NOT_EMPTY')
								});

								return;
							}

							return tqCoreConnector.chatter.createFeedItemForRecordFeed($scope.feedObjectId,
								post.input,
								$scope.post.attachmentImageUrl)
								.then(function (feedItem) {
									post.input = '';
									$scope.post.attachmentImageUrl = null;
                                    if (angular.isFunction($scope.postNewItemInFeed)){
                                        $scope.postNewItemInFeed(feedItem);
                                    }
								});
						};

						$scope.post.getPhoto = function () {
							if (!$scope.post.attachmentImageUrl) {
								tqPhotoPicker.show().then(function (imageUrl) {
									$scope.post.attachmentImageUrl = imageUrl;
								});
							}
						};

						$scope.$on('$destroy', function () {
							cleanAttachmentImage();
						});
					}
				};
			});
	});
