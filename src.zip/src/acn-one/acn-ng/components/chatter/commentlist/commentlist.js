define(['angular', 'uiRouter', 'coreapi', 'components/translations/translations'], function(angular) {
    return angular.module('tq.chatter.commentlist', ['ui.router', 'tq.coreapi', 'tq.translations'])
        .directive('tqChatterCommentList', function() {
            return {
                restrict: 'E',
                transclude: 'true',
                scope: {
                    feedItemId: "=?",
                    feedItem: "=?",
                    scrollDelegateHandle: '@?'
                },
                link: function link(scope, element, attrs, controller, transcludeFn) {
                    transcludeFn(scope, function(clone, scope) {
                        element.html(clone);
                    });
                },
                controller: 'TqChatterCommentsController'
            };
        })
        .controller('TqChatterCommentsController', function($scope, tqCoreConnector, $ionicScrollDelegate, $ionicPopup, $translate) {
            var _this = this;
            if ($scope.feedItemId == null && $scope.feedItem != null){
                $scope.feedItemId = $scope.feedItem.rawRecord.Id;
            }

            this.scrollDelegate = null;
            if ($scope.scrollDelegateHandle != null){
                this.scrollDelegate = $ionicScrollDelegate.$getByHandle($scope.scrollDelegateHandle);
            }

            $scope.feedComments = [];
            $scope.commentsLoading = false;
            $scope.loadingFromServer = false;
            $scope.canLoadMoreFromServer = false;
            $scope.newCommentText = '';

            var checkCanLoadMoreFromServer = function(){
                if ($scope.feedItem != null && $scope.feedItem.rawRecord.CommentCount != null && $scope.feedComments != null){
                    if ($scope.feedItem.rawRecord.CommentCount > $scope.feedComments.length) {
                        return true;
                    }
                }

                return false;
            };

            this.loadFeedCommentsList = function(){
                $scope.commentsLoading = true;
                $scope.canLoadMoreFromServer = false;
                var query = {
                    objectApiName: 'FeedComment',
                    where: {FeedItemId: {'$eq': $scope.feedItemId}},
                    orderby: 'CreatedDate ASC'
                };

                var queryPromise = tqCoreConnector.storage.find(query);
                queryPromise.then(
                   function(records){
                       $scope.feedComments = records;
                       $scope.commentsLoading = false;
                       $scope.canLoadMoreFromServer = checkCanLoadMoreFromServer();
                       //Prevent autoresizing elements to fix bug in IOS fixing zoom styling
                       //Will not be executed if default value is not changed, that's why value cannot be 100%
                       angular.element('tq-chatter-comment-list').css('zoom', '100.00001%');
                   },
                   function(error){
                       $scope.commentsLoading = false;
                       console.log(error);
                       $scope.feedComments = [];
                   }
                );
                return queryPromise;
            };

            this.loadCommentsFromServer = function(){
                if (tqCoreConnector.appstatus.isOnline()){
                    $scope.loadingFromServer = true;
                    tqCoreConnector.chatter.downloadFeedItemComments($scope.feedItemId).then(
                        function(commentResponse){
                            $scope.loadingFromServer = false;
                            if (commentResponse && _.isArray(commentResponse.commentIds) && $scope.feedItem){
                                $scope.feedItem.rawRecord.CommentCount = commentResponse.commentIds.length;
                            }

                            if (commentResponse && _.isArray(commentResponse.comments)){
                                $scope.feedComments = commentResponse.comments;
                                $scope.canLoadMoreFromServer = false;
                            } else {
                                _this.loadFeedCommentsList().then(function(){
                                    if (_this.scrollDelegate != null){
                                        _this.scrollDelegate.scrollBottom(true);
                                    }
                                });
                            }
                        },
                        function(){
                            $scope.loadingFromServer = false;
                            $ionicPopup.alert({
                                template: $translate.instant('OPERATION_FAILED')
                            });
                        }
                    );
                }
                else {
                    $ionicPopup.alert({
                        template: $translate.instant('CHATTER_REFRESH_ONLINE_ONLY')
                    });
                }
            };

            $scope.loadMoreCommentsFromServer = this.loadCommentsFromServer;


            var startCallback = function(){
                console.log('Updating tf-chatter comments');
            };

            var successCallback = function(response){
                if (_.isArray(response.commentIds) && response.commentIds.length != $scope.feedComments.length){
                    if ($scope.feedItem){
                        $scope.feedItem.rawRecord.CommentCount = response.commentIds.length;
                    }

                    if (_.isArray(response.comments)){
                        $scope.feedComments = response.comments;
                    } else {
                        _this.loadFeedCommentsList();
                    }
                }
            };
            var failCallback = function(error){
                console.log(error);
            };

            var stopFeedCommentsObserving = tqCoreConnector.chatter.startFeedCommentsObserving(
                $scope.feedItemId, {when: 'every 15 seconds'}, startCallback, successCallback, failCallback
            );

            $scope.createNewComment = function(event){
				event.stopPropagation();
                if (_.isEmpty($scope.newCommentText)){
                    $ionicPopup.alert({
                        template: $translate.instant('POST_NOT_EMPTY')
                    });
                    return;
                }

                tqCoreConnector.chatter.createTextFeedCommentForFeedItem($scope.feedItemId, $scope.newCommentText).then(
                   function (newRecord){
                       $scope.newCommentText = '';
                       if (_this.scrollDelegate != null){
                           _this.scrollDelegate.scrollBottom(true);
                       }
                       $scope.feedComments.push(newRecord);
                   },
                   function (error){
                       console.log(error);
                   }
                );
            };

            this.deleteComment = $scope.deleteComment = function(feedComment){
                $ionicPopup.confirm({
                    title: 'Are you sure you want to delete this comment?',
                    cssClass: 'tf-popup-confirm',
                    cancelType: 'button-cancel'
                }).then(function (affermative) {
                    // user confirms
                    if (affermative) {
                        tqCoreConnector.chatter.removeFeedComment(feedComment).then(function(){
                            var itemIndex = _.indexOf($scope.feedComments, feedComment);
                            if (itemIndex > 0){
                                $scope.feedComments.splice(itemIndex, 1);
                            }
                            if ($scope.feedItem){
                                $scope.feedItem.rawRecord.CommentCount--;
                            }
                            $scope.$evalAsync();
                        }, function(error){
                            console.log(error);
                        });
                    }
                });
            };

            var currentUserId = tqCoreConnector.user.getId();
            this.isFeedItemOwner = function(){
                return $scope.feedItem && $scope.feedItem.rawRecord.CreatedById == currentUserId;
            };

            this.loadFeedCommentsList();

            $scope.$on('$destroy', function(){
               if (stopFeedCommentsObserving != null){
                   stopFeedCommentsObserving();
                   stopFeedCommentsObserving = null;
               }
            });
        });
});
