define(['angular'], function (angular) {
	return angular.module('tq.chatter.followerlist', [])
		.directive('tqFollowerList', function () {
			return {
				restrict: 'E',
				transclude: 'true',
				scope: {
					feedObjectId: "=?",
					scrollDelegateHandle: '@?',
                    excludeDirector: '=?',
                    sortMethod: '@?'
				},
				link: function link(scope, element, attrs, controller, transcludeFn) {
					transcludeFn(scope, function (clone, scope) {
						element.html(clone);
					});
				},
				controller: 'TqFollowerListController'
			};
		})
		.controller('TqFollowerListController', function (tqCoreConnector, $scope, $timeout) {
			var self = this;
			$scope.followers = [];


			this.scrollDelegate = null;
			if ($scope.scrollDelegateHandle != null) {
				this.scrollDelegate = $ionicScrollDelegate.$getByHandle($scope.scrollDelegateHandle);
			}

            function followerIds(followers) {
                return followers.map(function (follower) {
                    return follower.rawRecord.SubscriberId;
                });
            }

            this.sortFollowers = function(){
                if (angular.isFunction($scope.sortMethod)){
                    $scope.sortMethod({followers: $scope.followers});
                }
            };

			this.getFollowerList = function () {
				var query = {
					objectApiName: 'EntitySubscription',
					where: {
						ParentId: {'$eq': $scope.feedObjectId}
					}
				};

				tqCoreConnector.storage.find(query)
					.then(
					function (followers) {

						if (_.isEmpty(followers)) {
							return;
						}

                        if (!!$scope.excludeDirector){
                            var travelDirectorIds = [];
                            tqCoreConnector.storage.find({
                                objectApiName: 'User',
                                where: {
                                    Id: {
                                        '$in': followerIds(followers)
                                    }
                                }
                            }).then(function (users) {
                                _.each(users.filter(function (u) {
                                    return u.rawRecord.Is_Travel_Director__c;
                                }), function (u) {
                                    travelDirectorIds.push(u.rawRecord.Id);
                                });
                            }).finally(function(){
                                $scope.followers = followers.filter(function (follower){
                                    return !_.includes(travelDirectorIds, follower.rawRecord.SubscriberId);
                                });
                                self.sortFollowers();
                            });
                        } else {
                            $scope.followers = followers;
                            self.sortFollowers();
                        }
					},
					function (error) {
						$scope.followers = [];
						console.log(error);
					}
				);
			};

            $scope.getFollowerList = function(){
                return this.getFollowerList();
            };

            $scope.getAvatarUrl = function (follower) {
				return (!_.isEmpty(follower.photoData)) ? follower.photoData.largePhotoUrl
					: follower.userData.FullPhotoUrl;
			};

			this.getFollowerList();

			//Initialize loading functionality
			var startCallback = function () {
			};

			var successCallback = function (response) {
				self.getFollowerList();
			};
			var failCallback = function (error) {
				console.log(error);
			};

			var stopObserving = null;

			this.startObserving = function () {
				stopObserving = tqCoreConnector.chatter.startFollowersObserving(
					$scope.feedObjectId, {}, startCallback, successCallback, failCallback
				);
			};

			this.stopObserving = function () {
				if (stopObserving != null) {
					stopObserving();
					stopObserving = null;
				}
			};

			this.startObserving();

			$scope.$on('$destroy', function () {
				self.stopObserving();
			});
		});
});
