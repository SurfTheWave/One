import template from './feed.tpl.html';
define(['angular',
    'uiRouter',
    'coreapi',
    'ionic'
], function(angular) {
    return angular.module('tq.chatter.feed', [
        'ui.router',
        'tq.coreapi',
        'ionic'
    ])
        .constant('TQ_CHATTER_PAGE_SIZE', 10)
        .constant('TQ_MAX_FEED_PAGE_SIZE', 100)
        .service('tqChatterFeedDelegate', ionic.DelegateService([
            'deleteItem',
            'postNewItemInFeed'
        ]))
        .directive('tqChatterFeed', function($timeout) {
            return {
                restrict: 'E',
                template: template,
                transclude: true,
                scope: {
                    feedType: '=?',
                    // when full page component, has no header and we use the main nav for post controls
                    feedObjectId: '=?',
                    delegateHandle: '@?',
                    readonly: '=?'
                },
                link: function link(scope, element, attrs, controller, transcludeFn) {
                    // Note using the function instead of the 'ng-transclude' directive gives more control
                    // in this case we need to give to the transcluded html the directive's scope instead of the parent's one
                    // the first parameter is optional (defaults to scope.$parent scope)
                    // we can anyway explicitly pass this as a first parameter of the transcludeFn (scope.$parent or scope)
                    transcludeFn(scope, function(clone, scope) {
                        // transclude the html into our directive tpl
                        element.html(clone);
                    });
                },
                controller: function($rootScope, $scope, $state, $timeout, $q, tqChatterFeedDelegate,
                                     $ionicPopup, tqCoreConnector, TQ_CHATTER_PAGE_SIZE, TQ_MAX_FEED_PAGE_SIZE) {
                    var self = this;
                    if (_.isEmpty($scope.feedType)) {
                        $scope.feedType = tqCoreConnector.chatter.FeedType.FeedTypeRecord;
                    }

                    var deregisterInstance = null;
                    if (angular.isString($scope.delegateHandle) && $scope.delegateHandle !== '') {
                        deregisterInstance = tqChatterFeedDelegate._registerInstance(this, $scope.delegateHandle);
                    }

                    $scope._initList = function () {
                        $scope.records = [];
                        $scope.recordsMap = {};
                        $scope.page = 0;
                        $scope.pagesize = TQ_CHATTER_PAGE_SIZE;
                        $scope.nextFeedPageUrl = null;
                        $scope.moreDataCanBeLoaded = true;
                        $scope.lastDeferred = null;
                    };
                    $scope._initList();

                    if (($scope.feedType == tqCoreConnector.chatter.FeedType.FeedTypeRecord ||
                        $scope.feedType == tqCoreConnector.chatter.FeedType.FeedTypeGroups) &&
                        $scope.feedObjectId) {
                        $scope.chatterWhereCondition = {'ParentId' : {'$eq' : $scope.feedObjectId}};
                    }
                    else {
                        $scope.chatterWhereCondition = undefined;
                    }

                    var refreshRecordWithNewValues = function(record, newValues){
                        var key;
                        for (key in newValues.rawRecord){
                            if (!_.isEqual(record.rawRecord[key], newValues.rawRecord[key])){
                                record.rawRecord[key] = newValues.rawRecord[key];
                            }
                        }

                        if (newValues.chatterData){
                            for (key in newValues.chatterData){
                                if (!_.isEqual(record.chatterData[key], newValues.chatterData[key]) && key != 'ContentBody'){
                                    record.chatterData[key] = newValues.chatterData[key];
                                }
                            }
                        }

                        if (newValues.comments){
                            record.comments = newValues.comments;
                        }
                    };

                    var getRecordIdInScope = function(serverId){
                        if (!!$scope.recordsMap[serverId]){
                            return serverId;
                        } else if (self.localAssignmentsMap && self.localAssignmentsMap[serverId]){
                            return self.localAssignmentsMap[serverId];
                        } else {
                            return null;
                        }
                    };

                    var updateRecordInList = function(newRecordValues){
                        var localListId = getRecordIdInScope(newRecordValues.rawRecord.Id);
                        if (localListId){
                            var originalRecord = $scope.recordsMap[localListId];
                            if (originalRecord){
                                refreshRecordWithNewValues(originalRecord, newRecordValues);
                            }
                        }
                    };

                    var insertRecordToList = function(newRecord, toTheTop){
                        toTheTop = !!toTheTop;

                        var localListId = getRecordIdInScope(newRecord.rawRecord.Id);
                        if (!localListId) {
                            $scope.recordsMap[newRecord.rawRecord.Id] = newRecord;
                            if (toTheTop) {
                                $scope.records.unshift(newRecord);
                            } else {
                                $scope.records.push(newRecord);
                            }
                        }
                    };

                    var upsertRecordToList = function(newRecord, toTheTop){
                        var localListId = getRecordIdInScope(newRecord.rawRecord.Id);
                        if (localListId && $scope.recordsMap[localListId]){
                            updateRecordInList(newRecord);
                        } else {
                            insertRecordToList(newRecord, toTheTop);
                        }
                    };

                    var removeRecordIdFromList = function(recordId){
                        var localListId = getRecordIdInScope(recordId);
                        if ($scope.recordsMap[localListId]){
                            delete $scope.recordsMap[localListId];
                            for (var index = 0; index < $scope.records.length; index++){
                                if ($scope.records[index].rawRecord.Id == localListId){
                                    $scope.records.splice(index, 1);
                                    break;
                                }
                            }
                        }
                    };

                    this.postNewItemInFeed = function(newFeedItem){
                        if (!$scope.readonly){
                            insertRecordToList(newFeedItem, true);
                        }
                    };

                    this.loadMore = $scope.loadMore = function(fullReload){
                        if ($scope.moreDataCanBeLoaded) {
                            var page = fullReload ? 0 : $scope.page;
                            var pageSize = $scope.pagesize;
                            if (fullReload){
                                pageSize = Math.max(
                                    Math.min($scope.page * $scope.pagesize, TQ_MAX_FEED_PAGE_SIZE),
                                    TQ_CHATTER_PAGE_SIZE
                                );
                            }

                            var currentDeferred = tqCoreConnector.chatter.getChatterFeedPage(
                                $scope.feedType, $scope.feedObjectId, page, pageSize,
                                (fullReload ? null : $scope.nextFeedPageUrl)
                            );
                            $scope.lastDeferred = currentDeferred;
                            currentDeferred.then(
                                function onSuccess(responseData){
                                    if ($scope.lastDeferred != currentDeferred){
                                        return;
                                    }
                                    if (fullReload){
                                        $scope.records = responseData.records;
                                        $scope.page = responseData.records.length / TQ_CHATTER_PAGE_SIZE;
                                    } else {
                                        var records = responseData.records;
                                        angular.forEach(records, function(record){
                                            upsertRecordToList(record);
                                        });
                                        $scope.page++;

                                        $scope.nextFeedPageUrl = responseData.nextPageUrl;
                                        if (!$scope.nextFeedPageUrl){
                                            $scope.moreDataCanBeLoaded = false;
                                        }
                                    }

                                    $scope.$broadcast('scroll.infiniteScrollComplete');
                                },
                                function onError(error){
                                    console.log(error);
                                    if ($scope.lastDeferred == currentDeferred){
                                        $scope.moreDataCanBeLoaded = false;
                                        $scope.nextFeedPageUrl = null;
                                        $scope.$broadcast('scroll.infiniteScrollComplete');
                                    }
                                }
                            ).finally(function(){
                                $scope.firstLoading = false;
                            });
                        }
                    };

                    $scope.shouldLoadMore = function(){
                        return $scope.moreDataCanBeLoaded && !$scope.firstLoading;
                    };

                    this.refreshWithUpdates = function(updatesData){
                        //Specify created elements to upsert
                        if (!angular.isArray(updatesData.created)){
                            updatesData.created = [];
                        }
                        var upsertElementIds = updatesData.created;
                        //Specify updated elements in list to update
                        if (angular.isArray(updatesData.updated)){
                            upsertElementIds = _.union(upsertElementIds, updatesData.updated);
                        }
                        var allIds = upsertElementIds;
                        if (angular.isArray(updatesData.deleted)){
                            allIds = _.union(allIds, updatesData.deleted);
                        }

                        if (upsertElementIds.length >= TQ_MAX_FEED_PAGE_SIZE ||
                            (upsertElementIds.length > 0 && $scope.records.length === 0) ||
                            upsertElementIds.length > $scope.records.length){
                            //TODO make proper refresh in case when too much data in list has been updated
                            $scope._initList();
                            return this.loadMore();
                        } else {
                            self.localAssignmentsMap = tqCoreConnector.sync.getLocalIdsForServerIds(allIds);

                            if (angular.isArray(updatesData.deleted)){
                                angular.forEach(updatesData.deleted, function(deletedId){
                                    removeRecordIdFromList(updatesData.deleted[indx]);
                                });
                            }

                            tqCoreConnector.chatter.getFeedItemsByIds(upsertElementIds).then(
                                function onSuccess(feedItems){
                                    for (var index = 0; index < feedItems.length; index++){
                                        if (_.includes(updatesData.created, feedItems[index].rawRecord.Id)){
                                            upsertRecordToList(feedItems[index], true);
                                        } else {
                                            updateRecordInList(feedItems[index]);
                                        }
                                    }
                                },
                                function onError(error){
                                    console.log('Error fetching items for chatter feed');
                                    console.log(error);
                                }
                            ).finally(function(){
                                self.localAssignmentsMap = null;
                            });
                        }
                    };

                    var startCallback = function(){console.log('Updating tf-chatter');};

                    var isNotEmptyResponse = function(response){
                        return !_.isEmpty(response) && (!_.isEmpty(response.created) || !_.isEmpty(response.deleted) ||
                            !_.isEmpty(response.updated) /*|| !_.isEmpty(response.uploaded)*/);
                    };

                    var successCallback = function(event, response){
                        if (isNotEmptyResponse(response)) {
                            self.refreshWithUpdates(response);
                        }
                    };

                    var failCallback = function(error){console.log(error);};

                    var stopFeedObserving = tqCoreConnector.chatter.startFeedObserving(
                        $scope.feedType, $scope.feedObjectId, {when: 'every 20 seconds'},
                        startCallback, successCallback, failCallback
                    );

                    this.deleteItem = $scope.deleteItem = function(feedItem){
                        $ionicPopup.confirm({
                            title: 'Are you sure you want to delete chatter post?',
                            cssClass: 'tf-popup-confirm',
                            cancelType: 'button-cancel'
                        }).then(function (affermative) {
                            // user confirms
                            if (affermative) {
                                tqCoreConnector.chatter.removeFeedItem(feedItem).then(function(){
                                    removeRecordIdFromList(feedItem.rawRecord.Id);
                                }, function(error){
                                    console.log(error);
                                });
                            }
                        });
                    };

                    $scope.firstLoading = true;
                    this.loadMore();

                    $scope.$on('$destroy', function(){
                        if (angular.isFunction(stopFeedObserving)){
                            stopFeedObserving();
                            stopFeedObserving = null;
                        }

                        if (angular.isFunction(deregisterInstance)){
                            deregisterInstance();
                            deregisterInstance = null;
                        }
                    });
                }
            };
        });
});
