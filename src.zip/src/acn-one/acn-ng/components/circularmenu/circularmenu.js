import template from './circularmenu.tpl.html';
define([
	'angular',
	'components/navigation/navigation'], function (angular) {

	angular.module('tq.circularmenu', ['tq.navigation'])
		// Runs during compile
		.directive('tqCircularMenu', function (tqNavigation, goTo, $log, $document) {
			return {
				restrict: 'A',
				template: template,
				scope: {
					onItemClicked: '=',
					onInactiveBtnClicked: '=',
					onFilterActiveNavItemsMapping: '='
				},
				controller: function($scope){
					var centralAngle;
					$scope.cm = {};
					$scope.cm.goSomewhere = function (link) {
						$scope.toggleNav();
						if (angular.isFunction($scope.onItemClicked)) {
							try {
								$scope.onItemClicked(link);
							} catch (error) {
								$log.error('tqCircularMenu.onItemClicked handler threw this: ', error);
							}
						}

						if (link.stateChange) {
							goTo.state(link.state.name, link.state.params);
						} else {
							goTo.section(link.anchor, true, tqNavigation.getActiveNavItemsMapping().scrollHandle);
						}
					};

					$scope.cm.onInactiveBtnClicked = function () {

						if ($scope.links.length > 0) {
							return; // it's not really inactive if it has more links than zero right?

						} else if (angular.isFunction($scope.onItemClicked)) {
							try {
								$scope.onInactiveBtnClicked();
							} catch (error) {
								$log.error('tqCircularMenu.onInactiveBtnClicked handler threw this: ', error);
							}
						}
					};

					// once we have the new value of the links we calculate their sizes


					// a items
					function setATagStyle(){
						if (centralAngle) {
							var unRotate = -(90 - (centralAngle / 2));
							var skew = -(90 - centralAngle);
							var transformVal = 'skew(' + skew + 'deg) rotate(' + unRotate + 'deg)  scale(1)'.toString();
							$scope.aTagStyle = {transform: transformVal};
						}
					}

					$scope.liTagStyle = function (index) {
						if (centralAngle) {
							var rotateValue = centralAngle * index;
							var skewValue = 90 - (centralAngle);
							var transformVal = 'rotate(' + rotateValue + 'deg) skew(' + skewValue + 'deg)'.toString();
							return {transform: transformVal};
						}
						$scope.$apply();
					};


					$scope.cm = {};
					$scope.cm.goSomewhere = function (link) {
							if (angular.isFunction($scope.onItemClicked)) {
							try {
								$scope.onItemClicked(link);
							} catch (error) {
								$log.error('tqCircularMenu.onItemClicked handler threw this: ', error);
							}
						}
						if (link.stateChange) {
							if (typeof link.state === 'string') {
								goTo.state(link.state);
							} else {
								goTo.state(link.state.name, link.state.params);
							}
						}
						else {
							goTo.section(link.anchor, true, tqNavigation.getActiveNavItemsMapping().scrollHandle);
						}
					};

					$scope.cm.onInactiveBtnClicked = function () {

						if ($scope.links.length > 0) {
							return; // it's not really inactive if it has more links than zero right?

						}
						else if (angular.isFunction($scope.onItemClicked)) {
							try {
								$scope.onInactiveBtnClicked();
							} catch (error) {
								$log.error('tqCircularMenu.onInactiveBtnClicked handler threw this: ', error);
							}
						}
					};


					// note you can only watch strings that define variables defined in scope. so return as a function what needs to be watched
					$scope.$watch(function () {
							return tqNavigation.activeNavItems;
						}, function (nv, ov) {
							if (!angular.equals(nv, ov)) {
								// get items from the navigation menu service
								var availableItems = tqNavigation.getActiveNavItemsMapping().items;
								// filter based on selected trip being current|future|past trip
								var filteredItems = angular.isFunction($scope.onFilterActiveNavItemsMapping) ? $scope.onFilterActiveNavItemsMapping(availableItems) : availableItems;
								// finally set the items on the menu
								$scope.links = [];
								$scope.links = filteredItems;
								centralAngle = 180 / $scope.links.length;
								setATagStyle();

								// init the btn status (active or inactive depending on # of links)
								if ($scope.links.length > 0) {
									$scope.activeNav = 'active-nav';
								}
								else {
									$scope.activeNav = 'inactive-nav';
								}
							}
						}
					);

					$scope.toggleNav = function (event) {
						event.stopPropagation();
						if ($scope.activeNav === 'active-nav') {
							if (!$scope.navOpenClass) {
								$scope.navOpenClass = true;
								$('ion-nav-bar').css({pointerEvents: 'none'});
							}
							else {
								$scope.navOpenClass = false;
								$('ion-nav-bar').css({pointerEvents: 'initial'});

							}
						}
						$scope.$evalAsync();
					};

					$document.on('click', function (event) {
						if ($scope.navOpenClass) {
							$scope.toggleNav(event);
						}
						$scope.$evalAsync();
					});

				},
				link: function ($scope, elem) {
					elem.addClass('tq-circular-menu');

				}
			};
		})
	;
})
;
