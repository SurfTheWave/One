define(['angular',
    'uiRouter',
    'signaturePad',
    'ionic'], function (angular) {
    return angular.module('tq.signature', ['ionic', 'ui.router'])
        .service('tqSignatureDelegate', ionic.DelegateService([
            'getDataURL',
            'getBase64Data',
            'clear'
        ]))

        .directive('tqSignaturePad', function (tqSignatureDelegate) {
            return {
                restrict: 'E',
                scope: {
                    delegateHandle: '@?'
                },
                link: function (scope, element, attrs) {
                    var canvas = document.createElement('canvas');
                    var canvasElement = angular.element(canvas);
                    element.empty().append(canvasElement);
                    scope.signaturePad = new SignaturePad(canvas);

                    var deregisterInstance = null;
                    if (!_.isEmpty(scope.delegateHandle)) {
                        deregisterInstance = tqSignatureDelegate._registerInstance({
                                getDataURL: function(){
                                    return scope.signaturePad.toDataURL();
                                },
                                getBase64Data: function(){
                                    return scope.signaturePad.toDataURL().replace('data:image/png;base64,', '');
                                },
                                clear: function(){
                                    scope.signaturePad.clear();
                                }
                            },
                            scope.delegateHandle);
                    }

                    scope.$on('$destroy', function(){
                        if (angular.isFunction(deregisterInstance)){
                            deregisterInstance();
                        }
                    });
                }
            };
        });
});