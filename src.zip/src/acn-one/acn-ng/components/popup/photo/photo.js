define(['angular', 'coreapi', 'components/translations/translations'], function (angular) {

	return angular.module('tq.popup.photo', ['ionic', 'tq.coreapi', 'tq.translations'])
		.service('tqPhotoPicker', function (tqCoreConnector, $ionicPopup, $q, $translate) {

			/**
			 * Show an alert popup and then restart app on user ok btn
			 *
			 */
			this.show = function () {
				var pickDefer = $q.defer();

				if (!tqCoreConnector.device.platform.isDevice()) {
					$q.when($ionicPopup.alert({
						template: $translate.instant('OPERATION_FAILED')
					}))['finally'](function () {
						pickDefer.reject();
					});
				} else {

					var SOURCE_PICK = tqCoreConnector.device.media.picture.PICK_PICTURE;
					var SOURCE_TAKE = tqCoreConnector.device.media.picture.TAKE_PICTURE;

					var getPicture = function (source) {
						return function (event) {
							tqCoreConnector.device.media.picture.getPicture(source)
								.then(function (sourceUrl) {
									pickDefer.resolve(sourceUrl);
								}, function (error) {
									pickDefer.reject(error);
								});
						};
					};

					// alert user
					$ionicPopup.show({
						cssClass: 'tq-photo-popup',
						// String. The title of the popup.
						buttons: [
							{
								text: 'Take a Photo',
								type: 'button-positive',
								onTap: getPicture(SOURCE_TAKE)
							},
							{
								text: 'Choose from Library',
								type: 'button-positive',
								onTap: getPicture(SOURCE_PICK)
							},
							{
								text: 'Cancel',
								type: 'button-cancel',
								onTap: function () {
									pickDefer.reject();
								}
							}
						]
					})['catch'](function (error) {
						pickDefer.reject(error);
					});
				}


				return pickDefer.promise;
			};
		});
});