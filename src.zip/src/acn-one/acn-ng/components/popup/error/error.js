define(['angular', 'coreapi'], function (angular) {

    return angular.module('tq.popup.error', ['ionic', 'tq.coreapi'])
        .service('tqErrorListPopup', function ($ionicPopup, $rootScope, tqCoreConnector) {

            /**
             * Show an alert popup with a list of errors
             *
             * @param {Array} Array of errors
             * @param {Object} [config] Custom ionic popup configuration
             * @param {Object} [scopeData] Additional scope data to put inside template
             */
            this.show = function (errorList, config, scopeData) {
                // default
                if (angular.isString(errorList)){
                    errorList = [errorList];
                }

                var scope = $rootScope.$new();
                scope.errorList = errorList;
                if (angular.isObject(scopeData)){
                    angular.merge(scope, scopeData);
                }
                var popupConfig = {
                    title: 'Operation failed',
                    cssClass: 'tq-error-popup',
                    subTitle: 'Operation hasn\'t been completed successfully because of next errors: ',
                    templateUrl: 'acn-one/acn-ng/components/popup/error/error.tpl.html',
                    scope: scope,
                    buttons: [{
                        text: 'OK',
                        type: 'button-positive'
                    }]
                };
                if (angular.isObject(config)){
                    angular.merge(popupConfig, config);
                }
                // alert user
                return $ionicPopup.alert(popupConfig);
            };

            /**
             * Show an alert popup with a list of errors presented in response
             *
             * @param {Object} [uploadResponse] Response of uploading to server
             * @param {Object} [config] Custom ionic popup configuration
             * @param {Object} [scopeData] Additional scope data to put inside template
             */
            this.showResponseErrors = function (uploadResponse, config, scopeData) {
                errorList = tqCoreConnector.utils.getResponseErrorList(uploadResponse);
                return this.show(errorList, config, scopeData);
            };
        });
});