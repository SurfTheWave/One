define(['angular', 'coreapi'], function (angular) {

	return angular.module('acn.popup', ['ionic']).service('acnPopup', function AcnPopupFactory($q, $timeout, $ionicPopup, tqCoreConnector) {

		var self = this;

		this._dialogConfigStack = [];
		this._dialogDeferredStack = [];
		this._currentAlertConfig = null;

		this.TYPE = {};
		this.TYPE.CONFIRM = 'confirm';
		this.TYPE.PROMPT = 'prompt';
		this.TYPE.ALERT = 'alert';

		this.thereAreOpenAlerts = function () {
			return self._dialogDeferredStack.length > 0;
		};

		this.thereArePendingAlerts = function () {
			return self._dialogConfigStack.length > 0;
		};

		this._isEqualCurrentAlertConfig = function (theAlertConfigToCheck) {
			var equalityFields = ['title', 'subTitle', 'template', 'templateUrl', 'okText', 'okType', 'cssClass'];
			var currentConfig = _.pick(self._currentAlertConfig, equalityFields);
			var nextCandidateConfig = _.pick(theAlertConfigToCheck, equalityFields);
			return _.isEqual(currentConfig, nextCandidateConfig);
		};

		/**
		 * Calls $ionicPopup.alert() in order to perform it's task. The added feature is that this method can be called
		 * multiple times while another pop-up is still active in the DOM, and it won't cause any of them to break (which
		 * it does in ionic as of 1.1, the current latest version).
		 * <p>
		 *     This method also does some filtering by default, which means that if you submit the exact same  dialog
		 *     configuration twice, it will only show it once. To disable this feature, pass in the
		 *     {@code allowDuplicates: true} parameter in the {@code config} object parameter.
		 * </p>
		 * @param config The details of the dialog or pop-up that will get shown.
		 *
		 * @returns {*} A promise that resolves when the pop-up has been concluded which means closed/dismissed by any
		 * user action, be that positive or negative.
		 */
		this.show = function (config) {

			var deferredDialogConclusion = $q.defer();

			// default
			config.title = config.title ? config.title : '';
			config.okText = config.okText ? config.okText : 'OK';

			var alertConfig = {
				// Possible values can be seen in {@code this.TYPES}, all are mapped to the similarly named $ionicPopup
				// methods.
				type: config.type,
				// String. The title of the popup.
				title: config.title,
				// String (optional). The sub-title of the popup.
				subTitle: config.subTitle,
				// String (optional). The html template to place in the popup body.
				template: config.template,
				// String (optional). The URL of an html template to place in the popup   body.
				templateUrl: config.templateUrl,
				// String (default: 'OK'). The text of the OK button.
				okText: config.okText,
				// String (default: null) The text of the cancel button.
				cancelText: config.cancelText,
				// String (default: 'button-positive'). The type of the OK button.
				okType: config.okType,
				// scope for the templateUrl / template
				scope: config.scope,
				// global class for the popup container
				cssClass: config.cssClass
			};

            for (var key in config) {
                if (alertConfig[key] === undefined) {
                    alertConfig[key] = config[key];
                }
            }

			var onPopupConcluded = function (userHasConfirmed) {

				if (userHasConfirmed) {

					if (angular.isFunction(config.onUserConfirmed)) {
						try {
							config.onUserConfirmed();
						} catch (anException) {
							tqCoreConnector.logger.error(anException);
						}
					}
				} else {

					if (angular.isFunction(config.onUserCancelled)) {
						try {
							config.onUserCancelled();
						} catch (anException) {
							tqCoreConnector.logger.error(anException);
						}
					}
				}

				if (self.thereArePendingAlerts()) {
					var alertConfigThatWasPending = self._dialogConfigStack.pop();
					self._currentAlertConfig = alertConfigThatWasPending;
					self._showByType(alertConfigThatWasPending).then(alertConfigThatWasPending.onPopupConcluded);
				} else {
					self._currentAlertConfig = null;
				}

				self._dialogConfigStack.splice(self._dialogConfigStack.indexOf(alertConfig), 1);
				self._dialogDeferredStack.splice(self._dialogDeferredStack.indexOf(deferredDialogConclusion), 1);
				deferredDialogConclusion.resolve(userHasConfirmed);
			};

			alertConfig.onPopupConcluded = onPopupConcluded;
			alertConfig.deferredDialogConclusion = deferredDialogConclusion;

			if (!self.thereAreOpenAlerts()) {
				self._currentAlertConfig = alertConfig;
				self._showByType(alertConfig).then(onPopupConcluded);
			} else {
				if (config.allowDuplicates === true) {
					self._dialogConfigStack.push(alertConfig);
				} else if (!self._isEqualCurrentAlertConfig(alertConfig)) {
					self._dialogConfigStack.push(alertConfig);
				}
			}

			return deferredDialogConclusion.promise;
		};

		this._showByType = function (theDialogconfig) {

			self._dialogDeferredStack.push(theDialogconfig.deferredDialogConclusion);

			if (theDialogconfig.type === self.TYPE.CONFIRM) {
				return $ionicPopup.confirm(theDialogconfig);
			} else if (theDialogconfig.type === self.TYPE.PROMPT) {
				return $ionicPopup.prompt(theDialogconfig);
			} else {
				return $ionicPopup.alert(theDialogconfig);
			}
		};
	});
});