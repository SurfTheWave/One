define(['angular',
	'coreapi'], function (angular) {

	return angular.module('tq.popup.social', ['ionic', 'tq.coreapi', 'tq.translations'])
		.service('tqSocialSharePopup', function (tqCoreConnector, $ionicPopup, $q, $translate) {
			this.ErrorCode = {
				NOT_MOBILE_DEVICE: 'NotMobileDevice',
				OFFLINE: 'Offline',
				POPUP_ERROR: 'PopupError',
				NO_IMAGE: 'NoImage',
				CANCELED: 'Canceled'
			};

			this.getExternalButtons = function (messageText, imageUrl, link) {
				return [];
			};

			this.shouldDisplayPopup = function () {
				if (!tqCoreConnector.device.platform.isDevice()) {
					this.deferError.displayMessage = 'You need to work on device to share your data';
					this.deferError.errCode = this.ErrorCode.NOT_MOBILE_DEVICE;
					this.pickDefer.reject(this.deferError);
					return false;
				} else if (!tqCoreConnector.appstatus.isOnline()) {
					this.deferError.displayMessage = 'You you need be online to share your data in social networks';
					this.deferError.errCode = this.ErrorCode.OFFLINE;
					this.pickDefer.reject(this.deferError);
					return false;
				}
				return true;
			};

			/**
			 * Show an alert popup and then restart app on user ok btn
			 *
			 */
			this.showAndShare = function (messageText, imageUrl, link) {
				var _this = this;
				var pickDefer = $q.defer();
				var deferError = {};
				deferError.displayMessage = null;

				this.pickDefer = pickDefer;
				this.deferError = deferError;

				if (this.shouldDisplayPopup()) {
					var imagePresent = !_.isEmpty(imageUrl);
					var socialShareMethod = function (shareType) {
						return function () {
							if (!tqCoreConnector.appstatus.isOnline()) {
								_this.deferError.displayMessage = 'You you need be online to share your data' +
								' in social networks';
								_this.deferError.errCode = _this.ErrorCode.OFFLINE;
								_this.pickDefer.reject(_this.deferError);
								return;
							}
							if (imageUrl == null && (shareType == tqCoreConnector.device.share.ShareType.Instagram ||
								shareType == (tqCoreConnector.device.share.ShareType.Pinterest))) {
								_this.deferError.displayMessage = 'You can share only data with image to ' + shareType;
								_this.deferError.errCode = _this.ErrorCode.OFFLINE;
								_this.pickDefer.reject(_this.deferError);
								return;
							}

							tqCoreConnector.device.share.shareVia(shareType, messageText, imageUrl, link).then(
								function (shouldShowAlert) {
									if (shouldShowAlert) {
										$ionicPopup.alert({
											template: $translate.instant('CHATTER_SHARE_SUCCESSFUL')
										}).finally(function () {
											pickDefer.resolve();
										});
									}
								},
								function (error) {
									if (_.isString(error)) {
										deferError.displayMessage = error;
									}
									else {
										deferError.displayMessage = 'Operation has failed';
									}
									deferError.details = error;
									pickDefer.reject(deferError);
								});
						};
					};

					var getButtons = function () {
						var buttons = [
							{
								text: 'Facebook',
								type: 'button-facebook',
								onTap: socialShareMethod(tqCoreConnector.device.share.ShareType.Facebook)
							},
							{
								text: 'Twitter',
								type: 'button-twitter',
								onTap: socialShareMethod(tqCoreConnector.device.share.ShareType.Twitter)
							},
							{
								text: 'Instagram',
								type: imagePresent ? 'button-instagram' : 'button-instagram-disabled',
								onTap: socialShareMethod(tqCoreConnector.device.share.ShareType.Instagram)
							},
							{
								text: 'Pinterest',
								type: imagePresent ? 'button-pinterest' : 'button-pinterest-disabled',
								onTap: socialShareMethod(tqCoreConnector.device.share.ShareType.Pinterest)
							},

						];

						if (!tqCoreConnector.device.platform.isIOS()) {
							buttons.push({
								text: 'Google+',
								type: 'button-google',
								onTap: socialShareMethod(tqCoreConnector.device.share.ShareType.GooglePlus)
							});
						}

						var externalButtons = _this.getExternalButtons(messageText, imageUrl, link);

						if (!_.isEmpty(externalButtons)) {
							for (var index = 0; index < externalButtons.length; index++) {
								buttons.push(externalButtons[index]);
							}
						}

						buttons.push({
							text: 'Cancel',
							type: 'button-cancel',
							onTap: function () {
								deferError.errCode = _this.ErrorCode.CANCELED;
								pickDefer.reject(deferError);
							}
						});
						return buttons;
					};

					var cssClass = tqCoreConnector.appstatus.isOnline() ? 'tq-social-popup' :
						'tq-social-popup tq-social-popup-offline';
					// alert user
					$ionicPopup.show({
						cssClass: cssClass,
						title: 'Share via',
						// String. The title of the popup.
						buttons: getButtons()
					}).catch(function (error) {
						deferError.errCode = _this.ErrorCode.POPUP_ERROR;
						deferError.details = error;
						pickDefer.reject(deferError);
					});
				}

				var deferPromise = pickDefer.promise;
				deferPromise.catch(function (error) {
					if (error.displayMessage != null) {
						$ionicPopup.alert({
							template: error.displayMessage
						});
					}
				}).finally(function () {
					_this.pickDefer = null;
					_this.deferError = null;
				});

				return deferPromise;
			};
		});
});