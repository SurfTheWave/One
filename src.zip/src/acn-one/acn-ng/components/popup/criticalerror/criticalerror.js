define(['angular',
	'coreapi'], function (angular) {

	return angular.module('tq.popup.criticalerror', ['ionic', 'tq.coreapi'])
		.service('tqPopupCriticalError', function (tqCoreConnector, $ionicPopup) {

			/**
			 * Show an alert popup and then restart app on user ok btn
			 *
			 * @param {String} message
			 * @param {String} [title]
			 */
			this.show = function (config) {
				// default
				config.title = config.title ? config.title : 'Critical Error';
				config.okText = config.okText ? config.okText : 'Restart';
				config.restart = angular.isDefined(config.restart) ? config.restart : true;
				config.customAction = angular.isDefined(config.customAction) ? config.customAction : false;
				// alert user
				return $ionicPopup.alert({
					// String. The title of the popup.
					title: config.title,
					// String (optional). The sub-title of the popup.
					subTitle: null,
					// String (optional). The html template to place in the popup body.
					template: config.message,
					// String (optional). The URL of an html template to place in the popup   body.
					// templateUrl: '',
					// String (default: 'OK'). The text of the OK button.
					okText: config.okText,
					// String (default: 'button-positive'). The type of the OK button.
					okType: 'tq-popup-criticalerror-btn'

				}).then(
					// on ok restart the device
					function (userHasConfirmed) {
						if (userHasConfirmed) {
							if (config.restart) {
								tqCoreConnector.device.platform.restart();
							}
							if (config.customAction) {
								config.customAction();
							}
							return userHasConfirmed;
						} else {
							//close the modal
							return userHasConfirmed;
						}

					});
			};
		});
});