define(['angular'], function (angular) {

	var theStaticResourcePath = window.getSfdcStaticResourcePathSafe();
	console.info('ao-sf-src Directive - will use Salesforce Static Resource Path: ', theStaticResourcePath);

	return angular.module('ao.sf-src', [])

		.directive('aoSfSrc', function () {
			return {
				restrict: 'A',
				link: function (scope, element, attr) {
					var expandedSrcValue = theStaticResourcePath.concat(attr.aoSfSrc);
					element.attr('src', expandedSrcValue);
				}
			};
		});
});