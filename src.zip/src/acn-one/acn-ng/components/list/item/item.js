import template from './item.tpl.html';
define(['angular', 'coreapi'], function (angular) {
	return angular.module('tq.list.item', ['tq.coreapi'])
		.directive('tqListItem', function () {
			return {
				restrict: 'E',
				scope: {
					index: '=',
					// new functionality, pass record (record now it's unfortunately a rawRecord in parent scopes) and objectApiName to the list <tq-list-item>
					record: '=?',
					objectApiName: '&?',
					// for simple lists (picklist and multipick) pass a simple label instead of a record
					label: '=?',

					icon: '=',
					swipeOptions: '=',
					click: '&',
					swipe: '&'
				},
				template: template,
				controller: function ($scope, tqCoreConnector) {

					////////////////////////////////////////////////////////////
					// TODO put in service (used by sort.js and item.js)
					//
					// api names
					$scope.listHeaderFieldSet = tqCoreConnector.metadata.getTrackedObjectHeaderFieldSet($scope.objectApiName());

					// custom setting listHeaderFieldSet empty
					if (_.isEmpty($scope.listHeaderFieldSet)) {
						// then use the name field
						$scope.listHeaderFieldSet.push(tqCoreConnector.metadata.getNameField($scope.objectApiName()));
						// use custom setting listHeaderFieldSet
					} else {
						// 2 cols on phone and 5 on tablet TODO not hardcoded
						$scope.deviceType = 'tablet';
						if ($scope.deviceType === 'browser') {
							$scope.nCols = 10; // col10
						} else if ($scope.deviceType === 'tablet') {
							$scope.nCols = 5; // col20
						} else {
							$scope.nCols = 2; // col50
						}

						// slice it up depending on deviceType TODO update css col class accordingly in tpl
						$scope.listHeaderFieldSet = $scope.listHeaderFieldSet.slice(0, $scope.nCols);
					}
					//
					////////////////////////////////////////////////////////////

					$scope.getFieldType = function (fieldApiName) {
						if (fieldApiName) {
							return tqCoreConnector.metadata.getFieldMetadata($scope.objectApiName(), fieldApiName).type;
						}
					};

					$scope.swipeOptionClicked = function (action, $event) {
						$scope.swipe({
							action: action,
							index: $scope.index
						});

						// Prevent bubbling to item div
						// On recent browsers, only $event.stopPropagation() is needed
						if ($event.stopPropagation) {
							$event.stopPropagation();
						}
						if ($event.preventDefault) {
							$event.preventDefault();
						}
						$event.cancelBubble = true;
						$event.returnValue = false;
					};
				}
			};
		});
});
