import template from './related.tpl.html';
/**
 *
 *  Example usage of related list with prepopulation map when creating new related record

 directly from the tpl

 <tq-list-related object-api-name="'Contact'"
 parent-record-id="record.rawRecord.Id"
 relationship-field-api-name="'AccountId'"
 new-prepopulation-map="{Email: record.rawRecord.Email}">
 </tq-list-related>

 NOTE that a where condition can be added on top of the parentRecordId and relationshipFieldApiName
 Ex: where="{ForecastCategoryName:{$eq: 'Pipeline'}}"


 optionally through controller (especially when building dynamic where conditions)

 controller (when retrieving async the parent record)

 $scope.relatedObjectApiName = 'Attachment';
 $scope.relatedObjectWhere = {
                    ParentId: {
                        $eq: $scope.rawRecord.Id
                    };

                    $scope.childFieldPrepopulationMap = {
                        Email: $scope.rawRecord.Email
                    };

        template

             <tq-list-related object-api-name="relatedObjectApiName"
                              where="relatedObjectWhere"
                              searchable="true"
                              has-header="false"
                              new-prepopulation-map="childFieldPrepopulationMap">
             </tq-list-related>

 */
define(['angular',
	'coreapi'], function (angular) {

	return angular.module('tq.list.related', [
		'tq.coreapi'])

		.directive('tqListRelated', function () {
			return {
				restrict: 'E',
				template: template,
				scope: {
					// required are
					parentRecordId: '=',
					objectApiName: '=',
					relationshipFieldApiName: '=',

					// whether we have a header showing the object api name (plural label)
					hasHeader: '&?',
					// can override the above specifying a custom label for the header
					headerLabel: '@?',
					// can create new records
					creatable: '&?',
					// can prepopulate parameters in the edit form
					newPrepopulationMap: '&?',
					// whether the list has its own header
					listHasHeader: '&?',

					// tq-list std functionality (when where is specified, merge with parentRecordId/relationshipFieldApiName)
					where: '=?',
					orderby: '=?',
					searchable: '&?',
					sortable: '&?',
					onListItemClick: '&?',

					// size of scrollable container, in this case it has own scrolling separate from page
					scrollHeight: '&?'
				},

				link: function (scope) {

					// update where when parentRecordId changes
					scope.$watch('parentRecordId', function (newValue, oldValue) {

						// at least a parameter
						if (newValue || scope.where) {
							// where not specified
							if ((newValue !== oldValue) || !scope.where) {
								scope.prepareWhereCondition(newValue);
							}
						}

					}, true);
				},

				controller: function ($scope, $state, tqCoreConnector) {
					$scope.hasHeader = angular.isFunction($scope.hasHeader) ? $scope.hasHeader() : true;
					$scope.creatable = angular.isFunction($scope.creatable) ? $scope.creatable() : true;
					$scope.listHasHeader = angular.isFunction($scope.listHasHeader) ? $scope.listHasHeader() : true;
					$scope.newPrepopulationMap = angular.isFunction($scope.newPrepopulationMap) ? $scope.newPrepopulationMap() : {};

					$scope.searchable = angular.isFunction($scope.searchable) ? $scope.searchable() : true;
					$scope.sortable = angular.isFunction($scope.sortable) ? $scope.sortable() : true;
					$scope.onListItemClick = angular.isFunction($scope.onListItemClick) ? $scope.onListItemClick() : null;

					$scope.scrollHeight = angular.isFunction($scope.scrollHeight) ? $scope.scrollHeight() : null;

					// shared across link and controller
					$scope.prepareWhereCondition = function (parentRecordId) {
						var newWhere = {};

						// where && parentRecordId
						if ($scope.where && parentRecordId) {

							var parentWhere = {};
							parentWhere[$scope.relationshipFieldApiName] = {
								'$eq': parentRecordId
							};
							newWhere = {
								'$and': [$scope.where, parentWhere]    // note that scope.where can be again $and
							};

							// only where
						} else if ($scope.where && !parentRecordId) {
							newWhere = $scope.where;
							// only parentRecordId
						} else if (parentRecordId) {
							newWhere[$scope.relationshipFieldApiName] = {
								'$eq': parentRecordId
							};
						}

						// we can automatically add the relationship field value to the prep.map
						if ($scope.relationshipFieldApiName && parentRecordId) {
							$scope.newPrepopulationMap[$scope.relationshipFieldApiName] = parentRecordId;
						}

						// NOTE! doing a complete assignment, we can trigger tq-list watch for where changes
						$scope.where = newWhere;
					};

					$scope.isCreatable = function () {
						// TODO move to a service this &&
						return tqCoreConnector.metadata.isTrackedObjectCreatable($scope.objectApiName) && tqCoreConnector.metadata.isTrackedObjectDisplayable($scope.objectApiName);
					};

					// header label calculation
					$scope.getHeaderLabel = function () {
						// custom label
						if ($scope.headerLabel) {
							return $scope.headerLabel;
							// if no special label is specified, display the object plural label
						} else {
							// second parameter specifies to get the plural label
							return tqCoreConnector.metadata.getTrackedObjectLabel($scope.objectApiName, true);
						}
					};

					// creation of a new related record using the 'newPrepopulationMap'
					$scope.newRecord = function () {
						$state.go('tqnew', {
							objectapiname: $scope.objectApiName,
							prepopulationRawRecordMap: $scope.getPrepopulationRawRecordMapAsParam()
						});
					};

					// prepare the map as a string
					$scope.getPrepopulationRawRecordMapAsParam = function () {
						// 1.we pass from the directive.tpl the parameter 'newPrepopulatedMap'
						// 2.important is to pass {} in the case no map object is passed
						var prepopulationRawRecordMap = $scope.newPrepopulationMap || {};
						return JSON.stringify(prepopulationRawRecordMap);
					};
				}
			};
		});
});
