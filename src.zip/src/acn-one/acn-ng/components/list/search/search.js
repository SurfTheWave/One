import template from './search.tpl.html';
define(['angular'], function (angular) {
	return angular.module('tq.list.search', [])
		.directive('tqListSearch', function () {
			return {
				restrict: 'E',
				replace: 'true',
				template: template,
				scope: {
					keyword: '=',
					search: '&',
					reset: '&'
				}
			};
		});
});
