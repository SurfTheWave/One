import template from './list.tpl.html';
import templateWithoutScroller from './listwithoutscroller.tpl.html';
import templateWithScroller from './listwithscroller.tpl.html';
define([
    'angular',
    'uiRouter',
    'coreapi',
    'components/list/search/search',
    'components/list/sort/sort',
    'components/list/item/item',
    'components/media/picture/picture'
], function(angular) {

    return angular.module('tq.list', [
        'ui.router',
        'tq.coreapi',
        'tq.list.sort',
        'tq.list.search',
        'tq.list.item',
        'tq.media.picture'
    ])

    .directive('tqList', function($timeout, $templateCache, $compile) {
        return {
            restrict: 'E',
            template: template,
            scope: {
                // required
                objectApiName: '=',
                // optionals
                delegateHandle: '@?',
                onListItemClick: '&?',
                onPullRefresh: '&?',
                onBeforeSearch: '&?',
                pullingText: '@?',
                where: '=?',
                orderby: '=?',
                // whether has the list header or not
                hasHeader: '&?',
                // whether each list header items have sort functionality (TODO goes away when header is completed with proper sort functionalities)
                searchable: '&?',
				searchName: '@?',
                sortable: '&?',
                swipable: '&?',
                scrollHeight: '&?',
                emptyListText: '@'
            },
            transclude: true,
            controller: 'TqListController',
            link: function(scope, elem, attrs, TqListController, transcludeFn) {
                //Change height of container to size of original list if it's less then scrollHeight
                scope.showInside = true;
                scope.showOutside = true;
                scope.fitScrollContent = function() {
                    var parentContainer = elem.find('.tq-list-parent-container');
                    var scrollableContent = parentContainer.find('.scroll');

                    if (parentContainer.height() > scrollableContent.height()) {
                        parentContainer.height(scrollableContent.height() + 10);
                    }
                };
                // check that list inner content is not empty (note would be enough to read content.length)
                var isEmptyContent = function(content) {
                    return content.context && content.context.wholeText &&
                        content.context.wholeText.trim().length === 0 &&
                        content.length <= 1;
                };

                // transclusion with dynamic tpl (get and compile)
                transcludeFn(scope, function(toTransclude) {
                    
                    var tplToCompile = null;

                    // set the parent container with the fixed height (and internal scroller) when we have to use a fixed height
                    if(scope.scrollHeight){
                        tplToCompile = templateWithScroller;
                    // use parent ion-content instead
                    } else {
                        tplToCompile = templateWithoutScroller;
                    }

                    // we need to use the compiled tpl
                    var compiledTpl = $compile(tplToCompile)(scope);
                    // set the html
                    elem.find('.tq-list-content').html(compiledTpl);

                    // finally transclude the actual list-items
                    if (!isEmptyContent(toTransclude)) {
                        elem.find('.tq-list-items-wrapper').html(toTransclude);
                    }
                });

                // when tq-list is used inside other directives, value of where can be changing after an async load of it's parameters
                // once this happens, we need to forget the first load of tq-list and start a new one
                scope.$watch('where', function(newValue, oldValue) {
                    if (newValue !== oldValue) {
                        scope.refresh();
                    }
                }, true);
            }
        };
    })

    .service('tqListDelegate', ionic.DelegateService([
            'refresh',
            'insertNewRecord',
            'removeRecord',
            'refreshWithUpdates'
       ]))

    .controller('TqListController', [
        '$rootScope',
        '$scope',
        '$state',
        'tqCoreConnector',
        'tqDeviceMediaPicture',
        '$timeout',
        'tqListDelegate',

        function($rootScope, $scope, $state, tqCoreConnector, tqDeviceMediaPicture, $timeout, tqListDelegate) {
            // default values for optional params
			$scope.orderby = $scope.orderby ? $scope.orderby : tqCoreConnector.metadata.getNameField($scope.objectApiName);
            $scope.onListItemClick = angular.isFunction($scope.onListItemClick) ? $scope.onListItemClick() : null;
            $scope.swipable = angular.isFunction($scope.swipable) ? $scope.swipable() : true;
            $scope.searchable = angular.isFunction($scope.searchable) ? $scope.searchable() : true;
            $scope.sortable = angular.isFunction($scope.sortable) ? $scope.sortable() : false;
            $scope.hasHeader = angular.isFunction($scope.hasHeader) ? $scope.hasHeader() : true;
            $scope.scrollHeight = angular.isFunction($scope.scrollHeight) ? $scope.scrollHeight() : null;
            $scope.pullingText = $scope.pullingText || 'Pull to refresh';
			$scope.searchName = $scope.searchName || 'Name';

            var that = this;

            var deregisterInstance = null;
            if (!_.isEmpty($scope.delegateHandle)) {
                deregisterInstance = tqListDelegate._registerInstance(this, $scope.delegateHandle);
            }

            // init generic
            $scope.objectNameField = tqCoreConnector.metadata.getNameField($scope.objectApiName);
            $scope.search = {
                keyword: ''
            };

            // init refresh
            $scope._initList = function() {
                $scope.records = [];
                $scope.offset = 0;
                $scope.limit = 10;
                $scope.moreDataCanBeLoaded = true;
                $scope.queryDeferred = null;
            };
            $scope.limit = 10;
            $scope._initList();

            // reload listener (used for example with the tq-media-picture)
            $rootScope.$on(tqDeviceMediaPicture.events.PICTURE_ATTACHMENT_CREATED_SUCCESS, function(event, objectApiName) {
                // refresh is 'slower' then adding record to $scope.tqRecords, but it respects the where condition
                // so you don't follow in the scenario where different attachment lists on the same page
                // using different where conditions, are all displaying the new record even if outside of the where range
                if (objectApiName === $scope.objectApiName) {
                    $scope.refresh();
                }
            });

            function getQueryBase(){
                var newQuery = {
                    objectApiName: $scope.objectApiName
                };

                if ($scope.search.keyword) {

                    var keyword = '%' + $scope.search.keyword + '%';
                    var searchWhere = {};

					//support for custom search fields
					searchWhere[$scope.searchName] = {
                            '$like': keyword
                        };

                    var whereObject;
                    if ($scope.where) {
                        whereObject = {
                            '$and': [$scope.where, searchWhere]
                        };
                    } else {
                        whereObject = searchWhere;
                    }

                    newQuery.where = whereObject;
                } else if ($scope.where) {
                    newQuery.where = $scope.where;
                }

                if ($scope.orderby) {
                    newQuery.orderby = $scope.orderby;
                }
                return newQuery;
            }

            // method which prepares query for the
            function getObjectQuery(offset, limit) {
                var newQuery = getQueryBase();

                newQuery.offset = offset;
                newQuery.limit = limit;

                return newQuery;
            }

            //If doRefresh parameter is set, instead of loading more we will reload all existing list and then replace
            //old records array with the response
            $scope.loadMore = function(doRefresh) {

                // only when we can load more
                if (!$scope.moreDataCanBeLoaded && !doRefresh) {
                    return;
                }

                // prepare the query
                var offset = doRefresh ? 0 : $scope.offset;
                var limit = doRefresh ? $scope.offset  : $scope.limit;
                if (limit < $scope.limit){
                    limit = $scope.limit;
                }
                var newQuery = getObjectQuery(offset, limit);

                // load records
				var thisDeferred = $scope.queryDeferred = tqCoreConnector.storage.find(newQuery);

                thisDeferred
                    .then(
                        // success
                        function(records) {

                            // in the case we watch 'where', once set, we call refresh() that set $scope.queryDeferred to
                            if (thisDeferred != $scope.queryDeferred) {
                                return;
                            }

                            //If we are doing refresh we shouldn't clear records immediately but after receiving new list
                            if (doRefresh){
                                var currentOffset = $scope.offset;
                                $scope._initList();
                                $scope.offset = currentOffset;
                            }

                            if (records.length > 0) {
                                $scope.records = $scope.records.concat(records);
                            }

                            // If we have loaded number of elements less then limit,
                            // it means that we have reached the last element, so we can stop loading
                            if (!doRefresh && records.length < $scope.limit) {
                                $scope.moreDataCanBeLoaded = false;
                            }

                            $timeout(function() {
                                $scope.$apply();
                            });

                            $scope.queryDeferred = null;
                            // stop spinner
                            $scope.$broadcast('scroll.infiniteScrollComplete');

                            //If list contains just couple records 1-2 and scrollHeight is bigger then
                            //original height of all list content the big margin will appear on UI
                            //To prevent this fitScrollContent function is called
                            if (!$scope.moreDataCanBeLoaded && $scope.scrollHeight) {
                                $timeout(function() {
                                    $scope.fitScrollContent();
                                }, 400);
                            }


                            // prepare next page load
                            if (!doRefresh) {
                                $scope.offset += $scope.limit;
                            }
                        },
                        // error
                        function(err) {
                            $scope.moreDataCanBeLoaded = false;
                            $scope.queryDeferred = null;
                            // stop spinner
                            $scope.$broadcast('scroll.infiniteScrollComplete');
                            if ($scope.scrollHeight) {
                                $timeout(function() {
                                    $scope.fitScrollContent();
                                }, 400);
                            }
                        });
            };

            $scope.doSearch = function() {

                try {
                    $scope.onBeforeSearch();
                } catch (error) {
                   console.error('TqList - Failed to execute onBeforeSearch callback:', error);
                }

                $scope.refresh();
            };

            this.refresh = function(startLoadingManually){
                // init the basic variables (not search)
                if (startLoadingManually === true) {
                    $scope.loadMore(true);
                }
                else {
                    $scope._initList();
                    // trigger the new load
                    $scope.loadMore();
                }
            };

            this.insertNewRecord = function(newRecord){
                $scope.records.unshift(newRecord);
                $scope.offset++;
            };

            this.removeRecord = function(record){
                var recordIndex = _.indexOf($scope.records, record);
                if (recordIndex !== -1){
                    $scope.records.splice(recordIndex, 1);
                    $scope.offset--;
                    $scope.$evalAsync();
                }
            };

            var smartRecordUpdate = function(record, newVersion){
                angular.forEach(newVersion, function(newValue, key) {
                    var recordValue = record[key];
                    if (_.isObject(newValue) && !_.isArray(newValue) && !_.isDate(newValue) &&
                        _.isObject(recordValue) && !_.isArray(recordValue) && !_.isDate(recordValue)){
                        smartRecordUpdate(recordValue, newValue);
                    } else if (record[key] != newValue){
                        record[key] = newValue;
                    }
                });

                return record;
            };

            this.refreshWithUpdates = function(updatesMap){
                if (_.isEmpty(updatesMap)) {
                    return;
                }
                //Get unique array, which contains all ids of deleted/created/updated records
                var updatedCount = 0;
                var updatedIds = [];
                for (var key in updatesMap){
                    if (_.isArray(updatesMap[key])){
                        updatedCount += updatesMap[key].length;
                        updatedIds = _.union(updatedIds, updatesMap[key]);
                    }
                }

                if (updatedCount === 0){
                    //If nothig has been changed then do nothing
                    return;
                } else if (updatedCount >= 100) { //$scope.records.length){
                    //If number of changed records is more or equal to existing list size, do normal  refresh
                    return this.refresh(true);
                } else {
                    var self = this;
                    var query = getQueryBase();
                    //Prepare query which gets all list values which match current where condition
                    if (_.isEmpty(query.where)){
                        query.where = {'Id' : {'$in' : updatedIds}};
                    } else {
                        query.where = { $and : [
                            query.where,
                            {'Id' : {'$in' : updatedIds}}
                        ] };
                    }

                    //Fetch all changed values
                    tqCoreConnector.storage.find(query).then(function(result){
                        if (_.isArray(result) && result.length > $scope.records.length){
                            return self.refresh(true);
                        }

                        //Get Map with indexes of records for each id
                        var index, key;
                        var recordIndexMap = {};
                        for (index = 0; index < $scope.records.length; index++){
                            recordIndexMap[$scope.records[index].rawRecord.Id] = index;
                        }

                        if (!_.isEmpty(result) && _.isArray(result)){
                            var resultMap = {};

                            for (index = 0; index < result.length; index++){
                                resultMap[result[index].rawRecord.Id] = result[index];
                            }

                            //Implement changes for deleted records
                            if (!_.isEmpty(updatesMap.deleted)){
                                for (index = 0; index < updatesMap.deleted.length; index++){
                                    var deletedId = updatesMap.deleted[index];
                                    if (recordIndexMap[deletedId] != null){
                                        for (key in recordIndexMap) {
                                            if (recordIndexMap[key] > recordIndexMap[deletedId]) {
                                                recordIndexMap[key]--;
                                            }
                                        }

                                        $scope.records.splice(recordIndexMap[deletedId], 1);
                                        $scope.offset--;
                                        delete recordIndexMap[deletedId];
                                    }
                                }
                            }

                            //Implement changes of modififed elements
                            if (!_.isEmpty(updatesMap.updated)){
                                for (index = 0; index < updatesMap.updated.length; index++){
                                    var updatedId = updatesMap.updated[index];
                                    if (recordIndexMap[updatedId] != null &&
                                        resultMap[updatedId] != null){
                                        smartRecordUpdate(
                                            $scope.records[recordIndexMap[updatedId]],
                                            resultMap[updatedId]
                                        );
                                    }
                                }
                            }

                            //Implement changes for created elements
                            if (!_.isEmpty(updatesMap.created)){
                                var localIdsMap = tqCoreConnector.sync.getLocalIdsForServerIds(updatesMap.created);

                                //Should goes from end of array to beginning according to sorting order
                                for (index = 0; index < updatesMap.created.length; index++){
                                    var createdId = updatesMap.created[index];
                                    var recordIndex = null;
                                    if (resultMap[createdId] == null) {continue;}

                                    if (recordIndexMap[createdId] != null){
                                        recordIndex = recordIndexMap[createdId];
                                    }
                                    else if (recordIndexMap[localIdsMap[createdId]] != null){
                                        recordIndex = recordIndexMap[localIdsMap[createdId]];
                                    }

                                    if (recordIndex != null){
                                        smartRecordUpdate(
                                            $scope.records[recordIndex],
                                            resultMap[createdId]
                                        );

                                        //$scope.records[recordIndex] = resultMap[createdId];
                                    } else {
                                        $scope.records.unshift(resultMap[createdId]);
                                        $scope.offset++;
                                        for (key in recordIndexMap){
                                            recordIndexMap[key]++;
                                        }
                                        recordIndexMap[createdId] = 0;
                                    }
                                }
                            }

                            $scope.$evalAsync();
                        }
                    });
                }
            };

            $scope.refresh = function() {
                that.refresh();
            };

            $scope.cancelSearch = function() {
                $scope.search.keyword = '';
                $scope.doSearch();
            };

            $scope.sort = function() {
                if ($scope.orderBy === $scope.objectNameField + ' ASC') {
                    $scope.orderBy = $scope.objectNameField + ' DESC';
                } else {
                    $scope.orderBy = $scope.objectNameField + ' ASC';
                }
                $scope.doSearch();
            };

            // on list item tap
            $scope.click = function(index, record) {

                // custom on click behaviour
                if ($scope.onListItemClick && _.isFunction($scope.onListItemClick)) {
                    $scope.onListItemClick(record);
                    // default behaviour is to route to the record detail
                } else {
                    $state.go('tqdetails', {
                        objectapiname: $scope.objectApiName,
                        recordid: record.rawRecord.Id
                    });
                }
            };

            // edit a record
            $scope.editRecord = function(record) {
                $state.go('tqedit', {
                    objectapiname: $scope.objectApiName,
                    recordid: record.rawRecord.Id
                });
            };

            // when we click on one of the hidden list options
            $scope.swipe = function(action, index) {
                switch (action) {
                    case 'remove':
                        $scope.removeRecord($scope.records[index]);
                        break;
                    case 'edit':
                        $scope.editRecord($scope.records[index]);
                        break;
                }
            };

            $scope.removeRecord = function(record) {

                // remove record
                tqCoreConnector.storage.remove(record)
                    .then(
                        // remove from list on success
                        function success() {
                            // find and remove from list
                            var index = $scope.records.indexOf(record);
                            $scope.records.splice(index, 1);

                            // To keep limit the same we should upload one more item
                            var indexToUpload = $scope.offset - 1;
                            var oneRecordQuery = getObjectQuery(indexToUpload, 1);
                            $scope.offset--;

                            // get extra record
                            tqCoreConnector.storage.find(oneRecordQuery)
                                .then(
                                    function(result) {
                                        if (result.length > 0) {
                                            // add new one to the list
                                            $scope.records.push(result[0]);
                                            $scope.offset++;
                                        }
                                    },
                                    // error getting record
                                    function(err) {
                                        console.log('tqlist:delete:error finding a new record');
                                    }
                                );
                        },
                        // error removing the record
                        function error(err) {
                            console.log('tqlist:delete:error deleting record');
                        }
                    );
            };

            $scope.pullRefresh = function(){
                // call passed function
                if($scope.onPullRefresh){
                    $scope.onPullRefresh()
                        .then(
                            // success
                            function(){
                                // refresh the list
                                $scope.refresh();
                                $scope.$broadcast('scroll.refreshComplete');
                            },
                            // error
                            function(err){
                                $scope.$broadcast('scroll.refreshComplete');
                            }
                        );
                // simply refresh list
                } else {
                    $scope.refresh();
                    $scope.$broadcast('scroll.refreshComplete');
                }
            };

            $scope.loadMore();

            // note that ion-infinite-scroll directive within tpl calls the triggers the query on page opening
            $scope.$on('$destroy', function() {
                if (!_.isEmpty(deregisterInstance)){
                    deregisterInstance();
                }
            });
        }
    ]);
});
