import template from './sort.tpl.html';
define(['angular'], function (angular) {

	return angular.module('tq.list.sort', [])
		.directive('tqListSort', function () {
			return {
				restrict: 'E',
				replace: 'true',
				template: template,
				scope: {
					isAscending: '=',
					sort: '&',
					objectApiName: '&?'
				},
				controller: function ($scope, tqCoreConnector) {
					$scope.ascending = true;

					$scope.toggle = function () {
						$scope.ascending = !$scope.ascending;
						$scope.sort();
					};

					// get field related label
					$scope.getFieldLabel = function (fieldApiName) {
						if (fieldApiName) {
							return tqCoreConnector.metadata.getFieldLabel($scope.objectApiName(), fieldApiName);
						}
					};

					////////////////////////////////////////////////////////////
					// TODO put in service (used by sort.js and item.js)
					//
					// api names
					$scope.listHeaderFieldSet = tqCoreConnector.metadata.getTrackedObjectHeaderFieldSet($scope.objectApiName());

					// custom setting listHeaderFieldSet empty
					if (_.isEmpty($scope.listHeaderFieldSet)) {
						// then use the name field
						$scope.listHeaderFieldSet.push(tqCoreConnector.metadata.getNameField($scope.objectApiName()));
						// use custom setting listHeaderFieldSet
					} else {
						// 2 cols on phone and 5 on tablet TODO not hardcoded
						$scope.deviceType = 'tablet';
						if ($scope.deviceType === 'browser') {
							$scope.nCols = 10; // col10
						} else if ($scope.deviceType === 'tablet') {
							$scope.nCols = 5; // col20
						} else {
							$scope.nCols = 2; // col50
						}

						// slice it up depending on deviceType TODO update css col class accordingly in tpl
						$scope.listHeaderFieldSet = $scope.listHeaderFieldSet.slice(0, $scope.nCols);
					}
					//
					////////////////////////////////////////////////////////////
				}
			};
		});
});
