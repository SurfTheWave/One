import template from './attachment.tpl.html';
define(['angular',
	'coreapi',
	'components/list/list',
	'components/media/picture/picture',
	'components/popup/criticalerror/criticalerror'
], function (angular) {

	return angular.module('tq.list.attachment', [
		'ionic',
		'tq.coreapi',
		'tq.media.picture',
		'tq.list',
		'tq.popup.criticalerror'
	])


	/**
	 * Usage Example
	 *
	 * <tq-list-attachment parent-record-id="parentRecordId">
	 * </tq-list-attachment>
	 */
		.directive('tqListAttachment', function () {
			return {
				restrict: 'E',
				template: template,
				scope: {
					// specify the parent we are showing attachment for in the tq-list
					parentRecordId: '=',

					// is the related list searchable?
					searchable: '&?',
					// we show a header at the top
					hasHeader: '&?',
					// can customize the label for the header
					headerLabel: '@?',
					// size of scrollable container, in this case it has own scrolling separate from page
					scrollHeight: '&?'
				},

				// support async loading of parameters
				link: function (scope) {

					// configuration for tq-list-related p1
					scope.relatedObjectApiName = 'Attachment';

					// watch will call the function scope.parentRecordId (given &) and get new value
					scope.$watch('parentRecordId', function (newValue, oldValue) {
						if (newValue !== oldValue) {
							// configuration for tq-list-related p2
							scope.relatedParentRecordId = newValue;
						}
					}, true);
				},

				controller: function ($scope, tqCoreConnector, tqPopupCriticalError, $ionicLoading) {
					$scope.searchable = angular.isFunction($scope.searchable) ? $scope.searchable() : false;
					$scope.hasHeader = angular.isFunction($scope.hasHeader) ? $scope.hasHeader() : true;
					$scope.headerLabel = $scope.headerLabel ? $scope.headerLabel : 'Attachments';
					$scope.scrollHeight = angular.isFunction($scope.scrollHeight) ? $scope.scrollHeight() : null;
					$scope.relatedParentRecordId = $scope.parentRecordId;

					// on list item click, open the file
					$scope.openFile = function (record) {
						// device only
						if (tqCoreConnector.device.platform.isDevice()) {
							// spinner in
							$ionicLoading.show({
								template: 'Loading...'
							});
							// launch the file opener (eventually download the asset when online)
							tqCoreConnector.device.file.openFile(record)
								.then(
								// open success
								function () {
									// spinner out
									$ionicLoading.hide();
								},
								// error opening
								function (err) {
									// spinner out
									$ionicLoading.hide();
									// error UI
									if (err === tqCoreConnector.device.connection.OFFLINE) {
										$scope.showErrorMsg('Open of a remote file is available only when online');
									} else if (err === tqCoreConnector.device.file.LOAD_FILE_FROM_SERVER_ERROR) {
										$scope.showErrorMsg('Error while downloading the file. Try again');
									} else {
										// TODO SEND LOG
										$scope.showErrorMsg('Generic error. Contact your admin');
										console.log('attachment:error:not handled error');
									}
								}
							);
							// browser
						} else {
							$scope.showErrorMsg('Attachments work only on device');
						}
					};

					// show error wrapper
					$scope.showErrorMsg = function (message) {
						tqPopupCriticalError.show({
							title: 'Open File',
							message: message,
							okText: 'Ok',
							restart: false
						});
					};
				}
			};
		});
});
