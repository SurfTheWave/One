define(['angular', 'coreapi'], function (angular) {
	return angular.module('tq.lazysrc', ['tq.coreapi'])
		.directive('tqLazySrc', ['tqCoreConnector', function (tqCoreConnector) {
			return {
				restrict: 'A',
				link: function (scope, element, attrs) {
					//Check type of the element. If it's image value will be placed in src attribute
					//In other case css attribute background-url will be updated
					var updateImageAttribute = function (elem, value) {
						if (elem.is('img')) {
							elem.attr('src', value);
						} else {
							var cssValue = _.isEmpty(value) ? '' : 'url(' + value + ')';
							elem.css('background-image', cssValue);
						}
					};

					var fileLoadedCallback = function (localUrl) {
						if (localUrl) {
							updateImageAttribute(element, localUrl);
						}
					};

					var fileFailedCallback = function (error) {
						console.log(error);
					};

					//If image path contains not an image or it's broken or unaccessible replace it with a placeholder
					if (element.is('img')) {
						element.bind('error', function () {
							var placeholder = element.attr('placeholder');
							if (!_.isEmpty(placeholder) && element.attr('src') != placeholder) {
								updateImageAttribute(element, placeholder);
							}
						});
					}

					//Watch changes of the directive attribute tq-lazy-src to subscribe on file load event
					attrs.$observe('tqLazySrc', function (newSrc, oldSrc) {
						if (newSrc != oldSrc) {
							if (oldSrc) {
								//If tq-lazy-src was set before, unsubscribe from previous file load
								tqCoreConnector.sync.offFileLoad(oldSrc, fileLoadedCallback, fileFailedCallback);
							} else if (!_.isEmpty(attrs.placeholder)) {
								//Replace original value with a placeholder
								updateImageAttribute(element, attrs.placeholder);
							}

							if (!newSrc || newSrc === '') {
								//If new value is empty remove the image
								updateImageAttribute(element, null);
							} else if (newSrc.indexOf('data:') === 0){
                                updateImageAttribute(element, newSrc);
                            } else {
								//Handle event when file will be loaded
								tqCoreConnector.sync.onFileLoad(newSrc, fileLoadedCallback, fileFailedCallback);
							}
						}
					});

					//Unsubscribe from file load event when removing directive
					scope.$on('$destroy', function () {
						var lazySrcValue = element.attr('tq-lazy-src');
						if (lazySrcValue && lazySrcValue !== '') {
							tqCoreConnector.sync.offFileLoad(lazySrcValue, fileLoadedCallback, fileFailedCallback);
						}
						element.unbind('error');
					});
				}
			};
		}]);
});