define(['angular'], function (angular) {

	return angular.module('tq.fadein', [])

		.directive('tqFadeIn', function ($timeout) {
			return {
				restrict: 'A',
				link: function ($scope, $element, attrs) {
					// hide
					$element.addClass("tq-hide");
					// when image is loaded, fade it in
					if ($element.is('img')) {
						$($element).on('load', function () {
							$element.addClass("tq-fade-in");
						});
					} else {
						// watch for style changes
						// TODO
//                        attrs.$observe('style', function(n, o){
//                            debugger;
//                        });
//                        $scope.$watch(function(){return attrs.style;}, function(n,o){
//                            debugger;
//                        });
					}

					// watch for src changes
					// TODO
				}
			};
		});
});