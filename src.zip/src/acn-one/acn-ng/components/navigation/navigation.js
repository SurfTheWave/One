define(['angular',
	'coreapi'], function (angular) {

	return angular.module('tq.navigation', [
		'tq.coreapi'])

	/**
	 * this navigation service defines the control of a generic UI menu for the client application
	 * in ex. can be used with
	 * -circular menu
	 * -fan menu
	 * -[standard footer]
	 */
		.service('tqNavigation', function () {

			// active items for the menu, depending on state
			this.activeNavItems = [];

			// the items within the menu, set at client startup
			this.navItemsMapping = [];

			/**
			 * in the particular menu we set the $scope.links property
			 * @returns {Array}
			 */

			this.getActiveNavItemsMapping = function () {
				var that = this;
				var activeNavItemsMapping = {};
				activeNavItemsMapping.items = [];

				if (this.activeNavItems && this.activeNavItems.items) {
					this.activeNavItems.items.forEach(
						function (activeNav) {
							that.navItemsMapping.forEach(function (navItemMap) {

								if (navItemMap.name === activeNav.name) {
									activeNavItemsMapping.items.push(_.extend(navItemMap, activeNav));
								}
							});
						}
					);
				}


				activeNavItemsMapping.scrollHandle = this.activeNavItems.scrollHandle;
				return activeNavItemsMapping;
			};

			/**
			 * @param states The list of active states
			 */
			this.setActiveNavItems = function (states) {
				this.activeNavItems = states;
			};
		}).service('goTo', function ($ionicScrollDelegate, $state) {
			var goTo = {};

			goTo.section = function (section, animate, scrollHandle) {
				var scrollDelegate = $ionicScrollDelegate.$getByHandle(scrollHandle);
				section = $('#' + section);
				if (typeof animate === 'undefined') {
					animate = true;
				}
				if (!_.isEmpty(section)) {
					var top = section.position().top;
					var currPosition = scrollDelegate.getScrollPosition().top;
					scrollDelegate.scrollTo(0, top + currPosition, animate);
				}
			};

			goTo.state = function (state, params) {
				$state.go(state, params);
			};

			return goTo;

		})
		/*
		 Register callbacks against the position of a dom node
		 */
		.service('viewport', function ($window, $ionicScrollDelegate, $state, $rootScope) {
			var _callbacks = [];
			var axisY = {};

			function itemIsInViewport(position, item, top) {
				return position >= top && position <= item.height() + top;
			}

			function justEnteredItem(axis, top) {
				return axis.newScroll > top && axis.oldScroll < top;
			}

			$rootScope.$on('$ionicView.beforeLeave', function () {
				_callbacks = [];
				//only one scroll delegate per page
				axisY = {};
			});

			var callCallbacks = function (delegate) {

				axisY = {
					newScroll: delegate.getScrollPosition().top,
					oldScroll: axisY.newScroll,
					oldDirection: axisY.direction,
					direction: ''
				};

				var isForward = axisY.newScroll > axisY.oldScroll;

				axisY.direction = isForward ? 'down' : 'up';

				_callbacks.forEach(
					function (cb) {
						//Ionic's method of scrolling ensures that items are all given inaccurate top values
						// this is why we calculate realTop
						var realTop = cb.item.position().top + axisY.newScroll;

						//item specific details
						if (itemIsInViewport(axisY.newScroll, cb.item, realTop - 15)) {
							axisY.isInViewport = true;
						} else {
							axisY.isInViewport = false;
						}

						if (justEnteredItem(axisY, realTop)) {
							axisY.justEnteredItem = true;
						} else {
							axisY.justEnteredItem = false;
						}

						/**
						 * Callbacks are invoked with the axis object, which should be enough
						 * to calculate what the appropriate thing to do is
						 */
						if (axisY.justEnteredItem || axisY.isInViewport) {
							cb.cb(axisY);
						}
					}
				);
			};

			/**
			 * @param item
			 * @param cb
			 * @param delegateHandle
			 * @param type
			 */

			function registerCallback(item, cb, delegateHandle, type) {
				var delegate;
				if (typeof item == 'string') {
					item = $(item);
				}
				if (typeof delegateHandle === 'undefined') {
					delegate = $ionicScrollDelegate;
				}
				else {
					delegate = $ionicScrollDelegate.$getByHandle(delegateHandle);
				}
				if (!_.isEmpty(item)) {
					_callbacks.push({item: item, cb: cb, delegate: delegate});
				}
			}

			return {
				registerCallback: registerCallback,
				onScroll: callCallbacks
			};
		});
});