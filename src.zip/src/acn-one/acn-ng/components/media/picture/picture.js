/**
 * Directive where the template has a basic UI with two buttons, one to take and one to pick picture
 */
define(['angular',
	'coreapi',
	'components/popup/criticalerror/criticalerror'], function (angular) {

	return angular.module('tq.media.picture', [
		'tq.coreapi',
		'tq.popup.criticalerror'])

	/**
	 * Usage Example
	 *
	 * <tq-media-picture parent-record-id="parentRecordId"
	 *                   on-picture-success="addRecordToTqList">
	 * </tq-media-picture>
	 */
		.directive('tqMediaPicture', function () {
			return {
				restrict: 'E',
				templateUrl: function (elem, attrs) {
					if (attrs.templateUrl) {
						return attrs.templateUrl;
					}

					return 'acn-one/acn-ng/components/media/picture/picture.tpl.html';
				},
				scope: {
					// if the parent TQRecord is passed, we can automatically create an attachment record with the captured media
					parentRecordId: '=',
					// if a custom function is specified then execute it passing the returned value
					onPictureSuccess: '=?',
					onPictureError: '=?',
					// alternatively can broadcast events
					broadcastSuccessEvent: '&?',                // tq.media.picture.success.attachment || tq.media.picture.success
					broadcastErrorEvent: '&?',                  // tqDeviceMediaPicture.events.PICTURE_ERROR
					// buttons options
					takePictureBtn: '&?',
					pickPictureBtn: '&?'
				},

				controller: function ($rootScope, $scope, tqCoreConnector, tqDeviceMediaPicture, tqPopupCriticalError) {
					$scope.TAKE_PICTURE = tqCoreConnector.device.media.picture.TAKE_PICTURE;
					$scope.PICK_PICTURE = tqCoreConnector.device.media.picture.PICK_PICTURE;
					// default values
					$scope.takePictureBtn = angular.isFunction($scope.takePictureBtn) ? $scope.takePictureBtn() : true;
					$scope.pickPictureBtn = angular.isFunction($scope.pickPictureBtn) ? $scope.pickPictureBtn() : true;
					$scope.broadcastSuccessEvent = angular.isFunction($scope.broadcastSuccessEvent) ? $scope.broadcastSuccessEvent() : false;
					$scope.broadcastSuccessEvent = angular.isFunction($scope.broadcastErrorEvent) ? $scope.broadcastErrorEvent() : false;

					$scope.getPicture = function (source) {

						// rely on the service (source is coming from directive UI btns)
						tqDeviceMediaPicture.getPicture(source)
							.then(
							// result simply the fileName
							function (fileName) {

								// A. auto generation of an attachment, related to a parent record
								if ($scope.parentRecordId) {
									// create a new attachment record
									var attachment = tqCoreConnector.record.getTrackedObjectRecordInstance('Attachment');
									// prepare the values
									attachment.rawRecord.Body = fileName;
									attachment.rawRecord.ParentId = $scope.parentRecordId;
									attachment.rawRecord.Name = fileName;

									// insert record
									tqCoreConnector.storage.upsert(attachment)
										.then(
										function () {
											// callback
											if ($scope.onPictureSuccess && _.isFunction($scope.onPictureSuccess)) {
												// return the attachment itself
												$scope.onPictureSuccess(attachment);
												// event
											} else if ($scope.broadcastSuccessEvent) {
												// event contains the attachment record that can be added to observer lists
												$rootScope.$broadcast(tqDeviceMediaPicture.events.PICTURE_ATTACHMENT_CREATED_SUCCESS, 'Attachment');
											} else {
												console.log('camera:success:created attachment. no callback or event specified');
											}
										},
										function (err) {
											// debug
											console.log('camera:error:impossible to upsert the new attachment record');
											// callback
											if ($scope.onPictureError && _.isFunction($scope.onPictureError)) {
												$scope.onPictureError(err);
												// event
											} else if ($scope.broadcastErrorEvent) {
												// event contains the err
												$rootScope.$broadcast(tqDeviceMediaPicture.events.PICTURE_ERROR, err);
											} else {
												console.log('camera:error: ' + err + ' ...specify a callback function');
											}
										}
									);

									// B. std behaviour, simply return result
								} else {

									// callback
									if ($scope.onPictureSuccess && _.isFunction($scope.onPictureSuccess)) {
										$scope.onPictureSuccess(fileName);
										// event
									} else if ($scope.broadcastSuccessEvent) {
										// event
										$rootScope.$broadcast(tqDeviceMediaPicture.events.PICTURE_SUCCESS);
									} else {
										console.log('camera:success:don\'t know what to do with this result ' + result);
									}
								}
							},
							function (err) {

								// user cancel
								if (err === tqCoreConnector.device.media.picture.NO_IMAGE_SELECTED) {
									console.log('camera:error: ' + err + ' ...specify a callback function');
									// picture in browser
								} else if (err === tqCoreConnector.device.media.picture.PICTURE_NOT_AVAILABLE) {

									// alert user
									tqPopupCriticalError.show({
										title: 'Pictures',
										message: 'Pictures work only on device',
										okText: 'Ok',
										restart: false
									});
									// all others
								} else {
									// callback
									if ($scope.onPictureError && _.isFunction($scope.onPictureError)) {
										$scope.onPictureError(err);
										// event
									} else if ($scope.broadcastErrorEvent) {
										// event
										$rootScope.$broadcast(tqDeviceMediaPicture.events.PICTURE_ERROR, err);
									} else {
										console.log('camera:error: ' + err + ' ...specify a callback function');
									}
								}
							}
						);
					};
				}
			};
		})

	/**
	 * Usage Example
	 *
	 * tqDeviceMediaPicture.getPicture(source)
	 *    .then(
	 *      function(fileName){}
	 *      function(err){}
	 *    )
	 *
	 * where source is
	 *  tqCoreConnector.device.media.picture.TAKE_PICTURE => take new from camera
	 *  tqCoreConnector.device.media.picture.PICK_PICTURE => take existing from camera roll
	 */
		.service('tqDeviceMediaPicture', function (tqCoreConnector) {

			// constants
			this.events = {
				PICTURE_ERROR: 'tq.media.picture.error',
				PICTURE_SUCCESS: 'tq.media.picture.success',
				PICTURE_ATTACHMENT_CREATED_SUCCESS: 'tq.media.picture.success.attachment'
			};

			// get picture access to the core
			this.getPicture = function (source) {
				// result is {fileName: xxx, fileURI: xxx}
				return tqCoreConnector.device.media.picture.getPicture(source);
			};
		});
});