define(['angular',
        'facebook',
        'pinterest'], function (angular) {
    return angular.module('tq.socialsharing', [])

        .provider('tqSocialSharing', function tqSocialSharingProvider() {
            //905418596207969
            var socialNetwotkPreferences = {
                FacebookAppId: '1659462291010102',//'873495816099000',//'1659462291010102',
                TwitterAppId: '',
                PinterestAppId: '',
                GooglePlusAppId: ''
            };

            this.setSocialNetworkPreferences = function(networkPreferences){
                angular.merge(socialNetwotkPreferences, networkPreferences);
            };

            //'507164896126400',//'145634995501895',//'903222893094206'
            FB.init({
                appId      : socialNetwotkPreferences.FacebookAppId,
                xfbml      : true,
                version    : 'v2.4'
            });

            var tqSocialSharingService = null;

            var mergeTextAndHashtags = function(text, hashtags){
                if (!hashtags || hashtags === ''){
                    return text;
                } else if (!text || text === ''){
                    return hashtags || '';
                } else {
                   return text + ' ' + hashtags;
                }
            };

            this.$get = function ($q,  $settings , tqCoreConnector) {
                if (!tqSocialSharingService){
                    tqSocialSharingService = {
                        //Just choose social network as first parameter
                        //Link Url should be option when possible
                        shareVia: function(socialNetwork, messageText, imageUrl, linkUrl){

                        },

                        shareViaFacebook: function(messageText, imageUrl, linkUrl, hashtags){
                          // will only work with people who have access to the dev account
                          var url = "https://www.facebook.com/dialog/feed?name=My+Travel+Space";
                          var app_id = socialNetwotkPreferences.FacebookAppId;
                          var description = encodeURIComponent(mergeTextAndHashtags(messageText, hashtags));
                          var redirect_uri = encodeURIComponent(linkUrl);
                          var link = linkUrl || imageUrl;


                          url+= '&app_id='+app_id+'&display=popup';
                          url+= '&description='+description;
                          url+= '&redirect_uri='+encodeURIComponent("http://www.facebook.com");
                          if (imageUrl) {
                              url += '&picture=' + encodeURIComponent(imageUrl);
                          }
                          if (link) {
                              url += '&link=' + encodeURIComponent(link);
                          }

                          window.open(
                            url,
                            'facebook-share-dialog',
                            'width=963,height=447,scrollbars=yes');
                        },

                        shareViaTwitter: function(messageText, imageUrl, linkUrl, hashtags){
                          var urlString = 'https://www.twitter.com/intent/tweet?';

                          if (messageText) {
                            urlString += 'text=' + encodeURIComponent(
                                mergeTextAndHashtags(messageText.toString(), hashtags)
                            );
                          }
                          /*if (hashtags) {
                            urlString += '&hashtags=' + hashtags.toString();
                          }*/
                          if (imageUrl) {
                            urlString += '&url=' + encodeURIComponent(imageUrl);
                          }


                          window.open(
                            urlString,
                            'sharer', 'toolbar=0,status=0,width=500,height=250'
                          );

                        },

                        shareViaPinterest: function(messageText, imageUrl, linkUrl, hashtags){
                          PDK.pin(imageUrl, mergeTextAndHashtags(messageText, hashtags), linkUrl);
                        },

                        shareViaGooglePlus: function(messageText, imageUrl, linkUrl, hashtags){
                          var urlString = 'https://plus.google.com/share?url='+encodeURIComponent(imageUrl);
                          if (hashtags && hashtags !== ''){
                              urlString += '&hashtags=' + encodeURIComponent(hashtags);
                          }

                          window.open(
                            urlString,
                            'sharer', 'toolbar=0,status=0,width=500,height=250'
                          );
                        }
                    };
                }

                return tqSocialSharingService;
            };
        })
        .service('tqSocialSharingPopup', function (tqSocialSharing, $ionicPopup, $timeout, $rootScope) {
            var self = this;
            //Popup just contains buttons for social sharing, each of them is doing separate job.
            this.show = function(messageText, imageUrl, linkUrl, hashtags, popupPreferences){
              if (self.showing) {return;}
              self.showing = true;
              $timeout(function(){self.showing = false;}, 2000);

              var $scope = $rootScope.$new();
              var myPopup = $ionicPopup.show({
                title: 'Share',
                templateUrl: 'acn-one/acn-ng/components/socialsharing/sharePopoupContent.tpl.html',
                moduleName: 'socialsharing',
                scope: $scope,
                cssClass: 'tq-social-sharing ' + (popupPreferences.cssClass || ''),
                buttons: [
                  { text: 'Cancel', onTap: function(e) { return false; } }
                ]
              });
              $scope.imageUrl = imageUrl;
              $scope.linkUrl = linkUrl;
              //click events for social buttons inside template
              $scope.shareFacebook = ionic.throttle(function() {
                try {
                    tqSocialSharing.shareViaFacebook(messageText, imageUrl, linkUrl, hashtags);
                } finally {
                    $timeout( function() { myPopup.close();}, 100);
                }
              }, 1000);
              $scope.shareTwitter = ionic.throttle(function() {
                try {
                    tqSocialSharing.shareViaTwitter(messageText, imageUrl, linkUrl, hashtags);
                } finally {
                    $timeout( function() { myPopup.close();}, 100);
                }
              }, 1000);
              $scope.sharePinterest = ionic.throttle(function() {
                try {
                    tqSocialSharing.shareViaPinterest(messageText, imageUrl, linkUrl);
                } finally {
                    $timeout( function() { myPopup.close();}, 100);
                }
              }, 1000);
              $scope.shareGooglePlus = ionic.throttle(function() {
                try {
                    tqSocialSharing.shareViaGooglePlus(messageText, imageUrl, linkUrl);
                } finally {
                    $timeout( function() { myPopup.close();}, 100);
                }
              }, 1000);
            };

        });
});
