import template from './collapsible.tpl.html';
define(['angular'], function (angular) {
    return angular.module('tq.collapsible', [])
        .directive('tqCollapsible', function () {
            return {
                restrict: 'E',
                template: template,
                scope: {
                    header: '@?',
                    collapsed: '=?',
                    isCollapsable: '=?',
                    /**
                     * required for resize of the content scroller the collapsible is within
                     */
                    delegateHandle: '@?',
                    icon: '@?',
                    onchange: '&?'
                },
                transclude: true,
                replace: false,
                controller: function ($scope, $ionicScrollDelegate, $timeout) {
                    $scope.collapsed = $scope.collapsed ? true : false; //Convert to boolean even if is undefined
                    $scope.isCollapsable = $scope.isCollapsable ? true : false; //Convert to boolean even if is undefined
                    $scope.isCollapsed = $scope.collapsed;

                    if (!$scope.delegateHandle) {
                        $scope.delegateHandle = 'ionCollapsibleContentScrollHandle';
                    }
                    var contentScroller = $ionicScrollDelegate.$getByHandle($scope.delegateHandle);

                    $scope.toggleCollapsed = function () {
                        if($scope.isCollapsable){
                            $scope.isCollapsed = !$scope.isCollapsed;
                            if (angular.isFunction($scope.onchange)){
                                $scope.onchange({collapsed: $scope.isCollapsed});
                            }
                            $timeout(function(){
                                contentScroller.resize();
                            }, 300);
                        }
                    };
                }
            };
        });
});
