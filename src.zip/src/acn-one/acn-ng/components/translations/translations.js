define([
	'angular',
	'angularTranslate',
	'angularTranslateLoaderStaticFiles'

], function (angular) {
	'use strict';

	return angular.module('tq.translations', [
		'pascalprecht.translate'

	])
		.constant('ACN_NG_TRANSLATION_FILES', [
			'ACN_EN'
		])

		.config(function ($translateProvider, ACN_NG_TRANSLATION_FILES) {

			$translateProvider.useStaticFilesLoader({prefix: '', suffix: '.json'});
			$translateProvider.preferredLanguage(_.last(ACN_NG_TRANSLATION_FILES));
		});
});
