define(['angular'], function (angular) {

    return angular.module('tq.menu.overlay', [])
        .directive('ionMenuOverlay', ['$timeout', function ($timeout) {
            return {
                restrict: 'A',
                require: '^ionSideMenus',
                link: function($scope, $element, $attr, $ionicSideMenus){
                    var sideMenusController = $ionicSideMenus;
                    var amountValue = 0;
                    var minOpacity = 0.5;
                    var contentAnimationElement = null;

                    $scope.$watch(function(){
                        return sideMenusController.right;
                    }, function(rightMenu){
                        if (rightMenu && rightMenu.el) {
                            rightMenu.el.style[ionic.CSS.TRANSFORM] = 'translate3d(' + rightMenu.width + 'px,0,0)';
                            rightMenu.el.style.zIndex = 1;
                            angular.element(rightMenu.el).addClass('menu-animated');
                        }
                    });

                    $scope.$watch(function(){
                        return sideMenusController.left;
                    }, function(leftMenu){
                        if (leftMenu && leftMenu.el) {
                            leftMenu.el.style[ionic.CSS.TRANSFORM] = 'translate3d(' + rightMenu.width + 'px,0,0)';
                            leftMenu.el.style.zIndex = 1;
                            angular.element(leftMenu.el).addClass('menu-animated');
                        }
                    });

                    $scope.$watch(function(){
                        return sideMenusController.content;
                    }, function(controllerContent){
                        if (controllerContent && controllerContent.element) {
                            contentAnimationElement = controllerContent.element;
                            var navView = angular.element(controllerContent).children('ion-nav-view');
                            if (navView.length > 0 ){
                                contentAnimationElement = navView.get(0);
                            }

                            contentAnimationElement.style[ionic.CSS.TRANSITION] = 'transform 200ms ease';
                        }
                    });

                   var processOpen = false;

                    sideMenusController.openAmount = function(amountLength){
                        var newWidth;

                        if (Math.abs(amountLength - amountValue) > 160) {
                            if (processOpen) {
                                return;
                            } else {
                                processOpen = true;
                                $timeout(function () {
                                    processOpen = false;
                                }, 200);
                            }
                        }

                        if (amountLength < 0 && -amountLength > sideMenusController.right.width){
                            amountLength = -sideMenusController.right.width;
                        }

                        if (amountLength > 0 && amountLength > sideMenusController.left.width){
                            amountLength = sideMenusController.left.width;
                        }

                        if (contentAnimationElement && !(amountLength > 0 && !sideMenusController.left.el) &&
                            !(amountLength < 0 && !sideMenusController.right.el)){
                            var animationContent = angular.element(contentAnimationElement);
                            if (animationContent.children('ion-nav-view').length > 0){
                                animationContent = animationContent.children('ion-nav-view');
                            }
                            var maxLength = Math.max(sideMenusController.right && sideMenusController.right.width,
                                                     sideMenusController.left && sideMenusController.left.width,
                                                     100);
                            var calculatedOpacity = 1 - (Math.abs(amountLength) / maxLength) * (1 - minOpacity);
                            animationContent.css({opacity : calculatedOpacity});
                        }

                        if (amountLength <= 0 && sideMenusController.right.el){
                            newWidth = (sideMenusController.right.width + amountLength);
                            sideMenusController.right.el.style[ionic.CSS.TRANSFORM] = 'translate3d(' + newWidth + 'px,0,0)';
                        }

                        if (amountLength >= 0 && sideMenusController.left.el){
                            if (sideMenusController.left.el){
                                newWidth =  -amountLength;
                                sideMenusController.left.el.style[ionic.CSS.TRANSFORM] = 'translate3d(' + newWidth + 'px,0,0)';
                            }
                        }

                        amountValue = amountLength;
                    };

                    sideMenusController.getOpenAmount = function(){
                        return amountValue;
                    };
                }
            };
        }]);
});