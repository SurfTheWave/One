/**
 * Service works only with Android devices
 *
 * When on iOS or Browser, service returns an error with param value tqCoreConnector.device.scan.nfc.NFC_NOT_AVAILABLE
 *
 */
define(['angular',
	'coreapi'], function (angular) {

	return angular.module('tq.scan.nfc', [
		'tq.coreapi'])

		.service('tqScanNfc', function (tqCoreConnector) {

			/**
			 * Start a scan session
			 *
			 * We use notify callback to keep receiving new scans once started a session
			 *
			 * Example usage is
			 *
			 *
			 // start a nfc session (Android only)
			 tqScanNfc.startScanningSession()
			 .then(
			 // success NOT USED because we use notify
			 function(result){},

			 // error
			 function(err){
                            if(err === 'nfc:listen:browser'){
                                // POTENTIALLY ALERT USER
                            } else {
                                // DO YOUR STUFF HERE
                            }
                        },

			 // notify > every scan ends here
			 function(result){
                           // DO YOUR STUFF HERE
                        }
			 );

			 Where notify 'result'

			 result
			 tag: Object           // optionally see the whole tag Object
			 acquired: true
			 text: String

			 And error 'err'

			 if err === tqCoreConnector.device.scan.nfc.NFC_NOT_AVAILABLE then chip is not available (we are on browser or iOS)
			 *
			 */
			this.startScanningSession = function () {
				return tqCoreConnector.device.scan.nfc.startListening();
			};


			/**
			 * Stop a scan session
			 *
			 * Example usage
			 *
			 *
			 // close a nfc session (Android only)
			 tqScanNfc.closeScanningSession()
			 .then(
			 // listener removed correctly
			 function(){
                           // DO YOUR STUFF HERE
                        },
			 // error removing listener
			 function(err) {
                            // DO YOUR STUFF HERE
                        }
			 );
			 *
			 */
			this.closeScanningSession = function () {
				return tqCoreConnector.device.scan.nfc.stopListening();
			};
		});
});