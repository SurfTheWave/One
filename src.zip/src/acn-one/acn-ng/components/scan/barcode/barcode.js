define(['angular',
	'coreapi',
	'components/popup/criticalerror/criticalerror'], function (angular) {

	return angular.module('tq.scan.barcode', [
		'tq.coreapi',
		'tq.popup.criticalerror'])

		// service will be shared across all the different directives (UIs and functionality) within this module
		.service('tqScanBarcode', function (tqCoreConnector, tqPopupCriticalError) {

			/**
			 * Launch a scan session
			 * in case of success deferred will contain
			 *
			 * result.acquired: true,
			 * result.text: 'http://www.amazon.co.uk/obqruk',
			 * result.format: 'QR_CODE'
			 *
			 * success => onScanSuccess will be called with the above result object
			 * error => onScanError will be called with the error object
			 */
			this.scan = function (onScanSuccess, onScanError) {

				// scanner works only on device
				if (TQ.device.Platform.isDevice()) {
					// access core scanner module
					tqCoreConnector.device.scan.barcode.scan()
						.then(
						function (result) {
							if (result.acquired) {
								// callback
								if (onScanSuccess && _.isFunction(onScanSuccess)) {
									onScanSuccess(result);
								} else {
									console.log('barcode:success:text= ' + result.text + ' format=' + result.format + '...specify a callback function');
								}

							} else {
								// callback
								if (onScanSuccess && _.isFunction(onScanSuccess)) {
									onScanSuccess(result);
								} else {
									console.log('barcode:success:cancelled' + ' ...specify a callback function');
								}
							}
						},
						function (err) {
							// callback
							if (onScanError && _.isFunction(onScanError)) {
								onScanError(err);
							} else {
								console.log('barcode:error: ' + err + ' ...specify a callback function');
							}
						}
					);

					// alert user is not available on browser
				} else {
					tqPopupCriticalError.show({
						title: 'Barcode Scanner',
						message: 'Barcode Scanner works only on device',
						okText: 'Ok',
						restart: false
					});
				}
			};
		})

	/**
	 *  Example usage
	 *
	 *  controller:
	 *
	 $scope.scannerSuccessCallback = function(result){
                    console.log('barcode:success:text= ' + result.text + ' format=' + result.format);
                };

	 $scope.scannerErrorCallback = function(err){};


	 template:

	 <tq-scan-barcode scanner-success-callback="scannerSuccessCallback"
	 scanner-error-callback="scannerErrorCallback">
	 </tq-scan-barcode>
	 */
		.directive('tqScanBarcode', function () {
			return {
				restrict: 'E',
				templateUrl: 'acn-one/acn-ng/components/scan/barcode/barcode.tpl.html',
				scope: {
					// optional
					loopScan: '&?',
					// callback functions (not optionals)
					onScanSuccess: '=',
					onScanError: '='
				},
				controller: function ($scope, tqScanBarcode) {
					// default values: for a boolean for example, clean solution is
					$scope.loopScan = angular.isFunction($scope.loopScan) ? $scope.loopScan() : false;

					// launch a scan or multiple subsequent scans
					$scope.scan = function () {
						// single scan
						if (!$scope.loopScan) {
							// rely on service, passing the callback actions
							tqScanBarcode.scan($scope.onScanSuccess, $scope.onScanError);

							// loop scan
						} else {
							// TODO
						}
					};
				}
			};
		});
});