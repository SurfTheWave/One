define(['angular',
	'coreapi'], function (angular) {

	return angular.module('tq.viewfullimg', ['tq.coreapi'])
		.service('tqViewFullImg', function ($rootScope, $ionicModal) {

			/**
			 * open up a fullscreen modal displaying a given url
			 * @param $scope
			 * @param url
			 * @param [text]
			 */
			this.show = function (url, text) {
				// create a scope for the tpl
				var $scope = $rootScope.$new();

				// used in the modal
				$scope.url = url;
				$scope.text = text;

				// create the modal
				$ionicModal.fromTemplateUrl('acn-one/acn-ng/components/viewfullimg/viewfullimg.tpl.html', {
					scope: $scope,
					backdropClickToClose: false

					// do not work without the ion-modal as tpl wrapper
					//,animation: 'slide-in-up',
					//backdropClickToClose: false
					// then save and open
				}).then(function (modal) {
					// save in scope
					$scope.modal = modal;

					//HACK: to keep css working without making .modal-wrapper a global style.
					modal.el.classList.add('full-image');

					// show the modal
					$scope.modal.show();
				});

				// every time we remove it when closing it down in order to free up memory
				$scope.closeModal = function () {
					// hide
					$scope.modal.hide();
					// remove
					$scope.modal.remove();
				};

				// cleanup the modal in the case we change state
				$scope.$on('$ionicView.leave', function () {
					$scope.modal.remove();
				});
			};
		});
});    