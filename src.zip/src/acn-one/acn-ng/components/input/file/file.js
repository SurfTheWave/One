define(['angular',
    'exif-js',
    'acnNg/components/popup/generic/popup',
    'angularTranslate'], function (angular) {
    return angular.module('tq.input.file', ['acn.popup', 'pascalprecht.translate'])
        .directive('tqInputFileAttachment', ['$parse', '$window', 'acnPopup', '$translate', function ($parse, $window, acnPopup, $translate) {
            return {
                restrict: 'A',
                link: function(scope, element, attr){
                    var inputId = 'input:file:' + Math.round((Math.random() * 10000000));
                    var fileFilter = attr.accept;
                    var canvas = document.createElement('canvas');
                    var compressionRate = !!attr['tqDisableCompression'] ? 1.0 : 0.7 ;

                    var inputFile = angular.element('<input type="file" capture="camera" class="tq-file-input" id="' + inputId + '" +' +
                        ((!!fileFilter) ? ('accept="' + fileFilter + '"') : '') + ' />');
                    //element.after(inputFile);

                    var inputLabel = angular.element('<label class="tq-file-input-label" for="' + inputId + '"></label>');
                    inputLabel.append(inputFile);
                    element.append(inputLabel);
                    element.addClass('tq-file-input-container');

					inputFile.bind('click', function onFileInputClickHandler(clickEvent) {

						if (!$window.navigator.onLine) {

							$translate([
								'FILE_UPLOAD_DISABLED_OFFLINE_TITLE',
								'FILE_UPLOAD_DISABLED_OFFLINE_BODY'
							])
								.then(function onFileInputTranslationsReceived(theTranslationsMap) {

								acnPopup.show({
									title: theTranslationsMap.FILE_UPLOAD_DISABLED_OFFLINE_TITLE,
									template: theTranslationsMap.FILE_UPLOAD_DISABLED_OFFLINE_BODY
								});
							});

							clickEvent.preventDefault();
							clickEvent.stopPropagation();
						}
					});

                    var isRotationRequired = function(file){
                        return file.type === 'image/jpeg' && /iPad|iPhone|iPod/.test(navigator.platform);
                    };

                    function getNormalizedDimensions(width, height) {
                        var max = {
                            w: parseInt(attr['tqMaxWidth']) || 850,
                            h: parseInt(attr['tqMaxHeight']) || 315
                        };
                        var ratio = 0;
                        if (width > max.w) {
                            ratio = max.w / width;
                            width = max.w;
                            height = height * ratio;
                        }
                        if (height > max.h) {
                            ratio = max.h / height;
                            height = max.h;
                            width = width * ratio;
                        }
                        return {
                            width: Math.floor(width),
                            height: Math.floor(height)
                        };
                    }

                    inputFile.bind("change", function (changeEvent) {
                        var files = (!!changeEvent.target.files) ? changeEvent.target.files : [];
                        if ( !files.length || !window.FileReader ) {
                            return;
                        }

                        var fn = $parse(attr['tqInputFileAttachment']);
                        var testRegexp = /^image/;
                        if (!!fileFilter){
                            fileFilter = fileFilter.replace(',', '|');
                            fileFilter.replace('*', '.*');
                            testRegexp = new RegExp('^' + fileFilter + '$', 'i');
                        }

                        if ( testRegexp.test( files[0].type ) ) {
                            var url = window.URL ? window.URL : window.webkitURL;
                            var image = new Image();
                            image.onload = function(result) {
                                var width = image.width, height = image.height, transform;

                                EXIF.getData(image, function() {
                                    var orientation = EXIF.getTag(this, "Orientation");
                                    if (orientation === 8) {
                                        width = image.height;
                                        height = image.width;
                                        transform = "left";
                                    } else if (orientation === 6) {
                                        width = image.height;
                                        height = image.width;
                                        transform = "right";
                                    } else if (orientation === 3) {
                                        transform = "flip";
                                    }

                                    var newDimensions = getNormalizedDimensions(width, height);
                                    canvas.width = width = newDimensions.width;
                                    canvas.height = height = newDimensions.height;

                                    var ctx = canvas.getContext("2d");
                                    ctx.fillStyle = 'white';
                                    ctx.fillRect(0, 0, width, height);
                                    if(transform === 'left') {
                                        ctx.setTransform(0, -1, 1, 0, 0, height);
                                        ctx.drawImage(image, 0, 0, height, width);
                                    } else if(transform === 'right') {
                                        ctx.setTransform(0, 1, -1, 0, width, 0);
                                        ctx.drawImage(image, 0, 0, height, width);
                                    } else if(transform === 'flip') {
                                        ctx.setTransform(1, 0, 0, -1, 0, height);
                                        ctx.drawImage(image, 0, 0, width, height);
                                    } else {
                                        ctx.setTransform(1, 0, 0, 1, 0, 0);
                                        ctx.drawImage(image, 0, 0, width, height);
                                    }
                                    ctx.setTransform(1, 0, 0, 1, 0, 0);

                                    var resultUrl = canvas.toDataURL(files[0].type, compressionRate);
                                    scope.$apply(function () {
                                        changeEvent.dataUrl = resultUrl;
                                        changeEvent.dataBase64 = resultUrl.replace(/data:.*?;base64,/, '');
                                        changeEvent.originalName = files[0].name;
                                        fn(scope, {$event: changeEvent});
                                    });
                                });
                            };
                            image.src = url.createObjectURL(files[0]);
                        } else {
                            alert('Selected file has a wrong format');
                        }
                    });

                }
            };
        }]);
});
