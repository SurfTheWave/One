define(['angular'], function (angular) {
	return angular.module('tq.input.datetime', [])
		.directive('tqInputDatetime', function () {
			return {
				restrict: 'E',
				scope: {
					date: '='
				},
				templateUrl: 'acn-one/acn-ng/components/input/datetime/datetime.tpl.html',
				controller: function ($scope, $filter) {
					// on start converts the js datetime into string (ready for ui input)
					$scope.$watch('$scope.date', function () {
						// date present
						if ($scope.date) {
							var dateValue = new Date($scope.date);
							if (_.isDate(dateValue) && !_.isNaN(dateValue.getTime())) {
								$scope.timezone = $scope.date.toString().split(' ').splice(5, 2);
								$scope.formattedDate = $filter('date')($scope.date, 'yyyy-MM-ddTHH:mm:ss');
							}
							// date is null
						} else {
							$scope.formattedDate = '';
						}
					});

					// when datetime is entered, convert the string it into js datetime (ready for storage)
					$scope.dateChanged = function () {
						if ($scope.formattedDate === '') {
							$scope.date = null;
						} else {
							var date = $scope.formattedDate.split('T')[0].split('-').join('/');
							var time = $scope.formattedDate.split('T')[1];

							var datetime = date + ' ' + time;

							$scope.dateWithDefaultTimezone = new Date(datetime).toString().split(' ');
							$scope.dateWithDefaultTimezone.splice(5, 2);

							$scope.date = new Date($scope.dateWithDefaultTimezone.concat($scope.timezone).join(' '));
						}
					};
				}
			};
		});
});