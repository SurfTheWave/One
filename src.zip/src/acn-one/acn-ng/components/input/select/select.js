define([
	'angular',
	'uiRouter',
	'coreapi',
	'components/list/search/search',
	'components/list/sort/sort',
	'components/list/item/item'
], function (angular) {
	return angular.module('tq.input.select', [
		'ui.router',
		'tq.coreapi',
		'tq.list.search',
		'tq.list.sort',
		'tq.list.item'
	])
		.directive('tqInputSelect', function () {
			return {
				restrict: 'E',
				replace: 'true',
				templateUrl: 'acn-one/acn-ng/components/input/select/select.tpl.html',
				scope: {
					itemList: '=',
					selectedItem: '=',
					itemChange: '&',
					sortable: '=',
					objectApiName: '&'
				},
				controller: function ($scope) {
					$scope.objectApiName = $scope.objectApiName();

					$scope.reverse = false;
					$scope.search = {keyword: ''};

					$scope.sort = function () {
						$scope.reverse = !$scope.reverse;
					};

					$scope.isSelected = function (item) {
						return item === $scope.selectedItem;
					};

					$scope.click = function (item) {
						$scope.selectedItem = item;
						$scope.itemChange();
					};
				}
			};
		});
});