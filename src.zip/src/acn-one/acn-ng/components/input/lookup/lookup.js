define(['angular', 'coreapi', 'components/list/list', 'components/list/item/item'], function (angular) {
	// accenture-one module contains the tqCoreConnector service
	return angular.module('tq.input.lookup', ['tq.coreapi', 'tq.list', 'tq.list.item'])
		// this directive is made of two tpls controlled by one single controller
		// note that each time we use the directive (ex in a ng-repeat) this is a new instance!!
		.controller('TqLookupCtrl', function TqLookupCtrl($scope, $ionicModal, tqCoreConnector, $timeout) {
			// hide in the lookup.tpl what is the value of the input
			$scope.fieldValue = $scope.record.rawRecord[$scope.fieldApiName];
			// value actually displayed to the user
			$scope.displayValue = null;

			$scope.getDisplayValue = function () {
				tqCoreConnector.storage.generateParentRecordMap($scope.record).then(
					function (parentRecordMap) {
						$scope.parentRecordsMap = parentRecordMap;
						parentMapEntry = $scope.parentRecordsMap[$scope.fieldApiName];
						$scope.displayValue = parentMapEntry ? parentMapEntry.parentRecordName : null;
						// in order to always have the reference field to show correctly the information
						$timeout(function () {
							$scope.$apply();
						});
					},
					function (err) {
						// TODO error finding any of the parent records
					}
				);
			};

			// TODO find a way to have direct binding working (bind to the record.rawRecord[fieldApiName]
			$scope.$watch('fieldValue', function (newValue, oldValue) {
				// update back the upper scope rawRecord[fieldApiName] once we update the value
				$scope.record.rawRecord[$scope.fieldApiName] = newValue;
				// change the displayValue
				$scope.getDisplayValue();
			});

			// work out the parentObjectApiName given the fieldApiName and record (contains the objectApiName of the current record)
			$scope.parentObjectApiName = tqCoreConnector.metadata.getFieldMetadata($scope.record.objectApiName, $scope.fieldApiName).referenceTo[0];

			// header label
			$scope.getHeaderLabel = function () {
				// second parameter specifies to get the plural label
				return tqCoreConnector.metadata.getTrackedObjectLabel($scope.parentObjectApiName, true);
			};

			// open the actual lookup list
			$scope.openModal = function () {

				// open modal only if the store is available
				if (tqCoreConnector.storage.storeExist($scope.parentObjectApiName)) {
					// load modal
					if (!$scope.modal) {

						$ionicModal.fromTemplateUrl('acn-one/acn-ng/components/input/lookup/lookupmodal.tpl.html', {
							scope: $scope,
							animation: 'slide-in-up',
							backdropClickToClose: false,
							focusFirstInput: false
							// async
						}).then(function (modal) {

							$scope.modal = modal;

							$scope.closeModal = function () {
								// remove to avoid memory leaks
								$scope.modal.remove();
								// remove doesn't null the modal
								$scope.modal = null;
							};

							$scope.clearValue = function () {
								$scope.setPickedValue(null);
							};

							$scope.setPickedValue = function (tqRecord) {
								// set value (NEEDS TO BE WATCHED TO BE PLAYED BACK TO PARENT)
								$scope.fieldValue = tqRecord.rawRecord.Id;
								// close
								$scope.closeModal();
							};

							// show modal first time
							$scope.modal.show();
						});

						// second time
					} else {
						$scope.modal.show();
					}
				} else {
					if ($scope.errorList !== undefined && $scope.errorList !== null) {
						// NOTE only push will update the parent var value... assignment doesn't work
						$scope.errorList.push($scope.fieldApiName + ' refers to an Object not synchronized. Contact your admin in order to enable it');
					}
				}
			};
		})
		// define the directive object within the module (this controls the tpl of the input field)
		.directive('tqInputLookup', function () {
			return {
				// we use it as html element (tq-list-lookup)
				restrict: 'E',
				// template (root is the app folder)
				templateUrl: 'acn-one/acn-ng/components/input/lookup/lookup.tpl.html',
				// define the scope vars
				scope: {
					fieldApiName: '=',
					record: '=',
					// optional
					errorList: '=?'
				}
			};
		});
});