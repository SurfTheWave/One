define([
	'angular',
	'uiRouter',
	'coreapi',
	'components/list/search/search',
	'components/list/sort/sort',
	'components/list/item/item'
], function (angular) {
	return angular.module('tq.input.multiselect', [
		'ui.router',
		'tq.coreapi',
		'tq.list.search',
		'tq.list.sort',
		'tq.list.item'
	])
		.directive('tqInputMultiselect', function () {
			return {
				restrict: 'E',
				replace: 'true',
				templateUrl: 'acn-one/acn-ng/components/input/multiselect/multiselect.tpl.html',
				scope: {
					itemList: '=',
					selectedItems: '=',
					done: '&',
					cancel: '&',
					sortable: '=',
					objectApiName: '&'
				},
				controller: function ($scope) {
					$scope.objectApiName = $scope.objectApiName();
					$scope.reverse = false;
					$scope.search = {keyword: ''};

					$scope.isSelected = function (item) {
						return _.includes($scope.selectedItems, item);
					};

					$scope.sort = function () {
						$scope.reverse = !$scope.reverse;
					};

					$scope.click = function (selectedItem) {
						if ($scope.selectedItems.indexOf(selectedItem) > -1) {
							$scope.selectedItems.splice($scope.selectedItems.indexOf(selectedItem), 1);
						} else {
							$scope.selectedItems.push(selectedItem);
						}
					};
				}
			};
		});
});