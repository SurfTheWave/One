define(['angular'], function (angular) {
	return angular.module('tq.input.date', [])
		.directive('tqInputDate', function () {
			return {
				restrict: 'E',
				scope: {
					date: '=',
                    dateFormat: '@?'
				},
				templateUrl: 'acn-one/acn-ng/components/input/date/date.tpl.html',
				controller: function ($scope, $filter) {
                    var getFormat = function(){
                        return $scope.dateFormat || 'yyyy-MM-dd';
                    };

					$scope.$watch('$scope.date', function () {
						var dateValue = new Date($scope.date);
						if (_.isDate(dateValue) && !_.isNaN(dateValue.getTime())) {
							$scope.formattedDate = $filter('date')(dateValue, $scope.format);
						}
					});

                    $scope.getPlaceholder = function(){
                        $scope.format = $scope.dateFormat || 'yyyy-MM-dd';
                        return $scope.format.toLowerCase();
                    };

					$scope.dateChanged = function () {
						if ($scope.formattedDate === '') {
							$scope.date = null;
						}
						else {
							$scope.date = new Date($scope.formattedDate);
						}
					};
				}
			};
		});
});