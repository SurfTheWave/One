import template from './footer.tpl.html';
define(['angular'], function (angular) {
    return angular.module('tq.footer', [])
        .directive('tqFooter', function () {
            return {
                restrict: 'E',
                template: template,
                controller: function($scope, tqCoreConnector) {
                    // outside VF
                    $scope.logoutAvailable = true;
                    $scope.syncIconClass = 'icomoon-synced';

                    var sessionId = window.accentureONECore ? window.accentureONECore.sessionId : null;
                    // within VF
                    if (sessionId !== "{!$Api.Session_Id}") {
                        $scope.logoutAvailable = false;
                    }

                    var refreshSyncIcon = function () {
                        var syncStatus = tqCoreConnector.syncstatus.getSyncStatus();

                        if (syncStatus === tqCoreConnector.syncstatus.SYNCHRONIZING) {
                            $scope.syncIconClass = 'icomoon-syncing';
                        } else {
                            var onlinePart = tqCoreConnector.appstatus.isOnline() ? '' : '-outline';
                            var syncPart = 'ion-ios-cloud';

                            switch (syncStatus) {
                                case tqCoreConnector.syncstatus.SYNCHRONIZED:
                                    syncPart = 'ion-ios-cloud';
                                    break;
                                case tqCoreConnector.syncstatus.AWAITING_SYNCHRONIZATION:
                                    syncPart = 'ion-ios-cloud-upload';
                                    break;
                                case tqCoreConnector.syncstatus.SYNC_ERROR:
                                    syncPart = 'ion-ios-thunderstorm';
                                    break;
                            }

                            $scope.syncIconClass =  syncPart + onlinePart ;
                        }
                    };

                    tqCoreConnector.syncstatus.onSyncStatusChange(refreshSyncIcon);
                    tqCoreConnector.appstatus.connectionStatusChanged(refreshSyncIcon);
                    refreshSyncIcon();
                }
            };
        });
});
