define([
	'angular',
	'coreapi'], function (angular) {

	return angular.module('tq.redirector', [
		'ionic',
		'tq.coreapi'])

		.service('tqRedirector', function ($rootScope, $state, $location, $injector, $q) {
			var routeMethods = [];
			var stateReplacements = {};
            var _routeRedirectMethod = null;

			this.processRequset = function (event, toState, toParams, fromState, fromParams) {
				if (stateReplacements[toState.name]) {
					var newState = stateReplacements[toState.name];

					for (var keyToReplace in newState) {
						var replacement = newState[keyToReplace];

						if (_.isFunction(replacement)) {
							var replacementResult = replacement(toParams);
							if (replacementResult) {
								toState[keyToReplace] = replacementResult;
							}
						}
						else if (replacement) {
							toState[keyToReplace] = replacement;
						}
					}
				}

				this.processRouteMethods(event, toState, toParams, fromState, fromParams);
			};

			this.processRouteMethods = function (event, toState, toParams, fromState, fromParams) {
				for (var index in routeMethods) {
					var redirectionRuleCheckMethod = routeMethods[index];
					if (_.isFunction(redirectionRuleCheckMethod)) {
						var redirectScope = redirectionRuleCheckMethod(toState, toParams, fromState, fromParams);
						if (redirectScope) {
							event.preventDefault();
							return $state.go(redirectScope);
						}
					}
				}
			};

			this.addRuleMethod = function (method) {
				routeMethods.push(method);
				return this;
			};

			this.state = function (scopeName, scopeParams) {
				stateReplacements[scopeName] = scopeParams;
				return this;
			};

			this.clearState = function () {
			//	$location.path('');
			};

			this.saveCurrentState = function () {
				$rootScope.preActivationState = $location.path();
			};

            this.setRouteRedirectMethod = function(method){
                _routeRedirectMethod = method;
            };

			// routing on bootstrap/activation
			this.routeToStartState = function () {
				// avoid routing to login or activation (happens in case of errors)
				if ($rootScope.preActivationState &&
					$rootScope.preActivationState != '/' &&
					$rootScope.preActivationState.indexOf('login') === -1 &&
					$rootScope.preActivationState.indexOf('activation') === -1) {

			//		$location.path($rootScope.preActivationState);
				} else if (_routeRedirectMethod){
                    $q.when($injector.invoke(_routeRedirectMethod)).then(function(resultLocation){
           //             $location.path(resultLocation);
                    }, function(error){
                        console.log(error);
                    });
                } else {
			//		$location.path(TQ.config.Client.defaultStartState);
				}
			};
		});
});