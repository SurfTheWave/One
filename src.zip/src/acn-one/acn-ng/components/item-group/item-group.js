define(['angular'], function (angular) {

	return angular.module('tq.item-group', [])

		.controller('TqItemGroupDirectiveCtrl', function TqItemGroupDirectiveCtrlFactory($scope, $timeout, $ionicScrollDelegate) {

			var self = this;

			this.resizeScrollersAsync = function () {
				$timeout(function () {
					$ionicScrollDelegate.resize();
				}, 300);
			};

			/**
			 * If given group is the selected group, deselect it else, select the given group
			 */
			$scope.toggleGroup = function (group) {
				group.show = !group.show;
				self.resizeScrollersAsync();
			};

			$scope.isGroupShown = function (group) {
				return group.show;
			};
		})

	/**
	 * Usage example:
	 *
	 * <code>
	 *
	 *        <tq-item-group tq-item-groups="theItemGroups"
	 *            tq-item-group-header-class="topsLeftMenuSubTitle"
	 *            tq-item-group-member-click="onTheClick"
	 *            tq-item-group-member-class="topsLeftMenuSubTitle">
	 *        </tq-item-group>
	 *
	 * </code>
	 *
	 */
		.directive('tqItemGroup', function TqItemGroupDirectiveFactory() {
			return {
				restrict: 'E',
				templateUrl: 'acn-one/acn-ng/components/item-group/item-group.tpl.html',
				controller: 'TqItemGroupDirectiveCtrl',
				scope: {

					/**
					 * This parameter has to be an {@code Array} of {@code Object}s that hold the groups and their items.
					 * Usage example:
					 * <code>
					 *    [
					 *
					 *    {
					 *	label: 'Group 1',
					 *	items: [{label: 'Allocations', ngHref: '#/profile/allocations'}, {label: 'Item 1/2'}, {label: 'Item 1/3'}],
					 *	show: false
					 *	},
					 *
					 *  {
					 *	label: 'Group 2',
					 *	items: [{label: 'Skills', ngHref: '#/profile/skills'}, {label: 'Item 2/2'}, {label: 'Item 2/3'}],
					 *		show: false
					 *	}
					 *    ]
					 * </code>
					 *
					 */
					tqItemGroups: '=',

					/**
					 * The reference to a function that will be called whenever a group member item is clicked on.
					 *
					 * Example definition of such a Javascript method:
					 * <code>
					 * $scope.onTheClick = function ($event, item, groupItems, group) {
					 * 		console.warn('OMG SOMEONE CLICKED ME! ', $event, item, groupItems, group);
					 * };
					 * </code>
					 */
					tqItemGroupMemberClick: '=',

					/**
					 * CSS class name that will be added to the group header items of the groups.
					 * Backed by ng-class under the hood.
					 */
					tqItemGroupHeaderClass: '@',

					/**
					 * CSS class name that will be added to the group member items of the groups.
					 * Backed by ng-class under the hood.
					 */
					tqItemGroupMemberClass: '@'
				}
			};
		});
});