define(['angular',
	'coreapi', 'jcarousel'], function (angular) {

	return angular.module('tq.carousel', [
		'tq.coreapi'])
		 .service('tqCarouselDelegate', ionic.DelegateService([
	        'setImages',
            'onItemClick'
	    ]))
		.directive('tqCarousel', function ($timeout, tqCarouselDelegate) {
			return {
				restrict: 'A',
				replace: true,
				transclude: false,
				scope: {
				images: "="
			},
			templateUrl: 'acn-one/acn-ng/components/carousel/carousel.tpl.html',
			link: function link(scope, element, attrs) {
				var container = $(element);
				var carousel = container.children('.jcarousel');
                var onClickDelegateMethod = null;

				carousel.jcarousel({
					wrap: 'circular'
				}).on('jcarousel:reload jcarousel:create', function () {
                	var carousel = $(this), width = carousel.innerWidth();

                	var elementsPerWindow = 1;

	                if (width <= 400) {
	                    elementsPerWindow = 1;
	                } else {
	                    elementsPerWindow = Math.ceil((width - 200) / 200);
	                }

	                var children = carousel.find('li');
	                if (children.length < elementsPerWindow){
	                	elementsPerWindow = children.lengthhey;
	                }

	                children.css('width', Math.ceil(width / elementsPerWindow) + 'px');
    	        });

                scope.elementClick = function(id){
                    if (angular.isFunction(onClickDelegateMethod)){
                        onClickDelegateMethod(id);
                    }
                };
            
				scope.$watch(attrs.images, function (value) {
					$timeout(function(){
						carousel.jcarousel('reload');
					}, 50);
				});

				container.find('.jcarousel-control-prev').jcarouselControl({
					target: '-=1'
				});

				container.find('.jcarousel-control-next').jcarouselControl({
					target: '+=1'
				});

				var delegateHandle = {
                    setImages: function(images) {
                    	scope.images = images;
                    	$timeout(function(){
							carousel.jcarousel('reload');
						}, 50);
                    },
                    onItemClick: function(method){
                        onClickDelegateMethod = method;
                        return function(){
                            if (method == onClickDelegateMethod){
                                onClickDelegateMethod = null;
                            }
                        };
                    }
                };

				var deregisterInstance = null;
                if(attrs.tqCarousel) {
                    deregisterInstance = tqCarouselDelegate._registerInstance(delegateHandle, attrs.tqCarousel);
                }

                scope.$on('$destroy', function(){
                    if(angular.isFunction(deregisterInstance)) {
                        deregisterInstance();
                        deregisterInstance = null;
                    }
                    if (angular.isFunction(onClickDelegateMethod)){
                        onClickDelegateMethod = null;
                    }
                    scope.pathElements = null;
                    scope.element = null;
                });
			}
		};
	});
});