define(['angular',
	'coreapi',
	'components/popup/criticalerror/criticalerror',
	'components/analytics/analytics',
	'components/loading/loading',
	'components/redirector/redirector',
	'components/translations/translations'
], function(angular) {

	return angular.module('tq.bootstrap', [
		'tq.coreapi',
		'tq.translations',
		'tq.analytics',
		'tq.loading',
		'tq.redirector',
		'tq.popup.criticalerror'
	])

	.provider('tqBootstrap', function tqBootstrapProvider() {
		var activationPage = '/tqactivation';
		var thisTqBootstrap;
		var activationFinishedDeferredList = [];
		var coreBootstrapFinishDeferredList = [];

		this.setDefaultActivationPage = function(defaultActivationPage) {
			activationPage = defaultActivationPage;
			return this;
		};

		//Add task which should be executed after activation will finish.
		//Could be simple function or promise
		//In this case bootstrap will finish only when this task will be done
		this.addTaskOnActivationFinish = function(eventHandlingMethod) {
			activationFinishedDeferredList.push(eventHandlingMethod);
			return this;
		};


		//Add task which should be executed after core bootstrap, no matter if user activated or not.
		//Could be simple function or promise
		//In this case bootstrap will finish only when this task will be done
		this.addTaskOnCoreBootstrapFinish = function(eventHandlingMethod) {
			coreBootstrapFinishDeferredList.push(eventHandlingMethod);
			return this;
		};

		this.$get = function($rootScope, $location, $timeout, tqCoreConnector, tqPopupCriticalError, $q,
			tqRedirector, $translate, tqLoading, $injector) {

			var processBootstrapError = function(error) {
				// remove loading
				tqLoading.hide();

				if (error && error.code !== -100) {
					// critical error - restart
					tqPopupCriticalError.show({
						title: '',
						message: $translate.instant('REPORT_IF_ISSUE_PERSISTS')
					});
				}
			};

			if (!thisTqBootstrap) {
				thisTqBootstrap = {
					loginPage: '/',
					loginParams: {},
					setDefaultLoginPage: function(defaultLoginPage, defaultLoginParams) {
						this.loginPage = defaultLoginPage;
						if (defaultLoginParams) {
							this.loginParams = defaultLoginParams;
						}
						//return this;
					},
					// start the process from authentication check
					// - manual
					// - auto via refresh token
					start: function() {

                        thisTqBootstrap.authenticate();

						// save the deep link for later (once activation is finished)
						//tqRedirector.saveCurrentState();
						// stop routing to deep link
						//tqRedirector.clearState();

						// redirect to user manual authentication
						//if (!tqCoreConnector.session.isAuthenticated()) {
							// $location.path(this.loginPage, this.loginParams, {
							// 	relative: null
							// });

							// run auto authentication
						//} else {
						//	thisTqBootstrap.authenticate();
						//}
					},

					getLoginPage: function() {
						return this.loginPage;
					},

					getActivationPage: function() {
						return activationPage;
					},

					// bootstrap core services
					// - logger
					// - metadata
					// - settings
					// - scheduler
					// - logging
					coreBootstrap: function() {

						// add loading
						tqLoading.show();

						tqCoreConnector.bootstrap.start()
							.then(
								function onSuccess() {
									thisTqBootstrap.executeTasksAfterCoreBootstrap().then(
										function onSuccess() {
											// app can start
											if (tqCoreConnector.appstatus.isActivated()) {
												thisTqBootstrap.executePostActivationTasks();
											} else {
												// remove loading
												tqLoading.hide();
												// route to activation
												$location.path(activationPage);

												$timeout(function() {
													$rootScope.$broadcast('tqBootstrapFinished');
												}, 800);
											}
										},
										processBootstrapError
									);
								},
								// error
								processBootstrapError
							);

					},

					//Execute list of tasks definfed to be executed after core bootstrap + activation will finish
					executePostActivationTasks: ['$q', '$injector', function(executedAfterActivation) {
						var deferredList = [];
						angular.forEach(activationFinishedDeferredList, function(promiseMethod) {
							deferredList.push($q.when($injector.invoke(promiseMethod)));
						});

						return $q.all(deferredList).then(function() {
							if (!executedAfterActivation) {
								tqLoading.hide();
								$timeout(function() {
									$rootScope.$broadcast('tqBootstrapFinished');
								}, 800);
							}

							tqRedirector.routeToStartState();
						}, processBootstrapError);
					}],

					//Execute list of tasks definfed to be executed after core bootstrap will finish
					executeTasksAfterCoreBootstrap: function() {
						var deferredList = [];
						angular.forEach(coreBootstrapFinishDeferredList, function(promiseMethod) {
							deferredList.push($q.when($injector.invoke(promiseMethod)));
						});

						return $q.all(deferredList);
					},

					// core authentication
					authenticate: function(environment) {

						// add loading
						tqLoading.show();

						tqCoreConnector.session.login(environment)
							.then(
								// success
								function() {
									// bootstrap the core services
									thisTqBootstrap.coreBootstrap();
								},
								// error
								processBootstrapError
							);

					}
				};
			}

			return thisTqBootstrap;
		};
	});
});