define([
	'angular',
], function (angular) {

	return angular.module('tq.loading', []).service('tqLoading',
		function ($ionicLoading, $document) {
            var getSplashScreen = function(){
                return angular.element($document).find('#SPLASHSCREEN');
            };

			return {
				show: function () {
                    var splashscreen = getSplashScreen();
                    if (!splashscreen || !splashscreen.length){
                        $ionicLoading.show({
                            template: '<ion-spinner icon="spiral"></ion-spinner>'
                        });
                    } else {
                        splashscreen.show();
                    }

				},
				hide: function () {
                    var splashscreen = getSplashScreen();
                    if (!splashscreen || !splashscreen.length){
                        $ionicLoading.hide();
                    } else {
                        splashscreen.find('.tq-after-hide').remove();
                        splashscreen.remove();
                    }
				}
			};
		});

});
