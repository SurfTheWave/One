import template from './hero-profile-picture.tpl.html';
define([
	'angular',
	'angularTranslate',
	'ionic',
	'coreapi',
	'components/loading/loading',
	'acnNg/components/input/file/file',
	'acnNg/components/popup/generic/popup'
], function (angular) {

	'use strict';

	return angular.module('tq.hero-profile-picture', [
		'tq.input.file',
		'ionic',
		'pascalprecht.translate',
		'acn.popup'
	])

		.directive('tqHeroProfilePicture', function () {
			return {
				restrict: 'EA',
				controller: 'TqHeroProfilePictureCtrl',
				template: template,
				scope: {
					tqUserName: '@',
					tqUserProfileImageUrl: '@',
					tqUpdatingPhotoLabel: '@',
					tqAvatarUpdatedLabel: '@',
					tqAvatarUpdatedBodyLabel: '@',
					tqAvatarUploadFailedTitleLabel: '@',
					tqAvatarUploadFailedGenericBodyLabel: '@',
					tqAvatarUploadFailedTooBigLabel: '@',
					tqWrapperClass: '@',
					tqProfileBlurBackgroundClass: '@',
					tqProfilePictureChangeClass: '@',
					tqProfilePictureClass: '@',
					tqAvatarUserNameClass: '@',
					tqAvatarChangeTextClass: '@'
				},
				link: function (scope, element, attr) {
				}
			};
		})

		.controller('TqHeroProfilePictureCtrl', function TqHeroProfilePictureCtrlFactory($rootScope, $scope, $timeout, $ionicLoading, $translate, tqCoreConnector, acnPopup) {

			var self = this;

			this.init = function () {
				self.tqUpdatingPhotoLabel = _.isString($scope.tqUpdatingPhotoLabel) ? $scope.tqUpdatingPhotoLabel : 'UPDATING_PHOTO';
				self.tqAvatarUpdatedLabel = _.isString($scope.tqAvatarUpdatedLabel) ? $scope.tqAvatarUpdatedLabel : 'AVATAR_UPDATED';
				self.tqAvatarUpdatedBodyLabel = _.isString($scope.tqAvatarUpdatedBodyLabel) ? $scope.tqAvatarUpdatedBodyLabel : 'AVATAR_UPDATED_BODY';
				self.tqAvatarUploadFailedTitleLabel = _.isString($scope.tqAvatarUploadFailedTitleLabel) ? $scope.tqAvatarUploadFailedTitleLabel : 'AVATAR_UPLOAD_FAILED_TITLE';
				self.tqAvatarUploadFailedGenericBodyLabel = _.isString($scope.tqAvatarUploadFailedGenericBodyLabel) ? $scope.tqAvatarUploadFailedGenericBodyLabel : 'AVATAR_UPLOAD_FAILED_GENERIC_BODY';
				self.tqAvatarUploadFailedTooBigLabel = _.isString($scope.tqAvatarUploadFailedTooBigLabel) ? $scope.tqAvatarUploadFailedTooBigLabel : 'AVATAR_UPLOAD_FAILED_TOO_BIG_BODY';


				self._fetchPromise = self.fetch();
			};

			this.fetch = function () {
				return self.fetchTranslations();
			};

			this.fetchTranslations = function () {

				return $translate([
					self.tqUpdatingPhotoLabel,
					self.tqAvatarUpdatedLabel,
					self.tqAvatarUpdatedBodyLabel,
					self.tqAvatarUploadFailedTitleLabel,
					self.tqAvatarUploadFailedGenericBodyLabel,
					self.tqAvatarUploadFailedTooBigLabel

				]).then(function onTranslationDone(theTranslationsMap) {

					self.tqUpdatingPhotoLabel = theTranslationsMap[self.tqUpdatingPhotoLabel] || self.tqUpdatingPhotoLabel;
					self.tqAvatarUpdatedLabel = theTranslationsMap[self.tqAvatarUpdatedLabel] || self.tqAvatarUpdatedLabel;
					self.tqAvatarUpdatedBodyLabel = theTranslationsMap[self.tqAvatarUpdatedBodyLabel] || self.tqAvatarUpdatedBodyLabel;
					self.tqAvatarUploadFailedTitleLabel = theTranslationsMap[self.tqAvatarUploadFailedTitleLabel] || self.tqAvatarUploadFailedTitleLabel;
					self.tqAvatarUploadFailedGenericBodyLabel = theTranslationsMap[self.tqAvatarUploadFailedGenericBodyLabel] || self.tqAvatarUploadFailedGenericBodyLabel;
					self.tqAvatarUploadFailedTooBigLabel = theTranslationsMap[self.tqAvatarUploadFailedTooBigLabel] || self.tqAvatarUploadFailedTooBigLabel;
				});
			};

			$scope.backgroundImageCss = function () {
				return 'url(' + $scope.tqUserProfileImageUrl + ')';
			};

			$scope.saveUserAvatarToServer = function (event) {

				self._fetchPromise.then(function onFetchPromiseResolved() {

					var imageUrl = event.dataUrl;

					$ionicLoading.show($scope.tqUpdatingPhotoLabel);

					tqCoreConnector.user.updateUserAvatar(event.dataUrl).then(
						function (photoData) {

							$timeout(function () {

								$ionicLoading.hide();

								acnPopup.show({
									title: self.tqAvatarUpdatedLabel,
									template: self.tqAvatarUpdatedBodyLabel

								}).then(function () {

									$timeout(function () {

										$scope.tqUserProfileImageUrl = photoData.smallPhotoUrl;

										$rootScope.$broadcast('user-profile-updated',
											{UserPhotoData: photoData, dataUrl: imageUrl});
									}, 1000);
								});
							}, 2000);
						},
						function (error) {
							$ionicLoading.hide();
							console.log(error);

							if (error.status === 0) {

								$translate([
									'FILE_UPLOAD_DISABLED_OFFLINE_TITLE',
									'FILE_UPLOAD_DISABLED_OFFLINE_BODY'
								])
									.then(function onFileInputTranslationsReceived(theTranslationsMap) {

										acnPopup.show({
											title: theTranslationsMap.FILE_UPLOAD_DISABLED_OFFLINE_TITLE,
											template: theTranslationsMap.FILE_UPLOAD_DISABLED_OFFLINE_BODY
										});
									});
							} else {

								var seemsLikeTheProblemIsFileSize = error.responseText.indexOf('dimensions are too large') > -1;

								if (seemsLikeTheProblemIsFileSize) {
									acnPopup.show({
										title: self.tqAvatarUploadFailedTitleLabel,
										template: self.tqAvatarUploadFailedTooBigLabel
									});
								} else {
									acnPopup.show({
										title: self.tqAvatarUploadFailedTitleLabel,
										template: self.tqAvatarUploadFailedGenericBodyLabel
									});
								}
							}

							tqCoreConnector.device.file.removeFile(imageUrl);
						}
					);
				});


			};

			self.init();
		});
});
