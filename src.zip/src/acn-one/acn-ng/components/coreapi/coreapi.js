define([
	'angular',
	'acnCore/connector'

], function (angular) {

	return angular.module('tq.coreapi', [])
		.service('tqCoreConnector', function ($q) {

			this.errors = TQ.Connector.errors;

			/**
				@class NG.tqCoreConnector.bootstrap
			*/
			this.bootstrap = {
				/**
				 	@private
					Starts the bootsreap of the application
					@return {$q.promise} executes when bootstrap finishes
				*/
				'start': function () {
					return $q.when(TQ.Connector.bootstrap.start());
				}
			};

			/**
				@class NG.tqCoreConnector.device
			*/
			this.device = {
				connection: {
					'OFFLINE': TQ.Connector.device.connection.OFFLINE
				},
				share: {
					ShareType: TQ.Connector.device.share.ShareType,
					shareVia: function (shareType, messageText, imageUrl, link) {
						return $q.when(TQ.Connector.device.share.shareVia(shareType, messageText, imageUrl, link));
					}
				},
				/**
					@class NG.tqCoreConnector.device.platform
				*/
				platform: {
					/**
						Tell whether you are running your code on a hybrid mobile app or as web app
						@return {Boolean} true if is a mobile device; false otherwise
					*/
					'isDevice': function () {
						return TQ.Connector.device.platform.isDevice();
					},
					/**
						Tell whether you are on iOS or not
						@return {Boolean}
					*/
					'isIOS': function () {
						return TQ.Connector.device.platform.isIOS();
					},
					/**
						Tell whether you are on Android or not
						@return {Boolean}
					*/
					'isAndroid': function () {
						return TQ.Connector.device.platform.isAndroid();
					},

					/**
						Restarts the application
					*/
					'restart': function () {
						return TQ.Connector.device.platform.restart();
					}
				},

				/**
					@class NG.tqCoreConnector.device.scan
				*/
				scan: {
					barcode: {
						'scan': function () {
							return $q.when(TQ.Connector.device.scan.barcode.scan());
						}
					},

					nfc: {
						'startListening': function () {
							return $q.when(TQ.Connector.device.scan.nfc.startListening());
						},

						'stoptListening': function () {
							return $q.when(TQ.Connector.device.scan.nfc.stoptListening());
						},

						NFC_NOT_AVAILABLE: TQ.Connector.device.scan.nfc.NFC_NOT_AVAILABLE
					}
				},

				media: {
					/**
						@class NG.tqCoreConnector.device.media.picture
					*/
					picture: {
						/**
						 	Get a picture from camera or gallery
							@params {String} Can be picture.TAKE_PICTURE or picture.PICK_PICTURE
							@return {$q.promise} Parameter is the base64 of the picture or error value
						*/
						'getPicture': function (source) {
							return $q.when(TQ.Connector.device.media.picture.getPicture(source));
						},
						/**
						 * @property {String}
						 * Error value: user cancels without selecting or taking any picture
						 */
						NO_IMAGE_SELECTED: TQ.Connector.device.media.picture.NO_IMAGE_SELECTED,
						/**
						 * @property {String}
						 * Error value: picture exides the max file size
						 */
						MAX_FILE_SIZE_EXCEEDED: TQ.Connector.device.media.picture.MAX_FILE_SIZE_EXCEEDED,
						/**
						 * @property {String}
						 * Error value: selected picture is not avaible
						 */
						PICTURE_NOT_AVAILABLE: TQ.Connector.device.media.picture.PICTURE_NOT_AVAILABLE,
						/**
						 * @property {String}
						 * Source used in {@link NG.tqCoreConnector.device.media.picture#getPicture},
						 * takes picture from camera
						 */
						TAKE_PICTURE: TQ.Connector.device.media.picture.TAKE_PICTURE,
						/**
						 * @property {String}
						 * Source used in {@link NG.tqCoreConnector.device.media.picture#getPicture},
						 * let the user choose image from gallery
						 */
						PICK_PICTURE: TQ.Connector.device.media.picture.PICK_PICTURE
					},
					video: {
						// TODO
					},
					audio: {
						// TODO
					}
				},
				/**
					@class NG.tqCoreConnector.device.file
				*/
				file: {
					/**
					 * @param record {}
					 * @param bodyFieldApiName {}
					 * @return {$q.promise} Fired when file is opened
					 */
					'openFile': function (record, bodyFieldApiName) {
						return $q.when(TQ.Connector.device.file.openFile(record, bodyFieldApiName));
					},
					/**
					 * @param record {}
					 */
					'shareRecordWithFile': function (record) {
						return $q.when(TQ.Connector.device.file.shareRecordWithFile(record));
					},
					/**
					 * Removes file from device storage
					 * @param fileURI {String}
					 */
					'removeFile': function (fileURI) {
						return $q.when(TQ.Connector.device.file.removeFile(fileURI));
					},
					/**
					 *
					 */
					OFFLINE: TQ.Connector.device.file.OFFLINE,
					LOAD_FILE_FROM_SERVER_ERROR: TQ.Connector.device.file.LOAD_FILE_FROM_SERVER_ERROR,
					ERROR_SHARING_IS_NOT_AVAILABLE: TQ.Connector.device.file.ERROR_SHARING_IS_NOT_AVAILABLE
				}
			};

			/**
				@class NG.tqCoreConnector.app
			*/
			this.app = {
				/**
					Returns the value of the requested configuration param
					@param {String} fieldName
					@return {any} Value of the requested field
				*/
				'getAppSettingsValue': function (fieldName) {
					return TQ.Connector.app.getAppSettingsValue(fieldName);
				}
			};

			/**
				@class NG.tqCoreConnector.user
			*/
			this.user = {
				/**
					Returns the id of the current user
					@return {??}
				*/
				getId: function () {
					return TQ.Connector.user.getId();
				},
				/**
					Updates the avatar image of the current user
					@param {String} imageUrl
					@return {$q.promise}
				*/
				updateUserAvatar: function (imageUrl) {
					return $q.when(TQ.Connector.user.updateUserAvatar(imageUrl));
				},
				/**
					Updates the user name
					@param {String} newUserName
					@return {$q.promise}
				*/
				updateUserNameInStorage: function (newUserName) {
					return $q.when(TQ.Connector.user.updateUserNameInStorage(newUserName));
				},
				updateUserDataWithChatterAvatar: function (user) {
					return $q.when(TQ.Connector.user.updateUserDataWithChatterAvatar(user));
				},
				/**
					Updates the user name
					@param {String} newUserName
					@return {$q.promise}
				*/
				getUserDataPromise: function () {
					return $q.when(TQ.Connector.user.getUserDataPromise());
				},
        getUserAvatarDataPromise: function(){
            return $q.when(TQ.Connector.user.getUserAvatarDataPromise());
        },
				/**
					@class NG.tqCoreConnector.user.userInfo
				*/
				userInfo: TQ.Connector.user.userInfo
			};

			this.sync = {
				'type': {
					ACTIVATION: TQ.Connector.sync.type.ACTIVATION,
					INCREMENTAL_OR_NONE: TQ.Connector.sync.type.INCREMENTAL_OR_NONE
				},
				'startSync': function () {
					return $q.when(TQ.Connector.sync.startSync());
				},
				'syncServer': function (objectApiName, flatQuery) {
					return $q.when(TQ.Connector.sync.syncServer(objectApiName, flatQuery));
				},
				'getQueue': function () {
					return $q.when(TQ.Connector.sync.getQueue());
				},
				'immediateUpload': function (tqRecordList) {
					return $q.when(TQ.Connector.sync.immediateUpload(tqRecordList));
				},
				'getLocalUrl': function (filePath) {
					return TQ.Connector.sync.getLocalUrl(filePath);
				},
				'loadFile': function (filePath) {
					return $q.when(TQ.Connector.sync.loadFile(filePath));
				},
				'onFileLoad': function (filePath, successCallback, failCallback) {
					TQ.Connector.sync.onFileLoad(filePath, successCallback, failCallback);
				},
				'offFileLoad': function (filePath, successCallback, failCallback) {
					TQ.Connector.sync.offFileLoad(filePath, successCallback, failCallback);
				},
				'getLocalIdsForServerIds': function (serverIds) {
					return TQ.Connector.sync.getLocalIdsForServerIds(serverIds);
				},
				'cancelActivation': function () {
					TQ.Connector.sync.cancelActivation();
				},
        'downloadFromServerAndCache': function(objectApiName, whereCondition){
            return $q.when(TQ.Connector.sync.downloadFromServerAndCache(objectApiName, whereCondition));
        }
			};

			/**
				@class NG.tqCoreConnector.record
			*/
			this.record = {
				/**
					Returns current error on the record
					@param {TQRecord} record
					@return {String}
				*/
				'hasError': function (record) {
					return TQ.Connector.record.hasError(record);
				},
				/**
					Returns empty record instance
					@param {String} objectApiName
					@return {TQRecord}
					v. {@link TQ.sync.TQRecord}
				*/
				'getTrackedObjectRecordInstance': function (objectApiName) {
					return TQ.Connector.sync.getTrackedObjectRecordInstance(objectApiName);
				}
			};

			this.storage = {
				/**
				*	Find record in storage using a MongoDB query style.
				*     var queryObj = {
	      *    	objectApiName : 'Account',
	      *  		where : [
				*				{'Id' : {'$eq' : 20}},
		    *        {
		    *          '$or' : [
				*						{'Status' : {'$eq' : 'Open'}},
		    *            {'CreatedAt' : {'$lt' : new Date()}}
		    *      		]
		    *        }
		    *      ],
		    *      orderby : ['CreatedAt DESC', 'LastModified'],
		    *      pagesize : 20,
		    *      page : 2
		    *    }
				*	@param {Object} query must follow MongoDB syntax
				*	@param {Boolean} [includeDeleted=false] returns locally deleted records
				*	@return {$q.promise} argument is an array of records
				*/
				'find': function (query, includeDeleted) {
					return $q.when(TQ.Connector.storage.find(query, includeDeleted));
				},
				/**
				*	Like .find but returns a single object
				*	@param {Object} query must follow MongoDB syntax
				*	@return {$q.promise} argument is the first matching record
				*/
        'findOne': function (query) {
            return $q.when(TQ.Connector.storage.findOne(query));
        },
				/**
				*	Locally update the record
				*	@param {TQRecord} record must contain updated data in rawRecord property
				*	@return {$q.promise} argument is empty
				*/
				'upsert': function (record) {
					return $q.when(TQ.Connector.storage.upsert(record));
				},
				/**
				*	Locally delete the record
				*	@param {TQRecord} record
				*	@return {$q.promise} argument is empty
				*/
				'remove': function (record) {
					return $q.when(TQ.Connector.storage.remove(record));
				},
				/**
				*	@deprecated
				*/
				'count': function () {
				},
				/**
				*	Helper to find a specific record from its id
				*	@param {String} objectName
				*	@param {String} id
				*	@param {Boolean} [includeDeleted=false] returns locally deleted records
				*	@return {TQRecord}
				*	v. {@link TQ.sync.TQRecord}
				*/
				'findRecordById': function (objectName, id, includeDeleted) {
					return $q.when(TQ.Connector.storage.find({
						objectApiName: objectName,
						where: {Id: {'$eq': id}}
					}, (typeof includeDeleted == 'undefined') ? true : includeDeleted));
				},
				/**
				*	Reset all local changes including deleting actions
				*	@param {TQRecord} record
				*	@return {TQRecord} original record
				*	v. {@link TQ.sync.TQRecord}
				*/
				'resetLocalChanges': function (record) {
					return $q.when(TQ.Connector.storage.resetLocalChanges(record));
				},
				/**
				*	Locally validate record using metadata
				*	@param {TQRecord} record
				*	@return {Array} errorList list of errors, empty if no error is found
				*/
				'validateRecord': function (record) {
					return TQ.Connector.storage.validateRecord(record);
				},
				'generateParentRecordMap': function (record) {
					return TQ.Connector.storage.generateParentRecordMap(record);
				},
				/**
				*	Returns true if stores locally exists
				*	@param {String} objectApiName
				*	@return {Boolean}
				*/
				'storeExist': function (storeName) {
					return TQ.Connector.storage.storeExist(storeName);
				},
				/**
				* Adds an upsert into a queue of upsert actions to be done on the server sequentially
				*
				* Allows to threat separate changes to a record as separate upserts instead of a single one,
				* so that the change flow on the client can be recreated on the server when inserting the record
				*
				* Use instead of the upsert when you want to treat each change to a record as a separate commit
				* so the change flow on the client can be recreated when inserting records on the server
				* Ex. in the case of business process with a rule like
				* 'you can insert attachments (children) of an Opportunity (parent), only when stage has moved to CLOSE'
				* you will first commit (instead of upsert) the stage change to 'New' and then the state change to 'CLOSE',
				* only after the two attachment records have been upserted
				*	@param {TQRecord} record
				*	@return {$q.promise}
				*/
				commitChangesForRecord: function (record) {
					return $q.when(TQ.Connector.storage.commitChangesForRecord(record));
				},
				
				createIndex: function (indexName, objectApiName, fieldsArray, isUnique) {
					return $q.when(TQ.Connector.storage.createIndex(indexName, objectApiName,
						fieldsArray, isUnique));
				}
			};

			this.appstatus = {

				'PERFORM_LOGOUT': TQ.Connector.appstatus.PERFORM_LOGOUT,

				'isActivated': function () {
					return TQ.Connector.appstatus.isActivated();
				},
				'getErrorStatus': function () {
					return TQ.Connector.appstatus.getErrorStatus();
				},
				'getIsOfflineForced': function () {
					return TQ.Connector.appstatus.getIsOfflineForced();
				},
				'toggleForceOffline': function () {
					return TQ.Connector.appstatus.toggleForceOffline();
				},
				'isOnline': function () {
					return TQ.Connector.appstatus.isOnline();
				},
				'connectionStatusChanged': function (eventHandlingMethod) {
					return TQ.Connector.appstatus.connectionStatusChanged(eventHandlingMethod);
				}
			};

			this.syncstatus = {
				SYNC_ERROR: TQ.Connector.syncstatus.SYNC_ERROR,
				SYNCHRONIZED: TQ.Connector.syncstatus.SYNCHRONIZED,
				SYNCHRONIZING: TQ.Connector.syncstatus.SYNCHRONIZING,
				AWAITING_SYNCHRONIZATION: TQ.Connector.syncstatus.AWAITING_SYNCHRONIZATION,

				'isSyncing': function () {
					return TQ.Connector.syncstatus.isSyncing();
				},
				'getSyncErrorMessage': function () {
					return TQ.Connector.syncstatus.getSyncErrorMessage();
				},
				'getSyncStatus': function () {
					return TQ.Connector.syncstatus.getSyncStatus();
				},
				'getRecordErrorCount': function () {
					return TQ.Connector.syncstatus.getRecordErrorCount();
				},
				'getPendingRecordCount': function () {
					return TQ.Connector.syncstatus.getPendingRecordCount();
				},
				'onSyncStatusChange': function (handleMethod) {
					return TQ.Connector.syncstatus.onSyncStatusChange(handleMethod);
				},
				'offSyncStatusChange': function (handleMethod) {
					return TQ.Connector.syncstatus.offSyncStatusChange(handleMethod);
				}
			};

			this.logger = {

				log: function (entry) {
					return TQ.Connector.logger.log(entry);
				},
				info: function (entry) {
					return TQ.Connector.logger.info(entry);
				},
				warn: function (entry) {
					return TQ.Connector.logger.warn(entry);
				},
				error: function (entry) {
					return TQ.Connector.logger.error(entry);
				},
				getLoggedErrorsQueue: function () {
					return TQ.Connector.logger.getLoggedErrorsQueue();
				}
			};

			this.metadata = {
				'getTrackedObjectHeaderFieldSet': function (objectApiName) {
					return TQ.Connector.metadata.getTrackedObjectHeaderFieldSet(objectApiName);
				},
				'getTrackedObjectFieldSet': function (objectApiName, fieldSetApiName) {
					return TQ.Connector.metadata.getTrackedObjectFieldSet(objectApiName, fieldSetApiName);
				},
				'getFieldMetadata': function (objectApiName, fieldApiName) {
					return TQ.Connector.metadata.getFieldMetadata(objectApiName, fieldApiName);
				},
				'getFieldLabel': function (objectApiName, fieldApiName) {
					return TQ.Connector.metadata.getFieldLabel(objectApiName, fieldApiName);
				},
				'getFieldApiNameLabelsMap': function (record, objectApiName) {
					return TQ.Connector.metadata.getFieldApiNameLabelsMap(record, objectApiName);
				},
				'getTrackedObjectMetadata': function (objectApiName) {
					return TQ.Connector.metadata.getTrackedObjectMetadata(objectApiName);
				},
				// shortcut - second parameter is to get the plural (related-list)
				'getTrackedObjectLabel': function (objectApiName, plural) {
					if (!plural) {
						return TQ.Connector.metadata.getTrackedObjectMetadata(objectApiName).modelDescribe.label;
					} else {
						return TQ.Connector.metadata.getTrackedObjectMetadata(objectApiName).modelDescribe.labelPlural;
					}
				},
				'getNameField': function (objectApiName) {
					return TQ.Connector.metadata.getNameField(objectApiName);
				},
				'getActivePicklistValues': function (objectApiName, fieldApiName) {
					return TQ.Connector.metadata.getActivePicklistValues(objectApiName, fieldApiName);
				},
				'getTrackedObjectRequiredFieldsMap': function (objectApiName) {
					return TQ.Connector.metadata.getTrackedObjectRequiredFieldsMap(objectApiName);
				},
				'isUpdatable': function (objectApiName, fieldApiName) {
					return TQ.Connector.metadata.isUpdatable(objectApiName, fieldApiName);
				},
				'isCreatable': function (objectApiName, fieldApiName) {
					return TQ.Connector.metadata.isCreatable(objectApiName, fieldApiName);
				},
				'isDisplayable': function (objectApiName, fieldApiName) {
					return TQ.Connector.metadata.isDisplayable(objectApiName, fieldApiName);
				},
				'isTrackedObjectCreatable': function (objectApiName) {
					return TQ.Connector.metadata.isTrackedObjectCreatable(objectApiName);
				},
				'isTrackedObjectEditable': function (objectApiName) {
					return TQ.Connector.metadata.isTrackedObjectEditable(objectApiName);
				},
				'isTrackedObjectDeletable': function (objectApiName) {
					return TQ.Connector.metadata.isTrackedObjectDeletable(objectApiName);
				},
				'isTrackedObjectDisplayable': function (objectApiName) {
					return TQ.Connector.metadata.isTrackedObjectDisplayable(objectApiName);
				},
				'getRecordTypeId': function (objectApiName, recordTypeApiName) {
					return TQ.Connector.metadata.getRecordTypeId(objectApiName, recordTypeApiName);
				},
                'getRecordTypePicklistValues': function (objectApiName, recordTypeApiName){
                    return TQ.Connector.metadata.getRecordTypePicklistValues(objectApiName, recordTypeApiName);
                },
                'getFieldsetLayout': function(objectApiName, fieldsetApiName, recordTypeApiName){
                    return $q.when(
                        TQ.Connector.metadata.getFieldsetLayout(objectApiName, fieldsetApiName, recordTypeApiName)
                    );
                }
			};

            this.rest = {
                'apexrest' : function(path, method, payload, paramMap, retry){
                    return $q.when(TQ.Connector.rest.apexrest(path, method, payload, paramMap, retry));
                },
                'get' : function(path, options){
                    return $q.when(TQ.Connector.rest.apexrest(path, 'GET', null, options));
                },
                'post' : function(path, body, options){
                    return $q.when(TQ.Connector.rest.apexrest(path, 'POST', JSON.stringify(body), options));
                },
                'put' : function(path, body, options){
                    return $q.when(TQ.Connector.rest.apexrest(path, 'PUT', JSON.stringify(body), options));
                },
                'patch' : function(path, body, options){
                    return $q.when(TQ.Connector.rest.apexrest(path, 'PATCH', JSON.stringify(body), options));
                }
            };

			this.session = {
				'logout': function () {
					return $q.when(TQ.Connector.session.logout());
				},
				'refreshAuth': function () {
					TQ.Connector.session.refreshAuth();
				},
				isAuthenticated: function () {
					return TQ.Connector.session.isAuthenticated();
				},
				login: function (env) {
					return $q.when(TQ.Connector.session.login(env));
				},
				getSelectedEnvironment: function () {
					return TQ.Connector.session.getSelectedEnvironment();
				},
				getEnvironmentsList: function () {
					return TQ.Connector.session.getEnvironmentsList();
				},
                getCurrentEnvironmentOption: function(env) {
                    return TQ.Connector.session.getCurrentEnvironmentOption(env);
                }
			};

			this.config = {
				getEnableAnimations: function () {
					return TQ.Connector.config.core.getEnableAnimations();
				},
                isOnlineOnlyEnabled: function(){
                    return TQ.Connector.config.core.isOnlineOnlyEnabled();
                }
			};

			this.utils = {
				connectivity: {
					isTimeoutError: function (error) {
						return TQ.Connector.utils.connectivity.isTimeoutError(error);
					},
					isOfflineError: function (error) {
						return TQ.Connector.utils.connectivity.isOfflineError(error);
					}
				},
				getFilenameFromUrl: function (url) { return TQ.Connector.utils.getFilenameFromUrl(url); },
                isResponseSuccessful: function(response) { return TQ.Connector.utils.isResponseSuccessful(response); },
                getResponseErrorList: function(response) { return TQ.Connector.utils.getResponseErrorList(response); }
			};

			this.chatter = {
				FeedType: TQ.Connector.chatter.FeedType,

				downloadChatterFeedUpdates: function (feedType, feedObjectId, ignoreToken) {
					return $q.when(TQ.Connector.chatter.downloadChatterFeedUpdates(feedType, feedObjectId, ignoreToken));
				},
				syncChatterFeedUpdates: function (feedType, feedObjectId) {
					return $q.when(TQ.Connector.chatter.syncChatterFeedUpdates(feedType, feedObjectId));
				},
				downloadFeedItemComments: function (feedItemId) {
					return $q.when(TQ.Connector.chatter.downloadFeedItemComments(feedItemId));
				},
                getFollowersList: function (feedObjectId){
                    return $q.when(TQ.Connector.chatter.getFollowersList(feedObjectId));
                },
				startFeedObserving: function (feedType, feedObjectId, jobParameters, startCallback, successCallback, failCallback) {
					return TQ.Connector.chatter.startFeedObserving(feedType, feedObjectId, jobParameters,
						startCallback, successCallback, failCallback);
				},
				startFeedCommentsObserving: function (feedItemId, jobParameters, startCallback, successCallback, failCallback) {
					return TQ.Connector.chatter.startFeedCommentsObserving(feedItemId, jobParameters,
						startCallback, successCallback, failCallback);
				},
				startFollowersObserving: function (feedObjectId, jobParameters, startCallback, successCallback, failCallback) {
					return TQ.Connector.chatter.startFollowersObserving(feedObjectId, jobParameters,
						startCallback, successCallback, failCallback);
				},
                startConversationObserving: function (conversationId, jobParameters, startCallback, successCallback, failCallback) {
                    return TQ.Connector.chatter.startConversationObserving(conversationId, jobParameters,
                        startCallback, successCallback, failCallback);
                },
				newFeedItemInstance: function (ParentRecordId) {
					return TQ.Connector.chatter.newFeedItemInstance(ParentRecordId);
				},
				newFeedCommentInstance: function (feedItemId) {
					return TQ.Connector.chatter.newFeedCommentInstance(feedItemId);
				},
				createFeedItemForRecordFeed: function (recordId, postText, postAttachemntLink, postAttachmentFileName, additionFields) {
					return $q.when(TQ.Connector.chatter.createFeedItemForRecordFeed(recordId, postText,
						postAttachemntLink, postAttachmentFileName, additionFields));
				},
				createTextFeedCommentForFeedItem: function (feedItemId, commentText, feedItem) {
					return $q.when(TQ.Connector.chatter.createTextFeedCommentForFeedItem(feedItemId, commentText, feedItem));
				},
                sendPrivateMessage: function(messageText, recepients, conversationId){
                    return $q.when(TQ.Connector.chatter.sendPrivateMessage(messageText, recepients, conversationId));
                },
				likeFeedEntity: function (feedEntity, isFeedItem) {
					return $q.when(TQ.Connector.chatter.likeFeedEntity(feedEntity, isFeedItem));
				},
				dislikeFeedEntity: function (feedEntity, isFeedItem) {
					return $q.when(TQ.Connector.chatter.dislikeFeedEntity(feedEntity, isFeedItem));
				},
				removeFeedItem: function (feedItem) {
					return $q.when(TQ.Connector.chatter.removeFeedItem(feedItem));
				},
				removeFeedComment: function (feedComment) {
					return $q.when(TQ.Connector.chatter.removeFeedComment(feedComment));
				},
                getChatterFeedPage: function (feedType, feedObjectId, page, pageSize, pageUrl){
                    return $q.when(
                        TQ.Connector.chatter.getChatterFeedPage(feedType, feedObjectId, page, pageSize, pageUrl)
                    );
                },
                getConversationPage: function (conversationData, pageSize, startingDate, userId){
                    return $q.when(
                        TQ.Connector.chatter.getConversationPage(conversationData, pageSize, startingDate, userId)
                    );
                },
                getFeedItemsByIds: function(feedItemIdList){
                    return $q.when(TQ.Connector.chatter.getFeedItemsByIds(feedItemIdList));
                }
			};

			this.schedule = {
				'JOB_EXECUTION_DELAYED': TQ.Connector.schedule.JOB_EXECUTION_DELAYED,
				'executeTaskImmediately': function (jobId) {
					var taskPromise = TQ.Connector.schedule.executeTaskImmediately(jobId);
					if (taskPromise) {
						taskPromise = $q.when(taskPromise);
					}
					return taskPromise;
				},
				'getExecutingTaskDeferred': function (jobId) {
					return $q.when(TQ.Connector.schedule.getExecutingTaskDeferred(jobId));
				},
				'onJobStart': function (jobId, handleMethod) {
					return TQ.Connector.schedule.onJobStart(jobId, handleMethod);
				},
				'onJobSuccess': function (jobId, handleMethod) {
					return TQ.Connector.schedule.onJobSuccess(jobId, handleMethod);
				},
				'onJobFail': function (jobId, handleMethod) {
					return TQ.Connector.schedule.onJobFail(jobId, handleMethod);
				},
				'offJobStart': function (jobId, handleMethod) {
					return TQ.Connector.schedule.offJobStart(jobId, handleMethod);
				},
				'offJobSuccess': function (jobId, handleMethod) {
					return TQ.Connector.schedule.offJobSuccess(jobId, handleMethod);
				},
				'offJobFail': function (jobId, handleMethod) {
					return TQ.Connector.schedule.offJobFail(jobId, handleMethod);
				}
			};

			this.getTrackedObjectsList = function () {
				var def = $q.defer();
				var defList = [];
				var that = this;

				var trackedObjectList = TQ.Connector.metadata.getTrackedObjectList();

				_.each(trackedObjectList, function (trackObject) {
					defList.push($q.when(TQ.Connector.storage.count(trackObject)));
				});

				$q.all(defList).then(function (countList) {
					var result = [];

					for (var i = 0; i < trackedObjectList.length; i++) {
						result.push({
							name: trackedObjectList[i],
							label: that.metadata.getTrackedObjectLabel(trackedObjectList[i]),
							count: countList[i]
						});
					}
					def.resolve(result);
				});

				return def.promise;

			};

		});
});
