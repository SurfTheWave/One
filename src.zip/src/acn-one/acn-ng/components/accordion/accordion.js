define(['angular',
	'coreapi'], function (angular) {

	return angular.module('tq.accordion', [
		'tq.coreapi'])

		.directive('tqAccordion', function ($timeout) {
			return {
				restrict: 'AE',
				controller: function ($scope, $interval, $ionicScrollDelegate) {
					var activeItem = null;

					$scope.isToggled = function (item) {
						return item == activeItem ? true : false;
					};

					$scope.toggleItemBody = function (item, scrollDelegate) {
						if (item == activeItem) {
							activeItem = null;
						} else {
							activeItem = item;
						}

						// 6 fps resize!
						$interval(function () {
							$ionicScrollDelegate.$getByHandle(scrollDelegate).resize();
						}, 10, 60);

					};
				}
			};
		});
});